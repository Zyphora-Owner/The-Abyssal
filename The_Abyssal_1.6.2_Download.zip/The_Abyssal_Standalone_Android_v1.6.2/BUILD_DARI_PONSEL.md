# Build APK The Abyssal 1.6.2 dari HP

## Sebelum memasang

1. Ekspor Backup JSON dari versi lama dan simpan di folder Downloads.
2. Pertahankan `native/abyssal-debug-signing.bin` yang ada di ZIP; signing key yang sama diperlukan agar APK debug dapat memperbarui pemasangan lama.
3. Unduh ZIP `The_Abyssal_Standalone_Android_v1.6.2.zip`.

## Build melalui GitHub Actions

1. Ekstrak ZIP.
2. Unggah **isi folder proyek** ke root repository GitHub. Sertakan folder tersembunyi `.github/workflows`, folder `scripts`, `supabase`, `native`, dan seluruh folder ikon.
3. Hapus ZIP proyek versi lama dari root repository, sehingga workflow tidak menemukan beberapa ZIP sekaligus.
4. Commit dan push ke `main` atau `master`, atau jalankan workflow manual.
5. Buka **Actions → Build The Abyssal Native Android APK**.
6. Setelah job sukses, unduh artifact `the-abyssal-android-apk-1.6.2`, ekstrak, lalu pasang `app-debug.apk`.

APK harus ditandatangani dengan key yang sama seperti versi lama agar Android menerima pembaruan tanpa uninstall. Jangan uninstall versi lama sebelum backup save diamankan.

## Perbaikan 1.6.2

- Launcher icon Android sekarang dipasang langsung ke resource mipmap lama dan adaptive icon Android 8+, bukan hanya mengubah ikon PWA.
- Tombol Back Android menutup panel sesuai urutan, membuka Pause saat bermain, dan meminta konfirmasi saat di menu utama.
- Saat aplikasi masuk background, input gerak direset dan sesi permainan dijeda agar karakter tidak terus bergerak.
- Panel backend menguji endpoint Auth Supabase dan memberikan pesan yang lebih jelas bila URL/key salah atau server tidak terjangkau.
- Room mencoba memulihkan keanggotaan server setelah koneksi/perangkat kembali aktif.
- Migrasi SQL tambahan memperbaiki perpindahan pemilik room jika anggota lama sudah dibersihkan.

## Pembaruan backend Supabase

Jika kamu sudah menjalankan `202611060001_multiplayer.sql` pada versi 1.6.1, jalankan **hanya** `202611060002_room_recovery.sql` satu kali pada SQL Editor. Untuk proyek baru, jalankan migrasi 0001 lalu 0002 secara berurutan.

Di Authentication → Providers → Email, aktifkan Email dan izinkan sign-ups. Bila konfirmasi email aktif, verifikasi email terlebih dahulu sebelum Login.

## Uji setelah pemasangan

- Layar awal masuk ke menu utama tanpa error renderer.
- Uji orientasi landscape, sentuhan, joystick, kamera, HUD, inventory, hotbar, PDA, fauna, habitat, Fabricator, dan save lokal.
- Uji tombol Back Android pada panel, saat bermain, dan di menu utama.
- Uji launcher icon pada daftar aplikasi Android.
- Uji backend: Simpan & Hubungkan, Register, konfirmasi email (bila aktif), Login, Logout.
- Uji multiplayer dengan dua akun dan dua perangkat: Create Room, Join Room, avatar, chat, dan reconnect setelah jaringan terputus.

## Catatan verifikasi

`npm test` menjalankan pemeriksaan source, DOM, aset lokal, migrasi save v11, konfigurasi Supabase, migrasi SQL, ikon Android, dan packaging. Pengujian source bukan pengganti kompilasi APK, koneksi ke proyek Supabase nyata, atau uji dua perangkat. Build APK tetap harus berhasil di GitHub Actions dan diuji pada Android sebelum dirilis.
