# THE ABYSSAL 1.6.2 — Android Standalone

The Abyssal adalah game survival dan eksplorasi bawah laut 3D orisinal dengan mode single-player offline serta co-op online opsional. Cerita, fauna, bioma, identitas visual, dan aset orisinal dipertahankan. Game mengambil inspirasi dari genre survival bawah laut, bukan memakai kode atau aset resmi game lain.

## Perubahan 1.6.2 — reliabilitas aplikasi dan ikon baru

- Mengganti ikon aplikasi dengan ilustrasi leviathan laut dalam bergaya horror sci-fi.
- Memasang ikon Android secara native untuk mipmap densities dan adaptive icon Android 8+, selain ikon PWA.
- Menambahkan navigasi tombol Back native Android: panel kembali sesuai urutan, sesi dijeda ketika diperlukan, dan keluar dari aplikasi di menu utama meminta konfirmasi.
- Menjeda sesi saat aplikasi masuk background serta mereset input sentuh agar karakter tidak bergerak tanpa kendali.
- Memvalidasi koneksi backend melalui Auth settings endpoint Supabase menggunakan header `apikey`.
- Memberi status berbeda untuk konfigurasi tersimpan, server tidak terjangkau, pendaftaran dimatikan, dan provider Email tidak aktif.
- Memperbaiki pemulihan keanggotaan room setelah aplikasi tidur/putus koneksi lebih dari batas heartbeat.
- Menambahkan migrasi SQL 0002 untuk memperbaiki pemilik room ketika anggota lama dibersihkan.
- Save schema v11, lima slot, dunia offline, dan seluruh sistem survival versi sebelumnya tetap dipertahankan.

## Menyiapkan akun dan multiplayer

Login/Register dan online room memerlukan proyek Supabase milik pengelola. Baca [SUPABASE_SETUP_ID.md](./SUPABASE_SETUP_ID.md).

- Migrasi pertama: `supabase/migrations/202611060001_multiplayer.sql`.
- Migrasi perbaikan room: `supabase/migrations/202611060002_room_recovery.sql`.
- Project URL dan Publishable Key dimasukkan melalui panel Account / Multiplayer dalam game. Konfigurasi tidak membutuhkan build APK ulang.
- Jangan gunakan `sb_secret_...` atau `service_role` di aplikasi.
- Email Auth harus diaktifkan. Jika email confirmation aktif, verifikasi email sebelum Login.
- Setiap perangkat memakai Project URL/key yang sama dan akun berbeda.

## Multiplayer yang benar-benar tersedia

Versi 1.6.2 menyediakan registrasi/login email/password, sesi akun, ruang privat, kode undangan enam karakter, kapasitas empat pemain, daftar anggota online, avatar/posisi/arah, radio chat, heartbeat, serta pemulihan keanggotaan saat reconnect.

Ini belum menjadi shared-world server-authoritative penuh. Inventory, item yang dikumpulkan, fauna dan AI, health/oxygen, misi, bangunan habitat, kendaraan, dan save belum disinkronkan. Progress permainan tetap lokal pada tiap perangkat.

## Sistem permainan yang dipertahankan

- Dunia 3D prosedural deterministik, enam bioma, fauna, resource, supply cache, wreck, misi, radio, dan cutscene pembuka.
- Backpack 48 sel dengan ukuran footprint berbeda, lima Quick Slots, dan PDA di dalam Backpack.
- Survival: oksigen, HP, Food, Water, tangki O₂, fins, dan rebreather.
- Lifepod, interior habitat, Fabricator empat kategori, suplai oksigen di dalam habitat, serta Habitat Builder.
- Seaglide, baterai, Repair Tool, dan perbaikan konsol Lifepod.
- Lima slot save lokal dan Backup/Restore JSON. Save schema v11 dipertahankan.
- Single-player offline tetap dapat dimainkan tanpa akun.

## Build Android

1. Ekstrak ZIP dan unggah isi folder proyek ke root repository.
2. Sertakan `.github/workflows/android-apk.yml`, `scripts/`, `native/`, `supabase/`, `icons/`, `package.json`, dan `capacitor.config.json`.
3. Pastikan hanya satu ZIP proyek The Abyssal yang ada di root repository (atau unggah file proyek langsung).
4. Jalankan workflow **Build The Abyssal Native Android APK**.
5. Unduh artifact `the-abyssal-android-apk-1.6.2` setelah job sukses.

Application ID tetap `com.abyssal.game`. Pertahankan signing key yang sama untuk memperbarui instalasi lama. Ekspor backup save sebelum memasang APK baru.

## Verifikasi dan batasan

- `npm test` memeriksa syntax, DOM, aset, migrasi save, konfigurasi Supabase, SQL migration, fitur room/reconnect, serta Android launcher icon resources.
- Proyek Supabase milik pengguna, email verification sebenarnya, koneksi dua perangkat, kompilasi Gradle, dan GPU Android belum dapat diuji dari lingkungan ZIP ini.
- Jangan menyebut APK siap sebelum GitHub Actions selesai dan uji pemasangan nyata di perangkat Android berhasil.
