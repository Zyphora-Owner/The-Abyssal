# Mengaktifkan Akun dan Multiplayer The Abyssal 1.6.2

Panduan ini untuk pengelola backend. APK tidak membuat server Supabase sendiri. Setelah backend disiapkan, setiap perangkat cukup memasukkan Project URL dan Publishable Key di dalam game.

## A. Jika Supabase sudah dibuat untuk versi 1.6.1

Karena migrasi pertama sudah kamu jalankan, **jangan jalankan ulang migrasi pertama**. Cukup:

1. Buka Supabase Dashboard → SQL Editor.
2. Buka file `supabase/migrations/202611060002_room_recovery.sql` dari ZIP versi 1.6.2.
3. Salin seluruh isi file, tempel sebagai New Query, lalu tekan RUN.
4. Pastikan hasilnya sukses tanpa error.

Migrasi kedua ini memperbaiki pemulihan anggota yang lama terputus dan pemindahan kepemilikan room ketika pemilik sebelumnya sudah tidak aktif. Migrasi ini tidak menghapus akun atau save lokal.

## B. Jika membuat proyek Supabase baru

Jalankan kedua file SQL secara berurutan:

1. `supabase/migrations/202611060001_multiplayer.sql`
2. `supabase/migrations/202611060002_room_recovery.sql`

Jalankan masing-masing satu kali di SQL Editor. Pastikan kedua query selesai tanpa error.

## C. Periksa pengaturan Supabase Auth

Di Supabase Dashboard:

1. Buka **Authentication → Providers → Email**.
2. Pastikan provider Email aktif.
3. Pastikan **Allow new users to sign up / Enable sign ups** aktif agar tombol Register dapat digunakan.
4. Bila konfirmasi email aktif, pastikan alamat email yang kamu gunakan benar-benar bisa menerima email.
5. Buka **Authentication → URL Configuration**. Atur Site URL ke alamat web The Abyssal yang benar-benar sudah dipublikasikan. Tambahkan alamat itu ke Redirect URLs jika dibutuhkan oleh konfigurasi email.

Jangan menonaktifkan verifikasi email hanya untuk melewati error. Bila email confirmation aktif, selesaikan tautan verifikasi dahulu sebelum Login.

## D. Ambil dua nilai publik

1. Buka **Project Settings → API Keys** atau dialog **Connect**.
2. Salin **Project URL**.
3. Salin **Publishable Key** (`sb_publishable_...`). Legacy `anon` key juga diterima.
4. Jangan pernah mengambil atau memasukkan `sb_secret_...`, `service_role`, password database, atau access token.

Publishable key memang dirancang untuk dipakai aplikasi klien. Keamanan data tetap harus ditegakkan dengan RLS dan otorisasi server. Dokumentasi resmi: [Supabase API Keys](https://supabase.com/docs/guides/getting-started/api-keys).

## E. Hubungkan di aplikasi

Lakukan pada setiap perangkat:

1. Buka The Abyssal → **ACCOUNT / MULTIPLAYER**.
2. Buka **HUBUNGKAN BACKEND AKUN & MULTIPLAYER**.
3. Tempel Project URL dan Publishable Key.
4. Tekan **SIMPAN & HUBUNGKAN**.
5. Aplikasi sekarang menguji `GET /auth/v1/settings` memakai header `apikey`. Jika berhasil, status menampilkan server terhubung. Endpoint ini mengembalikan pengaturan Auth publik; lihat [Supabase Auth settings endpoint](https://supabase.github.io/auth/).

Jika status berkata konfigurasi tersimpan tetapi server belum terjangkau, konfigurasi tetap disimpan. Periksa internet, URL dan key dari proyek yang sama, lalu tekan **SIMPAN & HUBUNGKAN** lagi.

Jika Register dinonaktifkan, buka Authentication → Providers → Email dan aktifkan sign-ups. Jika Login gagal, baca pesan yang muncul di dalam game; jangan langsung membuat akun kedua.

## F. Register dan Login

1. Pilih **Register**.
2. Isi nama penyelam, email aktif, dan password minimal 8 karakter.
3. Jika game memberi pesan verifikasi, buka email dari Supabase dan tekan tautan konfirmasi.
4. Kembali ke aplikasi The Abyssal dan pilih **Login**.
5. Masukkan email dan password yang sama.

Jika pendaftaran sukses tetapi sesi belum ada, itu normal saat konfirmasi email diaktifkan. Login baru dapat dilakukan setelah email dikonfirmasi. Rujukan: [Supabase Password-based Auth](https://supabase.com/docs/guides/auth/passwords).

## G. Uji ruang multiplayer

Gunakan dua perangkat dan dua akun berbeda:

1. Perangkat pertama Login → Create Room.
2. Bagikan kode undangan enam karakter.
3. Perangkat kedua Login → Join Room → masukkan kode.
4. Kedua pemain masuk ke sesi game. Avatar akan muncul setelah perangkat mengirim pembaruan posisi.
5. Uji radio chat dan putus-sambung koneksi.

Maksimal empat penyelam dalam satu room. Kedua perangkat harus memakai Project URL dan Publishable Key yang sama.

## Batas multiplayer saat ini

Versi 1.6.2 mendukung autentikasi email/password, sesi akun, room privat berkode, Presence, posisi/arah avatar, chat, dan pemulihan keanggotaan setelah perangkat lama terputus. Ini **belum shared-world penuh**: inventory, item yang dipungut, fauna/AI, health/oxygen, misi, bangunan, kendaraan, dan save masih lokal per perangkat.

Jangan bagikan password, secret key, service-role key, atau token akun di chat maupun repository publik.
