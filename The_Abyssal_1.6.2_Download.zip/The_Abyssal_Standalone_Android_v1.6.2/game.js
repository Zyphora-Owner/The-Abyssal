import * as THREE from 'three';
import { FaunaDirector, FAUNA_SPECIES_COUNT } from './fauna.js';
import { normalizeGameSettings, normalizeSaveRecord, normalizeBackupPayload } from './save-schema.mjs';
import { hash2, valueNoise } from './world-generation.mjs';
import { online } from './multiplayer.js';

const $ = (id) => document.getElementById(id);
const canvas = $('world-canvas');
const UI = {
  boot: $('boot-screen'), main: $('main-menu'), newGame: $('new-game-screen'), load: $('load-screen'),
  settings: $('settings-screen'), multiplayer: $('multiplayer-screen'), inventory: $('inventory-screen'), build: $('build-screen'), fabricator: $('fabricator-screen'), storage: $('storage-screen'), pda: $('pda-screen'), hud: $('hud'), pause: $('pause-screen'), exit: $('exit-screen')
};
const STORAGE = { slots: 'the-abyssal-slots-v1', settings: 'the-abyssal-settings-v1' };
const CHUNK_SIZE = 64;
const SURVIVAL_DEFAULTS = { hp: 100, oxygen: 45, food: 100, water: 100, medkits: 2, rations: 3, waterBottles: 2 };
const SURVIVAL_STORAGE_VERSION = 5;
const INVENTORY_DEFAULTS = { titanium: 0, copper: 0, quartz: 0, kelp: 0, coral: 0, lithium: 0, sulfur: 0, magnetite: 0, salt: 0, glowcap: 0, fish_meat: 0, glass: 0, silicone: 0, fiber_mesh: 0, battery: 0, wiring_kit: 0, computer_chip: 0, silver: 0, power_cell: 0, lubricant: 0, bleach: 0 };
const RESOURCE_LABELS = { titanium: 'Titanium', copper: 'Copper Ore', quartz: 'Quartz', kelp: 'Creepvine', coral: 'Coral Sample', lithium: 'Lithium', sulfur: 'Sulfur Crystal', magnetite: 'Magnetite', salt: 'Salt Deposit', glowcap: 'Glowcap Mushroom', fish_meat: 'Fresh Fish', glass: 'Glass', silicone: 'Silicone Rubber', fiber_mesh: 'Fiber Mesh', battery:'Battery', wiring_kit:'Wiring Kit', computer_chip:'Computer Chip', silver:'Silver Ore', power_cell:'Power Cell', lubricant:'Lubricant', bleach:'Bleach' };
const EQUIPMENT_DEFAULTS = { tankLevel: 0, fins: false, rebreather: false, seaglideCharge: 0 };
const MISSION_SEQUENCE = [
  { id:'lifepod', title:'Repair the Lifepod', objective:'Collect Titanium, Creepvine, Copper Ore, and Quartz. Fabricate a Repair Tool in the Lifepod, equip it, then repair the control console.', done:'Lifepod console repaired. Emergency beacon and onboard systems are online.' },
  { id:'scan', title:'Read the Living Ocean', objective:'Scan one nearby life-form with the Explorer PDA.', done:'Life-form data stored. Your scanner can identify local fauna.' },
  { id:'materials', title:'Gather Survival Materials', objective:'Collect 3 resource drops from the seafloor.', target:3, done:'Basic resources secured. A fabricator can turn them into useful supplies.' },
  { id:'fish', title:'Secure Fresh Food', objective:'Catch one small fish for the Fabricator.', done:'Food sample secured. Avoid large predators and keep your distance.' },
  { id:'craft', title:'Prepare a Medical Kit', objective:'Craft a Medkit in your inventory.', done:'Medical supplies ready. Keep monitoring HP and oxygen.' },
  { id:'build', title:'Build a Habitat', objective:'Use the Habitat Builder to place a Multipurpose Room.', done:'Your first habitat is operational. Add a Solar Panel to power its systems.' },
  { id:'wreck', title:'Investigate the Wreck Signal', objective:'Approach the abandoned vessel in Wreckfall Shelf.', done:'Wreck signal located. New expedition data is available.' },
  { id:'freeplay', title:'Explore the Deep Frontier', objective:'Expedition objectives complete. Explore, build, scan, and survive.', done:'All initial directives completed.' }
];
const STORY_DEFAULTS = { introSeen:false, missionIndex:0, counters:{ materials:0 }, completed:[] };

const BIOME_DATA = {
  reef: { id:'reef', label:'Luminous Reef', terrain:0x4e9c91, fog:0x176a78, density:0.0019, temperature:27, note:'Terumbu dangkal dengan karang bercahaya dan ikan kecil.' },
  kelp: { id:'kelp', label:'Sapphire Kelp Forest', terrain:0x3e806d, fog:0x145c63, density:0.00205, temperature:23, note:'Hutan rumput laut tinggi menjadi tempat berlindung fauna.' },
  wreck: { id:'wreck', label:'Wreckfall Shelf', terrain:0x6e7778, fog:0x244957, density:0.00225, temperature:19, note:'Puing kapal dan serpihan logam tersebar di dasar.' },
  thermal: { id:'thermal', label:'Ember Vent Fields', terrain:0x8b6559, fog:0x493e4b, density:0.00245, temperature:38, note:'Retakan panas bumi memancarkan gelembung dan mineral langka.' },
  abyss: { id:'abyss', label:'The Hadal Reach', terrain:0x334d72, fog:0x101c3c, density:0.0030, temperature:8, note:'Zona gelap bertekanan tinggi. Fauna raksasa jarang terlihat.' },
  open: { id:'open', label:'Pelagic Expanse', terrain:0x397d91, fog:0x0d465e, density:0.0018, temperature:25, note:'Laut terbuka dengan migrasi paus dan predator pelagis.' }
};
const BIOME_CENTERS = { kelp:[[-190,-105],[220,115],[430,-320]], thermal:[[275,-205],[-290,260],[430,380]] };
const BUILD_RECIPES = {
  beacon: { label: 'Beacon', cost: { copper: 1, quartz: 1 } },
  foundation: { label: 'Foundation', cost: { titanium: 2 } },
  compartment: { label: 'Multipurpose Room', cost: { titanium: 6, quartz: 2 } },
  storage_locker: { label: 'Wall Locker', cost: { titanium: 2, copper: 1 } },
  solar_array: { label: 'Solar Panel', cost: { titanium: 2, copper: 2, quartz: 1 } }
};
const EQUIPMENT_RECIPES = {
  tank: { label:'Standard O₂ Tank Upgrade', cost:{ titanium:3, glass:1 } },
  fins: { label:'Swim Fins', cost:{ silicone:2, kelp:1 } },
  rebreather: { label:'Rebreather', cost:{ fiber_mesh:1, wiring_kit:1 } }
};
const ITEM_DEFS = {
  explorer_pda:{name:'PDA',icon:'explorer_pda',size:4,kind:'tool',width:2,height:2},
  scanner:{name:'Scanner',icon:'scanner',size:2,kind:'tool',width:1,height:2},
  knife:{name:'Survival Knife',icon:'knife',size:2,kind:'tool',width:1,height:2},
  flashlight:{name:'Flashlight',icon:'flashlight',size:2,kind:'tool',width:1,height:2},
  habitat_builder:{name:'Habitat Builder',icon:'habitat_builder',size:4,kind:'tool',width:2,height:2},
  repair_tool:{name:'Repair Tool',icon:'repair_tool',size:4,kind:'tool',width:2,height:2},
  seaglide:{name:'Seaglide',icon:'seaglide',size:6,kind:'tool',width:2,height:3},
  titanium:{name:'Titanium',icon:'titanium',size:1,stack:4,kind:'resource'},
  copper:{name:'Copper Ore',icon:'copper',size:1,stack:4,kind:'resource'},
  quartz:{name:'Quartz',icon:'quartz',size:1,stack:4,kind:'resource'},
  kelp:{name:'Creepvine',icon:'kelp',size:1,stack:4,kind:'resource'},
  coral:{name:'Coral Sample',icon:'coral',size:1,stack:4,kind:'resource'},
  lithium:{name:'Lithium',icon:'lithium',size:2,stack:2,kind:'resource'},
  sulfur:{name:'Sulfur Crystal',icon:'sulfur',size:2,stack:2,kind:'resource'},
  magnetite:{name:'Magnetite',icon:'magnetite',size:2,stack:2,kind:'resource'},
  salt:{name:'Salt Deposit',icon:'salt',size:1,stack:4,kind:'resource'},
  glowcap:{name:'Glowcap Mushroom',icon:'glowcap',size:1,stack:4,kind:'resource'},
  fish_meat:{name:'Fresh Fish',icon:'fish_meat',size:1,stack:3,kind:'resource'},
  glass:{name:'Glass',icon:'glass',size:2,stack:2,kind:'resource'},
  silicone:{name:'Silicone Rubber',icon:'silicone',size:2,stack:2,kind:'resource'},
  fiber_mesh:{name:'Fiber Mesh',icon:'fiber_mesh',size:2,stack:2,kind:'resource',width:2,height:1},
  battery:{name:'Battery',icon:'battery',size:2,stack:2,kind:'resource',width:2,height:1},
  wiring_kit:{name:'Wiring Kit',icon:'wiring_kit',size:2,stack:2,kind:'resource',width:2,height:1},
  computer_chip:{name:'Computer Chip',icon:'computer_chip',size:2,stack:2,kind:'resource',width:2,height:1},
  silver:{name:'Silver Ore',icon:'silver',size:2,stack:2,kind:'resource'},
  power_cell:{name:'Power Cell',icon:'power_cell',size:4,stack:1,kind:'resource',width:2,height:2},
  lubricant:{name:'Lubricant',icon:'lubricant',size:2,stack:2,kind:'resource',width:2,height:1},
  bleach:{name:'Bleach',icon:'bleach',size:2,stack:2,kind:'resource',width:2,height:1},
  medkit:{name:'Medkit',icon:'medkit',size:1,stack:4,kind:'supply'},
  ration:{name:'Rations',icon:'ration',size:1,stack:4,kind:'supply'},
  water:{name:'Purified Water',icon:'water',size:1,stack:4,kind:'supply'}
};
const STARTER_TOOLS = ['explorer_pda','scanner','knife','flashlight'];
const FABRICATOR_CATEGORIES = {
  sustenance:{title:'Sustenance',recipes:[
    {id:'medkit',name:'First Aid Kit',icon:'medkit',cost:{fiber_mesh:1}},
    {id:'ration',name:'Cooked Fish',icon:'ration',cost:{fish_meat:1}},
    {id:'water',name:'Filtered Water',icon:'water',cost:{bleach:1}}
  ]},
  personal:{title:'Personal',recipes:[
    {id:'tank',name:'O₂ Tank Upgrade',icon:'oxygen_tank',cost:{titanium:3,glass:1}},
    {id:'fins',name:'Swim Fins',icon:'fins',cost:{silicone:2,kelp:1}},
    {id:'rebreather',name:'Rebreather',icon:'rebreather',cost:{fiber_mesh:1,wiring_kit:1}},
    {id:'habitat_builder',name:'Habitat Builder',icon:'habitat_builder',cost:{titanium:2,copper:1,battery:1}},
    {id:'repair_tool',name:'Repair Tool',icon:'repair_tool',cost:{titanium:1,silicone:1,battery:1}},
    {id:'seaglide',name:'Seaglide',icon:'seaglide',cost:{battery:1,copper:1,titanium:1}}
  ]},
  resources:{title:'Resources',recipes:[
    {id:'glass',name:'Glass',icon:'glass',cost:{quartz:2}},
    {id:'silicone',name:'Silicone Rubber',icon:'silicone',cost:{kelp:2}},
    {id:'fiber_mesh',name:'Fiber Mesh',icon:'fiber_mesh',cost:{kelp:2}},
    {id:'lubricant',name:'Lubricant',icon:'lubricant',cost:{kelp:2}},
    {id:'bleach',name:'Bleach',icon:'bleach',cost:{salt:1,coral:1}}
  ]},
  electronics:{title:'Electronics',recipes:[
    {id:'battery',name:'Battery',icon:'battery',cost:{copper:1,quartz:1}},
    {id:'wiring_kit',name:'Wiring Kit',icon:'wiring_kit',cost:{silver:2}},
    {id:'computer_chip',name:'Computer Chip',icon:'computer_chip',cost:{quartz:1,copper:1,coral:1}},
    {id:'power_cell',name:'Power Cell',icon:'power_cell',cost:{battery:2,silicone:1}}
  ]}
};
let inventory = { ...INVENTORY_DEFAULTS };
let equipment = { ...EQUIPMENT_DEFAULTS };
let seaglideChargeUiBucket = -1;
let ownedTools = [...STARTER_TOOLS];
let hotbarSlots = ['scanner','knife','flashlight',null,null];
let selectedHotbarIndex = 0;
let hasUnsavedChanges = false;
let lastSavedRecord = null;
let fabricatorCategory = 'sustenance';
let lockerStorage = { ...INVENTORY_DEFAULTS };
let knownBiomes = new Set();
let currentBiome = BIOME_DATA.open;
let collectedResources = new Set();
let placedStructures = [];
let resourceNodes = new Map();
let floatingDrops = [];
let physicsDebris = [];
let dropMaterials = new Map();
let dropGeometry = null;
let debrisGeometry = null;
let storyState = { ...STORY_DEFAULTS, counters:{...STORY_DEFAULTS.counters}, completed:[] };
let lifepodGroup = null;
let introSequence = { active:false, elapsed:0, group:null, base:null, attacker:null, pod:null, lights:[], debrisSpawned:false, lineIndex:-1 };
let introDebris = [];
let introDebrisResources = [];
let debrisMaterials = [];
let radioHideTimer = 0;
let viewModel = null;
let lightRayGroup = null;
let terrainTexture = null, rockTexture = null, kelpTexture = null, coralTexture = null, woodTexture = null, metalTexture = null, causticTexture = null;
let terrainBumpTexture = null, rockBumpTexture = null, kelpBumpTexture = null, coralBumpTexture = null, woodBumpTexture = null, metalBumpTexture = null;
let terrainMaterials = {};
let kelpShader = null;
let soundNoiseGain = null;
let visualViewportResizeTimer = 0;
let updateCheckTimer = 0;

const copy = {
  id: {
    tagline: 'Lautan tak berujung. Rahasia yang menunggu ditemukan.', play: 'Play', continue: 'Continue', settings: 'Settings', exit: 'Exit',
    back: 'Kembali', newGame: 'Permainan Baru', newGameHint: 'Pilih slot untuk memulai ekspedisi baru. Slot berisi data lama akan ditimpa setelah konfirmasi.',
    load: 'Load', loadHint: 'Pilih salah satu dari lima slot untuk melanjutkan perjalanan.', graphics: 'Grafik', renderDistance: 'Jarak render',
    sound: 'Suara', fieldOfView: 'Field of view', language: 'Bahasa', display: 'Tampilan', fullscreen: 'Fullscreen',
    settingsNote: 'Perubahan grafik, suara, jarak render, bahasa, dan FOV diterapkan langsung.', sessionEnded: 'Sesi berakhir',
    exitHint: 'Progres telah disimpan. Kamu dapat kembali ke menu atau keluar ke Home Android.', mainMenu: 'Menu Utama'
  },
  en: {
    tagline: 'An endless ocean. Secrets waiting to be discovered.', play: 'Play', continue: 'Continue', settings: 'Settings', exit: 'Exit',
    back: 'Back', newGame: 'New Expedition', newGameHint: 'Choose a slot for a new expedition. Existing data will be replaced after confirmation.',
    load: 'Load', loadHint: 'Choose one of five slots to continue your journey.', graphics: 'Graphics', renderDistance: 'Render distance',
    sound: 'Sound', fieldOfView: 'Field of view', language: 'Language', display: 'Display', fullscreen: 'Fullscreen',
    settingsNote: 'Graphics, sound, render distance, language, and FOV changes apply immediately.', sessionEnded: 'Session ended',
    exitHint: 'Your progress has been saved. Return to the menu or leave to the Android home screen.', mainMenu: 'Main Menu'
  }
};

const defaults = { graphics: 'balanced', renderDistance: 2, volume: 55, fov: 70, language: 'id' };
let settings = normalizeGameSettings(loadJson(STORAGE.settings, defaults));
const rawSlots = loadJson(STORAGE.slots, [null, null, null, null, null]);
let slots = Array.isArray(rawSlots)
  ? Array.from({ length: 5 }, (_, index) => rawSlots[index] ? normalizeSaveRecord(rawSlots[index]) : null)
  : [null, null, null, null, null];

let renderer, scene, camera, water, particleGroup, playerGroup, playerBody, leftArm, rightArm, leftFin, rightFin;
let faunaDirector = null;
let faunaStatus = { count: 0, nearest: null, threat: null };
let survival = { ...SURVIVAL_DEFAULTS };
let oxygenDamageTimer = 0, hungerDamageTimer = 0, thirstDamageTimer = 0;
let respawnPoint = new THREE.Vector3(0, -7, 0);
let isRespawning = false;
let collectedCaches = new Set();
let terrainMaterial, rockGeometry, rockMaterial, kelpGeometry, kelpMaterial, coralGeometry, coralMaterial;
let chunks = new Map();
let gameActive = false;
let gamePaused = false;
let activeSlot = -1;
let settingsReturn = 'main';
let lastFrame = performance.now();
let lastHudUpdate = 0;
let lastMultiplayerSync = 0;
let multiplayerReturn = 'main';
const remoteDivers = new Map();

let chunkCenterX = NaN, chunkCenterZ = NaN;
let toastTimer = 0;
let ambientContext = null, ambientGain = null, ambientOscillators = [], lastAudioBiome = '';
let biomeSfxTimer = 0;
let rendererReady = false;

const player = { position: new THREE.Vector3(0, -7, 0), velocity: new THREE.Vector3(), yaw: 0, pitch: 0.08, bob: 0, swimPhase: 0 };
const input = { keys: new Set(), joyX: 0, joyY: 0, vertical: 0, forward: 0, strafe: 0 };
const look = { active: false, pointerId: null, x: 0, y: 0 };
const islandOfInterest = { x: 98, z: -58, name: 'Verdant Isle' };
const shipOfInterest = { x: -132, z: 150, name: 'Sunken Vessel' };
const supplyCacheLocations = [
  { id: 'verdant_cache', name: 'Verdant Isle Supply Cache', x: 205, y: -4, z: -58 },
  { id: 'wreck_cache', name: 'Sunken Vessel Supply Cache', x: -118, y: -35, z: 145 }
];
const tmpVector = new THREE.Vector3();
const tmpRight = new THREE.Vector3();
const tmpDirection = new THREE.Vector3();
const tmpCamera = new THREE.Vector3();
const clockState = { elapsed: 0 };

function loadJson(key, fallback) {
  try { const value = localStorage.getItem(key); return value ? JSON.parse(value) : fallback; }
  catch { return fallback; }
}
function saveJson(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); return true; }
  catch { showToast('Penyimpanan perangkat penuh atau tidak tersedia.'); return false; }
}
function disposeObjectTree(root, protectedResources = {}) {
  if (!root) return;
  const keepGeometries = new Set(protectedResources.geometries || []);
  const keepMaterials = new Set(protectedResources.materials || []);
  const geometries = new Set();
  const materials = new Set();
  root.traverse(object => {
    if (object.geometry && !keepGeometries.has(object.geometry)) geometries.add(object.geometry);
    const list = Array.isArray(object.material) ? object.material : [object.material];
    for (const material of list) if (material && !keepMaterials.has(material)) materials.add(material);
  });
  for (const geometry of geometries) geometry.dispose();
  for (const material of materials) material.dispose();
}
function clamp(value, min, max) { return Math.max(min, Math.min(max, value)); }
function getGameViewportSize() {
  const rect = $('game-shell').getBoundingClientRect();
  return { width: Math.max(1, Math.round(rect.width)), height: Math.max(1, Math.round(rect.height)) };
}
function lerp(a, b, t) { return a + (b - a) * t; }
function smoothstep(a, b, x) { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); }
function wrapAngle(a) { while (a > Math.PI) a -= Math.PI * 2; while (a < -Math.PI) a += Math.PI * 2; return a; }
function formatTime(value) {
  try { return new Intl.DateTimeFormat(settings.language === 'id' ? 'id-ID' : 'en-US', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)); }
  catch { return new Date(value).toLocaleString(); }
}
function showToast(message) {
  const toast = $('toast');
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2400);
}
function setVisibleScreen(name) {
  if (document.activeElement && /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName)) document.activeElement.blur();
  Object.values(UI).forEach(node => node.classList.add('hidden'));
  if (UI[name]) UI[name].classList.remove('hidden');
  document.body.classList.toggle('game-screen-open', name === 'hud');
}
function applyLanguage() {
  const words = copy[settings.language] || copy.id;
  document.documentElement.lang = settings.language === 'id' ? 'id' : 'en';
  document.querySelectorAll('[data-i18n]').forEach(node => {
    const key = node.dataset.i18n;
    if (words[key]) node.textContent = words[key];
  });
}
function exportSaveBackup() {
  if (gameActive && activeSlot >= 0) {
    slots[activeSlot] = buildSaveRecord();
    if (!saveJson(STORAGE.slots, slots)) { showToast('Backup dibatalkan karena progres aktif gagal disimpan.'); return; }
  }
  const payload = {
    format: 'the-abyssal-save-backup',
    schemaVersion: 2,
    exportedAt: new Date().toISOString(),
    slots: slots.map(record => record ? normalizeSaveRecord(record) : null),
    settings: normalizeGameSettings(settings)
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `the-abyssal-backup-${new Date().toISOString().slice(0,10)}.json`;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
  showToast('Backup lima slot dibuat. Simpan file JSON di Downloads.');
}

async function importSaveBackup(file) {
  if (gameActive) throw new Error('Kembali ke menu utama sebelum memulihkan backup.');
  if (!file || file.size > 2 * 1024 * 1024) throw new Error('File backup tidak valid atau lebih dari 2 MB.');
  const payload = JSON.parse(await file.text());
  const restored = normalizeBackupPayload(payload);
  if (!window.confirm('Pulihkan lima slot dari backup? Data slot yang sekarang akan diganti.')) return;
  if (!saveJson(STORAGE.slots, restored.slots)) throw new Error('Penyimpanan perangkat gagal. Slot lama tidak diubah.');
  slots = restored.slots;
  if (restored.settings) {
    settings = normalizeGameSettings(restored.settings);
    if (!saveJson(STORAGE.settings, settings)) showToast('Slot dipulihkan, tetapi pengaturan tidak dapat disimpan.');
    syncSettingsInputs();
    applySettings();
    applyLanguage();
  }
  renderSlotCards('load-slots', 'load');
  showToast('Backup berhasil dipulihkan ke lima slot lokal.');
}

function syncSettingsInputs() {
  $('graphics-select').value = settings.graphics;
  $('render-select').value = String(settings.renderDistance);
  $('volume-range').value = String(settings.volume);
  $('volume-value').textContent = `${settings.volume}%`;
  $('fov-range').value = String(settings.fov);
  $('fov-value').textContent = `${settings.fov}°`;
  $('language-select').value = settings.language;
}
function applySettings() {
  if (!rendererReady) return;
  const pixelCap = settings.graphics === 'high' ? 1.5 : settings.graphics === 'low' ? 0.85 : 1.15;
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, pixelCap));
  renderer.shadowMap.enabled = settings.graphics === 'high';
  const viewport = getGameViewportSize();
  renderer.setSize(viewport.width, viewport.height, false);
  camera.fov = Number(settings.fov);
  camera.aspect = viewport.width / viewport.height;
  camera.updateProjectionMatrix();
  updateAmbientVolume();
  if (scene) scene.fog.density = settings.graphics === 'low' ? 0.0029 : settings.graphics === 'high' ? 0.00175 : 0.00225;
  updateChunks(true);
  faunaDirector?.setQuality(settings.graphics);
  saveJson(STORAGE.settings, settings);
}
function openSettings(from = 'main') {
  settingsReturn = from;
  syncSettingsInputs();
  setVisibleScreen('settings');
  applyLanguage();
}
function closeSettings() {
  if (settingsReturn === 'pause' && gameActive) setVisibleScreen('pause');
  else setVisibleScreen('main');
}
function updateNetworkLabels() {
  const label = $('network-label');
  const dot = $('network-dot');
  if (!label) return;
  if (!online.configured) {
    label.textContent = 'OFFLINE PLAY AVAILABLE · ONLINE SETUP REQUIRED';
    if (dot) dot.style.background = '#d7b873';
  } else if (online.inRoom && online.connectionState === 'error') {
    label.textContent = `ROOM RECONNECTING · ${online.room.code}`;
    if (dot) dot.style.background = '#d7b873';
  } else if (online.inRoom) {
    label.textContent = `MULTIPLAYER ROOM · ${online.room.code}`;
    if (dot) dot.style.background = '#72e8cb';
  } else if (online.user) {
    label.textContent = 'ACCOUNT CONNECTED · NO ACTIVE ROOM';
    if (dot) dot.style.background = '#72e8cb';
  } else {
    label.textContent = 'ONLINE CONFIGURED · LOGIN TO PLAY TOGETHER';
    if (dot) dot.style.background = '#72b9e8';
  }
}

function updateOnlineStatus(message, type = 'info') {
  const status = $('online-status');
  if (!status) return;
  status.textContent = String(message || '');
  status.dataset.kind = type;
}

function explainOnlineError(error, fallback = 'Permintaan online gagal.') {
  const message = String(error?.message || error || '');
  if (/invalid login credentials/i.test(message)) return 'Email atau kata sandi tidak cocok. Periksa kembali, lalu coba Login lagi.';
  if (/email not confirmed|email_not_confirmed/i.test(message)) return 'Email belum diverifikasi. Buka email verifikasi Supabase terlebih dahulu.';
  if (/user already registered|already been registered/i.test(message)) return 'Email ini sudah terdaftar. Gunakan menu Login.';
  if (/password.*(characters|length|short)|weak password/i.test(message)) return 'Kata sandi belum memenuhi aturan keamanan Supabase. Gunakan kata sandi yang lebih kuat.';
  if (/invalid api key|invalid jwt|jwt expired/i.test(message)) return 'Project URL dan Publishable Key tidak cocok atau tidak valid. Periksa konfigurasi backend.';
  if (/failed to fetch|fetch failed|network request failed|networkerror/i.test(message)) return 'Server tidak dapat dijangkau. Periksa koneksi internet dan Project URL Supabase.';
  if (/rate limit|too many requests|email rate limit/i.test(message)) return 'Terlalu banyak percobaan. Tunggu beberapa saat sebelum mencoba lagi.';
  if (/pgrst202|could not find the function|function .* does not exist/i.test(message)) return 'Fungsi database multiplayer belum ditemukan. Jalankan seluruh file migrasi SQL The Abyssal di Supabase SQL Editor.';
  if (/row-level security|permission denied|not authorized|unauthorized/i.test(message)) return 'Akses ditolak oleh kebijakan keamanan database atau Realtime. Jalankan migrasi SQL terbaru dan pastikan akun sudah Login.';
  if (/email rate limit exceeded|over_email_send_rate_limit/i.test(message)) return 'Batas pengiriman email verifikasi tercapai. Periksa email yang sudah dikirim atau coba lagi nanti.';
  if (/user.*already.*registered/i.test(message)) return 'Email ini sudah terdaftar. Beralih ke menu Login.';
  if (/signup.*disabled|signups not allowed|disable_signup/i.test(message)) return 'Pendaftaran akun dinonaktifkan. Aktifkan Sign ups pada Supabase Authentication → Providers → Email.';
  return message || fallback;
}

function updateOnlineConfigNote() {
  const node = $('online-config-note');
  if (!node) return;
  if (online.configured) {
    node.textContent = 'KONFIGURASI TERSIMPAN · Login dan Register akan memeriksa layanan Supabase saat digunakan.';
    node.dataset.kind = 'success';
  } else {
    node.textContent = 'SUPABASE NOT CONNECTED · Masukkan Project URL dan Publishable Key pada bagian Hubungkan Backend di bawah.';
    node.dataset.kind = 'warning';
    const editor = $('backend-config-details');
    if (editor) editor.open = true;
  }
  const loginButton = $('login-submit-btn');
  const registerButton = $('register-submit-btn');
  if (loginButton) loginButton.disabled = !online.authReady;
  if (registerButton) {
    registerButton.disabled = !online.authReady || !online.signupAllowed;
    registerButton.title = online.signupAllowed ? '' : 'Pendaftaran akun dinonaktifkan pada Supabase Auth.';
  }
}

function updateOnlineRoomUi() {
  const authenticated = Boolean(online.user);
  $('online-auth-area')?.classList.toggle('hidden', authenticated);
  $('online-account-area')?.classList.toggle('hidden', !authenticated);
  if (authenticated) {
    $('account-display-name').textContent = online.displayName;
    $('account-email').textContent = online.user.email || 'Akun terhubung';
  }
  const room = online.room;
  $('online-room-state')?.classList.toggle('hidden', !room);
  $('online-chat-section')?.classList.toggle('hidden', !room);
  if (room) {
    $('online-room-code').textContent = room.code;
    $('online-room-name').textContent = room.name;
    const count = Math.max(online.members.length, 1);
    $('online-room-members').textContent = `${count} / ${room.maxPlayers || 4} DIVERS CONNECTED`;
  }
  for (const id of ['create-room-btn','join-room-btn']) {
    const button = $(id);
    if (button) button.disabled = !authenticated || !online.authReady || Boolean(room);
  }
  const leaveButton = $('leave-room-btn');
  if (leaveButton) leaveButton.disabled = !room;
  updateNetworkLabels();
}

function renderOnlineMembers(members = []) {
  online.members = members;
  updateOnlineRoomUi();
  const active = new Set(members.map(member => member.userId).filter(Boolean));
  for (const [userId, diver] of remoteDivers) {
    if (!active.has(userId)) {
      scene?.remove(diver.group);
      diver.labelTexture?.dispose();
      disposeObjectTree(diver.group);
      remoteDivers.delete(userId);
    }
  }
}

function appendOnlineChat(message) {
  const root = $('online-chat-log');
  if (!root || !message) return;
  root.querySelector('.chat-empty')?.remove();
  const row = document.createElement('div');
  row.className = message.senderId === online.userId ? 'chat-line own' : 'chat-line';
  const meta = document.createElement('small');
  meta.textContent = `${message.senderName} · ${new Date(message.sentAt).toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' })}`;
  const text = document.createElement('span');
  text.textContent = message.text;
  row.append(meta, text);
  root.append(row);
  while (root.children.length > 40) root.firstElementChild?.remove();
  root.scrollTop = root.scrollHeight;
}

function openMultiplayer(from = 'main') {
  multiplayerReturn = from;
  setVisibleScreen('multiplayer');
  updateOnlineConfigNote();
  if ($('backend-project-url')) $('backend-project-url').value = online.projectUrl || '';
  if ($('backend-publishable-key')) $('backend-publishable-key').value = online.publishableKey || '';
  updateOnlineRoomUi();
}

function closeMultiplayer() {
  if (multiplayerReturn === 'pause' && gameActive) {
    gamePaused = true;
    setVisibleScreen('pause');
  } else {
    setVisibleScreen('main');
  }
}

async function initializeOnlineServices() {
  try {
    await online.init({
      onAuthChange: () => { updateOnlineRoomUi(); updateNetworkLabels(); },
      onStatus: ({ message, type }) => { updateOnlineStatus(message, type); updateNetworkLabels(); },
      onRoomChange: () => { updateOnlineRoomUi(); updateNetworkLabels(); },
      onMembers: members => renderOnlineMembers(members),
      onPlayerState: state => updateRemoteDiver(state),
      onChat: message => appendOnlineChat(message)
    });
  } catch (error) {
    console.error('[The Abyssal] Online service initialization failed:', error);
    updateOnlineStatus(`Koneksi layanan online gagal: ${error.message || error}`, 'error');
  }
  updateOnlineConfigNote();
  if ($('backend-project-url')) $('backend-project-url').value = online.projectUrl || '';
  if ($('backend-publishable-key')) $('backend-publishable-key').value = online.publishableKey || '';
  updateOnlineRoomUi();
  updateNetworkLabels();
}

function makeRemoteDiver(userId, displayName) {
  const group = new THREE.Group();
  const suit = new THREE.MeshStandardMaterial({ color:0xe5e2d8, roughness:0.78, metalness:0.08 });
  const dark = new THREE.MeshStandardMaterial({ color:0x183c4b, roughness:0.7 });
  const visor = new THREE.MeshStandardMaterial({ color:0x62dce5, emissive:0x14545b, emissiveIntensity:0.7, transparent:true, opacity:0.86, roughness:0.16, metalness:0.28 });
  const accent = new THREE.MeshStandardMaterial({ color:0xefa45b, roughness:0.65 });
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.46,0.78,4,8), suit);
  torso.rotation.x = Math.PI / 2;
  torso.position.y = 0.02;
  group.add(torso);
  const chest = new THREE.Mesh(new THREE.BoxGeometry(0.52,0.38,0.22), dark);
  chest.position.set(0,0.12,-0.36); group.add(chest);
  const helmet = new THREE.Mesh(new THREE.SphereGeometry(0.39,12,10), suit);
  helmet.position.set(0,0.88,-0.04); group.add(helmet);
  const face = new THREE.Mesh(new THREE.SphereGeometry(0.29,12,9), visor);
  face.scale.set(1.1,0.72,0.58); face.position.set(0,0.91,-0.31); group.add(face);
  const tank = new THREE.Mesh(new THREE.CylinderGeometry(0.17,0.19,0.94,8), accent);
  tank.position.set(0,0.02,0.42); group.add(tank);
  const armGeo = new THREE.CapsuleGeometry(0.105,0.48,3,6);
  for (const x of [-0.5,0.5]) {
    const arm = new THREE.Mesh(armGeo,suit);
    arm.position.set(x,0.02,-0.02); arm.rotation.z = x < 0 ? -0.22 : 0.22; group.add(arm);
    const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.12,0.52,3,6),dark);
    leg.position.set(x*0.34,-0.66,0.08); group.add(leg);
    const fin = new THREE.Mesh(new THREE.BoxGeometry(0.22,0.09,0.5),accent);
    fin.position.set(x*0.34,-1.03,-0.1); group.add(fin);
  }
  const labelCanvas = document.createElement('canvas');
  labelCanvas.width = 512; labelCanvas.height = 128;
  const ctx = labelCanvas.getContext('2d');
  ctx.fillStyle = 'rgba(3,21,32,0.78)'; ctx.fillRect(16,28,480,74);
  ctx.strokeStyle = 'rgba(111,231,221,0.85)'; ctx.lineWidth = 4; ctx.strokeRect(16,28,480,74);
  ctx.font = '600 34px Arial'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#e4fffb';
  ctx.fillText(String(displayName || 'Diver').slice(0,24),256,66,450);
  const labelTexture = new THREE.CanvasTexture(labelCanvas);
  const label = new THREE.Sprite(new THREE.SpriteMaterial({ map:labelTexture, transparent:true, depthTest:false }));
  label.position.set(0,1.72,0); label.scale.set(2.2,0.55,1); group.add(label);
  group.scale.setScalar(0.92);
  group.visible = false;
  scene.add(group);
  return { userId, group, labelTexture, target:new THREE.Vector3(), targetYaw:0, lastSeen:Date.now(), initialized:false };
}

function updateRemoteDiver(state) {
  if (!gameActive || !state?.userId || state.userId === online.userId || !scene) return;
  let diver = remoteDivers.get(state.userId);
  if (!diver) {
    diver = makeRemoteDiver(state.userId, state.displayName);
    remoteDivers.set(state.userId, diver);
  }
  diver.target.set(state.x,state.y,state.z);
  diver.targetYaw = state.yaw;
  if (!diver.initialized) {
    diver.group.position.copy(diver.target);
    diver.group.rotation.y = diver.targetYaw;
    diver.initialized = true;
  }
  diver.lastSeen = Date.now();
  diver.group.visible = true;
  diver.group.userData.biome = state.biome;
  diver.group.userData.tool = state.tool;
  diver.group.userData.lastDepth = state.depth;
}

function updateRemoteDiverVisuals(dt) {
  for (const [userId, diver] of remoteDivers) {
    if (Date.now() - diver.lastSeen > 12000) {
      scene?.remove(diver.group); diver.labelTexture?.dispose(); disposeObjectTree(diver.group); remoteDivers.delete(userId); continue;
    }
    const blend = 1 - Math.exp(-Math.min(dt,0.08) * 8);
    diver.group.position.lerp(diver.target,blend);
    diver.group.rotation.y += wrapAngle(diver.targetYaw - diver.group.rotation.y) * blend;
  }
}

function clearRemoteDivers() {
  for (const diver of remoteDivers.values()) {
    scene?.remove(diver.group);
    diver.labelTexture?.dispose();
    disposeObjectTree(diver.group);
  }
  remoteDivers.clear();
}


function islandData(ix, iz) {
  const spacing = 280;
  if (ix === 0 && iz === 0) return { x: islandOfInterest.x, z: islandOfInterest.z, radius: 88, height: 27 };
  const rx = hash2(ix + 39, iz - 7);
  const rz = hash2(ix - 15, iz + 61);
  return {
    x: ix * spacing + (rx - 0.5) * 92,
    z: iz * spacing + (rz - 0.5) * 92,
    radius: 54 + hash2(ix + 7, iz + 91) * 34,
    height: 15 + hash2(ix - 55, iz + 8) * 18
  };
}
function heightAt(x, z) {
  const seaFloor = -43 + valueNoise(x * 0.017, z * 0.017) * 6.5 + valueNoise(x * 0.061, z * 0.061) * 1.8;
  const gx = Math.round(x / 280), gz = Math.round(z / 280);
  let height = seaFloor;
  for (let ix = gx - 1; ix <= gx + 1; ix++) {
    for (let iz = gz - 1; iz <= gz + 1; iz++) {
      const island = islandData(ix, iz);
      const dx = (x - island.x) / island.radius;
      const dz = (z - island.z) / (island.radius * (0.78 + hash2(ix + 8, iz + 3) * 0.36));
      const q = Math.sqrt(dx * dx + dz * dz);
      const blend = smoothstep(1.13, 0.86, q);
      if (blend > 0) {
        const hill = 2.4 + Math.pow(Math.max(0, 1 - q), 0.66) * island.height + valueNoise(x * 0.1, z * 0.1) * 2.3;
        height = Math.max(height, lerp(seaFloor, hill, blend));
      }
    }
  }
  return height;
}

function distance2D(x1, z1, x2, z2) { return Math.hypot(x1 - x2, z1 - z2); }
function getBiomeAt(x, y, z) {
  const depth = Math.max(0, -y);
  const wreckDistance = distance2D(x, z, shipOfInterest.x, shipOfInterest.z);
  if (depth > 33) return BIOME_DATA.abyss;
  if (wreckDistance < 108 && depth > 12) return BIOME_DATA.wreck;
  const ventDistance = Math.min(...BIOME_CENTERS.thermal.map(([vx, vz]) => distance2D(x, z, vx, vz)));
  if (ventDistance < 54 && depth > 19) return BIOME_DATA.thermal;
  const islandDistance = distance2D(x, z, islandOfInterest.x, islandOfInterest.z);
  if (depth < 20 && islandDistance < 178) return BIOME_DATA.reef;
  const kelpDistance = Math.min(...BIOME_CENTERS.kelp.map(([kx, kz]) => distance2D(x, z, kx, kz)));
  if (depth > 7 && depth < 34 && kelpDistance < 150) return BIOME_DATA.kelp;
  return BIOME_DATA.open;
}
function getMaxOxygen() { return 45 + (equipment.tankLevel || 0) * 30; }
function nearestBuiltStructure(type, maxDistance = 12) {
  let best = null;
  for (const item of placedStructures) {
    if (type && item.type !== type) continue;
    const d = Math.hypot(player.position.x - item.x, player.position.y - item.y, player.position.z - item.z);
    if (d <= maxDistance && (!best || d < best.distance)) best = { ...item, distance:d };
  }
  return best;
}

function makeProceduralTexture(kind = 'stone', size = 256) {
  const canvasTexture = document.createElement('canvas');
  canvasTexture.width = canvasTexture.height = size;
  const ctx = canvasTexture.getContext('2d', { willReadFrequently: true });
  const palettes = {
    sand: [178, 157, 117], stone: [83, 111, 119], kelp: [31, 91, 70], coral: [159, 105, 133],
    wood: [110, 76, 48], metal: [82, 119, 128]
  };
  const base = palettes[kind] || palettes.stone;
  const image = ctx.createImageData(size, size);
  const hash = (x,y) => { const n=Math.sin(x*127.1+y*311.7+17.3)*43758.5453; return n-Math.floor(n); };
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = (y * size + x) * 4;
      const broad = Math.sin(x * 0.045 + Math.sin(y * 0.026) * 2.1) * 6 + Math.cos(y * 0.038) * 4;
      const medium = (hash(Math.floor(x/4),Math.floor(y/4)) - 0.5) * 19;
      const fine = (hash(x,y) - 0.5) * (kind === 'sand' ? 25 : 18);
      let detail = broad + medium + fine;
      if (kind === 'sand') detail += Math.sin((x + Math.sin(y*.05)*9) * .17) * 5;
      if (kind === 'rock') detail += Math.sin(x*.11+y*.07)*7;
      if (kind === 'metal') detail += (hash(Math.floor(x/18),Math.floor(y/3))-.5)*24;
      image.data[i] = clamp(base[0] + detail, 0, 255);
      image.data[i + 1] = clamp(base[1] + detail, 0, 255);
      image.data[i + 2] = clamp(base[2] + detail, 0, 255);
      image.data[i + 3] = 255;
    }
  }
  ctx.putImageData(image, 0, 0);
  if (kind === 'sand') {
    for(let y=5;y<size;y+=19){ctx.strokeStyle='rgba(255,236,190,.11)';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(0,y);ctx.bezierCurveTo(size*.28,y-5,size*.62,y+5,size,y-2);ctx.stroke();}
    for(let i=0;i<95;i++){const x=hash(i,3)*size,y=hash(7,i)*size;ctx.fillStyle=`rgba(65,74,68,${.08+hash(i,9)*.12})`;ctx.beginPath();ctx.ellipse(x,y,1+hash(i,1)*2,.7,0,0,Math.PI*2);ctx.fill();}
  } else if (kind === 'wood') {
    ctx.strokeStyle = 'rgba(32,18,10,.25)'; ctx.lineWidth = 2;
    for (let y = 8; y < size; y += 18) { ctx.beginPath(); ctx.moveTo(0, y); ctx.bezierCurveTo(38, y - 5, 82, y + 5, size, y - 2); ctx.stroke(); }
    for(let i=0;i<18;i++){const x=hash(i,22)*size,y=hash(31,i)*size;ctx.strokeStyle='rgba(35,21,12,.18)';ctx.beginPath();ctx.ellipse(x,y,5+hash(i,8)*9,2,0,0,Math.PI*2);ctx.stroke();}
  } else if (kind === 'coral') {
    ctx.strokeStyle = 'rgba(255,220,235,.2)'; ctx.lineWidth = 2;
    for (let i = 0; i < 36; i++) { ctx.beginPath(); ctx.arc(hash(i,5)*size,hash(12,i)*size,3+hash(i,8)*10,0,Math.PI*2); ctx.stroke(); }
  } else if (kind === 'metal') {
    ctx.strokeStyle='rgba(220,246,241,.18)';ctx.lineWidth=1;
    for(let i=0;i<35;i++){const x=hash(i,11)*size,y=hash(21,i)*size;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+5+hash(i,4)*20,y+hash(i,6)*3);ctx.stroke();}
  } else if (kind === 'kelp') {
    ctx.strokeStyle='rgba(170,231,180,.25)';ctx.lineWidth=2;
    for(let x=8;x<size;x+=18){ctx.beginPath();ctx.moveTo(x,size);ctx.quadraticCurveTo(x+10,size*.5,x-3,0);ctx.stroke();}
  }
  const texture = new THREE.CanvasTexture(canvasTexture);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  texture.generateMipmaps = true;
  texture.anisotropy = renderer?.capabilities?.getMaxAnisotropy ? Math.min(8,renderer.capabilities.getMaxAnisotropy()) : 4;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.magFilter = THREE.LinearFilter;
  return texture;
}

function makeHeightTexture(kind = 'sand', size = 256) {
  const canvas = document.createElement('canvas'); canvas.width = canvas.height = size;
  const ctx = canvas.getContext('2d', { willReadFrequently:true });
  const image = ctx.createImageData(size,size);
  const seed = kind.split('').reduce((n,c)=>n+c.charCodeAt(0),0);
  for(let y=0;y<size;y++) for(let x=0;x<size;x++) {
    const i=(y*size+x)*4;
    const n1=Math.sin((x+seed)*.09)*Math.cos((y-seed)*.07);
    const n2=Math.sin((x+y+seed)*.23)*.28;
    const grain=(Math.sin(x*12.9898+y*78.233+seed)*43758.5453)%1;
    const v=clamp(128+(n1+n2)*35+grain*13,0,255);
    image.data[i]=image.data[i+1]=image.data[i+2]=v; image.data[i+3]=255;
  }
  ctx.putImageData(image,0,0);
  const tex=new THREE.CanvasTexture(canvas); tex.wrapS=tex.wrapT=THREE.RepeatWrapping; tex.generateMipmaps=true;
  tex.minFilter=THREE.LinearMipmapLinearFilter; tex.magFilter=THREE.LinearFilter; return tex;
}

function makeCausticTexture(size = 256) {
  const c = document.createElement('canvas'); c.width = c.height = size;
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#173f4b'; ctx.fillRect(0, 0, size, size);
  ctx.globalCompositeOperation = 'screen';
  for (let i = 0; i < 90; i++) {
    const x = hash2(i * 7, 13) * size, y = hash2(19, i * 11) * size;
    const r = 6 + hash2(i * 3, i * 5) * 28;
    ctx.strokeStyle = `rgba(123,226,218,${0.035 + hash2(i, 17) * 0.06})`;
    ctx.lineWidth = 1 + hash2(i * 9, 3) * 2;
    ctx.beginPath(); ctx.ellipse(x, y, r * 1.6, r * 0.55, hash2(i, i + 2) * Math.PI, 0, Math.PI * 2); ctx.stroke();
  }
  const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace; tex.wrapS = tex.wrapT = THREE.RepeatWrapping; tex.repeat.set(7, 7); tex.minFilter = THREE.LinearMipmapLinearFilter; return tex;
}

function makeFirstPersonViewModel() {
  viewModel = new THREE.Group();
  const suit = new THREE.MeshStandardMaterial({ color: 0xd9e5df, map:rockTexture, roughness: 0.78, metalness: 0.08 });
  const glove = new THREE.MeshStandardMaterial({ color: 0x173b48, roughness: 0.55, metalness: 0.12 });
  const deviceDark = new THREE.MeshStandardMaterial({ color: 0x112c3a, roughness: 0.44, metalness: 0.42 });
  const trim = new THREE.MeshStandardMaterial({ color: 0x47bfc0, emissive: 0x0b5963, emissiveIntensity: 0.42, roughness: 0.35 });
  const orange = new THREE.MeshStandardMaterial({ color: 0xe08b43, roughness: 0.56, metalness: 0.18 });
  const left = new THREE.Group(), right = new THREE.Group();
  const makeArm = (group, side) => {
    const upper = new THREE.Mesh(new THREE.CapsuleGeometry(0.105,0.26,5,10),suit);
    upper.position.set(0,-0.055,0.12); upper.rotation.x=-0.48; group.add(upper);
    const forearm = new THREE.Mesh(new THREE.CapsuleGeometry(0.115,0.34,5,10),suit);
    forearm.position.set(0,-0.205,-0.13); forearm.rotation.x=-0.34; group.add(forearm);
    const shoulder = new THREE.Mesh(new THREE.SphereGeometry(0.145,12,9),suit);
    shoulder.scale.set(1,0.9,1.05); shoulder.position.set(0,0.02,0.16); group.add(shoulder);
    const cuff = new THREE.Mesh(new THREE.CylinderGeometry(0.12,0.12,0.09,12),trim);
    cuff.rotation.x=Math.PI/2; cuff.position.set(0,-0.31,-0.27); group.add(cuff);
    const palm = new THREE.Mesh(new THREE.SphereGeometry(0.125,12,9),glove);
    palm.scale.set(0.95,0.72,1.28); palm.position.set(0,-0.39,-0.39); group.add(palm);
    for(let finger=0;finger<4;finger++){
      const f=new THREE.Mesh(new THREE.CapsuleGeometry(0.026,0.075,3,6),glove);
      f.position.set((finger-1.5)*0.052,-0.435,-0.505); f.rotation.x=-0.28; group.add(f);
    }
    const thumb=new THREE.Mesh(new THREE.CapsuleGeometry(0.032,0.08,3,6),glove);
    thumb.position.set(side*0.13,-0.39,-0.44); thumb.rotation.z=-side*0.68; group.add(thumb);
    const seam=new THREE.Mesh(new THREE.TorusGeometry(0.116,0.012,5,16),orange);
    seam.rotation.x=Math.PI/2; seam.position.set(0,-0.31,-0.27); group.add(seam);
  };
  makeArm(left,-1); makeArm(right,1);
  left.position.set(-0.48,-0.19,-0.58); right.position.set(0.48,-0.19,-0.58);
  const scanner = new THREE.Group();
  const scannerBody = new THREE.Mesh(new THREE.BoxGeometry(0.19,0.14,0.39),glove);
  scannerBody.position.set(0.02,-0.03,-0.25); scanner.add(scannerBody);
  const scannerScreen = new THREE.Mesh(new THREE.BoxGeometry(0.145,0.012,0.17),new THREE.MeshBasicMaterial({color:0x70fff0}));
  scannerScreen.position.set(0.02,0.046,-0.22); scanner.add(scannerScreen);
  const lens = new THREE.Mesh(new THREE.CylinderGeometry(0.058,0.058,0.065,16),orange);
  lens.rotation.x=Math.PI/2; lens.position.set(0.02,-0.025,-0.47); scanner.add(lens);
  const scannerGlow = new THREE.PointLight(0x70f5f1, 0.75, 3.2);
  scannerGlow.position.set(0.02, 0.04, -0.48); scanner.add(scannerGlow);
  scanner.position.set(0.37,-0.22,-0.77);
  right.add(scanner);

  const knife = new THREE.Group();
  const knifeHandle = new THREE.Mesh(new THREE.CylinderGeometry(0.045,0.055,0.33,8), orange);
  knifeHandle.rotation.x = Math.PI / 2; knifeHandle.position.set(0.02,-0.035,-0.17); knife.add(knifeHandle);
  const knifeGuard = new THREE.Mesh(new THREE.BoxGeometry(0.19,0.055,0.065), trim);
  knifeGuard.position.set(0.02,-0.035,-0.34); knife.add(knifeGuard);
  const knifeBlade = new THREE.Mesh(new THREE.BoxGeometry(0.105,0.045,0.46), new THREE.MeshStandardMaterial({color:0xb8d8d7,metalness:0.78,roughness:0.24}));
  knifeBlade.position.set(0.02,-0.02,-0.58); knife.add(knifeBlade);
  knife.position.set(0.26,-0.23,-0.70); knife.visible=false; right.add(knife);

  const flashlight = new THREE.Group();
  const torchBody = new THREE.Mesh(new THREE.CylinderGeometry(0.075,0.09,0.39,10), glove);
  torchBody.rotation.x=Math.PI/2; torchBody.position.z=-0.28; flashlight.add(torchBody);
  const torchLens = new THREE.Mesh(new THREE.CylinderGeometry(0.082,0.082,0.06,12), new THREE.MeshBasicMaterial({color:0x9ffaf1}));
  torchLens.rotation.x=Math.PI/2; torchLens.position.z=-0.51; flashlight.add(torchLens);
  const flashlightBeam = new THREE.SpotLight(0x9fefff, 8, 34, Math.PI / 7, 0.72, 1.55);
  flashlightBeam.position.set(0, -0.02, -0.51);
  flashlightBeam.target.position.set(0, -0.04, -14);
  flashlight.add(flashlightBeam, flashlightBeam.target);
  flashlight.position.set(0.27,-0.22,-0.68); flashlight.visible=false; right.add(flashlight);

  const builder = new THREE.Group();
  const builderBody = new THREE.Mesh(new THREE.BoxGeometry(0.24,0.16,0.43), orange);
  builderBody.position.z=-0.22; builder.add(builderBody);
  const builderScreen = new THREE.Mesh(new THREE.BoxGeometry(0.16,0.012,0.12), new THREE.MeshBasicMaterial({color:0x75fff0}));
  builderScreen.position.set(0,0.087,-0.20); builder.add(builderScreen);
  const builderGlow = new THREE.PointLight(0x67f7e8, 0.8, 4.5);
  builderGlow.position.set(0, 0.03, -0.42); builder.add(builderGlow);
  builder.position.set(0.31,-0.22,-0.74); builder.visible=false; right.add(builder);

  const repairTool = new THREE.Group();
  const repairBody = new THREE.Mesh(new THREE.CylinderGeometry(0.09,0.13,0.46,10), glove);
  repairBody.rotation.x = Math.PI / 2; repairBody.position.z = -0.25; repairTool.add(repairBody);
  const repairHead = new THREE.Mesh(new THREE.BoxGeometry(0.28,0.13,0.16), orange);
  repairHead.position.set(0,-0.005,-0.49); repairTool.add(repairHead);
  const repairGlow = new THREE.PointLight(0x73e8e0,0.8,3); repairGlow.position.set(0,0.04,-0.52); repairTool.add(repairGlow);
  repairTool.position.set(0.29,-0.22,-0.72); repairTool.visible=false; right.add(repairTool);

  const seaglide = new THREE.Group();
  const glideBody = new THREE.Mesh(new THREE.BoxGeometry(0.42,0.31,0.66), deviceDark);
  glideBody.position.set(0,0,-0.22); seaglide.add(glideBody);
  const glideScreen = new THREE.Mesh(new THREE.BoxGeometry(0.25,0.025,0.15), new THREE.MeshBasicMaterial({color:0x7df5e8}));
  glideScreen.position.set(0,0.17,-0.23); seaglide.add(glideScreen);
  const glideRing = new THREE.Mesh(new THREE.TorusGeometry(0.20,0.035,8,18), trim);
  glideRing.position.set(0,0,-0.62); seaglide.add(glideRing);
  const glideProp = new THREE.Group();
  const propMaterial = new THREE.MeshStandardMaterial({color:0x9bd9d6,metalness:0.72,roughness:0.3});
  for (let i=0;i<4;i++) {
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.055,0.26,0.035),propMaterial);
    blade.position.y=0.13; blade.rotation.z=i*Math.PI/2; glideProp.add(blade);
  }
  glideProp.position.set(0,0,-0.64); seaglide.add(glideProp);
  const glideLamp = new THREE.PointLight(0x5ee7dc,0.9,4); glideLamp.position.set(0,0.02,-0.7); seaglide.add(glideLamp);
  seaglide.position.set(0.28,-0.22,-0.78); seaglide.visible=false; right.add(seaglide);

  viewModel.add(left,right);
  viewModel.position.set(0,0,0);
  viewModel.frustumCulled=false;
  viewModel.renderOrder=20;
  camera.add(viewModel);
  viewModel.userData.left=left; viewModel.userData.right=right; viewModel.userData.scanner=scanner;
  viewModel.userData.knife=knife; viewModel.userData.flashlight=flashlight; viewModel.userData.builder=builder;
  viewModel.userData.repairTool=repairTool; viewModel.userData.seaglide=seaglide; viewModel.userData.seaglideProp=glideProp;
  viewModel.userData.equipTimer=0; viewModel.userData.actionTimer=0; viewModel.userData.actionType='';
}

function makePlayer() {
  playerGroup = new THREE.Group();
  const suit = new THREE.MeshStandardMaterial({ color: 0xe0ded2, roughness: 0.82, metalness: 0.08 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x183f4d, roughness: 0.8 });
  const glass = new THREE.MeshStandardMaterial({ color: 0x5ed6df, roughness: 0.18, metalness: 0.35, transparent: true, opacity: 0.78 });
  const orange = new THREE.MeshStandardMaterial({ color: 0xd18b49, roughness: 0.7 });
  playerBody = new THREE.Group();
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.72, 1.25, 4, 8), suit);
  torso.rotation.x = Math.PI / 2;
  torso.position.y = 0.1;
  playerBody.add(torso);
  const chest = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.52, 0.28), dark);
  chest.position.set(0, 0.22, -0.55);
  playerBody.add(chest);
  const helmet = new THREE.Mesh(new THREE.SphereGeometry(0.55, 12, 9), suit);
  helmet.position.set(0, 1.24, -0.05);
  playerBody.add(helmet);
  const visor = new THREE.Mesh(new THREE.SphereGeometry(0.38, 12, 8), glass);
  visor.scale.set(1.08, 0.72, 0.55);
  visor.position.set(0, 1.26, -0.44);
  playerBody.add(visor);
  const tank = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.32, 1.4, 8), orange);
  tank.position.set(0, 0.16, 0.62);
  playerBody.add(tank);
  const armGeo = new THREE.CapsuleGeometry(0.19, 0.72, 3, 6);
  leftArm = new THREE.Group();
  rightArm = new THREE.Group();
  const armL = new THREE.Mesh(armGeo, suit), armR = new THREE.Mesh(armGeo, suit);
  armL.position.y = -0.39; armR.position.y = -0.39;
  leftArm.add(armL); rightArm.add(armR);
  leftArm.position.set(-0.78, 0.42, -0.1); rightArm.position.set(0.78, 0.42, -0.1);
  playerBody.add(leftArm, rightArm);
  const legGeo = new THREE.CapsuleGeometry(0.23, 0.75, 3, 6);
  const legL = new THREE.Mesh(legGeo, dark), legR = new THREE.Mesh(legGeo, dark);
  legL.position.set(-0.3, -0.92, 0.03); legR.position.set(0.3, -0.92, 0.03);
  playerBody.add(legL, legR);
  const finGeo = new THREE.BoxGeometry(0.32, 0.13, 0.83);
  leftFin = new THREE.Mesh(finGeo, orange); rightFin = new THREE.Mesh(finGeo, orange);
  leftFin.position.set(-0.3, -1.45, -0.38); rightFin.position.set(0.3, -1.45, -0.38);
  playerBody.add(leftFin, rightFin);
  playerGroup.add(playerBody);
  playerGroup.scale.setScalar(0.86);
  scene.add(playerGroup);
}

function makePalm(group, localX, localZ, baseY, scale = 1) {
  const trunkMaterial = new THREE.MeshStandardMaterial({ color: 0x77583b, roughness: 1 });
  const leafMaterial = new THREE.MeshStandardMaterial({ color: 0x2d755e, roughness: 0.9, flatShading: true });
  const palm = new THREE.Group();
  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.42, 6.2, 6), trunkMaterial);
  trunk.position.y = 3.1;
  palm.add(trunk);
  for (let i = 0; i < 7; i++) {
    const leaf = new THREE.Mesh(new THREE.ConeGeometry(0.48, 4.6, 5), leafMaterial);
    const angle = (i / 7) * Math.PI * 2;
    leaf.position.set(Math.cos(angle) * 1.2, 6.0, Math.sin(angle) * 1.2);
    leaf.rotation.z = Math.cos(angle) * 0.92;
    leaf.rotation.x = Math.sin(angle) * 0.92;
    leaf.rotation.y = angle;
    palm.add(leaf);
  }
  palm.position.set(localX, baseY, localZ);
  palm.scale.setScalar(scale);
  group.add(palm);
}

function makeWreck(group, baseX, baseZ) {
  const wreck = new THREE.Group();
  const hullMat = new THREE.MeshStandardMaterial({ color: 0x684934, map:woodTexture, bumpMap:woodBumpTexture, bumpScale:0.24, roughness: 0.98, flatShading: true });
  const plankMat = new THREE.MeshStandardMaterial({ color: 0x947052, map:woodTexture, bumpMap:woodBumpTexture, bumpScale:0.18, roughness: 0.98 });
  const metalMat = new THREE.MeshStandardMaterial({ color: 0x314b51, map:metalTexture, bumpMap:metalBumpTexture, bumpScale:0.12, metalness: 0.58, roughness: 0.82 });
  const hull = new THREE.Mesh(new THREE.BoxGeometry(30, 6, 8), hullMat);
  hull.scale.set(1, 0.82, 1);
  wreck.add(hull);
  const bow = new THREE.Mesh(new THREE.ConeGeometry(4.2, 8, 4), hullMat);
  bow.rotation.z = Math.PI / 2;
  bow.rotation.y = Math.PI / 4;
  bow.position.x = 17.5;
  wreck.add(bow);
  const deck = new THREE.Mesh(new THREE.BoxGeometry(23, 0.65, 7.3), plankMat);
  deck.position.y = 3.1;
  wreck.add(deck);
  const cabin = new THREE.Mesh(new THREE.BoxGeometry(7, 4.3, 5.2), plankMat);
  cabin.position.set(-4, 5.4, 0);
  cabin.rotation.z = -0.12;
  wreck.add(cabin);
  const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.38, 15, 6), metalMat);
  mast.position.set(6, 9.5, 0);
  mast.rotation.z = 0.28;
  wreck.add(mast);
  const beam = new THREE.Mesh(new THREE.BoxGeometry(10, 0.28, 0.28), metalMat);
  beam.position.set(5.5, 11.8, 0);
  beam.rotation.z = 0.23;
  wreck.add(beam);
  const brokenPlank = new THREE.Mesh(new THREE.BoxGeometry(10, 0.45, 0.5), plankMat);
  brokenPlank.position.set(-12, 5.2, 5.4);
  brokenPlank.rotation.z = 0.4;
  wreck.add(brokenPlank);
  const beacon = new THREE.PointLight(0x63e0d6, 1.4, 28);
  beacon.position.set(-5, 7, 0);
  wreck.add(beacon);
  wreck.position.set(shipOfInterest.x - baseX, -37, shipOfInterest.z - baseZ);
  wreck.rotation.y = 0.72;
  wreck.rotation.z = 0.035;
  wreck.scale.setScalar(1.05);
  group.add(wreck);
}

function makeSupplyCache(group, cache, baseX, baseZ) {
  const crate = new THREE.Group();
  const hull = new THREE.MeshStandardMaterial({ color: 0x315e66, roughness: 0.72, metalness: 0.25 });
  const trim = new THREE.MeshStandardMaterial({ color: 0xd2a967, roughness: 0.52, metalness: 0.58 });
  const glow = new THREE.MeshStandardMaterial({ color: 0x79e8df, emissive: 0x168b91, emissiveIntensity: 1.1 });
  const body = new THREE.Mesh(new THREE.BoxGeometry(2.8, 1.45, 2.0), hull);
  crate.add(body);
  const lid = new THREE.Mesh(new THREE.BoxGeometry(2.94, 0.24, 2.12), trim);
  lid.position.y = 0.84;
  crate.add(lid);
  for (const side of [-1, 1]) {
    const band = new THREE.Mesh(new THREE.BoxGeometry(0.16, 1.58, 2.16), trim);
    band.position.x = side * 0.82;
    crate.add(band);
  }
  const beacon = new THREE.Mesh(new THREE.SphereGeometry(0.2, 8, 6), glow);
  beacon.position.set(0, 1.12, 0);
  crate.add(beacon);
  const lamp = new THREE.PointLight(0x61e5dc, 0.9, 16);
  lamp.position.set(0, 1.4, 0);
  crate.add(lamp);
  crate.position.set(cache.x - baseX, cache.y, cache.z - baseZ);
  crate.rotation.y = cache.id === 'wreck_cache' ? 0.4 : -0.3;
  group.add(crate);
}

function makeResourceNode(group, cx, cz, index, localX, localZ, groundY, type) {
  const id = `${cx}:${cz}:ore:${index}`;
  if (collectedResources.has(id)) return;
  const colors = { titanium: 0x9fb2b7, copper: 0xc47b4b, quartz: 0xb8eff0, kelp: 0x53be94, coral: 0xd47eae, lithium: 0xa59bdc, sulfur: 0xe6ca69, magnetite: 0x526d85, salt: 0xd8e8e6, glowcap: 0x83d9d0, silver:0xc3ced8 };
  const material = new THREE.MeshStandardMaterial({ color: colors[type], roughness: type === 'glowcap' ? 0.72 : 0.42, metalness: type === 'titanium' || type === 'copper' ? 0.58 : 0.12, emissive: colors[type], emissiveIntensity: type === 'quartz' || type === 'glowcap' ? 0.46 : 0.06, map: type === 'coral' ? coralTexture : type === 'kelp' ? kelpTexture : rockTexture, bumpMap:type === 'coral' ? coralBumpTexture : type === 'kelp' ? kelpBumpTexture : rockBumpTexture, bumpScale:0.12 });
  const node = new THREE.Group();
  const size = type === 'kelp' ? 0.9 : 0.65;
  if (type === 'glowcap') {
    const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.13,0.2,0.95,9), new THREE.MeshStandardMaterial({color:0xd7c7a3, map:rockTexture, bumpMap:rockBumpTexture, bumpScale:0.035, roughness:0.95}));
    stem.position.y=0.48; node.add(stem);
    const cap = new THREE.Mesh(new THREE.SphereGeometry(0.62,12,8,0,Math.PI*2,0,Math.PI*0.58), material);
    cap.scale.set(1.12,0.74,1.12); cap.position.y=0.96; node.add(cap);
    for(let spot=0;spot<5;spot++) {
      const dot=new THREE.Mesh(new THREE.SphereGeometry(0.055,6,5),new THREE.MeshBasicMaterial({color:0xd7fff5}));
      const a=spot/5*Math.PI*2; dot.position.set(Math.cos(a)*0.43,1.14,Math.sin(a)*0.43); node.add(dot);
    }
  } else {
    const geo = type === 'kelp' ? new THREE.ConeGeometry(0.45, 2.6, 5) : new THREE.IcosahedronGeometry(size, 1);
    const mesh = new THREE.Mesh(geo, material);
    mesh.position.y = type === 'kelp' ? 1 : 0.55;
    mesh.rotation.set(0.12, hash2(cx + index, cz - index) * Math.PI, 0.12);
    node.add(mesh);
  }
  const glow = new THREE.Mesh(new THREE.SphereGeometry(type === 'glowcap' ? 0.16 : 0.12, 8, 6), new THREE.MeshBasicMaterial({ color: colors[type], transparent: true, opacity: 0.72 }));
  glow.position.set(0, type === 'kelp' ? 2.5 : type === 'glowcap' ? 1.65 : 1.25, 0); node.add(glow);
  node.position.set(localX, groundY, localZ);
  node.userData.resourceId = id;
  node.userData.resourceType = type;
  node.userData.chunkKey = `${cx},${cz}`;
  group.add(node);
  resourceNodes.set(id, { mesh: node, type, chunkKey: `${cx},${cz}` });
}

function addBuiltStructure(group, structure, baseX, baseZ) {
  const root = new THREE.Group();
  const dark = new THREE.MeshStandardMaterial({ color: 0x183d4b, roughness: 0.52, metalness: 0.62, map: metalTexture, bumpMap:metalBumpTexture, bumpScale:0.1 });
  const glass = new THREE.MeshStandardMaterial({ color: 0x76d7dc, roughness: 0.18, metalness: 0.12, transparent: true, opacity: 0.32 });
  const glow = new THREE.MeshStandardMaterial({ color: 0x74f0e4, emissive: 0x168c8b, emissiveIntensity: 1.4 });
  if (structure.type === 'beacon') {
    const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.2, 2.5, 8), dark); mast.position.y = 1.2; root.add(mast);
    const orb = new THREE.Mesh(new THREE.SphereGeometry(0.28, 12, 8), glow); orb.position.y = 2.55; root.add(orb);
    const light = new THREE.PointLight(0x65e9df, 1.5, 25); light.position.y = 2.6; root.add(light);
  } else if (structure.type === 'foundation') {
    const base = new THREE.Mesh(new THREE.CylinderGeometry(3.4, 3.65, 0.42, 12), dark); base.position.y = 0.22; root.add(base);
    const rim = new THREE.Mesh(new THREE.TorusGeometry(3.1, 0.09, 6, 20), glow); rim.rotation.x = Math.PI / 2; rim.position.y = 0.48; root.add(rim);
  } else if (structure.type === 'compartment') {
    // A walk-in underwater habitat with a sealed shell, entry arch, lighting, and a fabricator console.
    const floorMat = new THREE.MeshStandardMaterial({ color:0x294b57, map:metalTexture, metalness:0.55, roughness:0.68 });
    const floor = new THREE.Mesh(new THREE.CylinderGeometry(4.35,4.45,0.28,24),floorMat); floor.position.y=0.18; root.add(floor);
    const floorRing = new THREE.Mesh(new THREE.TorusGeometry(4.17,0.12,8,32),glow); floorRing.rotation.x=Math.PI/2; floorRing.position.y=0.38; root.add(floorRing);
    const dome = new THREE.Mesh(new THREE.SphereGeometry(4.35,24,14,0,Math.PI*2,0,Math.PI/2),glass); dome.position.y=0.34; root.add(dome);
    for (let i=0;i<6;i++) {
      const angle=i*Math.PI/3; const post=new THREE.Mesh(new THREE.CylinderGeometry(0.11,0.16,4.2,8),dark);
      post.position.set(Math.cos(angle)*4.0,2.35,Math.sin(angle)*4.0); root.add(post);
    }
    const entry = new THREE.Mesh(new THREE.TorusGeometry(1.35,0.13,8,20),glow); entry.position.set(0,1.65,-4.18); root.add(entry);
    const fabBase = new THREE.Mesh(new THREE.BoxGeometry(1.55,1.65,1.05),dark); fabBase.position.set(2.25,1.13,0.8); root.add(fabBase);
    const fabTop = new THREE.Mesh(new THREE.BoxGeometry(1.35,0.1,0.9),glow); fabTop.position.set(2.25,2.02,0.8); root.add(fabTop);
    const fabScreen = new THREE.Mesh(new THREE.BoxGeometry(0.94,0.66,0.08),new THREE.MeshStandardMaterial({color:0x0c2734,emissive:0x0b6b75,emissiveIntensity:0.7})); fabScreen.position.set(2.25,1.58,0.24); root.add(fabScreen);
    const lamp = new THREE.PointLight(0x5ccbd4, 1.25, 17); lamp.position.set(0,4.1,0); root.add(lamp);
    const interiorLight = new THREE.PointLight(0x7ee9d9, 0.6, 9); interiorLight.position.set(2.1,2.9,0.8); root.add(interiorLight);
  } else if (structure.type === 'storage_locker') {
    const box = new THREE.Mesh(new THREE.BoxGeometry(2.1,2.5,1.7),dark); box.position.y=1.35; root.add(box);
    const door = new THREE.Mesh(new THREE.BoxGeometry(1.75,2.12,0.08),glass); door.position.set(0,1.38,-0.88); root.add(door);
    const latch = new THREE.Mesh(new THREE.BoxGeometry(0.12,0.55,0.12),glow); latch.position.set(0.66,1.38,-0.98); root.add(latch);
  } else if (structure.type === 'solar_array') {
    const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.12,0.2,3.5,8),dark); mast.position.y=1.75; root.add(mast);
    const panelMat = new THREE.MeshStandardMaterial({color:0x245e7b,metalness:0.72,roughness:0.28,emissive:0x082d45,emissiveIntensity:0.35});
    for (const side of [-1,1]) { const panel = new THREE.Mesh(new THREE.BoxGeometry(2.2,0.12,1.6),panelMat); panel.position.set(side*1.25,3.35,0); panel.rotation.z=side*0.16; root.add(panel); }
    const beacon = new THREE.Mesh(new THREE.SphereGeometry(0.18,8,6),glow); beacon.position.y=4.1; root.add(beacon);
  }
  root.position.set(structure.x - baseX, structure.y, structure.z - baseZ);
  root.rotation.y = Number(structure.yaw) || 0;
  root.userData.structureId = structure.id;
  group.add(root);
}

function makeFanCoral(group, x, y, z, scale = 1) {
  const mat = new THREE.MeshStandardMaterial({ color: 0xc9799b, roughness: 0.88, flatShading:true, map:coralTexture });
  const root = new THREE.Group();
  for (let i = 0; i < 5; i++) {
    const branch = new THREE.Mesh(new THREE.ConeGeometry(0.12 * scale, (1.3 + i * 0.18) * scale, 5), mat);
    const a = (i / 4 - 0.5) * 1.5;
    branch.position.set(Math.sin(a) * 0.45 * scale, (0.72 + i * 0.08) * scale, 0);
    branch.rotation.z = -a * 0.72;
    root.add(branch);
  }
  root.position.set(x, y + 0.15, z); root.rotation.y = hash2(x * 3, z * 5) * Math.PI * 2; group.add(root);
}

function makeThermalVent(group, x, z, groundY) {
  const root = new THREE.Group();
  const basalt = new THREE.MeshStandardMaterial({ color:0x354b52, roughness:0.98, flatShading:true, map:rockTexture });
  const hot = new THREE.MeshStandardMaterial({ color:0xe58d51, emissive:0xb84a23, emissiveIntensity:1.4, roughness:0.55 });
  for (let i=0;i<3;i++) {
    const h = 3.5 + i * 1.1;
    const chimney = new THREE.Mesh(new THREE.CylinderGeometry(0.55+i*0.15,1.2+i*0.22,h,7),basalt);
    chimney.position.set((i-1)*1.5,h/2,Math.cos(i*2)*1.2); root.add(chimney);
    const rim = new THREE.Mesh(new THREE.TorusGeometry(0.62+i*0.14,0.15,6,12),hot);
    rim.rotation.x=Math.PI/2; rim.position.set((i-1)*1.5,h,Math.cos(i*2)*1.2); root.add(rim);
  }
  const glow = new THREE.PointLight(0xff8652,1.15,22); glow.position.y=4; root.add(glow);
  root.position.set(x,groundY,z); group.add(root);
}

function makeCrystalCluster(group, x, y, z, biomeId, seed = 0) {
  const isThermal = biomeId === 'thermal';
  const crystal = new THREE.MeshStandardMaterial({
    color: isThermal ? 0xc87956 : 0x5cb9d4,
    emissive: isThermal ? 0x7c2f1c : 0x145b83,
    emissiveIntensity: isThermal ? 0.78 : 0.95,
    metalness: 0.24,
    roughness: 0.28,
    flatShading: true
  });
  const root = new THREE.Group();
  const count = 3 + Math.floor(hash2(seed, seed + 9) * 3);
  for (let i = 0; i < count; i++) {
    const height = 1.2 + hash2(seed + i * 3, seed - i * 5) * 3.2;
    const radius = 0.18 + hash2(seed + i * 7, seed + i * 11) * 0.34;
    const shard = new THREE.Mesh(new THREE.CylinderGeometry(radius * 0.22, radius, height, 5, 1), crystal);
    shard.position.set((hash2(seed + i * 13, seed - i * 2) - 0.5) * 1.4, height * 0.48, (hash2(seed - i * 9, seed + i * 17) - 0.5) * 1.4);
    shard.rotation.z = (hash2(seed + i * 5, seed + i) - 0.5) * 0.42;
    shard.rotation.x = (hash2(seed - i, seed + i * 4) - 0.5) * 0.35;
    root.add(shard);
  }
  root.position.set(x, y, z);
  group.add(root);
}

function makeChunk(cx, cz) {
  const baseX = cx * CHUNK_SIZE, baseZ = cz * CHUNK_SIZE;
  const group = new THREE.Group();
  group.position.set(baseX, 0, baseZ);
  const segments = 16;
  const positions = [], colors = [], indices = [], uvs = [];
  const deep = new THREE.Color(0x0b3448), mid = new THREE.Color(0x286a78), sand = new THREE.Color(0xc1ad7c);
  const grass = new THREE.Color(0x527d63), rock = new THREE.Color(0x77796b);
  const color = new THREE.Color();
  for (let z = 0; z <= segments; z++) {
    for (let x = 0; x <= segments; x++) {
      const wx = baseX + (x / segments) * CHUNK_SIZE;
      const wz = baseZ + (z / segments) * CHUNK_SIZE;
      const h = heightAt(wx, wz);
      positions.push((x / segments) * CHUNK_SIZE, h, (z / segments) * CHUNK_SIZE);
      uvs.push((x / segments) * 5, (z / segments) * 5);
      if (h < -24) color.copy(deep).lerp(mid, clamp((h + 44) / 20, 0, 1));
      else if (h < -2) color.copy(mid).lerp(sand, clamp((h + 24) / 22, 0, 1));
      else if (h < 13) color.copy(sand).lerp(grass, clamp((h + 2) / 15, 0, 1));
      else color.copy(grass).lerp(rock, clamp((h - 13) / 17, 0, 1));
      const biomeTint = new THREE.Color(getBiomeAt(wx, h - 2, wz).terrain);
      color.lerp(biomeTint, 0.12);
      const variation = 0.90 + (valueNoise(wx * 0.09, wz * 0.09) + 1) * 0.09;
      colors.push(color.r * variation, color.g * variation, color.b * variation);
    }
  }
  for (let z = 0; z < segments; z++) {
    for (let x = 0; x < segments; x++) {
      const a = z * (segments + 1) + x;
      const b = a + 1, c = a + segments + 1, d = c + 1;
      indices.push(a, c, b, b, c, d);
    }
  }
  const chunkBiome = getBiomeAt(baseX + 32, -20, baseZ + 32);
  const terrainGeometry = new THREE.BufferGeometry();
  terrainGeometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  terrainGeometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  terrainGeometry.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  terrainGeometry.setIndex(indices);
  terrainGeometry.computeVertexNormals();
  const terrain = new THREE.Mesh(terrainGeometry, terrainMaterials[chunkBiome.id] || terrainMaterial);
  terrain.receiveShadow = settings.graphics === 'high';
  terrain.frustumCulled = true;
  terrain.userData.chunkTerrain = true;
  group.add(terrain);

  // Small instanced seafloor details keep draw calls low as chunks stream in and out.
  const randoms = [];
  for (let i = 0; i < 20; i++) randoms.push(hash2(cx * 101 + i * 13, cz * 103 - i * 7));
  const rocks = new THREE.InstancedMesh(rockGeometry, rockMaterial, 16);
  const kelpCapacity = chunkBiome.id === 'kelp' ? 22 : 12;
  const kelp = new THREE.InstancedMesh(kelpGeometry, kelpMaterial, kelpCapacity);
  const coral = new THREE.InstancedMesh(coralGeometry, coralMaterial, 18);
  const coralPalette = [new THREE.Color(0xd27671), new THREE.Color(0x9c7bce), new THREE.Color(0xe0ad65), new THREE.Color(0x5eafa5)];
  const dummy = new THREE.Object3D();
  let rockCount = 0, kelpCount = 0, coralCount = 0;
  for (let i = 0; i < 16; i++) {
    const wx = baseX + randoms[i % randoms.length] * CHUNK_SIZE;
    const wz = baseZ + randoms[(i + 6) % randoms.length] * CHUNK_SIZE;
    const h = heightAt(wx, wz);
    if (h > -4) continue;
    const s = 0.45 + randoms[(i + 3) % 20] * 1.2;
    dummy.position.set(wx - baseX, h + s * 0.45, wz - baseZ);
    dummy.rotation.set(randoms[(i + 2) % 20], randoms[(i + 7) % 20] * Math.PI, 0.2);
    dummy.scale.set(s, s * (0.7 + randoms[(i + 9) % 20]), s);
    dummy.updateMatrix();
    rocks.setMatrixAt(rockCount++, dummy.matrix);
  }
  rocks.count = rockCount;
  rocks.instanceMatrix.needsUpdate = true;
  if (rockCount) { rocks.castShadow=settings.graphics==='high'; rocks.receiveShadow=settings.graphics==='high'; group.add(rocks); }
  for (let i = 0; i < (chunkBiome.id === 'kelp' ? 22 : 12); i++) {
    const wx = baseX + randoms[(i + 4) % 20] * CHUNK_SIZE;
    const wz = baseZ + randoms[(i + 12) % 20] * CHUNK_SIZE;
    const h = heightAt(wx, wz);
    if (h > -7 || randoms[i] < 0.25) continue;
    const s = 0.6 + randoms[(i + 8) % 20] * 0.9;
    dummy.position.set(wx - baseX, h, wz - baseZ);
    dummy.rotation.set(0, randoms[(i + 2) % 20] * 6, (randoms[(i + 5) % 20] - 0.5) * 0.25);
    dummy.scale.set(s, s, s);
    dummy.updateMatrix();
    kelp.setMatrixAt(kelpCount++, dummy.matrix);
  }
  kelp.count = kelpCount;
  kelp.instanceMatrix.needsUpdate = true;
  if (kelpCount) group.add(kelp);
  for (let i = 0; i < 18; i++) {
    const wx = baseX + randoms[(i + 2) % 20] * CHUNK_SIZE;
    const wz = baseZ + randoms[(i + 11) % 20] * CHUNK_SIZE;
    const h = heightAt(wx, wz);
    if (h > -7 || randoms[(i + 5) % 20] < 0.32) continue;
    const scale = 0.45 + randoms[(i + 9) % 20] * 0.85;
    dummy.position.set(wx - baseX, h + scale * 0.82, wz - baseZ);
    dummy.rotation.set(0, randoms[(i + 7) % 20] * Math.PI * 2, (randoms[(i + 3) % 20] - 0.5) * 0.28);
    dummy.scale.set(scale * 0.78, scale, scale * 0.78);
    dummy.updateMatrix();
    coral.setMatrixAt(coralCount, dummy.matrix);
    coral.setColorAt(coralCount, coralPalette[Math.floor(randoms[(i + 14) % 20] * coralPalette.length)]);
    coralCount++;
  }
  coral.count = coralCount;
  coral.instanceMatrix.needsUpdate = true;
  if (coral.instanceColor) coral.instanceColor.needsUpdate = true;
  if (coralCount) group.add(coral);

  // Palm trees are only created for island centers inside this streamed chunk.
  const minIslandX = Math.floor((baseX - 100) / 280), maxIslandX = Math.floor((baseX + CHUNK_SIZE + 100) / 280);
  const minIslandZ = Math.floor((baseZ - 100) / 280), maxIslandZ = Math.floor((baseZ + CHUNK_SIZE + 100) / 280);
  for (let ix = minIslandX; ix <= maxIslandX; ix++) {
    for (let iz = minIslandZ; iz <= maxIslandZ; iz++) {
      const island = islandData(ix, iz);
      if (island.x < baseX || island.x >= baseX + CHUNK_SIZE || island.z < baseZ || island.z >= baseZ + CHUNK_SIZE) continue;
      const treeCount = 2 + Math.floor(hash2(ix + 5, iz + 2) * 3);
      for (let t = 0; t < treeCount; t++) {
        const angle = hash2(ix * 13 + t, iz * 9 - t) * Math.PI * 2;
        const radius = island.radius * (0.18 + hash2(ix + t * 7, iz + t * 5) * 0.34);
        const tx = island.x + Math.cos(angle) * radius;
        const tz = island.z + Math.sin(angle) * radius;
        const th = heightAt(tx, tz);
        if (th > 3) makePalm(group, tx - baseX, tz - baseZ, th, 0.72 + hash2(t + ix, iz - t) * 0.5);
      }
    }
  }
  if (Math.floor(shipOfInterest.x / CHUNK_SIZE) === cx && Math.floor(shipOfInterest.z / CHUNK_SIZE) === cz) makeWreck(group, baseX, baseZ);
  for (const cache of supplyCacheLocations) {
    if (Math.floor(cache.x / CHUNK_SIZE) === cx && Math.floor(cache.z / CHUNK_SIZE) === cz) makeSupplyCache(group, cache, baseX, baseZ);
  }
  // Deterministic mineral and flora nodes are streamed with their terrain chunk.
  const resourceSets = {
    reef:['titanium','copper','quartz','kelp','coral','salt','glowcap','silver'],
    kelp:['titanium','copper','kelp','coral','salt','glowcap','silver'],
    wreck:['titanium','copper','quartz','magnetite','silver'],
    thermal:['lithium','sulfur','magnetite','copper','titanium'],
    abyss:['lithium','magnetite','sulfur','quartz','glowcap'],
    open:['titanium','copper','quartz','salt','coral']
  };
  const resourceTypes = resourceSets[chunkBiome.id] || resourceSets.open;
  for (let i = 0; i < 5; i++) {
    const rx = hash2(cx * 17 + i * 23, cz * 19 - i * 11);
    const rz = hash2(cx * 29 - i * 7, cz * 31 + i * 13);
    const wx = baseX + 5 + rx * (CHUNK_SIZE - 10);
    const wz = baseZ + 5 + rz * (CHUNK_SIZE - 10);
    const ground = heightAt(wx, wz);
    if (ground < -8) makeResourceNode(group, cx, cz, i, wx - baseX, wz - baseZ, ground + 0.1, resourceTypes[Math.floor(hash2(cx + i, cz - i) * resourceTypes.length)]);
  }
  for (const [vx, vz] of BIOME_CENTERS.thermal) {
    if (Math.floor(vx / CHUNK_SIZE) === cx && Math.floor(vz / CHUNK_SIZE) === cz) makeThermalVent(group, vx - baseX, vz - baseZ, heightAt(vx, vz));
  }
  if (chunkBiome.id === 'thermal' || chunkBiome.id === 'abyss') {
    for (let i = 0; i < 2; i++) {
      const gx = baseX + 10 + hash2(cx * 37 + i * 9, cz * 17 - i) * 44;
      const gz = baseZ + 10 + hash2(cx * 19 - i * 3, cz * 41 + i) * 44;
      const ground = heightAt(gx, gz);
      if (ground < -17) makeCrystalCluster(group, gx - baseX, ground + 0.12, gz - baseZ, chunkBiome.id, cx * 101 + cz * 53 + i * 17);
    }
  }
  if (chunkBiome.id === 'reef' || chunkBiome.id === 'kelp') {
    for (let i = 0; i < 4; i++) {
      const px = 8 + hash2(cx * 31 + i, cz * 17 - i) * 48;
      const pz = 8 + hash2(cx * 13 - i, cz * 29 + i) * 48;
      const py = heightAt(baseX + px, baseZ + pz);
      if (py < -7) makeFanCoral(group, px, py, pz, 0.65 + hash2(i + cx, cz + i) * 0.8);
    }
  }
  for (const structure of placedStructures) {
    if (Math.floor(structure.x / CHUNK_SIZE) === cx && Math.floor(structure.z / CHUNK_SIZE) === cz) addBuiltStructure(group, structure, baseX, baseZ);
  }
  scene.add(group);
  chunks.set(`${cx},${cz}`, { group, terrainGeometry, cx, cz });
}

function disposeChunk(chunk) {
  scene.remove(chunk.group);
  for (const [id, node] of resourceNodes) if (node.chunkKey === `${chunk.cx},${chunk.cz}`) resourceNodes.delete(id);
  const sharedGeometries = new Set([rockGeometry, kelpGeometry, coralGeometry]);
  const sharedMaterials = new Set([terrainMaterial, ...Object.values(terrainMaterials), rockMaterial, kelpMaterial, coralMaterial]);
  const disposedGeometries = new Set();
  const disposedMaterials = new Set();
  chunk.group.traverse(object => {
    if (!object.isMesh && !object.isInstancedMesh) return;
    if (object.geometry && object.geometry !== chunk.terrainGeometry && !sharedGeometries.has(object.geometry) && !disposedGeometries.has(object.geometry)) {
      object.geometry.dispose();
      disposedGeometries.add(object.geometry);
    }
    const materials = Array.isArray(object.material) ? object.material : [object.material];
    for (const material of materials) if (material && !sharedMaterials.has(material) && !disposedMaterials.has(material)) {
      material.dispose();
      disposedMaterials.add(material);
    }
  });
  chunk.terrainGeometry.dispose();
}

function updateChunks(force = false) {
  if (!scene || !gameActive && !rendererReady) return;
  const cx = Math.floor(player.position.x / CHUNK_SIZE);
  const cz = Math.floor(player.position.z / CHUNK_SIZE);
  if (!force && cx === chunkCenterX && cz === chunkCenterZ) return;
  chunkCenterX = cx; chunkCenterZ = cz;
  const radius = clamp(Number(settings.renderDistance) || 2, 1, 3);
  for (let z = cz - radius; z <= cz + radius; z++) {
    for (let x = cx - radius; x <= cx + radius; x++) {
      const key = `${x},${z}`;
      if (!chunks.has(key)) makeChunk(x, z);
    }
  }
  for (const [key, chunk] of chunks) {
    if (Math.abs(chunk.cx - cx) > radius || Math.abs(chunk.cz - cz) > radius) {
      disposeChunk(chunk);
      chunks.delete(key);
    }
  }
}

function makeWaterAndParticles() {
  const waterGeometry = new THREE.PlaneGeometry(1900, 1900, 52, 52);
  const waterMaterial = new THREE.MeshBasicMaterial({ color: 0x68b9bd, transparent: true, opacity: 0.13, depthWrite: false, side: THREE.DoubleSide, map: causticTexture });
  water = new THREE.Mesh(waterGeometry, waterMaterial);
  water.rotation.x = -Math.PI / 2;
  water.position.y = 0;
  water.renderOrder = 2;
  scene.add(water);

  const particlePositions = [];
  for (let i = 0; i < 260; i++) particlePositions.push((Math.random() - 0.5) * 190, (Math.random() - 0.5) * 70, (Math.random() - 0.5) * 190);
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(particlePositions, 3));
  const mat = new THREE.PointsMaterial({ color: 0xc2f5f3, size: 0.32, transparent: true, opacity: 0.54, depthWrite: false, sizeAttenuation: true });
  particleGroup = new THREE.Group();
  particleGroup.add(new THREE.Points(geo, mat));
  scene.add(particleGroup);

  // Soft underwater god-rays: lightweight textured planes, not expensive volumetric fog.
  lightRayGroup = new THREE.Group();
  const rayCanvas = document.createElement('canvas'); rayCanvas.width = 32; rayCanvas.height = 256;
  const rayCtx = rayCanvas.getContext('2d');
  const gradient = rayCtx.createLinearGradient(0, 0, 0, 256);
  gradient.addColorStop(0, 'rgba(146,244,239,0.34)');
  gradient.addColorStop(0.35, 'rgba(100,211,221,0.13)');
  gradient.addColorStop(1, 'rgba(66,177,196,0)');
  rayCtx.fillStyle = gradient; rayCtx.fillRect(0, 0, 32, 256);
  const rayTexture = new THREE.CanvasTexture(rayCanvas); rayTexture.colorSpace = THREE.SRGBColorSpace;
  const rayMaterial = new THREE.MeshBasicMaterial({ map: rayTexture, color: 0xc4ffff, transparent: true, opacity: 0.62, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide });
  for (let i = 0; i < 7; i++) {
    const ray = new THREE.Mesh(new THREE.PlaneGeometry(3.5 + (i % 3) * 1.5, 42), rayMaterial);
    const angle = i / 7 * Math.PI * 2;
    ray.position.set(Math.cos(angle) * (10 + i * 1.1), -16, Math.sin(angle) * (10 + i * 1.1));
    ray.rotation.y = angle * 0.37;
    lightRayGroup.add(ray);
  }
  scene.add(lightRayGroup);
}

function createWorld() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x0b3446);
  scene.fog = new THREE.FogExp2(0x0b4051, 0.00195);
  const viewport = getGameViewportSize();
  camera = new THREE.PerspectiveCamera(settings.fov, viewport.width / viewport.height, 0.08, 1300);
  camera.position.set(0, -2.5, 11);
  try {
    renderer = new THREE.WebGLRenderer({ canvas, antialias: settings.graphics !== 'low', alpha: false, powerPreference: 'high-performance', stencil: false, depth: true });
  } catch (error) {
    const webglAvailable = Boolean(window.WebGLRenderingContext || window.WebGL2RenderingContext);
    throw new Error(webglAvailable
      ? `Inisialisasi WebGL gagal (${error?.message || 'konteks grafis tidak tersedia'})`
      : 'Perangkat atau WebView tidak mendukung WebGL 2. Aktifkan akselerasi perangkat keras dan perbarui Android System WebView.');
  }
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.shadowMap.enabled = settings.graphics === 'high';
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.2;
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, settings.graphics === 'high' ? 1.5 : settings.graphics === 'low' ? 0.8 : 1.05));
  renderer.setSize(viewport.width, viewport.height, false);
  rendererReady = true;

  const hemi = new THREE.HemisphereLight(0xb8f2f2, 0x071b2a, 1.9);
  scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xb9f7f0, 1.65);
  sun.position.set(-60, 110, 40);
  sun.castShadow=settings.graphics==='high';
  sun.shadow.mapSize.set(1024,1024);
  sun.shadow.camera.left=-110; sun.shadow.camera.right=110; sun.shadow.camera.top=110; sun.shadow.camera.bottom=-110;
  sun.shadow.bias=-0.00018;
  scene.add(sun);
  const fill = new THREE.PointLight(0x287f9e, 1.5, 220);
  fill.position.set(20, -10, 20); scene.add(fill);
  const rim = new THREE.PointLight(0x56c7c6, 0.85, 90); rim.position.set(-32, -22, -28); scene.add(rim);

  terrainTexture = makeProceduralTexture('sand',256); terrainTexture.repeat.set(4, 4);
  rockTexture = makeProceduralTexture('stone',256); rockTexture.repeat.set(1.8, 1.8);
  kelpTexture = makeProceduralTexture('kelp',256); kelpTexture.repeat.set(1, 2);
  coralTexture = makeProceduralTexture('coral',256); coralTexture.repeat.set(1, 1);
  woodTexture = makeProceduralTexture('wood',256); woodTexture.repeat.set(2, 1);
  metalTexture = makeProceduralTexture('metal',256); metalTexture.repeat.set(1, 1);
  terrainBumpTexture=makeHeightTexture('sand',256); terrainBumpTexture.repeat.set(4,4);
  rockBumpTexture=makeHeightTexture('stone',256); rockBumpTexture.repeat.set(1.8,1.8);
  kelpBumpTexture=makeHeightTexture('kelp',256); kelpBumpTexture.repeat.set(1,2);
  coralBumpTexture=makeHeightTexture('coral',256);
  woodBumpTexture=makeHeightTexture('wood',256); woodBumpTexture.repeat.set(2,1);
  metalBumpTexture=makeHeightTexture('metal',256);
  causticTexture = makeCausticTexture(256);
  terrainMaterial = new THREE.MeshStandardMaterial({ vertexColors: true, map: terrainTexture, bumpMap:terrainBumpTexture, bumpScale:0.15, roughness: 0.96, metalness: 0.01, side: THREE.DoubleSide, flatShading: false });
  terrainMaterials = {
    reef: new THREE.MeshStandardMaterial({vertexColors:true,map:coralTexture,bumpMap:coralBumpTexture,bumpScale:0.10,roughness:0.91,side:THREE.DoubleSide}),
    kelp: new THREE.MeshStandardMaterial({vertexColors:true,map:kelpTexture,bumpMap:kelpBumpTexture,bumpScale:0.12,roughness:0.95,side:THREE.DoubleSide}),
    wreck: new THREE.MeshStandardMaterial({vertexColors:true,map:rockTexture,bumpMap:rockBumpTexture,bumpScale:0.24,roughness:0.97,side:THREE.DoubleSide}),
    thermal: new THREE.MeshStandardMaterial({vertexColors:true,map:metalTexture,bumpMap:metalBumpTexture,bumpScale:0.16,roughness:0.82,metalness:0.08,side:THREE.DoubleSide}),
    abyss: new THREE.MeshStandardMaterial({vertexColors:true,map:rockTexture,bumpMap:rockBumpTexture,bumpScale:0.2,roughness:0.99,side:THREE.DoubleSide}),
    open: terrainMaterial
  };
  rockGeometry = new THREE.DodecahedronGeometry(1.5, 1);
  rockMaterial = new THREE.MeshStandardMaterial({ color: 0x91aeb1, map: rockTexture, bumpMap:rockBumpTexture, bumpScale:0.22, roughness: 0.96, flatShading: true });
  kelpGeometry = new THREE.CylinderGeometry(0.08,0.46,4.2,9,6,true);
  kelpGeometry.translate(0,2.1,0);
  kelpMaterial = new THREE.MeshStandardMaterial({ color: 0x5ab995, map: kelpTexture, bumpMap:kelpBumpTexture, bumpScale:0.08, roughness: 0.88, flatShading: false, side: THREE.DoubleSide });
  kelpMaterial.onBeforeCompile = shader => {
    shader.uniforms.uAbyssTime={value:0};
    shader.vertexShader=shader.vertexShader.replace('#include <common>','#include <common>\nuniform float uAbyssTime;');
    shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nfloat kelpWeight = clamp(position.y / 4.2, 0.0, 1.0);\ntransformed.x += sin(uAbyssTime * 1.25 + position.y * 1.35) * 0.16 * kelpWeight;\ntransformed.z += cos(uAbyssTime * 0.9 + position.y * 1.1) * 0.07 * kelpWeight;');
    kelpShader=shader;
  };
  coralGeometry = new THREE.ConeGeometry(0.72, 2.1, 9, 2);
  coralMaterial = new THREE.MeshStandardMaterial({ color: 0xffffff, map: coralTexture, bumpMap:coralBumpTexture, bumpScale:0.12, roughness: 0.92, flatShading: false });
  makeWaterAndParticles();
  makePlayer();
  playerGroup.visible = false; // First-person only; no third-person diver model.
  makeFirstPersonViewModel();
  faunaDirector = new FaunaDirector(scene, applyDamage, heightAt);
  faunaDirector.setQuality(settings.graphics);
  updateChunks(true);
  applySettings();
}

function getCurrentMission() {
  return MISSION_SEQUENCE[clamp(storyState.missionIndex || 0, 0, MISSION_SEQUENCE.length - 1)];
}

function updateMissionUI() {
  const mission = getCurrentMission();
  const title = $('mission-title');
  const objective = $('mission-objective');
  const progress = $('mission-progress');
  if (title) title.textContent = mission.title;
  if (objective) objective.textContent = mission.objective;
  if (progress) {
    const count = mission.id === 'materials' ? `${Math.min(3, storyState.counters?.materials || 0)}/3 COLLECTED` : `DIRECTIVE ${Math.min(storyState.missionIndex + 1, MISSION_SEQUENCE.length)}/${MISSION_SEQUENCE.length}`;
    progress.textContent = count;
  }
  const root = $('mission-log');
  if (root) {
    root.replaceChildren();
    MISSION_SEQUENCE.forEach((entry, index) => {
      const card = document.createElement('article');
      const complete = (storyState.completed || []).includes(entry.id);
      const active = index === storyState.missionIndex;
      card.className = `pda-entry ${complete ? 'is-known' : 'is-unknown'}`;
      const heading = document.createElement('strong');
      heading.textContent = `${complete ? '✓ ' : active ? '▸ ' : '○ '}${entry.title}`;
      const note = document.createElement('p');
      note.textContent = entry.objective;
      const status = document.createElement('small');
      status.textContent = complete ? 'DIRECTIVE COMPLETE' : active ? 'ACTIVE DIRECTIVE' : 'LOCKED / PENDING';
      card.append(heading, note, status);
      root.append(card);
    });
  }
}

function speakRadio(speaker, text, cinematic = false) {
  const speakerNode = $(cinematic ? 'cinematic-speaker' : 'radio-speaker');
  const lineNode = $(cinematic ? 'cinematic-line' : 'radio-line');
  if (speakerNode) speakerNode.textContent = speaker;
  if (lineNode) lineNode.textContent = text;
  if (!cinematic) {
    $('radio-subtitle')?.classList.remove('hidden');
    clearTimeout(radioHideTimer);
    radioHideTimer = setTimeout(() => $('radio-subtitle')?.classList.add('hidden'), 5600);
  }
  playSfx('radio');
  try {
    if ('speechSynthesis' in window && typeof SpeechSynthesisUtterance !== 'undefined') {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = settings.language === 'id' ? 'id-ID' : 'en-US';
      utterance.rate = 0.91;
      utterance.pitch = 0.88;
      utterance.volume = clamp(settings.volume / 100, 0, 1);
      const voices = window.speechSynthesis.getVoices?.() || [];
      const voice = voices.find(item => item.lang?.toLowerCase().startsWith(settings.language === 'id' ? 'id' : 'en'));
      if (voice) utterance.voice = voice;
      window.speechSynthesis.speak(utterance);
    }
  } catch (error) {
    console.info('Voice synthesis unavailable; subtitles remain enabled.', error);
  }
}

function advanceMission(eventId) {
  const mission = getCurrentMission();
  if (!mission || mission.id !== eventId || mission.id === 'freeplay') return false;
  storyState.completed = Array.isArray(storyState.completed) ? storyState.completed : [];
  if (!storyState.completed.includes(mission.id)) storyState.completed.push(mission.id);
  storyState.missionIndex = Math.min(storyState.missionIndex + 1, MISSION_SEQUENCE.length - 1);
  speakRadio('ABYSSAL GUIDANCE', mission.done);
  updateMissionUI();
  playSfx('discovery');
  if (activeSlot >= 0) markUnsaved();
  const next = getCurrentMission();
  if (next && next.id !== 'freeplay') setTimeout(() => speakRadio('MISSION UPDATE', next.objective), 1200);
  return true;
}

function recordMissionMaterial() {
  if (getCurrentMission()?.id !== 'materials') return;
  storyState.counters.materials = Math.min(3, (storyState.counters.materials || 0) + 1);
  updateMissionUI();
  if (storyState.counters.materials >= 3) advanceMission('materials');
  else markUnsaved();
}

function makeLifePod() {
  if (lifepodGroup) { scene.remove(lifepodGroup); disposeObjectTree(lifepodGroup); lifepodGroup = null; }
  const root = new THREE.Group();
  const shellMat = new THREE.MeshStandardMaterial({ color:0xe6e5d7, map:metalTexture, bumpMap:metalBumpTexture, bumpScale:0.075, roughness:0.74, metalness:0.18, transparent:true, opacity:0.34, side:THREE.DoubleSide });
  const orangeMat = new THREE.MeshStandardMaterial({ color:0xd88445, map:metalTexture, roughness:0.52, metalness:0.28, emissive:0x4b1908, emissiveIntensity:0.12 });
  const glassMat = new THREE.MeshPhysicalMaterial({ color:0x83dce0, roughness:0.12, metalness:0.12, transparent:true, opacity:0.66, transmission:0.12 });
  const body = new THREE.Mesh(new THREE.CylinderGeometry(1.42,1.55,3.4,16,1), shellMat);
  body.rotation.x = Math.PI / 2; body.position.z = 0.15; root.add(body);
  const nose = new THREE.Mesh(new THREE.SphereGeometry(1.43,16,10,0,Math.PI*2,0,Math.PI/2), shellMat);
  nose.position.z = -1.55; nose.rotation.x = -Math.PI/2; root.add(nose);
  const rear = new THREE.Mesh(new THREE.ConeGeometry(1.52,1.25,16), orangeMat); rear.rotation.x = Math.PI/2; rear.position.z = 2.35; root.add(rear);
  const windowMesh = new THREE.Mesh(new THREE.CircleGeometry(0.56,20), glassMat); windowMesh.position.set(0,0.16,-1.0); windowMesh.rotation.y = Math.PI; root.add(windowMesh);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(1.48,0.10,8,28), orangeMat); ring.rotation.x = Math.PI/2; ring.position.z = 0.75; root.add(ring);
  const finMat = new THREE.MeshStandardMaterial({color:0x385866,map:metalTexture,bumpMap:metalBumpTexture,roughness:0.68,metalness:0.45});
  for(let i=0;i<4;i++){
    const fin = new THREE.Mesh(new THREE.BoxGeometry(0.22,1.15,1.5),finMat);
    const angle=i*Math.PI/2; fin.position.set(Math.cos(angle)*1.4,Math.sin(angle)*1.4,1.35); fin.rotation.z=angle; root.add(fin);
  }
  const consoleMaterial = new THREE.MeshStandardMaterial({color:0x4b3428,emissive:0xc05a22,emissiveIntensity:0.72});
  const console = new THREE.Mesh(new THREE.BoxGeometry(0.62,0.52,0.12),consoleMaterial);
  console.position.set(0,-0.45, 1.65); root.add(console);
  root.userData.consoleMaterial = consoleMaterial;
  const lamp = new THREE.PointLight(0x54e9df,1.35,18); lamp.position.set(0,1.1,0.2); root.add(lamp);
  // The Lifepod includes its own powered fabricator and interior oxygen supply.
  const interiorMetal = new THREE.MeshStandardMaterial({color:0x294653,metalness:0.55,roughness:0.62});
  const interiorGlow = new THREE.MeshStandardMaterial({color:0x6df3e6,emissive:0x1a9e9b,emissiveIntensity:1.4});
  const fab = new THREE.Mesh(new THREE.BoxGeometry(0.72,0.76,0.50),interiorMetal); fab.position.set(0.70,-0.78,-0.28); root.add(fab);
  const fabScreen = new THREE.Mesh(new THREE.BoxGeometry(0.48,0.34,0.045),new THREE.MeshStandardMaterial({color:0x0c2633,emissive:0x0e717b,emissiveIntensity:0.9})); fabScreen.position.set(0.70,-0.51,-0.55); root.add(fabScreen);
  const fabTrim = new THREE.Mesh(new THREE.BoxGeometry(0.60,0.05,0.06),interiorGlow); fabTrim.position.set(0.70,-0.98,-0.55); root.add(fabTrim);
  const oxygenOutlet = new THREE.Mesh(new THREE.CylinderGeometry(0.17,0.17,0.12,12),interiorGlow); oxygenOutlet.rotation.x=Math.PI/2; oxygenOutlet.position.set(0.38,-0.05,1.22); root.add(oxygenOutlet);
  const interiorLamp = new THREE.PointLight(0x70e9e0,0.62,7); interiorLamp.position.set(0,0.92,0.15); root.add(interiorLamp);
  root.position.set(0,-8,-7.5);
  root.rotation.y = 0.18;
  root.userData.isLifepod = true;
  scene.add(root);
  lifepodGroup = root;
  return root;
}

function createIntroCapsule() {
  const pod = new THREE.Group();
  const shell = new THREE.MeshStandardMaterial({color:0xe4e3d7,map:metalTexture,bumpMap:metalBumpTexture,bumpScale:0.08,roughness:0.7,metalness:0.22});
  const orange = new THREE.MeshStandardMaterial({color:0xe18a43,map:metalTexture,roughness:0.55,metalness:0.22,emissive:0x7b2d0a,emissiveIntensity:0.18});
  const glass = new THREE.MeshStandardMaterial({color:0x8fe8eb,roughness:0.16,metalness:0.16,transparent:true,opacity:0.7});
  const body = new THREE.Mesh(new THREE.CylinderGeometry(1.45,1.55,3.6,16),shell); body.rotation.x=Math.PI/2; pod.add(body);
  const front = new THREE.Mesh(new THREE.SphereGeometry(1.46,16,10,0,Math.PI*2,0,Math.PI/2),shell); front.position.z=-1.75; front.rotation.x=-Math.PI/2; pod.add(front);
  const rim = new THREE.Mesh(new THREE.TorusGeometry(1.48,0.12,8,24),orange); rim.rotation.x=Math.PI/2; rim.position.z=0.95; pod.add(rim);
  const port = new THREE.Mesh(new THREE.CircleGeometry(0.58,20),glass); port.position.z=-1.35; pod.add(port);
  const nozzle = new THREE.Mesh(new THREE.ConeGeometry(0.86,1.5,12),orange); nozzle.rotation.x=-Math.PI/2; nozzle.position.z=2.3; pod.add(nozzle);
  const glow = new THREE.PointLight(0xffa45e,1.8,18); glow.position.z=2.2; pod.add(glow);
  return pod;
}

function createIntroSet() {
  const group = new THREE.Group();
  const metal = new THREE.MeshStandardMaterial({color:0x476b77,map:metalTexture,bumpMap:metalBumpTexture,bumpScale:0.1,metalness:0.58,roughness:0.62});
  const pale = new THREE.MeshStandardMaterial({color:0xd5e5df,map:metalTexture,bumpMap:metalBumpTexture,bumpScale:0.05,metalness:0.22,roughness:0.72});
  const glass = new THREE.MeshPhysicalMaterial({color:0x67c8d0,roughness:0.12,metalness:0.1,transparent:true,opacity:0.36,transmission:0.18});
  const amber = new THREE.MeshStandardMaterial({color:0xf18c4b,emissive:0x9a3c16,emissiveIntensity:0.7});
  const base = new THREE.Group();
  base.position.set(0,3,-34);
  const platform = new THREE.Mesh(new THREE.CylinderGeometry(17,18,2.1,32),metal); platform.position.y=-1; base.add(platform);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(16.5,0.35,10,48),amber); ring.rotation.x=Math.PI/2; ring.position.y=0.2; base.add(ring);
  const hub = new THREE.Mesh(new THREE.CylinderGeometry(5.8,7.2,6.4,20),pale); hub.position.y=3.3; base.add(hub);
  const dome = new THREE.Mesh(new THREE.SphereGeometry(6.0,20,12,0,Math.PI*2,0,Math.PI/2),glass); dome.position.y=6.4; base.add(dome);
  const antenna = new THREE.Mesh(new THREE.CylinderGeometry(0.16,0.24,12,8),metal); antenna.position.set(0,12,0); base.add(antenna);
  for(let i=0;i<6;i++){
    const a=i*Math.PI/3; const tower=new THREE.Group();
    const leg=new THREE.Mesh(new THREE.CylinderGeometry(0.65,1.0,8,8),pale); leg.position.y=1.2; tower.add(leg);
    const windowBand=new THREE.Mesh(new THREE.BoxGeometry(2.2,1.1,1.0),glass); windowBand.position.y=2.4; tower.add(windowBand);
    tower.position.set(Math.cos(a)*11,0,Math.sin(a)*11); base.add(tower);
    const lamp=new THREE.PointLight(0x72eee1,1.8,18); lamp.position.set(Math.cos(a)*11,3,Math.sin(a)*11); base.add(lamp);
  }
  group.add(base);
  const attacker = new THREE.Group();
  const shadowMat = new THREE.MeshStandardMaterial({color:0x122936,roughness:0.4,metalness:0.12,emissive:0x071822,emissiveIntensity:0.32});
  const glowMat = new THREE.MeshStandardMaterial({color:0x67c9c7,emissive:0x35aaa9,emissiveIntensity:2.2});
  const body = new THREE.Mesh(new THREE.SphereGeometry(1,18,12),shadowMat); body.scale.set(6.8,3.1,10.5); attacker.add(body);
  for(let i=0;i<4;i++){
    const fin=new THREE.Mesh(new THREE.ConeGeometry(1.25,7,7),shadowMat); fin.position.set((i%2?1:-1)*4.8,-0.7,(i<2?-1:1)*5.8); fin.rotation.z=(i%2?1:-1)*0.8; fin.rotation.x=(i<2?0.5:-0.5); attacker.add(fin);
  }
  for(let i=0;i<6;i++){
    const tendril=new THREE.Mesh(new THREE.CylinderGeometry(0.12,0.035,6.8,7),shadowMat); tendril.position.set(Math.cos(i*Math.PI/3)*4,-2.7,Math.sin(i*Math.PI/3)*5); tendril.rotation.z=Math.cos(i*Math.PI/3)*0.6; tendril.rotation.x=Math.sin(i*Math.PI/3)*0.5; attacker.add(tendril);
  }
  for(const side of [-1,1]){const eye=new THREE.Mesh(new THREE.SphereGeometry(0.34,10,8),glowMat);eye.position.set(side*2.2,0.45,-8.6);attacker.add(eye);}
  attacker.position.set(38,0,-31); group.add(attacker);
  const pod = createIntroCapsule(); pod.position.set(-2,13,10); pod.rotation.set(0.05,0.3,-0.04); group.add(pod);
  scene.add(group);
  return {group,base,attacker,pod,lights:base.children.filter(child=>child.isPointLight)};
}

function setCinematicLine(index) {
  const lines = [
    ['ARRAY CONTROL','Pelagic Research Array. Semua sistem nominal. Selamat datang, penyelam.'],
    ['WARNING SYSTEM','Peringatan. Anomali raksasa terdeteksi mendekati struktur luar.'],
    ['ARRAY CONTROL','Perisai luar gagal. Tekanan struktur meningkat. Protokol evakuasi diaktifkan.'],
    ['EVACUATION SYSTEM','Kapsul darurat dilepas. Masuk ke air dan aktifkan suar penyelamat.'],
    ['ABYSSAL GUIDANCE','Kau selamat dari keruntuhan. Temukan kapsulmu, pulihkan sistem, dan bertahan hidup.']
  ];
  const line=lines[index]; if(!line) return;
  $('cinematic-speaker').textContent=line[0]; $('cinematic-line').textContent=line[1];
  $('radio-subtitle')?.classList.add('hidden');
  clearTimeout(radioHideTimer);
}

function startIntroCinematic() {
  if (storyState.introSeen || introSequence.active) return;
  const set=createIntroSet();
  introSequence={active:true,elapsed:0,...set,debrisSpawned:false,lineIndex:-1};
  $('cinematic-overlay')?.classList.remove('hidden');
  $('radio-subtitle')?.classList.add('hidden');
  $('hud')?.classList.add('hidden');
  camera.position.set(0,15,28); camera.lookAt(0,4,-34);
  updateMissionUI();
  setCinematicLine(0); introSequence.lineIndex=0;
}

function makeIntroDebris(position, count=22) {
  const geometry=new THREE.IcosahedronGeometry(0.26,0);
  introDebrisResources.push(geometry);
  for(let i=0;i<count;i++){
    const material=new THREE.MeshStandardMaterial({color:0x9b8170,roughness:0.82,metalness:0.28,emissive:0x6c321a,emissiveIntensity:0.18});
    introDebrisResources.push(material);
    const mesh=new THREE.Mesh(geometry,material);
    mesh.position.copy(position).add(new THREE.Vector3((Math.random()-0.5)*10,(Math.random()-0.5)*7,(Math.random()-0.5)*10));
    const velocity=new THREE.Vector3((Math.random()-0.5)*11,Math.random()*8+2,(Math.random()-0.5)*10);
    scene.add(mesh); introDebris.push({mesh,velocity,age:0});
  }
}

function disposeIntroSet() {
  if(introSequence.group){
    scene.remove(introSequence.group);
    introSequence.group.traverse(object=>{
      if(object.isMesh){object.geometry?.dispose(); if(Array.isArray(object.material)) object.material.forEach(material=>material.dispose()); else object.material?.dispose();}
    });
  }
  for(const item of introDebris)scene.remove(item.mesh);
  introDebris=[];
  for(const resource of introDebrisResources)resource.dispose();
  introDebrisResources=[];
  introSequence={active:false,elapsed:0,group:null,base:null,attacker:null,pod:null,lights:[],debrisSpawned:false,lineIndex:-1};
  try{window.speechSynthesis?.cancel();}catch{}
}

function finishIntroCinematic() {
  if(!introSequence.active) return;
  disposeIntroSet();
  $('cinematic-overlay')?.classList.add('hidden');
  $('radio-subtitle')?.classList.add('hidden');
  $('hud')?.classList.remove('hidden');
  storyState.introSeen=true;
  storyState.missionIndex=0;
  storyState.counters={materials:0};
  storyState.completed=[];
  player.position.set(0,-7,0); player.velocity.set(0,0,0); player.yaw=0; player.pitch=0.08;
  makeLifePod();
  updateMissionUI(); updateCamera(0.016); updateHud();
  speakRadio('ABYSSAL GUIDANCE','Lifepod terdeteksi di depanmu. Dekati kapsul dan aktifkan konsol darurat.');
  markUnsaved();
}

function updateCinematic(dt) {
  introSequence.elapsed+=dt;
  const t=introSequence.elapsed;
  const lineAt=[0,5.5,9.3,13.2,19.5];
  for(let i=lineAt.length-1;i>=0;i--){if(t>=lineAt[i] && introSequence.lineIndex<i){introSequence.lineIndex=i;setCinematicLine(i);break;}}
  const attackProgress=smoothstep(5.8,10.2,t);
  introSequence.attacker.position.set(lerp(38,9,attackProgress),Math.sin(t*2)*0.8,lerp(-31,-32,attackProgress));
  introSequence.attacker.rotation.y=Math.sin(t*0.75)*0.12;
  introSequence.attacker.rotation.z=Math.sin(t*1.1)*0.06;
  if(t>9.6 && !introSequence.debrisSpawned){
    introSequence.debrisSpawned=true;
    makeIntroDebris(new THREE.Vector3(-1,5,-34),34);
    playSfx('impact');
  }
  if(t>9.6){
    const flash=0.5+Math.sin(t*17)*0.5;
    introSequence.lights.forEach(light=>{light.intensity=0.35+flash*2.2;});
    introSequence.base.rotation.z=Math.sin((t-9.6)*1.1)*Math.min(0.18,(t-9.6)*0.025);
  }
  const podProgress=smoothstep(12.5,22.8,t);
  introSequence.pod.position.set(-2+Math.sin(t*2)*0.22,lerp(13,-7.2,podProgress),10-9*podProgress);
  introSequence.pod.rotation.set(Math.sin(t*2.3)*0.05,0.3+Math.sin(t)*0.08,Math.sin(t*1.6)*0.07);
  if(t>14 && Math.floor(t*3)%3===0 && Math.random()<dt*2.2){makeIntroDebris(introSequence.pod.position.clone(),2);}
  for(let i=introDebris.length-1;i>=0;i--){
    const item=introDebris[i];item.age+=dt;item.velocity.y-=5.4*dt;item.velocity.multiplyScalar(Math.exp(-0.55*dt));item.mesh.position.addScaledVector(item.velocity,dt);item.mesh.rotation.x+=dt*1.7;item.mesh.rotation.z+=dt*1.3;
    if(item.age>3.2){scene.remove(item.mesh);introDebris.splice(i,1);}
  }
  if(t<6.0){camera.position.lerp(new THREE.Vector3(0,14,25),1-Math.exp(-dt*0.7));camera.lookAt(0,3,-34);}
  else if(t<13){camera.position.lerp(new THREE.Vector3(18,5,1),1-Math.exp(-dt*0.5));camera.lookAt(introSequence.attacker.position);}
  else {const follow=introSequence.pod.position;camera.position.lerp(new THREE.Vector3(follow.x+7,follow.y+4,follow.z+13),1-Math.exp(-dt*1.1));camera.lookAt(follow);}
  if(t>23.8) finishIntroCinematic();
}

function createDropMaterial(type) {
  if(dropMaterials.has(type)) return dropMaterials.get(type);
  const colors={titanium:0xb5c4c7,copper:0xc47b4b,quartz:0xc9ffff,kelp:0x57c99a,coral:0xe38bb8,lithium:0xb9a9ed,sulfur:0xf1d36b,magnetite:0x607f9b,salt:0xecf7ee,glowcap:0x8df1dc,fish_meat:0xe7a27f};
  const color=colors[type]||0x9fc5c4;
  const material=new THREE.MeshStandardMaterial({color,map:type==='kelp'?kelpTexture:type==='coral'||type==='glowcap'?coralTexture:rockTexture,roughness:0.48,metalness:['titanium','copper','magnetite'].includes(type)?0.42:0.08,emissive:color,emissiveIntensity:type==='quartz'||type==='glowcap'?0.22:0.035});
  dropMaterials.set(type,material);return material;
}

function disposeWorldDrop(drop) {
  if (!drop?.mesh) return;
  scene?.remove(drop.mesh);
  disposeObjectTree(drop.mesh, {
    geometries: dropGeometry ? [dropGeometry] : [],
    materials: dropMaterials.has(drop.type) ? [dropMaterials.get(drop.type)] : []
  });
}

function spawnWorldDrop(type, position, amount=1) {
  for(let i=0;i<clamp(amount,1,4);i++){
    const mesh=new THREE.Group();
    if(type==='glowcap'){
      const stem=new THREE.Mesh(new THREE.CylinderGeometry(0.09,0.12,0.38,7),new THREE.MeshStandardMaterial({color:0xd7c9a6,roughness:0.9}));stem.position.y=0.1;mesh.add(stem);
      const cap=new THREE.Mesh(new THREE.SphereGeometry(0.28,9,7,0,Math.PI*2,0,Math.PI*0.58),createDropMaterial(type));cap.scale.y=0.78;cap.position.y=0.28;mesh.add(cap);
    } else {
      const geo=dropGeometry || (dropGeometry=new THREE.IcosahedronGeometry(0.26,1));
      const item=new THREE.Mesh(geo,createDropMaterial(type));item.scale.set(type==='fish_meat'?1.25:1,type==='fish_meat'?0.62:0.82,type==='fish_meat'?0.72:1);mesh.add(item);
    }
    mesh.position.copy(position).add(new THREE.Vector3((Math.random()-0.5)*0.55,0.6+Math.random()*0.35,(Math.random()-0.5)*0.55));
    const velocity=new THREE.Vector3((Math.random()-0.5)*2.1,1.4+Math.random()*2.0,(Math.random()-0.5)*2.1);
    const id=`drop-${Date.now()}-${Math.floor(Math.random()*1e8)}`;
    scene.add(mesh);floatingDrops.push({id,type,amount:1,mesh,velocity,age:0,settled:false});
  }
  while (floatingDrops.length > 80) disposeWorldDrop(floatingDrops.shift());
}

function restoreWorldDrops(records=[]) {
  for(const drop of floatingDrops) disposeWorldDrop(drop);
  floatingDrops=[];
  for(const record of Array.isArray(records)?records.slice(0,80):[]){
    if(!RESOURCE_LABELS[record.type]||!record.position)continue;
    const mesh=new THREE.Group();
    if(record.type==='glowcap'){
      const stem=new THREE.Mesh(new THREE.CylinderGeometry(0.09,0.12,0.38,7),new THREE.MeshStandardMaterial({color:0xd7c9a6,roughness:0.9}));stem.position.y=0.1;mesh.add(stem);
      const cap=new THREE.Mesh(new THREE.SphereGeometry(0.28,9,7,0,Math.PI*2,0,Math.PI*0.58),createDropMaterial(record.type));cap.scale.y=0.78;cap.position.y=0.28;mesh.add(cap);
    }else{const item=new THREE.Mesh(dropGeometry||(dropGeometry=new THREE.IcosahedronGeometry(0.26,1)),createDropMaterial(record.type));mesh.add(item);}
    mesh.position.set(Number(record.position.x)||0,Number(record.position.y)||-8,Number(record.position.z)||0);scene.add(mesh);
    floatingDrops.push({id:record.id||`restored-${Math.random()}`,type:record.type,amount:1,mesh,velocity:new THREE.Vector3(),age:0,settled:true});
  }
}

function nearestDrop(maxDistance=4.8){
  let best=null;
  for(const drop of floatingDrops){const distance=player.position.distanceTo(drop.mesh.position);if(distance<maxDistance&&(!best||distance<best.distance))best={...drop,distance};}
  return best;
}

function spawnDebrisBurst(position,color=0x9cb7b6,count=8){
  const geometry=debrisGeometry||(debrisGeometry=new THREE.IcosahedronGeometry(0.19,0));
  for(let i=0;i<count;i++){
    const material=new THREE.MeshStandardMaterial({color,roughness:0.78,metalness:0.12});
    const mesh=new THREE.Mesh(geometry,material);mesh.position.copy(position);mesh.scale.setScalar(0.45+Math.random()*1.2);scene.add(mesh);
    physicsDebris.push({mesh,velocity:new THREE.Vector3((Math.random()-0.5)*4,Math.random()*3.8+0.6,(Math.random()-0.5)*4),age:0,material});
  }
}

function updateWorldPhysics(dt){
  for(let i=floatingDrops.length-1;i>=0;i--){
    const drop=floatingDrops[i];drop.age+=dt;
    if(!drop.settled){
      drop.velocity.y-=5.2*dt;drop.velocity.addScaledVector(new THREE.Vector3(0,1.5,0),dt);drop.velocity.multiplyScalar(Math.exp(-1.35*dt));
      drop.mesh.position.addScaledVector(drop.velocity,dt);
      const floor=heightAt(drop.mesh.position.x,drop.mesh.position.z)+0.34;
      if(drop.mesh.position.y<floor){drop.mesh.position.y=floor;drop.velocity.y=Math.abs(drop.velocity.y)*0.19;drop.velocity.x*=0.56;drop.velocity.z*=0.56;if(Math.abs(drop.velocity.y)<0.24){drop.velocity.set(0,0,0);drop.settled=true;}}
      drop.mesh.rotation.x+=dt*1.1;drop.mesh.rotation.y+=dt*1.5;
    }else{drop.mesh.position.y+=Math.sin(clockState.elapsed*1.8+drop.mesh.position.x)*dt*0.025;drop.mesh.rotation.y+=dt*0.22;}
    if(drop.age>900){disposeWorldDrop(drop);floatingDrops.splice(i,1);}
  }
  for(let i=physicsDebris.length-1;i>=0;i--){
    const item=physicsDebris[i];item.age+=dt;item.velocity.y-=7.2*dt;item.velocity.multiplyScalar(Math.exp(-0.9*dt));item.mesh.position.addScaledVector(item.velocity,dt);item.mesh.rotation.x+=dt*2.2;item.mesh.rotation.y+=dt*1.7;
    const floor=heightAt(item.mesh.position.x,item.mesh.position.z)+0.1;
    if(item.mesh.position.y<floor){item.mesh.position.y=floor;item.velocity.y=Math.abs(item.velocity.y)*0.16;item.velocity.x*=0.4;item.velocity.z*=0.4;}
    if(item.age>2.8){scene.remove(item.mesh);item.mesh.material.dispose();physicsDebris.splice(i,1);}
  }
}

function updateMissionInteractions() {
  // Mission interactions use the same contextual Interact control as objects in the world.
}

function activateLifepod(){
  const inside=getInsideHabitat();
  if(!lifepodGroup||!inside||inside.type!=='lifepod'||!isNearInteriorPoint(inside,0,1.65,1.05)){showToast('Masuk ke dalam Lifepod dan dekati konsol yang rusak.');return;}
  if(!ownedTools.includes('repair_tool')||getSelectedHotbarItem()!=='repair_tool'){showToast('Buat Repair Tool di Fabricator, lalu pilih alat itu pada Quick Slot.');return;}
  triggerToolAnimation('repair');
  const consoleMaterial=lifepodGroup.userData?.consoleMaterial;
  if(consoleMaterial){consoleMaterial.color.setHex(0x173f43);consoleMaterial.emissive.setHex(0x18c9b8);consoleMaterial.emissiveIntensity=1.25;}
  playSfx('craft');
  advanceMission('lifepod');
}

function beginIntroDebriefForOldSave(){
  storyState={...STORY_DEFAULTS,introSeen:true,missionIndex:1,counters:{materials:0},completed:['lifepod']};
  updateMissionUI();
}

function startAmbient() {
  if (ambientContext) return;
  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  if (!AudioCtx) return;
  try {
    ambientContext = new AudioCtx();
    const osc = ambientContext.createOscillator();
    const filter = ambientContext.createBiquadFilter();
    ambientGain = ambientContext.createGain();
    osc.type = 'sine'; osc.frequency.value = 58;
    filter.type = 'lowpass'; filter.frequency.value = 130;
    ambientGain.gain.value = 0;
    osc.connect(filter); filter.connect(ambientGain); ambientGain.connect(ambientContext.destination);
    osc.start();
    ambientOscillators = [osc];
    const drone2 = ambientContext.createOscillator();
    const drone2Gain = ambientContext.createGain();
    drone2.type = 'triangle'; drone2.frequency.value = 87; drone2Gain.gain.value = 0.12;
    drone2.connect(drone2Gain); drone2Gain.connect(ambientGain); drone2.start(); ambientOscillators.push(drone2);
    const lfo = ambientContext.createOscillator();
    const lfoGain = ambientContext.createGain();
    lfo.type = 'sine'; lfo.frequency.value = 0.11; lfoGain.gain.value = 0.008;
    lfo.connect(lfoGain); lfoGain.connect(ambientGain.gain); lfo.start();
    const buffer = ambientContext.createBuffer(1, ambientContext.sampleRate * 2, ambientContext.sampleRate);
    const channel = buffer.getChannelData(0);
    for (let i = 0; i < channel.length; i++) channel[i] = (Math.random() * 2 - 1) * 0.16;
    const noise = ambientContext.createBufferSource();
    const noiseFilter = ambientContext.createBiquadFilter();
    soundNoiseGain = ambientContext.createGain();
    noise.buffer = buffer; noise.loop = true; noiseFilter.type = 'lowpass'; noiseFilter.frequency.value = 320;
    soundNoiseGain.gain.value = 0.012;
    noise.connect(noiseFilter); noiseFilter.connect(soundNoiseGain); soundNoiseGain.connect(ambientContext.destination); noise.start();
    updateAmbientVolume();
  } catch { ambientContext = null; }
}
function updateAmbientVolume() {
  if (ambientGain && ambientContext) {
    const target = (settings.volume / 100) * 0.035;
    ambientGain.gain.setTargetAtTime(target, ambientContext.currentTime, 0.12);
    if (soundNoiseGain) soundNoiseGain.gain.setTargetAtTime(target * 0.38, ambientContext.currentTime, 0.16);
  }
}

function updateBiomeAudio(biome) {
  if (!ambientContext || !biome || lastAudioBiome === biome.id) return;
  lastAudioBiome = biome.id;
  const base = { reef:62, kelp:54, wreck:46, thermal:78, abyss:31, open:58 }[biome.id] || 58;
  ambientOscillators.forEach((osc,index) => {
    const hz = base + (index ? 23 : 0);
    try { osc.frequency.setTargetAtTime(hz, ambientContext.currentTime, 1.8); } catch { /* audio is optional */ }
  });
}

function playSfx(kind = 'tap') {
  if (!ambientContext) return;
  try {
    if (ambientContext.state === 'suspended') ambientContext.resume().catch(() => {});
    const now = ambientContext.currentTime;
    const presets = { collect: [620, 920], craft: [420, 680], build: [310, 520], scan: [820, 1160], damage: [120, 76], tap: [360, 440], oxygen:[190,520], locker:[270,390], discovery:[740,1320], radio:[920,480], impact:[78,42] };
    const [startHz, endHz] = presets[kind] || presets.tap;
    const osc = ambientContext.createOscillator(); const gain = ambientContext.createGain();
    osc.type = kind === 'damage' ? 'sawtooth' : 'sine';
    osc.frequency.setValueAtTime(startHz, now); osc.frequency.exponentialRampToValueAtTime(Math.max(40, endHz), now + 0.22);
    gain.gain.setValueAtTime(0.0001, now); gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, settings.volume / 100 * 0.045), now + 0.025); gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.32);
    osc.connect(gain); gain.connect(ambientContext.destination); osc.start(now); osc.stop(now + 0.34);
  } catch { /* Audio is optional; gameplay must remain functional without it. */ }
}

async function enterFullscreenLandscape() {
  try {
    if (!document.fullscreenElement && document.documentElement.requestFullscreen) await document.documentElement.requestFullscreen({ navigationUI: 'hide' });
  } catch { /* Browser or installed-app policy may refuse; the PWA manifest still requests fullscreen. */ }
  try {
    if (screen.orientation && screen.orientation.lock) await screen.orientation.lock('landscape');
  } catch { /* Native Android Activity is already locked to landscape. */ }
  try { window.scrollTo(0, 0); } catch { /* no-op */ }
}

function getInventoryEntries(inventorySource = inventory, toolsSource = ownedTools, survivalSource = survival) {
  const entries = [];
  const addEntry = (id, count, kindOverride = null, suffix = '') => {
    const def = ITEM_DEFS[id];
    if (!def || count <= 0) return;
    const defaultWidth = def.size >= 4 ? 2 : def.size === 2 && def.kind !== 'tool' ? 2 : 1;
    const defaultHeight = def.size >= 4 ? 2 : def.size === 2 && def.kind === 'tool' ? 2 : 1;
    entries.push({ id: suffix || id, hotbarKey:id, name:def.name, icon:def.icon, size:def.size, width:def.width || defaultWidth, height:def.height || defaultHeight, kind:kindOverride || def.kind, count });
  };
  for (const id of toolsSource) addEntry(id, 1, 'tool');
  for (const [key, countValue] of Object.entries(inventorySource || {})) {
    const def = ITEM_DEFS[key];
    let remaining = Math.max(0, Math.floor(Number(countValue) || 0));
    if (!def || remaining <= 0) continue;
    const stackSize = def.stack || 1;
    let stackIndex = 0;
    while (remaining > 0) {
      const count = Math.min(stackSize, remaining);
      addEntry(key, count, def.kind, `${key}-${stackIndex++}`);
      remaining -= count;
    }
  }
  for (const [key, countValue] of [['medkit',survivalSource.medkits],['ration',survivalSource.rations],['water',survivalSource.waterBottles]]) {
    const def = ITEM_DEFS[key];
    let remaining = Math.max(0, Math.floor(Number(countValue) || 0));
    let stackIndex = 0;
    while (remaining > 0) {
      const count = Math.min(def.stack, remaining);
      addEntry(key, count, 'supply', `${key}-${stackIndex++}`);
      remaining -= count;
    }
  }
  return entries;
}

function packInventory(entries = getInventoryEntries()) {
  const columns = 8, rows = 6;
  const occupied = Array(columns * rows).fill(null);
  const placements = [], overflow = [];
  for (const entry of entries) {
    const width = clamp(Math.floor(entry.width || (entry.size > 2 ? 2 : 1)), 1, columns);
    const height = clamp(Math.floor(entry.height || (entry.kind === 'tool' && entry.size > 1 ? 2 : 1)), 1, rows);
    let found = null;
    for (let row = 0; row <= rows - height && !found; row++) {
      for (let col = 0; col <= columns - width; col++) {
        let free = true;
        for (let y = 0; y < height && free; y++) for (let x = 0; x < width; x++) if (occupied[(row+y)*columns+col+x]) { free = false; break; }
        if (free) { found = { row, col, width, height }; break; }
      }
    }
    if (!found) { overflow.push(entry); continue; }
    for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) occupied[(found.row+y)*columns+found.col+x] = entry;
    placements.push({ entry, ...found });
  }
  return { occupied, placements, overflow, used:occupied.filter(Boolean).length, capacity:columns*rows, columns, rows };
}

function canFitResource(type, amount = 1) {
  if (!ITEM_DEFS[type]) return false;
  const next = { ...inventory, [type]:clamp((inventory[type] || 0) + amount, 0, 999) };
  return packInventory(getInventoryEntries(next)).overflow.length === 0;
}

function canFitSupply(type, amount = 1) {
  const next = { ...survival };
  const key = type === 'medkit' ? 'medkits' : type === 'ration' ? 'rations' : 'waterBottles';
  next[key] = clamp((next[key] || 0) + amount, 0, 20);
  return packInventory(getInventoryEntries(inventory, ownedTools, next)).overflow.length === 0;
}

function renderHotbarNode(root) {
  if (!root) return;
  root.replaceChildren();
  for (let index = 0; index < 5; index++) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `hotbar-slot ${index === selectedHotbarIndex ? 'active' : ''}`;
    button.dataset.hotbarIndex = String(index);
    const number = document.createElement('span'); number.className='hotbar-number'; number.textContent=String(index+1);
    const img = document.createElement('img'); img.alt='';
    const label = document.createElement('small');
    const id = hotbarSlots[index];
    const def = id ? ITEM_DEFS[id] : null;
    if (def) { img.src=`./icons/items/${def.icon}.png`; img.hidden=false; label.textContent=id==='seaglide'?`${def.name} · ${Math.ceil(equipment.seaglideCharge)}%`:def.name; }
    else if (id && ITEM_DEFS[id]) { img.src=`./icons/items/${ITEM_DEFS[id].icon}.png`; label.textContent=ITEM_DEFS[id].name; }
    else if (id) { const fallback=ITEM_DEFS[id]; img.hidden=!fallback; if(fallback)img.src=`./icons/items/${fallback.icon}.png`; label.textContent=fallback?.name || id; }
    else { img.hidden=true; label.textContent='KOSONG'; }
    button.append(number,img,label);
    button.addEventListener('click', () => selectHotbar(index));
    root.append(button);
  }
}

function renderHotbar() {
  renderHotbarNode($('hotbar'));
  renderHotbarNode($('inventory-quickbar'));
  const builderSelected = getSelectedHotbarItem() === 'habitat_builder' && ownedTools.includes('habitat_builder');
  updateInteractionPrompt();
}

function getSelectedHotbarItem() { return hotbarSlots[selectedHotbarIndex] || null; }

function selectHotbar(index) {
  selectedHotbarIndex = clamp(Number(index) || 0, 0, 4);
  if (viewModel) viewModel.userData.equipTimer = 0.34;
  renderHotbar();
  const active = getSelectedHotbarItem();
  if (active) showToast(`Hotbar ${selectedHotbarIndex + 1}: ${ITEM_DEFS[active]?.name || RESOURCE_LABELS[active] || active}`);
  markUnsaved();
}

function assignItemToHotbar(itemId) {
  if (!itemId) return;
  if (itemId === 'explorer_pda') { showToast('Explorer PDA dibuka melalui tombol PDA, bukan Quick Slot.'); return; }
  hotbarSlots[selectedHotbarIndex] = itemId;
  renderHotbar();
  showToast(`${ITEM_DEFS[itemId]?.name || RESOURCE_LABELS[itemId] || itemId} dipasang di Hotbar ${selectedHotbarIndex + 1}.`);
  markUnsaved();
}

function renderInventory() {
  const root = $('inventory-list');
  if (!root) return;
  root.replaceChildren();
  const layout = packInventory();
  $('inventory-capacity').textContent = `${layout.used} / 48 CELLS USED${layout.overflow.length ? ` · ${layout.overflow.length} ITEM(S) CANNOT FIT` : ''}`;
  $('inventory-capacity').classList.toggle('is-full', layout.used >= 48 || layout.overflow.length > 0);
  const overflowRoot=$('inventory-overflow');
  if(overflowRoot){overflowRoot.replaceChildren();overflowRoot.classList.toggle('hidden',layout.overflow.length===0);for(const entry of layout.overflow){const row=document.createElement('div');row.className='inventory-overflow-item';const icon=document.createElement('img');icon.src=`./icons/items/${entry.icon}.png`;icon.alt='';const name=document.createElement('span');name.textContent=entry.name;const count=document.createElement('b');count.textContent=`x${entry.count} · ${entry.size} SLOT`;row.append(icon,name,count);overflowRoot.append(row);}}
  for (const placement of layout.placements) {
    const { entry, row, col, width, height } = placement;
    const card = document.createElement('button');
    card.type='button';
    card.className=`inventory-slot-item ${entry.kind || ''}`;
    card.style.gridColumn=`${col + 1} / span ${width}`;
    card.style.gridRow=`${row + 1} / span ${height}`;
    card.title=`${entry.name} · ${width}×${height} cells${entry.count > 1 ? ` · jumlah ${entry.count}` : ''}`;
    const img=document.createElement('img'); img.src=`./icons/items/${entry.icon}.png`; img.alt='';
    const name=document.createElement('span'); name.textContent=entry.name;
    const count=document.createElement('b'); count.textContent=entry.count > 1 ? `x${entry.count}` : `${width}×${height}`;
    card.append(img,name,count);
    card.addEventListener('click', () => {
      assignItemToHotbar(entry.hotbarKey);
    });
    root.append(card);
  }
  for (let index=0; index<48; index++) {
    if (layout.occupied[index]) continue;
    const empty=document.createElement('div'); empty.className='inventory-slot-empty';
    empty.style.gridColumn=String((index%8)+1); empty.style.gridRow=String(Math.floor(index/8)+1);
    empty.textContent=String(index+1).padStart(2,'0'); root.append(empty);
  }
  const eqRoot = $('equipment-list');
  if (eqRoot) {
    eqRoot.replaceChildren();
    const gear = [
      { id:'tank', name:'OXYGEN TANK', icon:'oxygen_tank', value:`TANK MK ${equipment.tankLevel + 1} · ${getMaxOxygen()} O₂`, action:() => showToast(`Tangki oksigen terpasang · kapasitas ${getMaxOxygen()}.`) },
      { id:'fins', name:'SWIM FINS', icon:'fins', value:equipment.fins?'EQUIPPED':'NOT CRAFTED', action:() => showToast(equipment.fins?'Swim Fins terpasang.':'Buat Swim Fins melalui Fabricator.') },
      { id:'rebreather', name:'REBREATHER', icon:'rebreather', value:equipment.rebreather?'EQUIPPED':'NOT CRAFTED', action:() => showToast(equipment.rebreather?'Rebreather terpasang.':'Buat Rebreather melalui Fabricator.') }
    ];
    for (const item of gear) {
      const button=document.createElement('button'); button.type='button'; button.className='equipment-slot';
      const img=document.createElement('img'); img.src=`./icons/items/${item.icon}.png`; img.alt='';
      const label=document.createElement('span'); label.textContent=item.name;
      const value=document.createElement('b'); value.textContent=item.value;
      button.append(img,label,value); button.addEventListener('click',item.action); eqRoot.append(button);
    }
  }
  renderHotbar();
}

function openInventory() {
  if (!gameActive) return;
  gamePaused = true;
  renderInventory();
  setVisibleScreen('inventory');
}

function closeGamePanel() {
  if (!gameActive) { setVisibleScreen('main'); return; }
  gamePaused = false;
  setVisibleScreen('hud');
  enterFullscreenLandscape();
}

function nearestResource(maxDistance = 9) {
  let best = null;
  for (const [id, node] of resourceNodes) {
    const position = node.mesh.getWorldPosition(tmpVector);
    const distance = player.position.distanceTo(position);
    if (distance < maxDistance && (!best || distance < best.distance)) best = { id, ...node, position: position.clone(), distance };
  }
  return best;
}

function getAimedWorldTarget() {
  const pitch = clamp(player.pitch, -1.1, 1.1);
  const forward = new THREE.Vector3(Math.sin(player.yaw)*Math.cos(pitch),-Math.sin(pitch),-Math.cos(player.yaw)*Math.cos(pitch)).normalize();
  const eye = new THREE.Vector3(player.position.x,player.position.y+0.55,player.position.z);
  let best = null;
  const consider = (kind,id,object,position,maxDistance) => {
    const distance=eye.distanceTo(position);
    if(distance>maxDistance || distance<0.2)return;
    const direction=position.clone().sub(eye).normalize();
    const alignment=forward.dot(direction);
    if(alignment<0.945)return;
    const score=alignment-distance*0.0015;
    if(!best||score>best.score)best={kind,id,object,position:position.clone(),distance,alignment,score};
  };
  for(const [id,node] of resourceNodes){
    const position=node.mesh.getWorldPosition(new THREE.Vector3());
    position.y+=node.type==='kelp'?1.6:1.15;
    consider('resource',id,node,position,15);
  }
  for(const drop of floatingDrops)consider('drop',drop.id,drop,drop.mesh.position.clone(),8);
  for(const cache of supplyCacheLocations){if(!collectedCaches.has(cache.id))consider('cache',cache.id,cache,new THREE.Vector3(cache.x,cache.y+1,cache.z),10);}
  return best;
}

function getInsideHabitat() {
  if(lifepodGroup){
    const dx=player.position.x-lifepodGroup.position.x;
    const dy=player.position.y-lifepodGroup.position.y;
    const dz=player.position.z-lifepodGroup.position.z;
    const angle=lifepodGroup.rotation.y||0;
    const lx=dx*Math.cos(angle)+dz*Math.sin(angle);
    const lz=-dx*Math.sin(angle)+dz*Math.cos(angle);
    if(Math.abs(lx)<1.06&&Math.abs(lz)<1.55&&dy>-0.72&&dy<1.25)return {type:'lifepod',id:'lifepod',x:lifepodGroup.position.x,y:lifepodGroup.position.y,z:lifepodGroup.position.z,yaw:angle};
  }
  for(const item of placedStructures){
    if(item.type!=='compartment')continue;
    const dx=player.position.x-item.x, dz=player.position.z-item.z;
    const angle=Number(item.yaw)||0;
    const lx=dx*Math.cos(angle)+dz*Math.sin(angle);
    const lz=-dx*Math.sin(angle)+dz*Math.cos(angle);
    const dy=player.position.y-item.y;
    if(Math.hypot(lx,lz)<3.62&&dy>1.45&&dy<5.85)return item;
  }
  return null;
}

function interiorPoint(inside, localX, localZ) {
  const angle=Number(inside?.yaw)||0;
  return {
    x:inside.x+localX*Math.cos(angle)+localZ*Math.sin(angle),
    z:inside.z-localX*Math.sin(angle)+localZ*Math.cos(angle)
  };
}
function isNearInteriorPoint(inside, localX, localZ, radius=2.8) {
  if(!inside)return false;
  const point=interiorPoint(inside,localX,localZ);
  return Math.hypot(player.position.x-point.x,player.position.z-point.z)<=radius;
}
function isNearFabricator(inside=getInsideHabitat()) {
  return inside?.type==='lifepod' ? isNearInteriorPoint(inside,0.70,-0.28,2.6) : isNearInteriorPoint(inside,2.25,0.8,3.2);
}

function findNearbyHabitat(maxDistance=10) {
  let best=null;
  if(lifepodGroup){
    const distance=player.position.distanceTo(lifepodGroup.position);
    if(distance<=maxDistance)best={type:'lifepod',id:'lifepod',x:lifepodGroup.position.x,y:lifepodGroup.position.y,z:lifepodGroup.position.z,yaw:lifepodGroup.rotation.y||0,distance};
  }
  for(const item of placedStructures){
    if(item.type!=='compartment')continue;
    const distance=Math.hypot(player.position.x-item.x,player.position.y-item.y,player.position.z-item.z);
    if(distance<=maxDistance&&(!best||distance<best.distance))best={...item,distance};
  }
  return best;
}

function enterHabitat(target) {
  if(!target)return;
  const yaw=Number(target.yaw)||0;
  if(target.type==='lifepod'){
    player.position.set(target.x,target.y+0.30,target.z);
  }else{
    player.position.set(target.x,target.y+2.15,target.z);
  }
  player.velocity.set(0,0,0);player.yaw=yaw;player.pitch=0.02;
  respawnPoint.copy(player.position);markUnsaved();
  updateCamera(0.016);updateSurvivalHud();updateInteractionPrompt();
  showToast('Kamu berada di dalam habitat. Oksigen dipulihkan hanya di dalam habitat berdaya atau di permukaan.');
}

function exitHabitat() {
  const inside=getInsideHabitat();if(!inside)return;
  const angle=Number(inside.yaw)||0;
  const distance=inside.type==='lifepod'?4.8:5.5;
  player.position.x=inside.x+Math.sin(angle)*distance;
  player.position.z=inside.z-Math.cos(angle)*distance;
  player.position.y=inside.y+(inside.type==='lifepod'?0.30:2.0);
  player.velocity.set(0,0,0);updateCamera(0.016);updateSurvivalHud();updateInteractionPrompt();
  showToast('Kamu keluar dari habitat.');
}

function updateReticleFeedback(kind = 'none', label = '') {
  const reticle = $('aim-reticle');
  const targetLabel = $('target-label');
  if (reticle) {
    reticle.dataset.targetKind = kind;
    reticle.classList.toggle('has-target', kind !== 'none');
    reticle.setAttribute('aria-label', kind === 'none' ? 'Tanda bidik' : `Target: ${label || kind}`);
  }
  if (targetLabel) targetLabel.dataset.targetKind = kind;
}

function triggerToolAnimation(type = 'scanner') {
  if (viewModel) {
    viewModel.userData.actionType = type;
    viewModel.userData.actionTimer = type === 'knife' ? 0.34 : 0.52;
  }
  if (type === 'scanner') {
    const flash = $('scan-flash');
    if (flash) {
      flash.classList.remove('active');
      void flash.offsetWidth;
      flash.classList.add('active');
    }
  }
}

function updateInteractionPrompt() {
  const interact=$('interact-btn');
  const targetLabel=$('target-label');
  if(!interact||!targetLabel)return;
  const selected=getSelectedHotbarItem();
  const inside=getInsideHabitat();
  const nearbyHabitat=findNearbyHabitat(10);
  const nearbyLocker=nearestBuiltStructure('storage_locker',8);
  const aim=getAimedWorldTarget();
  const faunaAim=getAimedHarvestTarget();
  const pitch=clamp(player.pitch,-1.1,1.1);
  const direction=new THREE.Vector3(Math.sin(player.yaw)*Math.cos(pitch),-Math.sin(pitch),-Math.cos(player.yaw)*Math.cos(pitch)).normalize();
  const origin=new THREE.Vector3(player.position.x,player.position.y+0.55,player.position.z);
  const scanAim=selected==='scanner'?faunaDirector?.getScanTarget(player.position,24,{origin,direction,minAlignment:0.945}):null;
  $('scan-btn')?.classList.toggle('hidden',selected!=='scanner'||!scanAim);
  $('scan-btn')?.classList.toggle('ready-to-scan',!!scanAim);
  $('exit-habitat-btn')?.classList.toggle('hidden',!inside);
  $('pda-btn')?.classList.toggle('hidden',!ownedTools.includes('explorer_pda'));
  const useCounts={medkit:survival.medkits,ration:survival.rations,water:survival.waterBottles,fish_meat:inventory.fish_meat||0};
  const canUse=['medkit','ration','water','fish_meat'].includes(selected)&&(useCounts[selected]||0)>0;
  const canRecharge=selected==='seaglide'&&equipment.seaglideCharge<100&&(inventory.battery||0)>0;
  const useButton=$('use-item-btn');
  const needsBattery=selected==='seaglide'&&equipment.seaglideCharge<100;
  useButton?.classList.toggle('hidden',!canUse&&!needsBattery);
  useButton?.classList.toggle('battery-action',needsBattery);
  useButton?.classList.toggle('needs-battery',needsBattery&&!canRecharge);
  if(useButton){useButton.dataset.hudLabel=needsBattery?'BATTERY':'USE';useButton.setAttribute('aria-label',needsBattery?'Ganti baterai Seaglide':'Gunakan item');useButton.title=needsBattery?'Ganti baterai Seaglide':'Use item';}
  interact.classList.add('hidden');
  interact.dataset.action='';
  for(const key of ['resourceId','dropId','cacheId','habitatId'])delete interact.dataset[key];
  let message='';let targetKind='none';
  const show=(label,action,hud,kind)=>{
    interact.textContent=label;interact.dataset.action=action;interact.dataset.hudLabel=hud;
    interact.setAttribute('aria-label',label);interact.title=label;interact.classList.remove('hidden');targetKind=kind;
  };
  if(inside){
    if(nearbyLocker){show('OPEN WALL LOCKER','storage','OPEN','storage');message='WALL LOCKER';}
    else if(getCurrentMission()?.id==='lifepod'&&inside.type==='lifepod'&&isNearInteriorPoint(inside,0,1.65,1.05)){
      if(ownedTools.includes('repair_tool')&&selected==='repair_tool'){show('REPAIR LIFEPOD','mission','REPAIR','mission');message='DAMAGED CONTROL CONSOLE · REPAIR TOOL READY';}
      else message=ownedTools.includes('repair_tool')?'CONTROL CONSOLE · EQUIP REPAIR TOOL':'CONTROL CONSOLE · FABRICATE REPAIR TOOL';
    }else if(isNearFabricator(inside)&&isHabitatPowered(inside)){
      show('FABRICATOR','fabricator','FAB','fabricator');message='FABRICATOR ACCESS';
    }else message='SAFE HABITAT INTERIOR';
  }else if(nearbyHabitat){
    show(nearbyHabitat.type==='lifepod'?'ENTER LIFEPOD':'ENTER HABITAT','enter','ENTER','habitat');
    interact.dataset.habitatId=nearbyHabitat.id||'';message=nearbyHabitat.type==='lifepod'?'LIFEPOD':'MULTIPURPOSE ROOM';
  }else if(nearbyLocker){show('OPEN WALL LOCKER','storage','OPEN','storage');message='WALL LOCKER';
  }else if(selected==='habitat_builder'&&ownedTools.includes('habitat_builder')){
    show('BUILD','build','BUILD','build');message='HABITAT BUILDER READY';
  }else if(aim?.kind==='drop'){
    show(`TAKE ${RESOURCE_LABELS[aim.object.type]?.toUpperCase()||'ITEM'}`,'take','TAKE','drop');
    interact.dataset.dropId=aim.id;message=`${RESOURCE_LABELS[aim.object.type]?.toUpperCase()||'ITEM'} · ${aim.distance.toFixed(1)} M`;
  }else if(aim?.kind==='cache'){
    show('OPEN SUPPLY CRATE','cache','OPEN','cache');interact.dataset.cacheId=aim.id;message=`SUPPLY CRATE · ${aim.distance.toFixed(1)} M`;
  }else if(aim?.kind==='resource'){
    const plant=aim.object.type==='kelp';
    show(plant?(selected==='knife'?'CUT CREEPVINE':'EQUIP KNIFE'):`BREAK ${RESOURCE_LABELS[aim.object.type].toUpperCase()}`,plant?'cut':'break',plant?'CUT':'BREAK','resource');
    interact.dataset.resourceId=aim.id;message=`${RESOURCE_LABELS[aim.object.type].toUpperCase()} · ${aim.distance.toFixed(1)} M`;
  }else if(scanAim){
    message=`${scanAim.name.toUpperCase()} · ${scanAim.distance.toFixed(1)} M · SCANNER LOCK`;targetKind='fauna';
  }else if(faunaAim){
    show(`CATCH ${faunaAim.name.toUpperCase()}`,'harvest','CATCH','fauna');message=`${faunaAim.name.toUpperCase()} · ${faunaAim.distance.toFixed(1)} M`;
  }
  targetLabel.textContent=message;
  updateReticleFeedback(targetKind,message);
}

function updateResourcePrompt() { updateInteractionPrompt(); }

function useSelectedHotbarItem() {
  const selected=getSelectedHotbarItem();
  if(selected==='seaglide'){
    if(equipment.seaglideCharge>=100){showToast('Baterai Seaglide masih penuh.');return;}
    if((inventory.battery||0)<1){showToast('Tidak ada baterai cadangan di Backpack.');return;}
    inventory.battery-=1;equipment.seaglideCharge=100;seaglideChargeUiBucket=100;
    renderInventory();renderHotbar();updateSurvivalHud();markUnsaved();playSfx('craft');showToast('Baterai Seaglide diganti · daya 100%.');return;
  }
  if(selected==='medkit'){useMedkit();return;}
  if(selected==='ration'){useRation();return;}
  if(selected==='water'){useWater();return;}
  if(selected==='fish_meat'){useFreshFish();return;}
  showToast('Item ini tidak memiliki aksi pakai langsung.');
}

function interactNearby() {
  const action=$('interact-btn')?.dataset.action;
  if(action==='fabricator') { openFabricator(); return; }
  if(action==='storage') { openStorage(); return; }
  if(action==='mission') { activateLifepod(); return; }
  if(action==='build') { openBuildMenu(); return; }
  if(action==='break' || action==='cut') { gatherNearbyResource(); return; }
  if(action==='harvest') { harvestNearbyFish(); return; }
  if(action==='enter') { enterHabitat(findNearbyHabitat(10)); return; }
  if(action==='cache'){ openSupplyCache($('interact-btn').dataset.cacheId||'');return; }
  if(action==='take') {
    const id=$('interact-btn').dataset.dropId;
    const index=floatingDrops.findIndex(item=>item.id===id);
    if(index<0){updateInteractionPrompt();return;}
    const drop=floatingDrops[index];
    if(!canFitResource(drop.type,drop.amount)){showToast('Inventory penuh. Kosongkan beberapa slot terlebih dahulu.');return;}
    inventory[drop.type]=clamp((inventory[drop.type]||0)+drop.amount,0,999);
    disposeWorldDrop(drop);floatingDrops.splice(index,1);
    renderInventory();playSfx('collect');
    if(drop.type==='fish_meat')advanceMission('fish');else recordMissionMaterial();
    markUnsaved();showToast(`+${drop.amount} ${RESOURCE_LABELS[drop.type]}`);return;
  }
  showToast('Tidak ada objek interaksi dalam bidikan.');
}

function gatherNearbyResource() {
  const target=getAimedWorldTarget();
  if(!target||target.kind!=='resource'){showToast('Arahkan tanda bidik ke Ore atau tanaman terlebih dahulu.');updateInteractionPrompt();return;}
  if (target.object.type === 'kelp' && getSelectedHotbarItem() !== 'knife') { showToast('Pilih Survival Knife untuk memotong Creepvine.'); return; }
  const node=resourceNodes.get(target.id);
  if(!node)return;
  if (node.type === 'kelp') triggerToolAnimation('knife');
  const position=node.mesh.getWorldPosition(new THREE.Vector3());
  const color=node.type==='copper'?0xc47b4b:node.type==='glowcap'?0x83d9d0:node.type==='kelp'?0x53be94:node.type==='quartz'?0xb8eff0:node.type==='silver'?0xc3ced8:0x9fb2b7;
  node.mesh.parent?.remove(node.mesh);disposeObjectTree(node.mesh);resourceNodes.delete(target.id);collectedResources.add(target.id);
  spawnDebrisBurst(position,color,9);
  spawnWorldDrop(node.type,position,node.type==='glowcap'||node.type==='kelp'?2:1);
  updateInteractionPrompt();playSfx('impact');markUnsaved();
  showToast(`${RESOURCE_LABELS[node.type]} dihancurkan. Ambil material yang jatuh.`);
}

function getAimedHarvestTarget(){
  const pitch=clamp(player.pitch,-1.1,1.1);
  const direction=new THREE.Vector3(Math.sin(player.yaw)*Math.cos(pitch),-Math.sin(pitch),-Math.cos(player.yaw)*Math.cos(pitch)).normalize();
  const origin=new THREE.Vector3(player.position.x,player.position.y+0.55,player.position.z);
  return faunaDirector?.getHarvestTarget(player.position,6.5,{origin,direction,minAlignment:0.945})||null;
}
function harvestNearbyFish(){
  const fish=getAimedHarvestTarget();
  if(!fish){showToast('Arahkan tanda bidik ke fauna kecil sebelum mengumpulkan sampel.');return;}
  const harvested=faunaDirector.harvestNearest(player.position,6.5,fish.id);
  if(!harvested){showToast('Fauna tersebut sudah menjauh.');return;}
  spawnDebrisBurst(harvested.position,0x9cc9c4,7);
  spawnWorldDrop('fish_meat',harvested.position,1);
  playSfx('impact');
  showToast(`${harvested.name} berhasil ditangkap.`);
}

function useFreshFish(){
  if((inventory.fish_meat||0)<1){showToast('Tidak ada ikan segar di inventory.');return;}
  inventory.fish_meat-=1;survival.food=clamp(survival.food+22,0,100);survival.water=clamp(survival.water-1,0,100);
  updateSurvivalHud();renderInventory();playSfx('collect');markUnsaved();showToast('Fresh Fish dikonsumsi · Food +22.');
}

function canAfford(cost) { return Object.entries(cost).every(([key, amount]) => (inventory[key] || 0) >= amount); }
function spendResources(cost) { for (const [key, amount] of Object.entries(cost)) inventory[key] -= amount; }

function craftSupply(kind) {
  const recipes = {
    medkit: { cost:{fiber_mesh:1}, label:'First Aid Kit' },
    ration: { cost:{fish_meat:1}, label:'Cooked Fish' },
    water: { cost:{bleach:1}, label:'Filtered Water' }
  };
  const recipe=recipes[kind];
  if(!recipe || !canAfford(recipe.cost)){showToast('Material belum mencukupi.');return;}
  if(!canFitSupply(kind)){showToast('Inventory penuh. Kosongkan slot sebelum fabrikasi.');return;}
  spendResources(recipe.cost);
  if(kind==='medkit') survival.medkits=clamp(survival.medkits+1,0,20);
  else if(kind==='ration') survival.rations=clamp(survival.rations+1,0,20);
  else if(kind==='water') survival.waterBottles=clamp(survival.waterBottles+1,0,20);
  updateSurvivalHud();renderInventory();playSfx('craft');markUnsaved();
  if(kind==='medkit') advanceMission('craft');
  showToast(`${recipe.label} berhasil dibuat.`);
}

function craftEquipment(kind) {
  const recipe=EQUIPMENT_RECIPES[kind];
  if(!recipe)return;
  if(kind==='tank'&&equipment.tankLevel>=3){showToast('Kapasitas O₂ sudah maksimum.');return;}
  if(kind!=='tank'&&equipment[kind]){showToast('Peralatan ini sudah dipasang.');return;}
  if(!canAfford(recipe.cost)){showToast('Material belum mencukupi.');return;}
  spendResources(recipe.cost);
  if(kind==='tank'){equipment.tankLevel+=1;survival.oxygen=clamp(survival.oxygen+30,0,getMaxOxygen());}
  else equipment[kind]=true;
  renderInventory();updateSurvivalHud();playSfx('craft');markUnsaved();
  showToast(`${recipe.label} berhasil dipasang.`);
}

function openPda() {
  if (!gameActive) return;
  if (!ownedTools.includes('explorer_pda')) { showToast('Explorer PDA tidak tersedia di inventory.'); return; }
  gamePaused = true;
  renderPda();
  setVisibleScreen('pda');
}
function renderPda() {
  const biomeRoot=$('biome-log'), speciesRoot=$('species-log');
  if (!biomeRoot || !speciesRoot) return;
  biomeRoot.replaceChildren(); speciesRoot.replaceChildren();
  for (const biome of Object.values(BIOME_DATA)) {
    const known=knownBiomes.has(biome.id);
    const card=document.createElement('article'); card.className=`pda-entry ${known?'is-known':'is-unknown'}`;
    const title=document.createElement('strong'); title.textContent=known?biome.label:'Unknown region';
    const note=document.createElement('p'); note.textContent=known?biome.note:'Jelajahi area baru untuk mengumpulkan data lingkungan.';
    const status=document.createElement('small'); status.textContent=known?'ENVIRONMENT LOGGED':'NOT DISCOVERED';
    card.append(title,note,status); biomeRoot.append(card);
  }
  const records=faunaDirector?.getDiscoveryRecords?.() || [];
  if (!records.length) { const p=document.createElement('p'); p.className='panel-hint'; p.textContent='Belum ada spesies yang dipindai. Gunakan SCAN LIFE saat makhluk terlihat.'; speciesRoot.append(p); }
  for (const species of records) {
    const card=document.createElement('article'); card.className='pda-entry is-known';
    const title=document.createElement('strong'); title.textContent=species.name;
    const note=document.createElement('p'); note.textContent=`Kategori: ${species.kind} · Kedalaman umum: ${Math.abs(species.depth[0])}–${Math.abs(species.depth[1])} m`;
    const status=document.createElement('small'); status.textContent='FAUNA SCAN COMPLETE';
    card.append(title,note,status); speciesRoot.append(card);
  }
  $('pda-progress').textContent=`${knownBiomes.size}/${Object.keys(BIOME_DATA).length} BIOME LOGGED · ${records.length}/${FAUNA_SPECIES_COUNT} SPECIES SCANNED`;
  updateMissionUI();
}

function isHabitatPowered(inside = getInsideHabitat()) {
  if (!inside) return false;
  if (inside.type === 'lifepod') return true;
  return placedStructures.some(item => item.type === 'solar_array' && Math.hypot(item.x-inside.x, item.z-inside.z) < 85);
}

function openFabricator() {
  if (!gameActive) return;
  const inside = getInsideHabitat();
  if (!inside) { showToast('Fabricator hanya dapat digunakan dari dalam Lifepod atau Multipurpose Room.'); return; }
  if (!isHabitatPowered(inside)) { showToast('Habitat belum memiliki daya. Pasang Solar Panel terlebih dahulu.'); return; }
  gamePaused=true;fabricatorCategory='sustenance';renderFabricator();setVisibleScreen('fabricator');
}

function renderFabricator() {
  const tabs=$('fabricator-tabs'),root=$('fabricator-recipes');
  if(!tabs||!root)return;
  tabs.querySelectorAll('[data-fabricator-category]').forEach(tab=>tab.classList.toggle('active',tab.dataset.fabricatorCategory===fabricatorCategory));
  root.replaceChildren();
  const category=FABRICATOR_CATEGORIES[fabricatorCategory]||FABRICATOR_CATEGORIES.sustenance;
  for(const recipe of category.recipes){
    const card=document.createElement('article');card.className='fabricator-recipe';
    const icon=document.createElement('img');icon.src=`./icons/items/${recipe.icon}.png`;icon.alt='';
    const info=document.createElement('div');info.className='fabricator-recipe-info';
    const title=document.createElement('strong');title.textContent=recipe.name;
    const cost=document.createElement('small');cost.textContent=Object.entries(recipe.cost).map(([key,value])=>`${value} ${RESOURCE_LABELS[key]||key}`).join(' · ');
    info.append(title,cost);
    const button=document.createElement('button');button.type='button';button.className='small-action';button.textContent='FABRICATE';
    const owned=recipe.id==='tank'?equipment.tankLevel>=3:['fins','rebreather'].includes(recipe.id)?Boolean(equipment[recipe.id]):['habitat_builder','repair_tool','seaglide'].includes(recipe.id)?ownedTools.includes(recipe.id):false;
    const supply= ['medkit','ration','water'].includes(recipe.id);
    const resourceOutput=ITEM_DEFS[recipe.id]&&['glass','silicone','fiber_mesh','battery','wiring_kit','computer_chip','power_cell','lubricant','bleach'].includes(recipe.id);
    const full=supply?!canFitSupply(recipe.id):resourceOutput&&!canFitResource(recipe.id,1);
    button.disabled=owned||!canAfford(recipe.cost)||full;
    button.textContent=owned?'OWNED / INSTALLED':full?'INVENTORY FULL':'FABRICATE';
    button.addEventListener('click',()=>craftFabricatorRecipe(recipe.id));
    card.append(icon,info,button);root.append(card);
  }
}

function craftFabricatorRecipe(id) {
  const inside=getInsideHabitat();
  if(!inside||!isHabitatPowered(inside)){showToast('Fabricator harus digunakan dari dalam habitat yang memiliki daya.');return;}
  if(['medkit','ration','water'].includes(id)){craftSupply(id);renderFabricator();return;}
  if(['tank','fins','rebreather'].includes(id)){craftEquipment(id);renderFabricator();return;}
  const resourceRecipes={
    glass:{cost:{quartz:2},label:'Glass'},silicone:{cost:{kelp:2},label:'Silicone Rubber'},
    fiber_mesh:{cost:{kelp:2},label:'Fiber Mesh'},battery:{cost:{copper:1,quartz:1},label:'Battery'},
    wiring_kit:{cost:{silver:2},label:'Wiring Kit'},computer_chip:{cost:{quartz:1,copper:1,coral:1},label:'Computer Chip'},
    power_cell:{cost:{battery:2,silicone:1},label:'Power Cell'},lubricant:{cost:{kelp:2},label:'Lubricant'},bleach:{cost:{salt:1,coral:1},label:'Bleach'}
  };
  if(resourceRecipes[id]){
    const recipe=resourceRecipes[id];
    if(!canAfford(recipe.cost)){showToast('Material belum mencukupi.');return;}
    if(!canFitResource(id,1)){showToast('Tidak ada ruang di inventory untuk hasil fabrikasi.');return;}
    spendResources(recipe.cost);inventory[id]=clamp((inventory[id]||0)+1,0,999);
    renderInventory();markUnsaved();playSfx('craft');showToast(`${recipe.label} berhasil dibuat.`);renderFabricator();return;
  }
  const tools={
    habitat_builder:{cost:{titanium:2,copper:1,battery:1}},
    repair_tool:{cost:{titanium:1,silicone:1,battery:1}},
    seaglide:{cost:{battery:1,copper:1,titanium:1}}
  };
  if(tools[id]){
    if(ownedTools.includes(id)){showToast(`${ITEM_DEFS[id].name} sudah dimiliki.`);return;}
    if(!canAfford(tools[id].cost)){showToast('Material belum mencukupi.');return;}
    const trial=[...ownedTools,id];
    if(packInventory(getInventoryEntries(inventory,trial)).overflow.length){showToast('Inventory tidak memiliki cukup ruang untuk alat baru.');return;}
    spendResources(tools[id].cost);ownedTools.push(id);
    if(id==='seaglide'){equipment.seaglideCharge=100;seaglideChargeUiBucket=100;}
    const empty=hotbarSlots.findIndex(value=>!value);
    const slot=empty>=0?empty:3;hotbarSlots[slot]=id;selectedHotbarIndex=slot;
    renderInventory();markUnsaved();playSfx('craft');showToast(`${ITEM_DEFS[id].name} berhasil dibuat dan dipasang di Quick Slot ${slot+1}.`);renderFabricator();
  }
}

function openBuildMenu() {
  if (!gameActive) return;
  if (!ownedTools.includes('habitat_builder') || getSelectedHotbarItem() !== 'habitat_builder') {
    showToast('Pilih Habitat Builder di Hotbar untuk membuka mode pembangunan.'); return;
  }
  gamePaused = true;
  updateBuildButtons();
  setVisibleScreen('build');
}

function updateBuildButtons() {
  document.querySelectorAll('[data-build]').forEach(button => {
    const recipe = BUILD_RECIPES[button.dataset.build];
    button.disabled = !recipe || !canAfford(recipe.cost) || !ownedTools.includes('habitat_builder');
  });
}

function placeStructure(type) {
  if (!ownedTools.includes('habitat_builder') || getSelectedHotbarItem() !== 'habitat_builder') { showToast('Pilih Habitat Builder pada Hotbar terlebih dahulu.'); return; }
  const recipe = BUILD_RECIPES[type];
  if (!recipe) return;
  if (!canAfford(recipe.cost)) { showToast('Material pembangunan belum cukup.'); return; }
  const fx = Math.sin(player.yaw), fz = -Math.cos(player.yaw);
  const x = player.position.x + fx * 8, z = player.position.z + fz * 8;
  const ground = heightAt(x, z);
  if (ground > -7) { showToast('Bangunan laut dalam hanya dapat dipasang di dasar laut.'); return; }
  if (Math.abs(player.position.y - ground) > 15) { showToast('Dekati dasar laut untuk memasang bangunan.'); return; }
  spendResources(recipe.cost);
  triggerToolAnimation('builder');
  const record = { id: `build-${Date.now()}-${Math.floor(Math.random()*9999)}`, type, x, y: ground + 0.08, z, yaw: player.yaw, builtAt: Date.now() };
  placedStructures.push(record);
  const cx = Math.floor(x / CHUNK_SIZE), cz = Math.floor(z / CHUNK_SIZE);
  const chunk = chunks.get(`${cx},${cz}`);
  if (chunk) addBuiltStructure(chunk.group, record, cx * CHUNK_SIZE, cz * CHUNK_SIZE);
  updateBuildButtons(); renderInventory(); playSfx('build'); markUnsaved();
  advanceMission('build');
  showToast(`${recipe.label} ditempatkan di dasar laut.`);
}

function openStorage() {
  if (!nearestBuiltStructure('storage_locker',13)) { showToast('Dekati Wall Locker terlebih dahulu.'); return; }
  gamePaused=true;renderStorage();setVisibleScreen('storage');
}

function renderStorage() {
  const root=$('locker-storage-list');
  const summary=$('locker-storage-summary');
  if(!root||!summary)return;
  root.replaceChildren();
  const stored=Object.entries(lockerStorage).filter(([,amount])=>amount>0);
  const total=stored.reduce((sum,[,amount])=>sum+amount,0);
  summary.textContent=`${total} MATERIAL STORED · MAX 99 PER TYPE`;
  if(!stored.length){const empty=document.createElement('p');empty.className='panel-hint';empty.textContent='Locker masih kosong.';root.append(empty);return;}
  for(const [key,amount] of stored){
    const row=document.createElement('div');row.className='storage-material-row';
    const icon=document.createElement('img');icon.src=`./icons/items/${ITEM_DEFS[key]?.icon||key}.png`;icon.alt='';
    const name=document.createElement('span');name.textContent=RESOURCE_LABELS[key]||key;
    const count=document.createElement('b');count.textContent=String(amount);
    row.append(icon,name,count);root.append(row);
  }
}

function lockerTransfer(direction) {
  if (!nearestBuiltStructure('storage_locker',13)) { showToast('Dekati Wall Locker terlebih dahulu.'); return; }
  let moved=0;
  for (const key of Object.keys(INVENTORY_DEFAULTS)) {
    if (direction==='store') {
      const amount=Math.max(0,inventory[key]||0);
      const room=Math.max(0,99-(lockerStorage[key]||0));
      const transfer=Math.min(amount,room);
      inventory[key]-=transfer;lockerStorage[key]=(lockerStorage[key]||0)+transfer;moved+=transfer;
    } else {
      let transfer=Math.max(0,lockerStorage[key]||0);
      while(transfer>0&&!canFitResource(key,transfer))transfer--;
      if(transfer){inventory[key]=(inventory[key]||0)+transfer;lockerStorage[key]-=transfer;moved+=transfer;}
    }
  }
  renderInventory();renderStorage();updateSurvivalHud();markUnsaved();
  showToast(moved?`${direction==='store'?'Material disimpan':'Material diambil'} · ${moved} unit`:'Tidak ada material yang dapat dipindahkan atau ruang backpack penuh.');
}

function renderSlotCards(containerId, mode) {
  const root = $(containerId);
  root.replaceChildren();
  for (let index = 0; index < 5; index++) {
    const record = slots[index];
    const card = document.createElement('div');
    card.className = 'slot-card';
    const info = document.createElement('div');
    info.className = 'slot-info';
    const title = document.createElement('div');
    title.className = 'slot-title';
    title.textContent = `SLOT ${String(index + 1).padStart(2, '0')}`;
    const meta = document.createElement('div');
    meta.className = 'slot-meta';
    meta.textContent = record ? `Last saved: ${formatTime(record.savedAt)} · ${Math.round(record.position?.x || 0)}, ${Math.round(record.position?.z || 0)}` : 'EMPTY · No expedition data';
    info.append(title, meta);
    const actions = document.createElement('div');
    actions.className = 'slot-actions';
    const action = document.createElement('button');
    action.type = 'button';
    action.className = 'slot-action';
    action.textContent = mode === 'new' ? (record ? 'REPLACE' : 'START') : 'LOAD';
    action.disabled = mode === 'load' && !record;
    action.addEventListener('click', () => {
      if (mode === 'new') {
        if (record && !window.confirm(`Timpa data Slot ${index + 1}?`)) return;
        startGame(index, true);
      } else if (record) startGame(index, false);
    });
    actions.append(action);
    if (mode === 'load' && record) {
      const del = document.createElement('button');
      del.type = 'button'; del.className = 'slot-action'; del.textContent = 'DEL';
      del.setAttribute('aria-label', `Hapus Slot ${index + 1}`);
      del.addEventListener('click', () => {
        if (!window.confirm(`Hapus data Slot ${index + 1}?`)) return;
        slots[index] = null; saveJson(STORAGE.slots, slots);
        renderSlotCards(containerId, mode);
      });
      actions.append(del);
    }
    card.append(info, actions);
    root.append(card);
  }
}

async function startGame(slotIndex, isNew) {
  clearRemoteDivers();
  startAmbient();
  if (ambientContext?.state === 'suspended') ambientContext.resume().catch(() => {});
  await enterFullscreenLandscape();
  activeSlot = slotIndex;
  const record = isNew ? null : normalizeSaveRecord(slots[slotIndex]);
  if (!isNew && !record) { showToast('Slot rusak atau tidak valid. Pulihkan backup atau pilih slot lain.'); return; }
  if (isNew) {
    if(lifepodGroup){scene.remove(lifepodGroup);disposeObjectTree(lifepodGroup);lifepodGroup=null;}
    for(const drop of floatingDrops)disposeWorldDrop(drop);floatingDrops=[];
    storyState={...STORY_DEFAULTS,counters:{materials:0},completed:[]};
    player.position.set(0, -7, 0);
    respawnPoint.set(0, -7, 0);
    player.velocity.set(0,0,0);
    player.yaw = 0;
    player.pitch = 0.08;
    survival = { ...SURVIVAL_DEFAULTS };
    collectedCaches = new Set();
    inventory = { ...INVENTORY_DEFAULTS };
    equipment = { ...EQUIPMENT_DEFAULTS };
    ownedTools = [...STARTER_TOOLS];
    hotbarSlots = ['scanner','knife','flashlight',null,null];
    selectedHotbarIndex = 0;
    hasUnsavedChanges = false;
    lastSavedRecord = null;
    survival.oxygen = getMaxOxygen();
    lockerStorage = { ...INVENTORY_DEFAULTS };
    knownBiomes = new Set();
    collectedResources = new Set();
    placedStructures = [];
    faunaDirector?.setDiscoveries([]);
  } else {
    if(lifepodGroup){scene.remove(lifepodGroup);lifepodGroup=null;}
    storyState = record.story && typeof record.story === 'object'
      ? { ...STORY_DEFAULTS, ...record.story, counters:{...STORY_DEFAULTS.counters,...(record.story.counters||{})}, completed:Array.isArray(record.story.completed)?record.story.completed:[] }
      : { ...STORY_DEFAULTS, introSeen:true, missionIndex:1, counters:{materials:0}, completed:['lifepod'] };
    player.position.set(record.position?.x || 0, clamp(record.position?.y ?? -7, -42, 12), record.position?.z || 0);
    player.velocity.set(0,0,0);
    player.yaw = record.yaw || 0;
    player.pitch = record.pitch ?? 0.08;
    survival = { ...SURVIVAL_DEFAULTS, ...(record.survival && typeof record.survival === 'object' ? record.survival : {}) };
    collectedCaches = new Set(Array.isArray(record.collectedCaches) ? record.collectedCaches : []);
    inventory = { ...INVENTORY_DEFAULTS, ...(record.inventory && typeof record.inventory === 'object' ? record.inventory : {}) };
    equipment = { ...EQUIPMENT_DEFAULTS, ...(record.equipment && typeof record.equipment === 'object' ? record.equipment : {}) };
    ownedTools = Array.isArray(record.ownedTools) ? [...new Set(record.ownedTools.filter(id => ITEM_DEFS[id]?.kind === 'tool'))] : [...STARTER_TOOLS];
    hotbarSlots = Array.isArray(record.hotbar) ? Array.from({length:5},(_,index)=>record.hotbar[index] || null) : ['scanner','knife','flashlight',null,null];
    hotbarSlots = hotbarSlots.map(item => item === 'explorer_pda' ? null : item);
    selectedHotbarIndex = clamp(Number(record.selectedHotbar)||0,0,4);
    hasUnsavedChanges = false;
    lockerStorage = { ...INVENTORY_DEFAULTS, ...(record.lockerStorage && typeof record.lockerStorage === 'object' ? record.lockerStorage : {}) };
    knownBiomes = new Set(Array.isArray(record.knownBiomes) ? record.knownBiomes.filter(id => BIOME_DATA[id]) : []);
    collectedResources = new Set(Array.isArray(record.collectedResources) ? record.collectedResources : []);
    placedStructures = Array.isArray(record.placedStructures) ? record.placedStructures : [];
    faunaDirector?.setDiscoveries(record.discoveries || []);
  }
  survival = Object.fromEntries(Object.entries(SURVIVAL_DEFAULTS).map(([key, fallback]) => {
    const value = Number(survival[key] ?? fallback);
    return [key, clamp(Number.isFinite(value) ? value : fallback, 0, key === 'medkits' || key === 'rations' || key === 'waterBottles' ? 20 : key === 'oxygen' ? getMaxOxygen() : 100)];
  }));
  survival.oxygen = clamp(survival.oxygen,0,getMaxOxygen());
  respawnPoint.copy(record?.respawnPoint ? new THREE.Vector3(record.respawnPoint.x,record.respawnPoint.y,record.respawnPoint.z) : new THREE.Vector3(0,-7,0));
  lastSavedRecord = !isNew && record ? JSON.parse(JSON.stringify(record)) : null;
  oxygenDamageTimer = hungerDamageTimer = thirstDamageTimer = 0;
  isRespawning = false;
  faunaDirector?.setQuality(settings.graphics);
  gameActive = true;
  gamePaused = false;
  for (const chunk of chunks.values()) disposeChunk(chunk);
  chunks.clear();
  resourceNodes.clear();
  chunkCenterX = NaN; chunkCenterZ = NaN;
  updateChunks(true);
  if(!isNew) { restoreWorldDrops(record?.droppedItems||[]); if(storyState.introSeen) makeLifePod(); }
  setVisibleScreen('hud');
  $('hud').classList.remove('hidden');
  updateMissionUI();
  updateNetworkLabels();
  updateSurvivalHud();
  renderHotbar();
  showToast(isNew ? `Ekspedisi dimulai · Slot ${slotIndex + 1}` : `Progres Slot ${slotIndex + 1} dimuat`);
  if (isNew) markUnsaved();
  if(isNew || !storyState.introSeen) startIntroCinematic();
}

function buildSaveRecord() {
  const previous = slots[activeSlot] || {};
  return normalizeSaveRecord({
    version: 11,
    savedAt: Date.now(),
    position: { x: player.position.x, y: player.position.y, z: player.position.z },
    yaw: player.yaw,
    pitch: player.pitch,
    survival: { ...survival, schemaVersion: SURVIVAL_STORAGE_VERSION },
    discoveries: faunaDirector?.getDiscoveries() || previous.discoveries || [],
    collectedCaches: [...collectedCaches],
    inventory: { ...inventory },
    equipment: { ...equipment },
    ownedTools: [...ownedTools],
    hotbar: [...hotbarSlots],
    selectedHotbar: selectedHotbarIndex,
    respawnPoint: { x:respawnPoint.x, y:respawnPoint.y, z:respawnPoint.z },
    lockerStorage: { ...lockerStorage },
    knownBiomes: [...knownBiomes],
    collectedResources: [...collectedResources],
    placedStructures: placedStructures.map(item => ({ ...item })),
    story: { ...storyState, counters:{ ...(storyState.counters||{}) }, completed:[...(storyState.completed||[])] },
    droppedItems: floatingDrops.slice(0,80).map(drop => ({ id:drop.id, type:drop.type, position:{x:drop.mesh.position.x,y:drop.mesh.position.y,z:drop.mesh.position.z} }))
  });
}

function markUnsaved() { hasUnsavedChanges = true; }

function saveCurrentSlot() {
  if (activeSlot < 0 || activeSlot > 4) return false;
  const record = buildSaveRecord();
  slots[activeSlot] = record;
  const okay = saveJson(STORAGE.slots, slots);
  if (!okay) { showToast('Save gagal. Periksa ruang penyimpanan perangkat.'); return false; }
  lastSavedRecord = JSON.parse(JSON.stringify(record));
  hasUnsavedChanges = false;
  showToast(`Game tersimpan · SLOT ${activeSlot + 1}`);
  return true;
}

async function persistCurrentSlotNow() { return saveCurrentSlot(); }

function returnToMain() {
  if (gameActive && hasUnsavedChanges && !window.confirm('Perubahan belum disimpan. Keluar tanpa menyimpan?')) return;
  gameActive = false; gamePaused = false;
  $('hud').classList.add('hidden');
  setVisibleScreen('main');
}
function pauseGame() {
  if (!gameActive || gamePaused) return;
  gamePaused = true;
  if (introSequence.active) $('cinematic-overlay')?.classList.add('hidden');
  setVisibleScreen('pause');
}
function resumeGame() {
  if (!gameActive) return;
  gamePaused = false;
  setVisibleScreen('hud');
  $('hud').classList.remove('hidden');
  if (introSequence.active) {
    $('hud').classList.add('hidden');
    $('cinematic-overlay')?.classList.remove('hidden');
  }
}
function handleNativeBack() {
  if (UI.inventory && !UI.inventory.classList.contains('hidden')) { closeGamePanel(); return true; }
  if (UI.build && !UI.build.classList.contains('hidden')) { closeGamePanel(); return true; }
  if (UI.pda && !UI.pda.classList.contains('hidden')) { closeGamePanel(); return true; }
  if (UI.fabricator && !UI.fabricator.classList.contains('hidden')) { closeGamePanel(); return true; }
  if (UI.storage && !UI.storage.classList.contains('hidden')) { closeGamePanel(); return true; }
  if (UI.settings && !UI.settings.classList.contains('hidden')) { closeSettings(); return true; }
  if (UI.multiplayer && !UI.multiplayer.classList.contains('hidden')) { closeMultiplayer(); return true; }
  if (UI.pause && !UI.pause.classList.contains('hidden')) { resumeGame(); return true; }
  if (gameActive) { pauseGame(); return true; }
  const secondary = ['newGame','load','exit'].find(key => UI[key] && !UI[key].classList.contains('hidden'));
  if (secondary) { setVisibleScreen('main'); return true; }
  return false;
}

let nativeLifecycleBound = false;
async function bindNativeLifecycle() {
  if (nativeLifecycleBound || !window.Capacitor?.isNativePlatform?.()) return;
  try {
    const { App } = await import('@capacitor/app');
    await App.addListener('backButton', async () => {
      const active = document.activeElement;
      if (active && /^(INPUT|TEXTAREA|SELECT)$/.test(active.tagName)) {
        active.blur();
        return;
      }
      const handled = handleNativeBack();
      if (!handled) {
        if (window.confirm('Keluar dari The Abyssal?')) await App.exitApp();
      }
    });
    await App.addListener('appStateChange', ({ isActive }) => {
      if (!isActive) {
        input.keys.clear();
        input.joyX = 0; input.joyY = 0; input.vertical = 0;
        if (gameActive && !gamePaused) pauseGame();
      } else {
        lastFrame = performance.now();
        onResize();
      }
    });
    nativeLifecycleBound = true;
  } catch (error) {
    console.warn('[The Abyssal] Native lifecycle listeners unavailable:', error?.message || error);
  }
}
async function exitGame() {
  if (gameActive && hasUnsavedChanges && !window.confirm('Ada perubahan yang belum disimpan. Keluar tanpa menyimpan?')) return;
  gameActive = false;
  gamePaused = false;
  $('hud')?.classList.add('hidden');
  setVisibleScreen('exit');
}

function setupControls() {
  $('play-btn').addEventListener('click', () => { renderSlotCards('new-slots', 'new'); setVisibleScreen('newGame'); });
  $('continue-btn').addEventListener('click', () => { renderSlotCards('load-slots', 'load'); setVisibleScreen('load'); });
  $('settings-btn').addEventListener('click', () => openSettings('main'));
  $('multiplayer-btn').addEventListener('click', () => openMultiplayer('main'));
  $('pause-multiplayer-btn').addEventListener('click', () => openMultiplayer('pause'));
  $('multiplayer-close-btn').addEventListener('click', closeMultiplayer);
  $('exit-btn').addEventListener('click', exitGame);
  $('backend-config-form').addEventListener('submit', async event => {
    event.preventDefault();
    const button = $('backend-config-save-btn'); button.disabled = true;
    try {
      const result = await online.configureBackend({
        url:$('backend-project-url').value,
        publishableKey:$('backend-publishable-key').value
      });
      updateOnlineConfigNote();
      updateOnlineRoomUi();
      if (result?.reachable === false) {
        updateOnlineStatus(`Konfigurasi tersimpan, tetapi server belum terjangkau. ${result.error?.message || 'Periksa internet dan Project URL, lalu tekan Simpan & Hubungkan lagi.'}`, 'warning');
      } else if (online.authSettings?.disable_signup === true) {
        $('backend-config-details').open = false;
        updateOnlineStatus('Server terhubung, tetapi Register dinonaktifkan di Supabase. Login tetap tersedia untuk akun yang sudah ada.', 'warning');
      } else if (online.authSettings?.external?.email === false) {
        $('backend-config-details').open = false;
        updateOnlineStatus('Server terhubung, tetapi provider Email belum aktif di Supabase Authentication.', 'warning');
      } else {
        $('backend-config-details').open = false;
        updateOnlineStatus('Server Supabase berhasil dihubungkan. Register dan Login siap digunakan.', 'success');
      }
    } catch (error) {
      updateOnlineConfigNote();
      updateOnlineRoomUi();
      updateOnlineStatus(explainOnlineError(error, 'Backend tidak dapat dihubungkan. Periksa URL dan Publishable Key.'), 'error');
    } finally { button.disabled = false; }
  });

  document.querySelectorAll('[data-auth-mode]').forEach(button => button.addEventListener('click', () => {
    const registerMode = button.dataset.authMode === 'register';
    $('online-login-section').classList.toggle('hidden', registerMode);
    $('online-register-section').classList.toggle('hidden', !registerMode);
    updateOnlineStatus(registerMode ? 'Buat akun baru dengan email aktif.' : 'Masuk menggunakan email dan kata sandi.', 'info');
  }));
  $('online-login-form').addEventListener('submit', async event => {
    event.preventDefault();
    const button = $('login-submit-btn'); button.disabled = true;
    try {
      await online.login({ email:$('login-email').value, password:$('login-password').value });
      updateOnlineStatus(`Berhasil masuk sebagai ${online.displayName}.`, 'success');
      $('login-password').value = '';
    } catch (error) {
      updateOnlineStatus(explainOnlineError(error, 'Login gagal. Periksa email dan kata sandi.'), 'error');
    } finally { button.disabled = !online.configured; }
  });
  $('online-register-form').addEventListener('submit', async event => {
    event.preventDefault();
    const button = $('register-submit-btn'); button.disabled = true;
    try {
      const result = await online.register({
        displayName:$('register-name').value,
        email:$('register-email').value,
        password:$('register-password').value
      });
      $('register-password').value = '';
      if (result.needsEmailConfirmation) {
        updateOnlineStatus('Akun berhasil dibuat. Buka email verifikasi dari Supabase, konfirmasi alamat email, lalu kembali ke sini untuk Login.', 'success');
        $('online-login-section').classList.remove('hidden');
        $('online-register-section').classList.add('hidden');
      } else {
        updateOnlineStatus(`Akun berhasil dibuat. Selamat datang, ${online.displayName}.`, 'success');
      }
    } catch (error) {
      updateOnlineStatus(explainOnlineError(error, 'Registrasi gagal. Coba email lain atau periksa konfigurasi Auth.'), 'error');
    } finally { button.disabled = !online.configured; }
  });
  $('logout-btn').addEventListener('click', async () => {
    const button = $('logout-btn'); button.disabled = true;
    try { await online.logout(); updateOnlineStatus('Kamu sudah logout.', 'success'); }
    catch (error) { updateOnlineStatus(error.message || 'Logout gagal.', 'error'); }
    finally { button.disabled = false; }
  });
  $('create-room-btn').addEventListener('click', async () => {
    const button = $('create-room-btn'); button.disabled = true;
    try {
      const room = await online.createRoom($('room-name-input').value);
      updateOnlineStatus(`Ruang ${room.code} berhasil dibuat. Bagikan kode undangan kepada teman.`, 'success');
      updateOnlineRoomUi();
    } catch (error) { updateOnlineStatus(error.message || 'Gagal membuat ruang.', 'error'); }
    finally { updateOnlineRoomUi(); }
  });
  $('join-room-btn').addEventListener('click', async () => {
    const button = $('join-room-btn'); button.disabled = true;
    try {
      const room = await online.joinRoom($('room-code-input').value);
      $('room-code-input').value = '';
      updateOnlineStatus(`Berhasil bergabung ke ${room.name} (${room.code}).`, 'success');
      updateOnlineRoomUi();
    } catch (error) { updateOnlineStatus(error.message || 'Tidak dapat bergabung ke ruang.', 'error'); }
    finally { updateOnlineRoomUi(); }
  });
  $('room-code-input').addEventListener('input', event => { event.target.value = event.target.value.toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,6); });
  $('leave-room-btn').addEventListener('click', async () => {
    const button = $('leave-room-btn'); button.disabled = true;
    try { await online.leaveRoom(); clearRemoteDivers(); updateOnlineStatus('Kamu sudah keluar dari ruang ekspedisi.', 'success'); }
    catch (error) { updateOnlineStatus(error.message || 'Gagal keluar dari ruang.', 'error'); }
    finally { updateOnlineRoomUi(); }
  });
  $('online-chat-form').addEventListener('submit', async event => {
    event.preventDefault();
    const inputNode = $('online-chat-input');
    const value = inputNode.value;
    try { await online.sendChat(value); inputNode.value = ''; }
    catch (error) { updateOnlineStatus(error.message || 'Pesan tidak dapat dikirim.', 'error'); }
  });
  document.querySelectorAll('[data-back]').forEach(button => button.addEventListener('click', () => {
    if (button.closest('#settings-screen')) closeSettings();
    else setVisibleScreen('main');
  }));
  $('pause-btn').addEventListener('click', pauseGame);
  $('resume-btn').addEventListener('click', resumeGame);
  $('pause-save-btn').addEventListener('click', saveCurrentSlot);
  $('pause-settings-btn').addEventListener('click', () => openSettings('pause'));
  $('main-menu-btn').addEventListener('click', returnToMain);
  $('scan-btn').addEventListener('click', scanNearestFauna);
  $('interact-btn').addEventListener('click', interactNearby);
  $('use-item-btn').addEventListener('click', useSelectedHotbarItem);
  $('exit-habitat-btn').addEventListener('click', exitHabitat);
  $('cinematic-skip').addEventListener('click', finishIntroCinematic);
  $('inventory-btn').addEventListener('click', openInventory);
  $('pda-btn').addEventListener('click', openPda);
  $('pda-close-btn').addEventListener('click', closeGamePanel);
  $('fabricator-close-btn').addEventListener('click', closeGamePanel);
  $('fabricator-tabs').addEventListener('click', event => { const tab=event.target.closest('[data-fabricator-category]'); if(!tab)return; fabricatorCategory=tab.dataset.fabricatorCategory; renderFabricator(); });
  $('storage-close-btn').addEventListener('click', closeGamePanel);
  $('storage-store-btn').addEventListener('click', () => lockerTransfer('store'));
  $('storage-take-btn').addEventListener('click', () => lockerTransfer('take'));
  $('inventory-close-btn').addEventListener('click', closeGamePanel);
  $('build-close-btn').addEventListener('click', closeGamePanel);
  document.querySelectorAll('[data-build]').forEach(button => button.addEventListener('click', () => placeStructure(button.dataset.build)));
  $('return-menu-btn').addEventListener('click', () => { setVisibleScreen('main'); });
  $('fullscreen-btn').addEventListener('click', enterFullscreenLandscape);
  $('export-save-btn').addEventListener('click', exportSaveBackup);
  $('import-save-btn').addEventListener('click', () => $('import-save-file').click());
  $('import-save-file').addEventListener('change', async event => {
    try { await importSaveBackup(event.target.files?.[0]); }
    catch (error) { showToast(error.message || 'Gagal membaca file backup.'); }
    finally { event.target.value = ''; }
  });

  // Local single-player campaign; the only save actions are manual and backup/restore.

  $('graphics-select').addEventListener('change', event => { settings.graphics = event.target.value; applySettings(); });
  $('render-select').addEventListener('change', event => { settings.renderDistance = Number(event.target.value); applySettings(); });
  $('volume-range').addEventListener('input', event => { settings.volume = Number(event.target.value); $('volume-value').textContent = `${settings.volume}%`; updateAmbientVolume(); saveJson(STORAGE.settings, settings); });
  $('fov-range').addEventListener('input', event => { settings.fov = Number(event.target.value); $('fov-value').textContent = `${settings.fov}°`; applySettings(); });
  $('language-select').addEventListener('change', event => { settings.language = event.target.value; applyLanguage(); saveJson(STORAGE.settings, settings); });

  window.addEventListener('keydown', event => {
    const target = event.target;
    const typing = target && (target.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName));
    if (typing) return;
    if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(event.code)) event.preventDefault();
    input.keys.add(event.code);
    if (event.code === 'KeyI' && gameActive && !gamePaused) openInventory();
    if (event.code === 'KeyB' && gameActive && !gamePaused) openBuildMenu();
    if (event.code === 'KeyJ' && gameActive && !gamePaused) openPda();
    if (event.code === 'KeyE' && gameActive && !gamePaused) interactNearby();
    if (/^Digit[1-5]$/.test(event.code) && gameActive && !gamePaused) selectHotbar(Number(event.code.slice(5))-1);
    if (event.code === 'Escape' && gameActive) { if (gamePaused) closeGamePanel(); else pauseGame(); }
  });
  window.addEventListener('keyup', event => input.keys.delete(event.code));
  window.addEventListener('blur', () => input.keys.clear());

  const joystick = $('joystick'), knob = $('joystick-knob');
  let joyPointer = null;
  const moveJoy = (event) => {
    if (event.pointerId !== joyPointer) return;
    const rect = joystick.getBoundingClientRect();
    const cx = rect.left + rect.width / 2, cy = rect.top + rect.height / 2;
    const dx = event.clientX - cx, dy = event.clientY - cy;
    const max = rect.width * 0.34;
    const length = Math.hypot(dx, dy) || 1;
    const factor = Math.min(1, max / length);
    const px = dx * factor, py = dy * factor;
    knob.style.transform = `translate(${px}px,${py}px)`;
    input.joyX = clamp(px / max, -1, 1);
    input.joyY = clamp(py / max, -1, 1);
  };
  joystick.addEventListener('pointerdown', event => { joyPointer = event.pointerId; joystick.setPointerCapture(joyPointer); moveJoy(event); });
  joystick.addEventListener('pointermove', moveJoy);
  const resetJoy = event => { if (event.pointerId !== joyPointer) return; joyPointer = null; input.joyX = 0; input.joyY = 0; knob.style.transform = 'translate(0,0)'; };
  joystick.addEventListener('pointerup', resetJoy); joystick.addEventListener('pointercancel', resetJoy); joystick.addEventListener('lostpointercapture', () => { joyPointer = null; input.joyX = 0; input.joyY = 0; knob.style.transform = 'translate(0,0)'; });

  const lookpad = $('lookpad');
  lookpad.addEventListener('pointerdown', event => { event.preventDefault(); look.active = true; look.pointerId = event.pointerId; look.x = event.clientX; look.y = event.clientY; lookpad.setPointerCapture(event.pointerId); });
  lookpad.addEventListener('pointermove', event => {
    if (!look.active || event.pointerId !== look.pointerId) return;
    const dx = event.clientX - look.x, dy = event.clientY - look.y;
    look.x = event.clientX; look.y = event.clientY;
    player.yaw -= dx * 0.0039;
    player.pitch = clamp(player.pitch + dy * 0.0027, -0.98, 0.98);
  });
  const stopLook = event => { if (event.pointerId === look.pointerId) { look.active = false; look.pointerId = null; } };
  lookpad.addEventListener('pointerup', stopLook); lookpad.addEventListener('pointercancel', stopLook);

  const bindHold = (id, direction) => {
    const node = $(id);
    const down = event => { event.preventDefault(); input.vertical = direction; node.setPointerCapture?.(event.pointerId); };
    const up = event => { event.preventDefault(); if (input.vertical === direction) input.vertical = 0; };
    node.addEventListener('pointerdown', down); node.addEventListener('pointerup', up); node.addEventListener('pointercancel', up); node.addEventListener('lostpointercapture', up);
  };
  bindHold('ascend-btn', 1); bindHold('descend-btn', -1);
  window.addEventListener('resize', onResize);
  window.addEventListener('orientationchange', () => setTimeout(onResize, 160));
  document.addEventListener('focusin', event => {
    const target = event.target;
    if (target && /^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName)) {
      document.body.classList.add('keyboard-open');
      setTimeout(() => target.scrollIntoView({ block: 'center', behavior: 'smooth' }), 120);
    }
  });
  document.addEventListener('focusout', () => {
    clearTimeout(visualViewportResizeTimer);
    visualViewportResizeTimer = setTimeout(() => {
      document.body.classList.remove('keyboard-open');
      onResize();
    }, 180);
  });
}

function onResize() {
  if (!renderer || !camera) return;
  // Keep the render target stable while Android's IME is visible; adjustPan
  // pans the content without shrinking the native full-screen game surface.
  if (document.body.classList.contains('keyboard-open')) return;
  const viewport = getGameViewportSize();
  renderer.setSize(viewport.width, viewport.height, false);
  camera.aspect = viewport.width / viewport.height;
  camera.updateProjectionMatrix();
}

function samplePlayerFloor(x, z) {
  // The swimmer is treated as a short capsule: sample the centre and four shoulder points.
  const r = 0.58;
  return Math.max(
    heightAt(x,z), heightAt(x+r,z), heightAt(x-r,z),
    heightAt(x,z+r), heightAt(x,z-r)
  );
}

function structureBlocksPosition(x, y, z) {
  for (const item of placedStructures) {
    // Walkable habitat pieces are intentionally not solid at the centre so the diver can enter them.
    if (item.type === 'compartment' || item.type === 'foundation') continue;
    const radius = item.type === 'solar_array' ? 1.7 : item.type === 'storage_locker' ? 0.9 : 0.72;
    if (Math.abs(y - item.y) < 2.0 && Math.hypot(x-item.x,z-item.z) < radius + 0.58) return true;
  }
  // The emergency capsule blocks divers outside, but its interior remains walkable after entry.
  if(lifepodGroup){
    const dx=x-lifepodGroup.position.x,dz=z-lifepodGroup.position.z,angle=lifepodGroup.rotation.y||0;
    const localX=dx*Math.cos(angle)+dz*Math.sin(angle),localZ=-dx*Math.sin(angle)+dz*Math.cos(angle),localY=y-lifepodGroup.position.y;
    const insideShell=Math.abs(localX)<0.82&&Math.abs(localZ)<1.42&&localY>-0.7&&localY<1.18;
    if(!insideShell&&Math.abs(localY)<2.1&&Math.hypot(localX,localZ)<2.05)return true;
  }
  // The large wreck hull is an oriented solid, not a pass-through decoration.
  const dx=x-shipOfInterest.x, dz=z-shipOfInterest.z, angle=0.72;
  const localX=dx*Math.cos(angle)-dz*Math.sin(angle);
  const localZ=dx*Math.sin(angle)+dz*Math.cos(angle);
  if (Math.abs(y+37)<4.2 && Math.abs(localX)<16.5 && Math.abs(localZ)<4.7) return true;
  // Supply crates also have a small interaction-safe collision volume.
  for (const cache of supplyCacheLocations) {
    if (Math.abs(y-cache.y)<1.5 && Math.abs(x-cache.x)<1.85 && Math.abs(z-cache.z)<1.45) return true;
  }
  return false;
}

function updateMovement(dt) {
  const keyForward = (input.keys.has('KeyW') || input.keys.has('ArrowUp') ? 1 : 0) - (input.keys.has('KeyS') || input.keys.has('ArrowDown') ? 1 : 0);
  const keyStrafe = (input.keys.has('KeyD') || input.keys.has('ArrowRight') ? 1 : 0) - (input.keys.has('KeyA') || input.keys.has('ArrowLeft') ? 1 : 0);
  const forward = clamp(keyForward - input.joyY, -1, 1);
  const strafe = clamp(keyStrafe + input.joyX, -1, 1);
  const vertical = input.vertical + (input.keys.has('Space') ? 1 : 0) - (input.keys.has('ControlLeft') || input.keys.has('ControlRight') ? 1 : 0);
  const pitch = clamp(player.pitch, -0.48, 0.58);
  const fwd = tmpVector.set(Math.sin(player.yaw)*Math.cos(pitch),-Math.sin(pitch),-Math.cos(player.yaw)*Math.cos(pitch));
  const right = tmpRight.set(Math.cos(player.yaw),0,Math.sin(player.yaw));
  const wish = tmpDirection.set(0,0,0).addScaledVector(fwd,forward).addScaledVector(right,strafe);
  if (wish.lengthSq()>1) wish.normalize();
  const seaglideSelected=getSelectedHotbarItem()==='seaglide'&&ownedTools.includes('seaglide');
  const seaglideEquipped=seaglideSelected&&equipment.seaglideCharge>0;
  const isMoving=wish.lengthSq()>0.02||Math.abs(vertical)>0.03;
  if(seaglideEquipped&&isMoving){
    const previousCharge=Math.ceil(equipment.seaglideCharge);
    equipment.seaglideCharge=clamp(equipment.seaglideCharge-0.30*dt,0,100);
    const nextCharge=Math.ceil(equipment.seaglideCharge);
    if(nextCharge!==previousCharge){markUnsaved();if(nextCharge!==seaglideChargeUiBucket){seaglideChargeUiBucket=nextCharge;renderHotbar();}}
    if(equipment.seaglideCharge===0){showToast('Daya Seaglide habis. Ganti baterai melalui tombol BATTERY.');renderHotbar();}
  }
  const speed=(settings.graphics==='low'?8.8:settings.graphics==='high'?11.2:10.2)*(equipment.fins?1.2:1)*(seaglideEquipped?1.75:1);
  const desiredX=wish.x*speed, desiredY=clamp(vertical,-1,1)*7.0, desiredZ=wish.z*speed;
  const accel=1-Math.exp(-dt*4.8), verticalAccel=1-Math.exp(-dt*5.2);
  player.velocity.x=lerp(player.velocity.x,desiredX,accel);
  player.velocity.z=lerp(player.velocity.z,desiredZ,accel);
  player.velocity.y=lerp(player.velocity.y,desiredY,verticalAccel);
  if (wish.lengthSq()<0.002 && Math.abs(vertical)<0.01) {
    player.velocity.x*=Math.exp(-dt*2.4); player.velocity.z*=Math.exp(-dt*2.4); player.velocity.y*=Math.exp(-dt*2.0);
  }

  const oldX=player.position.x, oldY=player.position.y, oldZ=player.position.z;
  const nextX=oldX+player.velocity.x*dt, nextZ=oldZ+player.velocity.z*dt;
  const nextY=clamp(oldY+player.velocity.y*dt,-42,28);
  const floorOld=samplePlayerFloor(oldX,oldZ)+1.9;
  const floorNext=samplePlayerFloor(nextX,nextZ)+1.9;
  // Block steep terrain faces rather than allowing the diver to tunnel through islands or cliffs.
  if (floorNext > oldY + 1.05 && floorNext > floorOld + 0.65) {
    const xOnlyFloor=samplePlayerFloor(nextX,oldZ)+1.9;
    const zOnlyFloor=samplePlayerFloor(oldX,nextZ)+1.9;
    if (xOnlyFloor <= oldY+1.05) { player.position.x=nextX; player.velocity.z=0; }
    else if (zOnlyFloor <= oldY+1.05) { player.position.z=nextZ; player.velocity.x=0; }
    else { player.velocity.x=0; player.velocity.z=0; }
  } else {
    player.position.x=nextX; player.position.z=nextZ;
  }
  if (structureBlocksPosition(player.position.x,nextY,player.position.z)) {
    const canSlideX=!structureBlocksPosition(player.position.x,nextY,oldZ);
    const canSlideZ=!structureBlocksPosition(oldX,nextY,player.position.z);
    if (canSlideX && !canSlideZ) { player.position.z=oldZ; player.velocity.z=0; }
    else if (canSlideZ && !canSlideX) { player.position.x=oldX; player.velocity.x=0; }
    else { player.position.x=oldX; player.position.z=oldZ; player.velocity.x=0; player.velocity.z=0; }
  }
  faunaDirector?.resolvePlayerCollision(player.position);
  const floorClearance=Math.max(-42,samplePlayerFloor(player.position.x,player.position.z)+1.9);
  // In open water the diver can reach the surface but cannot fly above it. On dry island terrain,
  // the terrain floor becomes the upper bound so the capsule can stand on the island.
  const upperBound=Math.max(-0.45,floorClearance);
  player.position.y=clamp(nextY,floorClearance,upperBound);
  if (player.position.y>=-0.5 && player.velocity.y>0) player.velocity.y*=0.3;
  player.bob+=dt*(wish.lengthSq()>0.015||Math.abs(vertical)>0.05?6.3:1.2);
  player.swimPhase+=dt*(2.3+Math.min(3,player.velocity.length()*0.22));
}

const cameraQuaternion = new THREE.Quaternion();
const cameraPreviousQuaternion = new THREE.Quaternion();
function updateCamera(dt) {
  const eyeBob = Math.sin(player.bob) * 0.022;
  const targetPosition = new THREE.Vector3(player.position.x, player.position.y + 0.55 + eyeBob, player.position.z);
  const cameraBlend = 1 - Math.exp(-Math.max(0.001,Math.min(dt,0.08))*18);
  camera.position.lerp(targetPosition,cameraBlend);
  if (viewModel) viewModel.visible = gameActive;
  const pitch = clamp(player.pitch, -1.15, 1.15);
  const forward = tmpDirection.set(Math.sin(player.yaw) * Math.cos(pitch), -Math.sin(pitch), -Math.cos(player.yaw) * Math.cos(pitch));
  cameraPreviousQuaternion.copy(camera.quaternion);
  camera.lookAt(tmpCamera.copy(camera.position).addScaledVector(forward, 22));
  cameraQuaternion.copy(camera.quaternion);
  camera.quaternion.copy(cameraPreviousQuaternion).slerp(cameraQuaternion,cameraBlend);
  const lateralSpeed = player.velocity.dot(tmpRight.set(Math.cos(player.yaw), 0, Math.sin(player.yaw)));
  camera.rotateZ(Math.sin(player.bob) * 0.0028 - clamp(lateralSpeed * 0.0022, -0.025, 0.025));
  if (viewModel) {
    const moving = clamp(player.velocity.length() / 10, 0, 1);
    const stroke = Math.sin(player.swimPhase);
    const selectedTool=getSelectedHotbarItem();
    viewModel.userData.scanner.visible=selectedTool==='scanner';
    viewModel.userData.knife.visible=selectedTool==='knife';
    viewModel.userData.flashlight.visible=selectedTool==='flashlight';
    viewModel.userData.builder.visible=selectedTool==='habitat_builder';
    viewModel.userData.repairTool.visible=selectedTool==='repair_tool';
    viewModel.userData.seaglide.visible=selectedTool==='seaglide';
    const equipTimer = Math.max(0, (viewModel.userData.equipTimer || 0) - dt);
    viewModel.userData.equipTimer = equipTimer;
    const equipProgress = 1 - equipTimer / 0.34;
    const equipDip = equipTimer > 0 ? Math.sin(equipProgress * Math.PI) * 0.095 : 0;
    const actionTimer = Math.max(0, (viewModel.userData.actionTimer || 0) - dt);
    viewModel.userData.actionTimer = actionTimer;
    const actionDuration = viewModel.userData.actionType === 'knife' ? 0.34 : 0.52;
    const actionProgress = actionTimer > 0 ? 1 - actionTimer / actionDuration : 0;
    const actionPulse = actionTimer > 0 ? Math.sin(actionProgress * Math.PI) : 0;
    viewModel.userData.knife.rotation.x = viewModel.userData.actionType === 'knife' ? -actionPulse * 0.92 : 0;
    viewModel.userData.scanner.rotation.x = viewModel.userData.actionType === 'scanner' ? -actionPulse * 0.15 : 0;
    viewModel.userData.builder.rotation.x = viewModel.userData.actionType === 'builder' ? -actionPulse * 0.12 : 0;
    viewModel.userData.repairTool.rotation.x = viewModel.userData.actionType === 'repair' ? -actionPulse * 0.16 : 0;
    viewModel.userData.seaglideProp.rotation.z += dt * (selectedTool === 'seaglide' ? 14 : 0.35);
    if (actionTimer <= 0) viewModel.userData.actionType = '';
    viewModel.userData.left.rotation.x = 0.08 + stroke * 0.20 * moving;
    viewModel.userData.right.rotation.x = 0.08 - stroke * 0.18 * moving;
    viewModel.userData.left.rotation.z = 0.035 + Math.cos(player.swimPhase * 0.5) * 0.048 + Math.sin(player.bob) * 0.012;
    viewModel.userData.right.rotation.z = -0.035 - Math.cos(player.swimPhase * 0.5) * 0.048 - Math.sin(player.bob) * 0.012;
    viewModel.userData.left.position.y = -0.19 + Math.sin(player.swimPhase * 2) * 0.028 * moving;
    viewModel.userData.right.position.y = -0.19 - Math.sin(player.swimPhase * 2) * 0.028 * moving;
    viewModel.position.y = -0.015 + eyeBob * 0.65 - equipDip;
    viewModel.position.x = Math.sin(player.swimPhase * 0.5) * 0.018 * moving;
  }
  if (particleGroup) { particleGroup.position.set(player.position.x, player.position.y, player.position.z); particleGroup.rotation.y += dt * 0.012; }
  if (lightRayGroup) { lightRayGroup.position.set(player.position.x, Math.min(-3, player.position.y + 18), player.position.z); lightRayGroup.rotation.y += dt * 0.004; }
  const waterCellX = Math.floor(player.position.x / 500) * 500;
  const waterCellZ = Math.floor(player.position.z / 500) * 500;
  if (water) { water.position.x = waterCellX; water.position.z = waterCellZ; water.position.y = Math.sin(clockState.elapsed * 0.35) * 0.08; }
  if (scene?.fog) {
    const depth = Math.max(0, -player.position.y);
    const biome = getBiomeAt(player.position.x, player.position.y, player.position.z);
    currentBiome = biome;
    updateBiomeAudio(biome);
    if (water?.material?.color) water.material.color.setHex(biome.fog);
    const baseDensity = settings.graphics === 'low' ? biome.density * 1.22 : settings.graphics === 'high' ? biome.density * 0.82 : biome.density;
    scene.fog.density = baseDensity + Math.min(0.0014, depth * 0.00003);
    scene.fog.color.setHex(biome.fog);
    if (water?.material?.map) { water.material.map.offset.x = (clockState.elapsed * 0.003) % 1; water.material.map.offset.y = (clockState.elapsed * 0.0017) % 1; }
  }
}

function setSurvivalBar(name, value) {
  const percent = clamp(Number(value) || 0, 0, 100);
  const fill = $(`${name}-fill`);
  const label = $(`${name}-value`);
  const gauge = $(`${name}-gauge`);
  if (gauge) {
    gauge.style.setProperty('--gauge-pct', `${percent}%`);
    gauge.classList.toggle('is-low', percent <= 25);
    gauge.classList.toggle('is-critical', percent <= 12);
    if (name === 'oxygen') gauge.style.setProperty('--gauge-color', percent <= 12 ? '#ff625f' : percent <= 25 ? '#efbb62' : '#83e4a0');
  }
  if (fill) {
    fill.style.width = `${percent}%`;
    fill.classList.toggle('is-low', percent <= 25);
    fill.classList.toggle('is-critical', percent <= 12);
  }
  if (label) label.textContent = String(Math.round(percent));
}

function updateSurvivalHud() {
  setSurvivalBar('hp', survival.hp);
  setSurvivalBar('oxygen', survival.oxygen / getMaxOxygen() * 100);
  $('oxygen-value').textContent = `${Math.ceil(survival.oxygen)}/${getMaxOxygen()}`;
  setSurvivalBar('food', survival.food);
  setSurvivalBar('water', survival.water);
  const depthNow=Math.max(0,-player.position.y);
  const hud = $('hud');
  if (hud) {
    hud.classList.toggle('is-deep', depthNow >= 28);
    hud.classList.toggle('is-oxygen-critical', survival.oxygen <= getMaxOxygen() * 0.22);
    hud.dataset.depthBand = depthNow < 10 ? 'shallow' : depthNow < 28 ? 'mid' : depthNow < 42 ? 'deep' : 'extreme';
  }
  const depthIndicator = document.querySelector('.depth-indicator');
  if (depthIndicator) {
    depthIndicator.style.setProperty('--depth-progress', `${clamp(depthNow / 42 * 100, 0, 100)}%`);
    depthIndicator.dataset.depthBand = depthNow < 10 ? 'shallow' : depthNow < 28 ? 'mid' : depthNow < 42 ? 'deep' : 'extreme';
  }
  const depthCaption = document.querySelector('.depth-caption');
  if (depthCaption) depthCaption.textContent = 'DEPTH';
  const critical = survival.hp <= 25 || survival.oxygen <= getMaxOxygen() * 0.18 || survival.water <= 15 || survival.food <= 10;
  $('survival-status')?.classList.toggle('is-warning', critical || survival.oxygen <= getMaxOxygen() * 0.32);
  if ($('biome-label')) $('biome-label').textContent = currentBiome.label.toUpperCase();
  const nearOxygen=isHabitatPowered(getInsideHabitat());
  const status=$('survival-status');
  if(status)status.textContent = critical ? 'WARNING' : nearOxygen ? 'O₂ REFILL' : survival.oxygen <= getMaxOxygen() * 0.32 ? 'LOW O₂' : 'STABLE';
  updateResourcePrompt();
}

function applyDamage(amount, source = 'Bahaya bawah laut') {
  if (!gameActive || isRespawning || amount <= 0) return;
  playSfx('damage');
  survival.hp = clamp(survival.hp - amount, 0, 100);
  const flash = $('damage-flash');
  flash.classList.remove('active');
  void flash.offsetWidth;
  flash.classList.add('active');
  showToast(`${source} · -${Math.round(amount)} HP`);
  updateSurvivalHud();
  if (survival.hp <= 0) {
    isRespawning = true;
    setTimeout(() => {
      player.position.copy(respawnPoint);
      player.velocity.set(0,0,0); player.pitch=0.02;
      survival.hp=75; survival.oxygen=Math.min(getMaxOxygen(),45);
      survival.food=Math.max(survival.food,35); survival.water=Math.max(survival.water,35);
      isRespawning=false; chunkCenterX=NaN; updateChunks(true); updateCamera(0.016); updateSurvivalHud();
      markUnsaved(); showToast('Kamu pingsan dan kembali ke habitat aman terakhir.');
    },850);
  }
}

function updateSurvival(dt) {
  const depth = Math.max(0, -player.position.y);
  const atSurface = player.position.y >= -1.4;
  const indoorHabitat = getInsideHabitat();
  const biome = getBiomeAt(player.position.x, player.position.y, player.position.z);
  currentBiome = biome;
  // Habitat oxygen is intentionally an interior-only service. Being next to a module or an outside station does not refill O2.
  if (indoorHabitat && isHabitatPowered(indoorHabitat)) {
    survival.oxygen = clamp(survival.oxygen + 15 * dt, 0, getMaxOxygen());
    if (Math.floor(clockState.elapsed) !== Math.floor(clockState.elapsed - dt)) playSfx('oxygen');
  } else if (atSurface) {
    survival.oxygen = clamp(survival.oxygen + 9 * dt, 0, getMaxOxygen());
  } else {
    const oxygenRate = equipment.rebreather && depth >= 20 ? 0.75 : 1;
    survival.oxygen = clamp(survival.oxygen - oxygenRate * dt, 0, getMaxOxygen());
  }
  survival.food = clamp(survival.food - 0.014 * dt, 0, 100);
  survival.water = clamp(survival.water - 0.02 * dt, 0, 100);
  // Depth changes visibility and fauna distribution; standard diving oxygen remains a continuous 1 unit/second.

  if (survival.oxygen <= 0) {
    oxygenDamageTimer += dt;
    if (oxygenDamageTimer >= 2.2) { oxygenDamageTimer = 0; applyDamage(6, 'Kehabisan oksigen'); }
  } else oxygenDamageTimer = 0;
  if (survival.food <= 0) {
    hungerDamageTimer += dt;
    if (hungerDamageTimer >= 10) { hungerDamageTimer = 0; applyDamage(2, 'Kelaparan'); }
  } else hungerDamageTimer = 0;
  if (survival.water <= 0) {
    thirstDamageTimer += dt;
    if (thirstDamageTimer >= 8) { thirstDamageTimer = 0; applyDamage(2.5, 'Dehidrasi'); }
  } else thirstDamageTimer = 0;
}

function useMedkit() {
  if (survival.medkits <= 0 || survival.hp >= 96) return;
  survival.medkits -= 1;
  survival.hp = clamp(survival.hp + 38, 0, 100);
  updateSurvivalHud();
  markUnsaved();
  showToast('Medkit digunakan · HP dipulihkan.');
}

function useRation() {
  if (survival.rations <= 0 || (survival.food >= 96 && survival.water >= 96)) return;
  survival.rations -= 1;
  survival.food = clamp(survival.food + 42, 0, 100);
  survival.water = clamp(survival.water + 38, 0, 100);
  updateSurvivalHud();
  markUnsaved();
  showToast('Ransum digunakan · Food dan Water dipulihkan.');
}

function useWater() {
  if (survival.waterBottles <= 0 || survival.water >= 96) return;
  survival.waterBottles -= 1;
  survival.water = clamp(survival.water + 46, 0, 100);
  updateSurvivalHud();
  markUnsaved();
  showToast('Air murni diminum · hidrasi dipulihkan.');
}

function openSupplyCache(cacheId) {
  const cache = supplyCacheLocations.find(item => item.id === cacheId);
  if (!cache || collectedCaches.has(cache.id)) { showToast('Tidak ada supply cache yang dapat dijangkau.'); return; }
  const distance = Math.hypot(player.position.x-cache.x, player.position.y-cache.y, player.position.z-cache.z);
  if (distance >= 14) { showToast('Dekati peti suplai terlebih dahulu.'); return; }
  collectedCaches.add(cache.id);
  survival.medkits = clamp(survival.medkits + 1, 0, 20);
  survival.rations = clamp(survival.rations + 2, 0, 20);
  survival.waterBottles = clamp(survival.waterBottles + 1, 0, 20);
  inventory.titanium = clamp(inventory.titanium + 2, 0, 999);
  inventory.copper = clamp(inventory.copper + 1, 0, 999);
  updateSurvivalHud();
  markUnsaved();
  showToast(`${cache.name} dibuka · +1 Medkit · +2 Rations`);
}

function scanNearestFauna() {
  triggerToolAnimation('scanner');
  playSfx('scan');
  const scanPitch=clamp(player.pitch,-1.1,1.1);
  const scanDirection=new THREE.Vector3(Math.sin(player.yaw)*Math.cos(scanPitch),-Math.sin(scanPitch),-Math.cos(player.yaw)*Math.cos(scanPitch)).normalize();
  const scanOrigin=new THREE.Vector3(player.position.x,player.position.y+0.55,player.position.z);
  const scanAim={origin:scanOrigin,direction:scanDirection,minAlignment:0.945};
  const faunaTarget=faunaDirector?.getScanTarget(player.position,62,scanAim);
  const worldTarget=getAimedWorldTarget();
  if(worldTarget && faunaTarget && worldTarget.distance <= faunaTarget.distance){showToast('Bidik makhluk hidup dengan reticle; ada objek lain lebih dekat di garis pandang.');return;}
  const result = faunaDirector?.scan(player.position, 24, scanAim);
  if (!result) { showToast('Arahkan reticle tepat ke makhluk hidup dalam jangkauan pemindai.'); return; }
  if (getCurrentMission()?.id === 'scan') advanceMission('scan');
  const prefix = result.isNew ? 'SPESIES BARU' : 'TERDETEKSI';
  showToast(`${prefix}: ${result.name} · ${result.distance} m · ${result.total}/${result.maximum}`);
  updateSurvivalHud();
  renderPda();
  if (activeSlot >= 0) markUnsaved();
}

function updateHud() {
  const liveBiome=getBiomeAt(player.position.x,player.position.y,player.position.z);
  currentBiome=liveBiome;
  $('biome-label').textContent = liveBiome.label.toUpperCase();
  if (!knownBiomes.has(liveBiome.id)) { knownBiomes.add(liveBiome.id); if(activeSlot>=0) markUnsaved(); showToast(`BIOME DISCOVERED · ${liveBiome.label}`); }
  faunaDirector?.setBiome(liveBiome.id);
  $('depth-label').textContent = `${Math.max(0, Math.round(-player.position.y))} m`;
  const dIsland = Math.hypot(player.position.x - islandOfInterest.x, player.position.z - islandOfInterest.z);
  const dShip = Math.hypot(player.position.x - shipOfInterest.x, player.position.z - shipOfInterest.z);
  if(dShip < 82 && getCurrentMission()?.id === 'wreck') advanceMission('wreck');
  updateResourcePrompt(); 
  $('poi-banner').innerHTML = `${liveBiome.label.toUpperCase()} <span>— ${liveBiome.note}</span>`;
  if (dIsland < 115) $('poi-banner').innerHTML = `VERDANT ISLE · ${liveBiome.label.toUpperCase()} <span>— Island habitat</span>`;
  else if (dShip < 95) $('poi-banner').innerHTML = `WRECKFALL SHELF <span>— Abandoned vessel signal</span>`;
  if (faunaStatus.threat && faunaStatus.threat.distance < 40) {
    $('poi-banner').innerHTML = `PREDATOR ALERT · ${faunaStatus.threat.name.toUpperCase()} <span>— Threat detected · ${Math.round(faunaStatus.threat.distance)} m</span>`;
    $('poi-banner').classList.add('danger-signal');
  } else if (faunaStatus.nearest) {
    $('poi-banner').classList.remove('danger-signal');
    if (dIsland >= 115 && dShip >= 95) $('poi-banner').innerHTML = `LIFEFORM SIGNAL <span>— ${faunaStatus.nearest.species.name} · ${Math.round(faunaStatus.nearest.distance)} m</span>`;
  } else $('poi-banner').classList.remove('danger-signal');
  updateSurvivalHud();
}

function animate(now) {
  requestAnimationFrame(animate);
  const dt = Math.min((now - lastFrame) / 1000, 0.05);
  lastFrame = now;
  clockState.elapsed += dt;
  if (kelpShader?.uniforms?.uAbyssTime) kelpShader.uniforms.uAbyssTime.value=clockState.elapsed;
  if(introSequence.active && !gamePaused) {
    updateCinematic(dt);
  } else if (gameActive && !gamePaused) {
    updateMovement(dt);
    updateWorldPhysics(dt);
    updateSurvival(dt);
    currentBiome = getBiomeAt(player.position.x, player.position.y, player.position.z);
    faunaStatus = faunaDirector?.update(dt, player.position, currentBiome.id) || faunaStatus;
    const cx = Math.floor(player.position.x / CHUNK_SIZE), cz = Math.floor(player.position.z / CHUNK_SIZE);
    if (cx !== chunkCenterX || cz !== chunkCenterZ) updateChunks();
    updateCamera(dt);

    // Co-op broadcasts player transforms at a conservative 5 Hz. Presence
    // and chat continue independently; local-only mode does not open sockets.
    if (online.inRoom && now - lastMultiplayerSync >= 190) {
      lastMultiplayerSync = now;
      online.broadcastPlayerState({
        x:player.position.x, y:player.position.y, z:player.position.z,
        yaw:player.yaw, pitch:player.pitch,
        depth:Math.max(0,-player.position.y), biome:currentBiome.id,
        tool:getSelectedHotbarItem() || ''
      }).catch(error => console.warn('[The Abyssal] Multiplayer broadcast:', error.message));
    }

    // No background saving: progress is committed only when the player selects Save.

    if (now - lastHudUpdate > 300) { lastHudUpdate = now; updateHud(); }
  } else if (rendererReady) {
    camera.position.x += Math.sin(now * 0.00007) * 0.012;
    camera.lookAt(0, -5, 0);
  }
  updateRemoteDiverVisuals(dt);
  if (renderer) renderer.render(scene, camera);
}

async function checkForAppUpdate() {
  const manifestUrl = window.ABYSSAL_UPDATE_MANIFEST_URL || '';
  if (!manifestUrl || !/^https:\/\//i.test(manifestUrl)) return;
  try {
    const response = await fetch(manifestUrl, { cache: 'no-store', headers: { Accept: 'application/json' } });
    if (!response.ok) throw new Error(`Update server returned ${response.status}`);
    const manifest = await response.json();
    const current = '1.6.2';
    if (!manifest || typeof manifest.version !== 'string' || typeof manifest.downloadUrl !== 'string') return;
    const download = new URL(manifest.downloadUrl);
    if (download.protocol !== 'https:') return;
    if (manifest.version !== current && compareVersions(manifest.version, current) > 0) {
      const install = window.confirm(`The Abyssal ${manifest.version} tersedia. Buka unduhan pembaruan APK?\n\n${manifest.notes || ''}\n\nAndroid akan meminta persetujuan sebelum memasang APK.`);
      if (install) {
        if (Boolean(window.Capacitor?.isNativePlatform?.())) {
          const { Browser } = await import('@capacitor/browser');
          await Browser.open({ url: download.toString() });
        } else window.open(download.toString(), '_blank', 'noopener');
      }
    }
  } catch (error) {
    console.info('Abyssal update check skipped:', error.message);
  }
}
function compareVersions(a, b) {
  const aa = a.split('.').map(Number), bb = b.split('.').map(Number);
  for (let i = 0; i < Math.max(aa.length, bb.length); i++) {
    const diff = (aa[i] || 0) - (bb[i] || 0);
    if (diff) return diff;
  }
  return 0;
}

async function boot() {
  try {
    $('boot-message').textContent = 'Membangun geometri dasar laut...';
    $('loading-bar').style.width = '18%';
    createWorld();
    $('boot-message').textContent = 'Menyiapkan kontrol dan antarmuka...';
    $('loading-bar').style.width = '72%';
    setupControls();
    bindNativeLifecycle().catch(error => console.warn('[The Abyssal] Native lifecycle setup skipped:', error));
    syncSettingsInputs();
    applyLanguage();
    // Online accounts/co-op are optional. Local single-player remains available
    // when no Supabase credentials or network connection are present.
    initializeOnlineServices().catch(error => console.warn('[The Abyssal] Online init skipped:', error));
    checkForAppUpdate().catch(() => {});
    $('boot-message').textContent = 'Dunia siap. Memulai ekspedisi...';
    $('loading-bar').style.width = '100%';
    // The APK contains its own offline-ready bundle. Service workers are only
    // used by an optional browser preview, never by the native Android shell.
    if (!Boolean(window.Capacitor?.isNativePlatform?.()) && 'serviceWorker' in navigator && location.protocol.startsWith('http')) {
      navigator.serviceWorker.register('./sw.js').catch(() => {});
    }
    setTimeout(() => {
      setVisibleScreen('main');
      $('boot-screen').classList.add('hidden');
    }, 350);
    requestAnimationFrame(animate);
  } catch (error) {
    console.error('[The Abyssal] Boot failed:', error);
    const message = error instanceof Error ? error.message : String(error);
    $('boot-title')?.classList.add('boot-error');
    $('boot-subtitle')?.classList.add('hidden');
    $('boot-message').textContent = `Dunia 3D gagal dimuat: ${message}. Periksa perangkat, lalu coba lagi.`;
    $('loading-bar').style.width = '100%';
    const retryButton = $('boot-retry-btn');
    if (retryButton) {
      retryButton.hidden = false;
      retryButton.onclick = () => window.location.reload();
    }
  }
}

boot();
