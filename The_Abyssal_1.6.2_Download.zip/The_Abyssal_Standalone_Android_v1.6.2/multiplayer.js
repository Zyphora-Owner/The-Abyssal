import { createClient } from '@supabase/supabase-js';
import {
  flattenPresence,
  normalizeRoomCode,
  sanitizeChatText,
  sanitizeDisplayName,
  sanitizePlayerState,
  validatePublicBackendConfig
} from './multiplayer-core.mjs';

const env = import.meta.env || {};
const runtimeConfig = typeof window !== 'undefined' ? (window.ABYSSAL_SUPABASE_CONFIG || {}) : {};
const ROOM_STORAGE_KEY = 'the-abyssal-online-room-v1';
const BACKEND_STORAGE_KEY = 'the-abyssal-supabase-config-v1';

function initialBackendConfig() {
  const candidates = [];
  if (typeof localStorage !== 'undefined') {
    try {
      const stored = JSON.parse(localStorage.getItem(BACKEND_STORAGE_KEY) || 'null');
      if (stored?.url || stored?.publishableKey) candidates.push([stored.url, stored.publishableKey]);
    } catch { /* ignore malformed local config */ }
  }
  candidates.push(
    [runtimeConfig.url, runtimeConfig.publishableKey || runtimeConfig.anonKey],
    [env.VITE_SUPABASE_URL, env.VITE_SUPABASE_PUBLISHABLE_KEY || env.VITE_SUPABASE_ANON_KEY]
  );
  for (const [url, key] of candidates) {
    if (!url || !key) continue;
    try { return validatePublicBackendConfig(url, key); }
    catch (error) { console.warn('[The Abyssal] Supabase config ignored:', error.message); }
  }
  return { url: '', publishableKey: '' };
}

class AbyssalOnlineService {
  constructor() {
    const backend = initialBackendConfig();
    this.projectUrl = backend.url;
    this.publishableKey = backend.publishableKey;
    this.client = null;
    this.user = null;
    this.room = null;
    this.channel = null;
    this.members = [];
    this.heartbeatTimer = 0;
    this.lastPlayerBroadcast = 0;
    this.callbacks = {};
    this.authSubscription = null;
    this.initialized = false;
    this.connectionState = 'idle';
    this.lastChatAt = 0;
    this.networkListenersBound = false;
    this.heartbeatInFlight = false;
    this.authSettings = null;
  }

  get configured() { return Boolean(this.projectUrl && this.publishableKey); }
  get authReady() { return Boolean(this.configured && this.client && this.initialized); }
  get signupAllowed() { return this.authSettings?.disable_signup !== true && this.authSettings?.external?.email !== false; }
  get inRoom() { return Boolean(this.room && this.channel); }
  get userId() { return this.user?.id || ''; }
  get displayName() {
    return sanitizeDisplayName(this.user?.user_metadata?.display_name || this.user?.email?.split('@')[0] || 'Diver');
  }

  notifyStatus(message, type = 'info') {
    this.callbacks.onStatus?.({ message: String(message || ''), type });
  }

  notifyAuth() {
    this.callbacks.onAuthChange?.(this.user);
  }

  async configureBackend({ url, publishableKey } = {}) {
    const backend = validatePublicBackendConfig(url, publishableKey);
    if (this.projectUrl === backend.url && this.publishableKey === backend.publishableKey && this.initialized) {
      try {
        const authSettings = await this.verifyBackend();
        this.authSettings = authSettings;
        this.connectionState = 'ready';
        return { configured: true, reachable: true, authSettings, user: this.user };
      } catch (error) {
        this.authSettings = null;
        this.connectionState = 'offline';
        this.notifyStatus(`Konfigurasi tersimpan, tetapi server belum dapat dijangkau: ${error.message || error}`, 'warning');
        return { configured: true, reachable: false, error, user: this.user };
      }
    }

    clearInterval(this.heartbeatTimer);
    this.heartbeatTimer = 0;
    this.heartbeatInFlight = false;
    if (this.channel && this.client) {
      const previousChannel = this.channel;
      this.channel = null;
      this.room = null;
      try { await previousChannel.untrack(); } catch { /* old socket may be closed */ }
      try { await this.client.removeChannel(previousChannel); } catch { /* best effort */ }
    }
    this.authSubscription?.unsubscribe?.();
    this.authSubscription = null;
    this.client = null;
    this.user = null;
    this.room = null;
    this.members = [];
    this.initialized = false;
    this.authSettings = null;
    this.connectionState = 'idle';
    this.callbacks.onMembers?.([]);
    this.callbacks.onRoomChange?.(null, []);
    this.projectUrl = backend.url;
    this.publishableKey = backend.publishableKey;
    try {
      localStorage.setItem(BACKEND_STORAGE_KEY, JSON.stringify(backend));
      localStorage.removeItem(ROOM_STORAGE_KEY);
    } catch { throw new Error('Konfigurasi tidak dapat disimpan pada perangkat ini. Periksa izin penyimpanan aplikasi.'); }
    return this.init(this.callbacks);
  }

  async init(callbacks = {}) {
    this.callbacks = callbacks;
    if (!this.configured) {
      this.notifyStatus('Backend belum dihubungkan. Buka bagian HUBUNGKAN BACKEND dan masukkan Project URL serta Publishable Key Supabase.', 'warning');
      return { configured: false, user: null };
    }
    if (this.initialized && this.client) return { configured: true, user: this.user };

    const validated = validatePublicBackendConfig(this.projectUrl, this.publishableKey);
    this.projectUrl = validated.url;
    this.publishableKey = validated.publishableKey;
    this.client = createClient(this.projectUrl, this.publishableKey, {
      auth: {
        autoRefreshToken: true,
        persistSession: true,
        detectSessionInUrl: false,
        flowType: 'pkce'
      },
      realtime: { params: { eventsPerSecond: 12 } }
    });

    const { data, error } = await this.client.auth.getSession();
    if (error) throw error;
    this.user = data.session?.user || null;
    this.authSubscription = this.client.auth.onAuthStateChange((event, session) => {
      this.user = session?.user || null;
      if (!this.user && this.channel) this.clearLocalRoom();
      this.notifyAuth();
      this.callbacks.onAuthEvent?.(event, this.user);
    }).data.subscription;
    this.initialized = true;
    this.connectionState = typeof navigator !== 'undefined' && navigator.onLine === false ? 'offline' : 'ready';
    if (typeof window !== 'undefined' && !this.networkListenersBound) {
      window.addEventListener('offline', () => {
        this.connectionState = 'offline';
        this.notifyStatus('Internet terputus. Ruang akan mencoba tersambung kembali saat koneksi pulih.', 'warning');
      });
      window.addEventListener('online', () => {
        this.connectionState = this.inRoom ? 'reconnecting' : 'ready';
        if (this.room) this.notifyStatus('Internet kembali. Menyambungkan ulang ruang ekspedisi...', 'info');
        else this.notifyStatus('Internet kembali tersedia.', 'success');
      });
      this.networkListenersBound = true;
    }
    this.notifyAuth();
    let reachable = false;
    try {
      this.authSettings = await this.verifyBackend();
      reachable = true;
      this.connectionState = 'ready';
      if (this.authSettings.disable_signup === true) {
        this.notifyStatus('Server terhubung, tetapi pendaftaran akun sedang dinonaktifkan pada pengaturan Supabase Auth.', 'warning');
      } else if (this.authSettings.external?.email === false) {
        this.notifyStatus('Server terhubung, tetapi provider Email belum diaktifkan pada Supabase Auth.', 'warning');
      } else {
        this.notifyStatus(this.user ? `Sesi akun dipulihkan: ${this.displayName}.` : 'Server Supabase terhubung. Kamu dapat Register atau Login.', 'success');
      }
    } catch (error) {
      this.authSettings = null;
      this.connectionState = 'offline';
      this.notifyStatus(`URL dan key tersimpan, tetapi server belum bisa dijangkau: ${error.message || error}. Periksa internet dan Project URL.`, 'warning');
    }
    if (this.user) this.resumeSavedRoom().catch(error => console.warn('[The Abyssal] Saved room restore skipped:', error.message));
    return { configured: true, reachable, authSettings: this.authSettings, user: this.user };
  }

  async verifyBackend() {
    this.requireClient();
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 12000);
    try {
      const response = await fetch(`${this.projectUrl}/auth/v1/settings`, {
        method: 'GET',
        headers: { apikey: this.publishableKey, Accept: 'application/json' },
        cache: 'no-store',
        signal: controller.signal
      });
      let settings = null;
      try { settings = await response.json(); } catch { /* server did not return JSON */ }
      if (!response.ok) {
        const detail = settings?.msg || settings?.message || settings?.error_description || `HTTP ${response.status}`;
        if (response.status === 401 || response.status === 403) {
          throw new Error('Publishable Key tidak cocok dengan Project URL atau tidak diterima oleh server.');
        }
        throw new Error(`Auth API Supabase merespons ${detail}.`);
      }
      if (!settings || typeof settings !== 'object' || Array.isArray(settings)) {
        throw new Error('Auth API merespons, tetapi data pengaturan tidak valid.');
      }
      return settings;
    } catch (error) {
      if (error?.name === 'AbortError') throw new Error('Pemeriksaan koneksi melewati batas waktu. Pastikan internet aktif.');
      if (/failed to fetch|networkerror|load failed/i.test(String(error?.message || ''))) {
        throw new Error('Tidak dapat menjangkau Supabase. Periksa koneksi internet, URL proyek, atau pembatasan jaringan.');
      }
      throw error;
    } finally {
      clearTimeout(timeout);
    }
  }

  async resumeSavedRoom() {
    if (!this.user || this.inRoom || typeof localStorage === 'undefined') return null;
    let code = '';
    try { code = normalizeRoomCode(localStorage.getItem(ROOM_STORAGE_KEY)); } catch { return null; }
    if (code.length !== 6) return null;
    try {
      const room = await this.joinRoom(code);
      this.notifyStatus(`Kembali ke ruang ${room.code}.`, 'success');
      return room;
    } catch (error) {
      try { localStorage.removeItem(ROOM_STORAGE_KEY); } catch { /* optional storage */ }
      this.notifyStatus(`Ruang sebelumnya tidak dapat dipulihkan: ${error.message || error}`, 'warning');
      return null;
    }
  }

  requireClient() {
    if (!this.configured || !this.client) throw new Error('Layanan online belum dikonfigurasi. Periksa pengaturan Supabase dan build aplikasi.');
  }

  async register({ displayName, email, password }) {
    this.requireClient();
    const name = sanitizeDisplayName(displayName, '');
    const normalizedEmail = String(email || '').trim().toLowerCase();
    if (name.length < 3) throw new Error('Nama penyelam harus terdiri dari minimal 3 karakter.');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) throw new Error('Masukkan alamat email yang valid.');
    if (String(password || '').length < 8) throw new Error('Kata sandi minimal 8 karakter.');
    const { data, error } = await this.client.auth.signUp({
      email: normalizedEmail,
      password: String(password),
      options: { data: { display_name: name } }
    });
    if (error) throw error;
    if (data.session?.user) this.user = data.session.user;
    this.notifyAuth();
    return { user: data.user || null, needsEmailConfirmation: !data.session, session: data.session || null };
  }

  async login({ email, password }) {
    this.requireClient();
    const normalizedEmail = String(email || '').trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) throw new Error('Masukkan alamat email yang valid.');
    if (!String(password || '')) throw new Error('Masukkan kata sandi.');
    const { data, error } = await this.client.auth.signInWithPassword({ email: normalizedEmail, password: String(password) });
    if (error) throw error;
    this.user = data.user;
    this.notifyAuth();
    this.resumeSavedRoom().catch(error => console.warn('[The Abyssal] Saved room restore skipped:', error.message));
    return data;
  }

  async logout() {
    this.requireClient();
    if (this.room) await this.leaveRoom();
    const { error } = await this.client.auth.signOut();
    if (error) throw error;
    this.user = null;
    this.notifyAuth();
  }

  async createRoom(name = 'Deep Expedition') {
    this.requireAuthenticated();
    const roomName = String(name || 'Deep Expedition').replace(/[\u0000-\u001f<>]/g, '').trim().replace(/\s+/g, ' ').slice(0, 32) || 'Deep Expedition';
    const { data, error } = await this.client.rpc('abyssal_create_room', { p_name: roomName, p_max_players: 4 });
    if (error) throw error;
    const room = Array.isArray(data) ? data[0] : data;
    if (!room?.room_id || !room?.room_code) throw new Error('Server tidak mengembalikan informasi ruang yang valid. Jalankan SQL multiplayer The Abyssal.');
    await this.connectRoom({ id: room.room_id, code: room.room_code, name: room.room_name, maxPlayers: room.max_players || 4 });
    return this.room;
  }

  async joinRoom(code) {
    this.requireAuthenticated();
    const roomCode = normalizeRoomCode(code);
    if (roomCode.length !== 6) throw new Error('Kode ruang harus terdiri dari 6 huruf atau angka.');
    const { data, error } = await this.client.rpc('abyssal_join_room', { p_room_code: roomCode });
    if (error) {
      if (/ROOM_NOT_FOUND/i.test(error.message)) throw new Error('Ruang tidak ditemukan. Periksa kembali kode undangan.');
      if (/ROOM_FULL/i.test(error.message)) throw new Error('Ruang sudah penuh (maksimal 4 penyelam).');
      throw error;
    }
    const room = Array.isArray(data) ? data[0] : data;
    if (!room?.room_id) throw new Error('Server tidak mengembalikan informasi ruang.');
    await this.connectRoom({ id: room.room_id, code: room.room_code, name: room.room_name, maxPlayers: room.max_players || 4 });
    return this.room;
  }

  requireAuthenticated() {
    this.requireClient();
    if (!this.user) throw new Error('Masuk ke akun terlebih dahulu.');
  }

  async connectRoom(room) {
    if (this.room?.id === room.id && this.channel) return;
    if (this.room) await this.leaveRoom();
    const topic = `abyssal-room:${room.id}`;
    const channel = this.client.channel(topic, {
      config: {
        private: true,
        broadcast: { self: false, ack: true },
        presence: { key: this.user.id }
      }
    });

    channel
      .on('broadcast', { event: 'player_state' }, ({ payload }) => {
        const state = sanitizePlayerState(payload);
        if (state && state.userId !== this.user?.id) this.callbacks.onPlayerState?.(state);
      })
      .on('broadcast', { event: 'room_chat' }, ({ payload }) => {
        const message = this.normalizeChatMessage(payload);
        if (message && message.senderId !== this.user?.id) this.callbacks.onChat?.(message);
      })
      .on('presence', { event: 'sync' }, () => this.updatePresence(channel))
      .on('presence', { event: 'join' }, () => this.updatePresence(channel))
      .on('presence', { event: 'leave' }, () => this.updatePresence(channel));

    this.room = room;
    this.channel = channel;
    this.members = [];
    await new Promise((resolve, reject) => {
      let settled = false;
      const timeout = setTimeout(() => {
        if (settled) return;
        settled = true;
        this.connectionState = 'error';
        reject(new Error('Koneksi ruang melewati batas waktu. Periksa internet, SQL migrasi, dan pengaturan kanal privat Supabase.'));
      }, 18000);

      const failInitialJoin = error => {
        this.connectionState = 'error';
        this.notifyStatus(error.message, 'error');
        if (!settled) {
          settled = true;
          clearTimeout(timeout);
          reject(error);
        }
      };

      channel.subscribe(async (status, realtimeError) => {
        // A room can disconnect and reconnect while the app remains open.
        // Re-track Presence after every successful subscription, not only the first one.
        if (this.channel !== channel || !this.room) return;
        if (status === 'SUBSCRIBED') {
          try {
            const trackStatus = await channel.track({
              user_id: this.user.id,
              display_name: this.displayName,
              joined_at: new Date().toISOString()
            });
            if (trackStatus !== 'ok') {
              throw new Error(`Presence gagal diperbarui (${String(trackStatus)}). Periksa izin Realtime pada SQL.`);
            }
            this.connectionState = 'in-room';
            try { localStorage.setItem(ROOM_STORAGE_KEY, room.code); } catch { /* room code persistence is optional */ }
            this.updatePresence(channel);
            this.startHeartbeat();
            this.callbacks.onRoomChange?.(this.room, this.members);
            if (!settled) {
              settled = true;
              clearTimeout(timeout);
              this.notifyStatus(`Terhubung ke ruang ${room.code}. Bagikan kode ini kepada teman.`, 'success');
              resolve();
            } else {
              this.notifyStatus('Koneksi ruang pulih. Posisi penyelam dan radio tersambung kembali.', 'success');
            }
          } catch (error) {
            failInitialJoin(error instanceof Error ? error : new Error(String(error)));
          }
        } else if (['CHANNEL_ERROR', 'TIMED_OUT', 'CLOSED'].includes(status)) {
          const detail = realtimeError?.message || realtimeError?.reason || status;
          failInitialJoin(new Error(`Koneksi realtime gagal: ${detail}. Periksa internet, SQL migrasi, dan izin kanal privat.`));
        }
      });
    }).catch(async error => {
      this.clearLocalRoom();
      try { await this.client.rpc('abyssal_leave_room', { p_room_id: room.id }); } catch { /* best-effort membership cleanup */ }
      throw error;
    });
  }

  updatePresence(channel = this.channel) {
    if (!channel) return;
    this.members = flattenPresence(channel.presenceState());
    this.callbacks.onMembers?.(this.members);
    if (this.room) this.callbacks.onRoomChange?.(this.room, this.members);
  }

  startHeartbeat() {
    clearInterval(this.heartbeatTimer);
    this.heartbeatInFlight = false;
    this.heartbeatTimer = setInterval(async () => {
      if (this.heartbeatInFlight || !this.room || !this.client || !this.user) return;
      this.heartbeatInFlight = true;
      const roomSnapshot = this.room;
      try {
        const { data, error } = await this.client.rpc('abyssal_touch_room', { p_room_id: roomSnapshot.id });
        if (error) throw error;
        if (data === false) {
          // The server prunes members that were asleep/offline for >90 seconds.
          // Rejoin with the stored invite code so waking the app restores the
          // actual database membership, not only the local Realtime socket.
          const { data: joined, error: joinError } = await this.client.rpc('abyssal_join_room', { p_room_code: roomSnapshot.code });
          if (joinError) throw joinError;
          const record = Array.isArray(joined) ? joined[0] : joined;
          if (!record?.room_id || record.room_id !== roomSnapshot.id) {
            throw new Error('Keanggotaan ruang tidak dapat dipulihkan. Minta kode undangan baru dari pemilik ruang.');
          }
          if (this.room?.id === roomSnapshot.id) {
            this.room = {
              ...this.room,
              name: record.room_name || this.room.name,
              maxPlayers: record.max_players || this.room.maxPlayers
            };
            this.connectionState = 'in-room';
            this.updatePresence();
            this.callbacks.onRoomChange?.(this.room, this.members);
            this.notifyStatus('Keanggotaan ruang dipulihkan setelah aplikasi kembali aktif.', 'success');
          }
        } else {
          this.connectionState = 'in-room';
        }
      } catch (error) {
        console.warn('[The Abyssal] Room heartbeat/rejoin failed:', error?.message || error);
        this.connectionState = 'reconnecting';
        this.notifyStatus(`Menghubungkan ulang ruang ekspedisi: ${error?.message || error}`, 'warning');
      } finally {
        this.heartbeatInFlight = false;
      }
    }, 20000);
  }

  async broadcastPlayerState(rawState) {
    if (!this.channel || !this.room) return false;
    const now = Date.now();
    if (now - this.lastPlayerBroadcast < 180) return false;
    this.lastPlayerBroadcast = now;
    const state = sanitizePlayerState({ ...rawState, userId: this.user?.id, displayName: this.displayName, sentAt: now });
    if (!state) return false;
    const status = await this.channel.send({ type: 'broadcast', event: 'player_state', payload: state });
    if (status !== 'ok') console.warn('[The Abyssal] Player state broadcast failed:', status);
    return status === 'ok';
  }

  async sendChat(text) {
    this.requireAuthenticated();
    if (!this.channel || !this.room) throw new Error('Masuk ke ruang multiplayer terlebih dahulu.');
    const body = sanitizeChatText(text);
    if (!body) throw new Error('Pesan tidak boleh kosong.');
    if (Date.now() - this.lastChatAt < 800) throw new Error('Tunggu sebentar sebelum mengirim pesan berikutnya.');
    const message = {
      senderId: this.user.id,
      senderName: this.displayName,
      text: body,
      sentAt: new Date().toISOString()
    };
    const status = await this.channel.send({ type: 'broadcast', event: 'room_chat', payload: message });
    if (status !== 'ok') throw new Error(`Radio gagal mengirim pesan (${String(status)}). Periksa koneksi ruang.`);
    this.lastChatAt = Date.now();
    this.callbacks.onChat?.(message);
    return message;
  }

  normalizeChatMessage(payload) {
    if (!payload || typeof payload !== 'object') return null;
    const text = sanitizeChatText(payload.text);
    const senderId = String(payload.senderId || '').slice(0, 80);
    if (!text || !senderId) return null;
    const date = new Date(payload.sentAt || Date.now());
    return {
      senderId,
      senderName: sanitizeDisplayName(payload.senderName),
      text,
      sentAt: Number.isNaN(date.getTime()) ? new Date().toISOString() : date.toISOString()
    };
  }

  async leaveRoom() {
    if (!this.room) { this.clearLocalRoom(); return; }
    const roomId = this.room.id;
    clearInterval(this.heartbeatTimer);
    this.heartbeatTimer = 0;
    this.heartbeatInFlight = false;
    const channel = this.channel;
    this.channel = null;
    this.room = null;
    this.members = [];
    this.connectionState = 'ready';
    try { localStorage.removeItem(ROOM_STORAGE_KEY); } catch { /* room code persistence is optional */ }
    if (channel) {
      try { await channel.untrack(); } catch { /* socket may already be closed */ }
      try { await this.client.removeChannel(channel); } catch { /* best effort */ }
    }
    if (this.client && this.user) {
      const { error } = await this.client.rpc('abyssal_leave_room', { p_room_id: roomId });
      if (error) console.warn('[The Abyssal] Could not remove room membership:', error.message);
    }
    this.callbacks.onMembers?.([]);
    this.callbacks.onRoomChange?.(null, []);
  }

  clearLocalRoom() {
    clearInterval(this.heartbeatTimer);
    this.heartbeatTimer = 0;
    this.heartbeatInFlight = false;
    const channel = this.channel;
    this.channel = null;
    this.room = null;
    this.members = [];
    this.connectionState = this.user ? 'ready' : 'idle';
    if (!this.user) { try { localStorage.removeItem(ROOM_STORAGE_KEY); } catch { /* storage may be unavailable */ } }
    if (channel && this.client) this.client.removeChannel(channel).catch(() => {});
    this.callbacks.onMembers?.([]);
    this.callbacks.onRoomChange?.(null, []);
  }
}

export const online = new AbyssalOnlineService();
