import { readFile, access, readdir } from 'node:fs/promises';
import { resolve, join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { WORLD_SEED, hash2, valueNoise } from '../world-generation.mjs';
import { normalizeRoomCode, sanitizeChatText, sanitizeDisplayName, sanitizePlayerState, flattenPresence, validatePublicBackendConfig } from '../multiplayer-core.mjs';
import {
  normalizeGameSettings,
  normalizeSaveRecord,
  normalizeBackupPayload,
  SAVE_SCHEMA_VERSION,
  SLOT_COUNT
} from '../save-schema.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const read = path => readFile(join(root, path), 'utf8');
const [html, game, fauna, styles, schema, worldGeneration, multiplayer, multiplayerCore, multiplayerSql, roomRecoverySql, envExample, manifestText, capacitorText, packageText, workflow, serviceWorker, nativeBuilder, nativePatcher, readme, backendSetup, gitignore] = await Promise.all([
  read('index.html'), read('game.js'), read('fauna.js'), read('styles.css'), read('save-schema.mjs'), read('world-generation.mjs'),
  read('multiplayer.js'), read('multiplayer-core.mjs'), read('supabase/migrations/202611060001_multiplayer.sql'),
  read('supabase/migrations/202611060002_room_recovery.sql'), read('.env.example'),
  read('manifest.webmanifest'), read('capacitor.config.json'), read('package.json'),
  read('.github/workflows/android-apk.yml'), read('sw.js'), read('scripts/build-native.mjs'), read('scripts/patch-android.mjs'), read('README_ID.md'), read('scripts/configure-backend.mjs'), read('.gitignore')
]);
const manifest = JSON.parse(manifestText);
const capacitor = JSON.parse(capacitorText);
const pkg = JSON.parse(packageText);
const setupGuide = await read('SUPABASE_SETUP_ID.md');

// Parse every runtime/build script with the same Node major used by CI. This
// catches syntax regressions before Vite or Gradle starts a longer build.
const scriptFiles = (await readdir(join(root, 'scripts'))).filter(file => file.endsWith('.mjs')).map(file => `scripts/${file}`);
const syntaxFiles = ['game.js', 'fauna.js', 'multiplayer.js', 'multiplayer-core.mjs', 'vite.config.js', 'app-update-config.js', 'sw.js', 'save-schema.mjs', 'world-generation.mjs', ...scriptFiles];
for (const file of syntaxFiles) {
  const result = spawnSync(process.execPath, ['--check', file], { cwd: root, encoding: 'utf8' });
  assert.equal(result.status, 0, `JavaScript syntax check failed for ${file}: ${result.stderr || result.stdout || result.error || 'unknown error'}`);
}

// DOM IDs must be unique, and every static game.js lookup must point to an element.
const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map(match => match[1]);
const idSet = new Set(ids);
const duplicates = [...new Set(ids.filter((id, index) => ids.indexOf(id) !== index))];
assert.deepEqual(duplicates, [], `Duplicate DOM IDs: ${duplicates.join(', ')}`);
const staticRefs = [...game.matchAll(/\$\(['"]([^'"]+)['"]\)/g)].map(match => match[1]);
const missing = [...new Set(staticRefs.filter(id => !idSet.has(id)))];
assert.deepEqual(missing, [], `Missing DOM nodes: ${missing.join(', ')}`);

// Local assets and module imports must resolve from the archive itself.
for (const match of html.matchAll(/(?:src|href)="\.\/([^?#"]+)/g)) {
  const target = match[1];
  if (!target.startsWith('data:')) await access(join(root, target));
}
for (const sourceFile of ['game.js', 'fauna.js', 'save-schema.mjs', 'world-generation.mjs', 'multiplayer.js', 'multiplayer-core.mjs']) {
  const source = await read(sourceFile);
  for (const match of source.matchAll(/(?:from\s*|import\s*\()(['"])(\.\/[^"]+?)\1/g)) {
    await access(join(root, dirname(sourceFile), match[2]));
  }
}
for (const match of game.matchAll(/icon:'([a-z0-9_-]+)'/gi)) {
  await access(join(root, 'icons', 'items', `${match[1]}.png`));
}
for (const match of html.matchAll(/\.\/icons\/([^"']+\.png)/g)) {
  await access(join(root, 'icons', match[1]));
}

// Save migration: old custom bed checkpoints and PDA hotbar assignments are retired.
assert.equal(SLOT_COUNT, 5);
assert.equal(SAVE_SCHEMA_VERSION, 11);
assert.deepEqual(normalizeGameSettings({ graphics: 'ultra', renderDistance: 99, volume: -5, fov: 140, language: 'xx', autoSave: true }), {
  graphics: 'balanced', renderDistance: 3, volume: 0, fov: 90, language: 'id'
});
const legacy = normalizeSaveRecord({
  version: 8,
  savedAt: 'bad-date',
  position: { x: 15, y: -12, z: -9 },
  respawnPoint: { x: 750, y: -24, z: -360 },
  yaw: 'NaN', pitch: 99,
  survival: { hp: -20, oxygen: 110, food: 'bad', water: 51, medkits: 999, rations: -3 },
  inventory: { titanium: -9, copper: '4.7', quartz: 10000, invalid: 12 },
  equipment: { tankLevel: 2, fins: 1, rebreather: true, reinforcedSuitOwned: true, helmetOwned: true },
  ownedTools: ['explorer_pda', 'scanner', 'knife', 'flashlight'],
  hotbar: ['explorer_pda', 'scanner', 'knife', 'flashlight', null],
  discoveries: ['clownfish', 'not-a-species', 'abyssal_leviathan'],
  knownBiomes: ['reef', 'bogus', 'abyss'],
  collectedCaches: ['verdant_cache', 'bogus'],
  collectedResources: ['1:2:ore:3', 'bad-key'],
  placedStructures: [
    { id: 'build-1', type: 'beacon', x: 4, y: -8, z: 9, yaw: 2 },
    { id: 'bad', type: 'teleporter', x: 0, y: 0, z: 0 }
  ],
  droppedItems: [
    { id: 'drop-1', type: 'glowcap', position: { x: 2, y: -9, z: 3 } },
    { id: 'bad', type: 'explosive', position: { x: 0, y: 0, z: 0 } }
  ],
  story: { introSeen: true, missionIndex: 999, counters: { materials: 99 }, completed: ['lifepod', 'evil'] }
});
assert.ok(legacy);
assert.equal(legacy.version, 11);
assert.deepEqual(legacy.respawnPoint, { x: 0, y: -7, z: 0 }, 'Legacy bed/checkpoint positions must not survive migration');
assert.equal(legacy.survival.hp, 0);
assert.equal(legacy.survival.oxygen, 105);
assert.equal(legacy.survival.medkits, 20);
assert.equal(legacy.inventory.titanium, 0);
assert.equal(legacy.inventory.copper, 5);
assert.equal(legacy.inventory.quartz, 999);
assert.equal(legacy.equipment.tankLevel, 2);
assert.equal('reinforcedSuitOwned' in legacy.equipment, false);
assert.equal('helmetOwned' in legacy.equipment, false);
assert.equal(legacy.equipment.seaglideCharge, 0, 'No legacy Seaglide should start charged unless it was owned');
assert.deepEqual(legacy.hotbar, [null, 'scanner', 'knife', 'flashlight', null]);
assert.deepEqual(legacy.discoveries, ['clownfish', 'abyssal_leviathan']);
assert.deepEqual(legacy.knownBiomes, ['reef', 'abyss']);
assert.deepEqual(legacy.collectedCaches, ['verdant_cache']);
assert.deepEqual(legacy.collectedResources, ['1:2:ore:3']);
assert.equal(legacy.placedStructures.length, 1);
assert.equal(legacy.droppedItems.length, 1);
assert.equal(legacy.story.missionIndex, 7);
assert.equal(normalizeSaveRecord({ totally: 'invalid' }), null);
const modern = normalizeSaveRecord({ version: 11, position: { x: 5, y: -9, z: 8 }, respawnPoint: { x: 20, y: -8, z: -10 }, survival: {}, inventory: {}, ownedTools:['seaglide'], equipment:{seaglideCharge:72} });
assert.deepEqual(modern.respawnPoint, { x: 20, y: -8, z: -10 });
assert.equal(modern.equipment.seaglideCharge, 72);
const migratedSeaglide = normalizeSaveRecord({ version: 10, position:{x:0,y:-7,z:0}, survival:{}, inventory:{}, ownedTools:['seaglide'] });
assert.equal(migratedSeaglide.equipment.seaglideCharge, 100, 'Legacy Seaglide owners should receive a full battery on migration');
const backup = normalizeBackupPayload({ format: 'the-abyssal-save-backup', schemaVersion: 1, slots: [legacy, null, null, null, null], settings: { volume: 120 } });
assert.equal(backup.slots.length, 5);
assert.equal(backup.settings.volume, 100);
assert.throws(() => normalizeBackupPayload({ format: 'wrong', slots: [] }), /Format backup/);
assert.throws(() => normalizeBackupPayload({ format: 'the-abyssal-save-backup', slots: [null] }), /tepat lima slot/);

// Subnautica-style core loop: backpack dimensions, quick slots, tool gating, survival and habitat systems.
assert.equal(pkg.version, '1.6.2');
assert.match(game, /from '\.\/world-generation\.mjs'/);
assert.match(game, /from '\.\/multiplayer\.js'/);
assert.match(worldGeneration, /export const WORLD_SEED = 0x0ab155a1/);
assert.ok(Number.isInteger(WORLD_SEED) && WORLD_SEED > 0);
assert.equal(hash2(0, 0), hash2(0, 0), 'World seed output must be deterministic');
assert.notEqual(hash2(0, 0), hash2(1, 0), 'Adjacent world coordinates should produce varied terrain');
for (const [x, z] of [[0, 0], [1.25, -4.5], [-180, 92], [10000, -10000]]) {
  const value = hash2(x, z);
  const noise = valueNoise(x, z);
  assert.ok(Number.isFinite(value) && value >= 0 && value < 1, 'World hash must be a finite unit interval value');
  assert.ok(Number.isFinite(noise) && noise >= -1 && noise <= 1, 'Terrain noise must be finite and bounded');
}
assert.match(game, /import \{ hash2, valueNoise \} from '\.\/world-generation\.mjs'/);
assert.doesNotMatch(game, /WORLD_SEED is not defined/);
assert.ok(idSet.has('boot-retry-btn'), 'Boot recovery button is required');
assert.match(game, /boot-retry-btn/);
assert.match(game, /Dunia 3D gagal dimuat/);
assert.match(game, /const SURVIVAL_DEFAULTS = \{ hp: 100, oxygen: 45/);
assert.match(game, /const columns = 8, rows = 6/);
assert.match(game, /for \(let index=0; index<48; index\+\+\)/);
assert.match(html, /48 CELLS USED/);
assert.match(html, /5 slot Hotbar/);
assert.match(game, /let hotbarSlots = \['scanner','knife','flashlight',null,null\]/);
assert.match(game, /if \(itemId === 'explorer_pda'\)/);
assert.match(game, /explorer_pda:\{name:'PDA'/);
assert.match(game, /size:6,kind:'tool',width:2,height:3/);
assert.match(game, /function getMaxOxygen\(\) \{ return 45 \+ \(equipment\.tankLevel \|\| 0\) \* 30; \}/);
assert.match(game, /survival\.oxygen = clamp\(survival\.oxygen - oxygenRate \* dt, 0, getMaxOxygen\(\)\)/);
assert.match(game, /const oxygenRate = equipment\.rebreather && depth >= 20 \? 0\.75 : 1/);
assert.match(game, /if \(indoorHabitat && isHabitatPowered\(indoorHabitat\)\)/);
assert.match(game, /else if \(atSurface\)/);
assert.match(game, /function isHabitatPowered\(/);
assert.match(game, /function openFabricator\(\)/);
assert.match(game, /function craftFabricatorRecipe\(id\)/);
assert.match(game, /sustenance:\{title:'Sustenance'/);
assert.match(game, /personal:\{title:'Personal'/);
assert.match(game, /resources:\{title:'Resources'/);
assert.match(game, /electronics:\{title:'Electronics'/);
assert.match(game, /function openBuildMenu\(\)[\s\S]*?getSelectedHotbarItem\(\) !== 'habitat_builder'/);
assert.match(game, /function interactNearby\(\)/);
assert.match(game, /function gatherNearbyResource\(\)/);
assert.match(game, /function scanNearestFauna\(\)/);
assert.match(game, /minAlignment:0\.945/);
assert.match(game, /function makeFirstPersonViewModel\(\)/);
assert.match(game, /viewModel\.userData\.seaglide\.visible=selectedTool==='seaglide'/);
assert.match(game, /equipment\.seaglideCharge-0\.30\*dt/);
assert.match(game, /Ganti baterai Seaglide/);
assert.match(game, /function activateLifepod\([\s\S]*?getSelectedHotbarItem/);
assert.match(game, /ownedTools\.includes\('repair_tool'\)\|\|getSelectedHotbarItem\(\)!=='repair_tool'/);
assert.match(game, /CONTROL CONSOLE · FABRICATE REPAIR TOOL/);
assert.match(game, /consoleMaterial\.emissive\.setHex\(0x18c9b8\)/);
assert.match(game, /const speed=.*seaglideEquipped\?1\.75/);
assert.match(game, /function enterHabitat\(target\)/);
assert.match(game, /function exitHabitat\(\)/);
assert.match(game, /function saveCurrentSlot\(\)/);
assert.match(game, /No background saving: progress is committed only when the player selects Save/);

// Explicitly retired custom features are absent from runtime, schema, and interface.
for (const [label, source] of [['game.js', game], ['save-schema.mjs', schema], ['index.html', html], ['styles.css', styles]]) {
  assert.doesNotMatch(source, /autoSave|autosave-toggle|autosave-setting/i, `${label} still exposes autosave`);
  assert.doesNotMatch(source, /bed-btn|bed checkpoint|checkpoint kasur|isNearHabitatBed/i, `${label} still exposes bed checkpoints`);
  assert.doesNotMatch(source, /chestplate|helmetOwned|reinforcedSuitOwned|oxygen_station/i, `${label} still exposes retired armor/oxygen-station gear`);
}
assert.doesNotMatch(game, /Math\.random\(\) \* 3|oxygenDrainTimer/, 'Random/timed oxygen drain must be removed');
assert.doesNotMatch(game, /pressureDamageTimer|thermalDamageTimer|temperatureC/, 'Custom pressure/temperature damage must be removed');
assert.ok(!idSet.has('supply-btn'), 'Separate supply button should be replaced by contextual Interact');
assert.ok(!idSet.has('autosave-toggle') && !idSet.has('bed-btn'));

// Android/offline packaging must not depend on an external backend.
assert.equal(manifest.orientation, 'landscape');
assert.equal(capacitor.appId, 'com.abyssal.game');
assert.equal(capacitor.webDir, 'www');
assert.ok(pkg.dependencies['@capacitor/app'], 'Native Android back/lifecycle plugin must be installed');
assert.match(serviceWorker, /the-abyssal-1-6-2-runtime-backend-coop/);
assert.match(game, /const current = '1\.6\.2'/);
assert.match(backendSetup, /VITE_SUPABASE_URL/);
assert.match(workflow, /node scripts\/configure-backend\.mjs/);
assert.match(workflow, /native\/abyssal-debug-signing\.bin/);
assert.match(nativePatcher, /native\/abyssal-debug-signing\.bin/);
assert.doesNotMatch(gitignore, /abyssal-debug-signing\.bin/);
await access(join(root, 'native/abyssal-debug-signing.bin'));
assert.match(workflow, /dump badging/);
assert.match(workflow, /com\.abyssal\.game/);
assert.match(workflow, /VITE_SUPABASE_URL/);
assert.match(workflow, /VITE_SUPABASE_PUBLISHABLE_KEY/);
assert.doesNotMatch(nativePatcher, /auth\/callback|deepLinkFilter/);
assert.match(nativeBuilder, /await build\(/);
assert.match(workflow, /npm test/);
assert.match(workflow, /assembleDebug/);
assert.match(workflow, /if \[ -d android \]/);
assert.match(workflow, /npm run android:sync/);
assert.match(workflow, /npm run android:add/);
assert.match(workflow, /actions\/upload-artifact@v7/);
assert.doesNotMatch(workflow, /actions\/upload-artifact@v4/);
assert.match(readme, /multiplayer/i);
assert.match(readme, /Supabase/i);
assert.match(multiplayer, /signUp/);
assert.match(multiplayer, /get authReady\(\)/);
assert.match(multiplayer, /signInWithPassword/);
assert.match(multiplayer, /abyssal_create_room/);
assert.match(multiplayer, /abyssal_join_room/);
assert.match(multiplayer, /player_state/);
assert.match(multiplayer, /room_chat/);
assert.match(multiplayer, /trackStatus !== 'ok'/);
assert.match(multiplayer, /status !== 'ok'/);
assert.match(multiplayer, /status === 'SUBSCRIBED'/);
assert.match(game, /diver\.initialized/);
assert.match(game, /ROOM RECONNECTING/);
assert.match(game, /KONFIGURASI TERSIMPAN/);
assert.match(workflow, /VITE_SUPABASE_URL: \$\{\{ secrets\.SUPABASE_URL \}\}/);
assert.match(workflow, /VITE_SUPABASE_PUBLISHABLE_KEY: \$\{\{ secrets\.SUPABASE_PUBLISHABLE_KEY \}\}/);
assert.match(workflow, /the-abyssal-android-apk-1\.6\.2/);
assert.match(nativeBuilder, /configure-backend\.mjs/);
assert.match(multiplayerSql, /enable row level security/i);
assert.match(multiplayerSql, /abyssal_is_room_member/);
assert.match(multiplayerSql, /realtime\.messages/);
assert.match(multiplayerSql, /realtime\.topic\(\)/i);
assert.match(multiplayerSql, /abyssal_is_realtime_room_member/i);
assert.match(multiplayerSql, /\[\^A-Za-z0-9\]/, 'Server room-code sanitizer must accept lowercase codes before uppercase normalization');
assert.match(envExample, /VITE_SUPABASE_URL/);
assert.match(envExample, /VITE_SUPABASE_PUBLISHABLE_KEY/);
assert.doesNotMatch(envExample, /VITE_[A-Z0-9_]+=(?:sb_secret_|[^\n]*service_role)/i, 'The environment template must never contain a secret key value');
assert.match(workflow, /secrets\.SUPABASE_URL/);
assert.match(workflow, /secrets\.SUPABASE_PUBLISHABLE_KEY/);
assert.match(game, /MULTIPLAYER ROOM/);
assert.match(html, /id="online-login-form"/);
assert.match(html, /id="online-register-form"/);
assert.match(html, /id="create-room-btn"/);
assert.match(html, /id="join-room-btn"/);
assert.match(html, /id="online-chat-form"/);
assert.match(html, /id="backend-config-form"/);
assert.match(html, /id="backend-project-url"/);
assert.match(html, /id="backend-publishable-key"/);
assert.match(multiplayer, /configureBackend/);
assert.match(multiplayer, /the-abyssal-supabase-config-v1/);
assert.match(game, /online\.configureBackend/);
assert.match(game, /!online\.authReady/);
assert.match(game, /explainOnlineError/);
assert.match(game, /Email belum diverifikasi/);
assert.deepEqual(validatePublicBackendConfig('https://abyssal-demo.supabase.co', 'sb_publishable_example_public_key'), { url:'https://abyssal-demo.supabase.co', publishableKey:'sb_publishable_example_public_key' });
assert.throws(() => validatePublicBackendConfig('http://abyssal-demo.supabase.co', 'sb_publishable_example_public_key'), /HTTPS/);
assert.throws(() => validatePublicBackendConfig('https://abyssal-demo.supabase.co', 'sb_secret_do_not_use'), /secret/);
assert.throws(() => validatePublicBackendConfig('https://abyssal-demo.supabase.co', 'not-a-key'), /Key tidak dikenali/);
assert.equal(normalizeRoomCode(' ab-12cd '), 'AB12CD');
assert.equal(normalizeRoomCode('A!B?'), 'AB');
assert.equal(sanitizeChatText('  hi\nthere\u0000  '), 'hi there');
assert.equal(sanitizeDisplayName('  <Diver>  '), 'Diver');
assert.equal(sanitizePlayerState({ userId:'u1', x:1, y:-7, z:2, yaw:0.5, pitch:0.2 }).depth, 7);
assert.equal(sanitizePlayerState({ userId:'u1', x:Infinity, y:-7, z:2, yaw:0, pitch:0 }), null);
assert.deepEqual(flattenPresence({u1:[{user_id:'u1',display_name:'Diver 1'}],u2:[{user_id:'u2',display_name:'Diver 2'}]}).map(member=>member.userId), ['u1','u2']);
assert.ok(styles.includes('.oxygen-gauge') && styles.includes('.depth-indicator') && styles.includes('.hotbar-slot'));
assert.ok(styles.includes('.inventory-slot-grid') && styles.includes('.fabricator-recipes') && styles.includes('.action-controls'));


const configureScript = join(root, 'scripts/configure-backend.mjs');
const cleanEnv = { ...process.env };
for (const key of ['VITE_SUPABASE_URL','SUPABASE_URL','VITE_SUPABASE_PUBLISHABLE_KEY','SUPABASE_PUBLISHABLE_KEY','VITE_SUPABASE_ANON_KEY','SUPABASE_ANON_KEY']) delete cleanEnv[key];
const offlineConfig = spawnSync(process.execPath, [configureScript], { cwd: root, env: cleanEnv, encoding: 'utf8' });
assert.equal(offlineConfig.status, 0, `Offline config should remain buildable: ${offlineConfig.stderr}`);
const configuredEnv = { ...cleanEnv, VITE_SUPABASE_URL:'https://abyssal-demo.supabase.co', VITE_SUPABASE_PUBLISHABLE_KEY:'sb_publishable_example_public_key' };
const validConfig = spawnSync(process.execPath, [configureScript], { cwd: root, env: configuredEnv, encoding: 'utf8' });
assert.equal(validConfig.status, 0, `Public Supabase configuration should validate: ${validConfig.stderr}`);
const partialConfig = spawnSync(process.execPath, [configureScript], { cwd: root, env: { ...cleanEnv, VITE_SUPABASE_URL:'https://abyssal-demo.supabase.co' }, encoding: 'utf8' });
assert.notEqual(partialConfig.status, 0, 'Partial Supabase config must fail closed');
const secretConfig = spawnSync(process.execPath, [configureScript], { cwd: root, env: { ...cleanEnv, VITE_SUPABASE_URL:'https://abyssal-demo.supabase.co', VITE_SUPABASE_PUBLISHABLE_KEY:'sb_secret_never_bundle' }, encoding: 'utf8' });
assert.notEqual(secretConfig.status, 0, 'Supabase secret keys must never be bundled');
const unknownKeyConfig = spawnSync(process.execPath, [configureScript], { cwd: root, env: { ...cleanEnv, VITE_SUPABASE_URL:'https://abyssal-demo.supabase.co', VITE_SUPABASE_PUBLISHABLE_KEY:'not-a-supabase-key' }, encoding: 'utf8' });
assert.notEqual(unknownKeyConfig.status, 0, 'Unknown key formats must fail closed');

// 1.6.2 runtime reliability: verify Supabase Auth reachability, app lifecycle,
// stale multiplayer membership recovery, and actual native launcher icon assets.
assert.match(multiplayer, /\/auth\/v1\/settings/);
assert.match(multiplayer, /headers:\s*\{\s*apikey:\s*this\.publishableKey/);
assert.match(multiplayer, /data === false/);
assert.match(multiplayer, /abyssal_join_room/);
assert.match(multiplayer, /heartbeatInFlight/);
assert.match(game, /bindNativeLifecycle/);
assert.match(game, /addListener\('backButton'/);
assert.match(game, /addListener\('appStateChange'/);
assert.match(game, /Keluar dari The Abyssal/);
assert.match(roomRecoverySql, /create or replace function public\.abyssal_join_room/);
assert.match(roomRecoverySql, /Promote the oldest[\s\S]*active member/);
assert.match(roomRecoverySql, /grant execute on function public\.abyssal_join_room\(text\) to authenticated/);
assert.match(nativePatcher, /native\/android-icons\/mipmap-\$\{density\}/);
assert.match(nativePatcher, /android:roundIcon="@mipmap\/ic_launcher_round"/);
assert.ok(nativePatcher.includes('manifest.match(/<application\\b'), 'Android manifest application tag must use a word-boundary regex');
for (const relative of [
  'icons/icon-192.png', 'icons/icon-512.png', 'icons/icon-maskable-512.png',
  'native/android-icons/ic_launcher_foreground.png',
  'native/android-icons/mipmap-anydpi-v26/ic_launcher.xml',
  'native/android-icons/mipmap-anydpi-v26/ic_launcher_round.xml',
  'native/android-icons/abyssal_launcher_colors.xml',
  'native/android-icons/mipmap-mdpi/ic_launcher.png',
  'native/android-icons/mipmap-hdpi/ic_launcher.png',
  'native/android-icons/mipmap-xhdpi/ic_launcher.png',
  'native/android-icons/mipmap-xxhdpi/ic_launcher.png',
  'native/android-icons/mipmap-xxxhdpi/ic_launcher.png'
]) await access(join(root, relative));
for (const [relative, expectedSize] of [
  ['icons/icon-192.png', 192],
  ['icons/icon-512.png', 512],
  ['icons/icon-maskable-512.png', 512],
  ['native/android-icons/ic_launcher_foreground.png', 432],
  ['native/android-icons/mipmap-mdpi/ic_launcher.png', 48],
  ['native/android-icons/mipmap-hdpi/ic_launcher.png', 72],
  ['native/android-icons/mipmap-xhdpi/ic_launcher.png', 96],
  ['native/android-icons/mipmap-xxhdpi/ic_launcher.png', 144],
  ['native/android-icons/mipmap-xxxhdpi/ic_launcher.png', 192]
]) {
  const png = await readFile(join(root, relative));
  assert.equal(png.subarray(0, 8).toString('hex'), '89504e470d0a1a0a', `${relative} must be a PNG`);
  assert.equal(png.readUInt32BE(16), expectedSize, `${relative} width is incorrect`);
  assert.equal(png.readUInt32BE(20), expectedSize, `${relative} height is incorrect`);
}
assert.match(setupGuide, /202611060002_room_recovery\.sql/);
assert.match(readme, /The Abyssal 1\.6\.2/i);
console.log(`The Abyssal 1.6.2 verification passed: ${ids.length} unique DOM IDs, ${staticRefs.length} valid DOM references, local assets, deterministic world generation, v11 save migration, survival/inventory/habitat regression checks, Supabase Auth reachability and private co-op room recovery, room-code/chat/player-state sanitizers, RLS SQL migrations, native Android lifecycle handlers, horror launcher icon resources, safe public-key configuration, and Android packaging checks.`);
