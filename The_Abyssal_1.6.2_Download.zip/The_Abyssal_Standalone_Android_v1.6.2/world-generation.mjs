/**
 * Stable procedural world primitives.
 *
 * Keep the seed explicit and version-independent: every expedition loads the
 * same authored world layout, so saved coordinates and discovered resources
 * continue to refer to the same terrain after app updates.
 */
export const WORLD_SEED = 0x0ab155a1;

/** Deterministic pseudo-random value in [0, 1). */
export function hash2(x, z, seed = WORLD_SEED) {
  const value = Math.sin(x * 127.1 + z * 311.7 + seed) * 43758.5453123;
  return value - Math.floor(value);
}

/** Smooth, deterministic value noise in approximately [-1, 1]. */
export function valueNoise(x, z, seed = WORLD_SEED) {
  const ix = Math.floor(x);
  const iz = Math.floor(z);
  const fx = x - ix;
  const fz = z - iz;
  const sx = fx * fx * (3 - 2 * fx);
  const sz = fz * fz * (3 - 2 * fz);
  const mix = (a, b, t) => a + (b - a) * t;
  const a = hash2(ix, iz, seed);
  const b = hash2(ix + 1, iz, seed);
  const c = hash2(ix, iz + 1, seed);
  const d = hash2(ix + 1, iz + 1, seed);
  return mix(mix(a, b, sx), mix(c, d, sx), sz) * 2 - 1;
}
