# Membuat APK THE ABYSSAL hanya dengan ponsel

Kamu tidak membutuhkan laptop, Android Studio, Node.js, atau Gradle di HP. GitHub Actions yang menyiapkan SDK dan menyusun APK pada server cloud. **Netlify tidak digunakan.**

## A. Siapkan repository GitHub dari browser HP

1. Masuk ke GitHub dan buat repository baru, misalnya `the-abyssal-android`.
2. Ekstrak `The_Abyssal_Standalone_Android_v0.6.zip` dengan aplikasi Files/Manajer File.
3. Buka folder `the-abyssal` hasil ekstraksi.
4. Unggah semua isinya ke root repository. Jangan mengunggah ZIP sebagai satu file. Pastikan `.github/workflows/android-apk.yml` ikut terunggah; aktifkan opsi tampilkan file tersembunyi jika folder `.github` tidak terlihat.
5. Commit ke branch `main`.

## B. Jalankan build APK

1. Di repository, buka tab **Actions**.
2. Pilih **Build The Abyssal Native Android APK**.
3. Tekan **Run workflow** pada branch `main`.
4. Buka run terbaru dan periksa job `Test and compile standalone APK`.
5. Jika status **Success**, buka bagian **Artifacts**.
6. Unduh `the-abyssal-android-apk`, ekstrak ZIP artifact, lalu pasang `app-debug.apk`.
7. Bila Android meminta izin, izinkan browser atau file manager tersebut memasang aplikasi dari sumber ini.

Jika status merah, buka job dan lihat langkah pertama yang gagal. APK belum berhasil dibuat sampai workflow menunjukkan Success dan artifact tersedia.

## C. Main tanpa Netlify

Setelah APK terpasang, game berjalan dari aset yang sudah tertanam di aplikasi:

- Single Player, dunia 3D, chunk, fauna, survival, dan local save tidak memerlukan internet.
- Netlify, browser, dan website tidak dibutuhkan untuk membuka game.
- Login Email/Google/Facebook, Cloud Save, dan Multiplayer memerlukan internet serta konfigurasi Supabase.

## D. Aktifkan Cloud, login, dan Multiplayer (opsional)

1. Buat satu project Supabase.
2. Salin Project URL dan **Publishable Key** (`sb_publishable_...`).
3. Pada GitHub repository, buka **Settings → Secrets and variables → Actions**.
4. Tambahkan repository secrets bernama `SUPABASE_URL` dan `SUPABASE_PUBLISHABLE_KEY` dengan nilai dari Supabase.
5. Jalankan seluruh `supabase/schema.sql` lewat Supabase **SQL Editor**.
6. Tambahkan `theabyssal://auth/callback` pada Supabase **Authentication → URL Configuration → Redirect URLs**.
7. Aktifkan Email provider. Untuk Google/Facebook, buat OAuth credential di masing-masing dashboard, lalu aktifkan provider pada Supabase. Masukkan callback URL Supabase yang tertera pada halaman provider ke daftar callback Google/Facebook.
8. Jalankan kembali workflow APK agar konfigurasi online dimasukkan ke paket baru.

Jangan memasukkan `service_role`, secret key, password, atau rahasia provider ke source atau file konfigurasi aplikasi.

## E. Uji setelah instalasi

1. Buka aplikasi dan pastikan menu utama tampil landscape dan fullscreen.
2. Putuskan internet, pilih Play, mulai ekspedisi, bergerak, lalu Save.
3. Tutup aplikasi sepenuhnya dan buka kembali; periksa Continue → slot yang disimpan.
4. Aktifkan internet dan konfigurasi Supabase untuk mencoba registrasi/login serta Cloud Save.
5. Gunakan dua perangkat dan dua akun berbeda untuk membuat Host World lalu Join World.
6. Pastikan hanya Host yang dapat menyimpan shared world.

## Catatan update APK

Workflow ini menghasilkan debug APK untuk uji instalasi. Build debug dari runner baru bisa memiliki tanda tangan berbeda; Android mungkin menolak memasangnya sebagai pembaruan di atas APK debug lama. Untuk update rutin tanpa uninstall dan tanpa kehilangan data lokal, proyek perlu diberi release keystore pribadi yang sama pada semua build release. Simpan keystore dan password sebagai GitHub Secrets, bukan di repository.
