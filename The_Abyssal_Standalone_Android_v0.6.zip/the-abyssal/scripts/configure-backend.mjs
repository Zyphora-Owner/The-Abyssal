import { writeFile } from 'node:fs/promises';

const url = (process.env.ABYSSAL_SUPABASE_URL || '').trim();
const key = (process.env.ABYSSAL_SUPABASE_PUBLISHABLE_KEY || '').trim();
const output = 'supabase-config.js';

if (!url && !key) {
  console.warn('Supabase config was not injected. The game will build, but online login/cloud/multiplayer will remain disabled until repository secrets are added.');
  process.exit(0);
}

if (!url || !key) {
  throw new Error('Both ABYSSAL_SUPABASE_URL and ABYSSAL_SUPABASE_PUBLISHABLE_KEY must be set together.');
}

const parsed = new URL(url);
if (parsed.protocol !== 'https:' || !parsed.hostname.endsWith('.supabase.co')) {
  throw new Error('ABYSSAL_SUPABASE_URL must be the HTTPS URL of your Supabase project.');
}
if (!key.startsWith('sb_publishable_')) {
  throw new Error('Use the Supabase publishable key (sb_publishable_...). Never use a service_role/secret key in the app.');
}

const contents = `// Generated during cloud build. This publishable key is intended for client use.\n// Never place a Supabase service_role or secret key in this file.\nexport const SUPABASE_URL = ${JSON.stringify(url)};\nexport const SUPABASE_PUBLISHABLE_KEY = ${JSON.stringify(key)};\nexport const NATIVE_AUTH_REDIRECT = 'theabyssal://auth/callback';\n`;
await writeFile(output, contents, 'utf8');
console.log('Supabase public client configuration injected for this build.');
