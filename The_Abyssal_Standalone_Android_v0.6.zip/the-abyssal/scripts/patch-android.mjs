import { readFile, writeFile, readdir } from 'node:fs/promises';
import { join } from 'node:path';

const manifestPath = 'android/app/src/main/AndroidManifest.xml';
let manifest = await readFile(manifestPath, 'utf8');

for (const permission of ['android.permission.INTERNET', 'android.permission.ACCESS_NETWORK_STATE']) {
  const escaped = permission.replaceAll('.', '\\.');
  if (!new RegExp(`<uses-permission\\s+android:name="${escaped}"`).test(manifest)) {
    manifest = manifest.replace('<application', `    <uses-permission android:name="${permission}" />\n\n    <application`);
  }
}

const activityMatch = manifest.match(/<activity\b[^>]*android:name="[^"]*MainActivity"[^>]*>[\s\S]*?<\/activity>/);
if (!activityMatch) throw new Error('MainActivity tidak ditemukan di AndroidManifest.xml');
let activity = activityMatch[0];
const openEnd = activity.indexOf('>') + 1;
let activityOpen = activity.slice(0, openEnd);
if (!/android:screenOrientation=/.test(activityOpen)) {
  activityOpen = activityOpen.replace('<activity', '<activity android:screenOrientation="landscape"');
} else {
  activityOpen = activityOpen.replace(/android:screenOrientation="[^"]*"/, 'android:screenOrientation="landscape"');
}
if (!/android:launchMode=/.test(activityOpen)) {
  activityOpen = activityOpen.replace('<activity', '<activity android:launchMode="singleTask"');
}
if (!/android:exported=/.test(activityOpen)) {
  activityOpen = activityOpen.replace('<activity', '<activity android:exported="true"');
}
activity = activityOpen + activity.slice(openEnd);

// Remove this app's previous callback filter so the patch remains idempotent.
activity = activity.replace(/\s*<intent-filter>[\s\S]*?<data android:scheme="theabyssal"[\s\S]*?<\/intent-filter>/g, '');
const deepLinkFilter = `
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="theabyssal" android:host="auth" android:pathPrefix="/callback" />
            </intent-filter>`;
activity = activity.replace('</activity>', `${deepLinkFilter}\n        </activity>`);
manifest = manifest.replace(activityMatch[0], activity);
await writeFile(manifestPath, manifest);

async function findMainActivity(dir) {
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const path = join(dir, entry.name);
    if (entry.isDirectory()) {
      const found = await findMainActivity(path);
      if (found) return found;
    } else if (entry.name === 'MainActivity.java' || entry.name === 'MainActivity.kt') return path;
  }
  return null;
}

const sourcePath = await findMainActivity('android/app/src/main/java');
if (!sourcePath) throw new Error('MainActivity.java / MainActivity.kt tidak ditemukan');
const original = await readFile(sourcePath, 'utf8');
const packageLine = original.match(/^package\s+[^;\n]+;?/m)?.[0]?.trim();
if (!packageLine) throw new Error('Package MainActivity tidak terbaca');

let source;
if (sourcePath.endsWith('.kt')) {
  const packageName = packageLine.replace(/^package\s+/, '').replace(/;$/, '');
  source = `package ${packageName}

import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyImmersiveMode()
    }
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersiveMode()
    }
    private fun applyImmersiveMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            )
        }
    }
}
`;
} else {
  source = `${packageLine}

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyImmersiveMode();
    }
    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersiveMode();
    }
    private void applyImmersiveMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            );
        }
    }
}
`;
}
await writeFile(sourcePath, source);
console.log('Android native shell patched: landscape, immersive fullscreen, Internet permission and one OAuth deep-link filter.');
