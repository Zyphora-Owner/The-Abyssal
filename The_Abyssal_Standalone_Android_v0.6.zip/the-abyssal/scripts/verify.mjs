import { readFile, access } from 'node:fs/promises';
import assert from 'node:assert/strict';

const html = await readFile('index.html', 'utf8');
const game = await readFile('game.js', 'utf8');
const fauna = await readFile('fauna.js', 'utf8');
const styles = await readFile('styles.css', 'utf8');
const online = await readFile('online.js', 'utf8');
const schema = await readFile('supabase/schema.sql', 'utf8');
const manifest = JSON.parse(await readFile('manifest.webmanifest', 'utf8'));
const cap = JSON.parse(await readFile('capacitor.config.json', 'utf8'));
const pkg = JSON.parse(await readFile('package.json', 'utf8'));
const nativeBuilder = await readFile('scripts/build-native.mjs', 'utf8');
const nativePatcher = await readFile('scripts/patch-android.mjs', 'utf8');
const buildWorkflow = await readFile('.github/workflows/android-apk.yml', 'utf8');
const serviceWorker = await readFile('sw.js', 'utf8');
const mobileGuide = await readFile('BUILD_DARI_PONSEL.md', 'utf8');
const readme = await readFile('README_ID.md', 'utf8');

const ids = new Set([...html.matchAll(/\bid="([^"]+)"/g)].map(match => match[1]));
const refs = [...game.matchAll(/\$\('([^']+)'\)/g)].map(match => match[1]);
const missing = [...new Set(refs.filter(id => !ids.has(id)))];
assert.deepEqual(missing, [], `Missing HTML IDs: ${missing.join(', ')}`);

assert.ok(!html.includes('type="importmap"'), 'Runtime CDN import map must be removed from source HTML');
assert.ok(!/cdn\.jsdelivr\.net|unpkg\.com/.test(html), 'Source HTML must not reference runtime CDNs');
assert.match(game, /import \* as THREE from 'three'/, 'Three.js must be a package dependency for local Vite bundling');
assert.ok(game.includes("import { FaunaDirector, FAUNA_SPECIES_COUNT } from './fauna.js'"), 'Marine fauna director is not wired into the game');
assert.ok(fauna.includes('Abyssal Leviathan') && fauna.includes('Humpback Whale') && fauna.includes('Hammerhead Shark') && fauna.includes('Giant Squid'), 'Large marine wildlife is missing');
assert.equal([...fauna.matchAll(/\{ id:'[^']+', name:'[^']+'/g)].length, 25, 'Expected 25 distinct marine species');
assert.ok(fauna.includes('Clownfish') && fauna.includes('Blue Tang') && fauna.includes('Jellyfish') && fauna.includes('Sea Turtle'), 'Marine species diversity is incomplete');
for (const id of ['hp-fill','oxygen-fill','food-fill','water-fill','scan-btn','medkit-btn','ration-btn','supply-btn','damage-flash','fauna-label']) assert.ok(ids.has(id), `Missing survival/ecology UI element: ${id}`);
assert.ok(game.includes('updateSurvival(dt)') && game.includes('saveCurrentSlot()') && game.includes('survival: { ...survival') && game.includes('collectedCaches: [...collectedCaches]'), 'Survival systems are not persisted');
assert.ok(game.includes('function openSupplyCache()') && game.includes('makeSupplyCache(group'), 'World supply caches are missing');
assert.ok(styles.includes('.survival-panel') && styles.includes('.action-controls'), 'Survival HUD styles are missing');

assert.equal(manifest.orientation, 'landscape');
assert.equal(cap.appId, 'com.abyssal.game');
assert.equal(cap.webDir, 'www');
assert.ok(online.includes("provider,\n      options:"), 'OAuth provider sign-in integration is missing');
assert.ok(online.includes("exchangeCodeForSession(code)"), 'Native OAuth code exchange is missing');
assert.ok(online.includes("import('@capacitor/core')") && online.includes("import('@supabase/supabase-js')"), 'Capacitor and Supabase dependencies must be imported as local package modules');
assert.ok(pkg.dependencies.three && pkg.dependencies['@supabase/supabase-js'] && pkg.dependencies['@capacitor/android'], 'Runtime dependencies must be in package.json for Vite bundling');
assert.ok(pkg.devDependencies.vite, 'Vite is required for self-contained local bundling');
assert.ok(pkg.scripts['android:add'].includes('build-native.mjs') || pkg.scripts['android:add'].includes('npm run build'), 'Android add must create a local bundle first');
assert.match(nativeBuilder, /await build\(/, 'Native builder must run Vite bundling');
assert.match(nativeBuilder, /Build audit failed/, 'Native builder must reject remote runtime imports');
assert.match(nativePatcher, /screenOrientation="landscape"/, 'Native activity must be locked to landscape');
assert.match(nativePatcher, /WindowInsetsController/, 'Native activity must use immersive fullscreen');
assert.match(nativePatcher, /android\.permission\.INTERNET/, 'Native app must have Internet permission for online services');
assert.match(nativePatcher, /theabyssal:\/\/auth\/callback|theabyssal/, 'Native OAuth deep link must be registered');
assert.match(game, /!online\.isNative\(\).*serviceWorker/s, 'Native app must not depend on a service worker');
assert.doesNotMatch(serviceWorker, /cdn\.jsdelivr\.net|unpkg\.com/, 'Optional browser preview service worker must not fetch runtime CDNs');
assert.ok(schema.includes('alter table public.room_saves enable row level security'));
assert.ok(schema.includes('room save insert host') && schema.includes('room save update host'));
assert.ok(schema.includes("'abyssal-room:' || r.id::text"), 'Private room channel policy is missing');
assert.match(buildWorkflow, /workflow_dispatch:/, 'APK workflow must be manually triggerable');
assert.match(buildWorkflow, /android-actions\/setup-android@v4/, 'Android SDK must be provisioned on the cloud runner');
assert.match(buildWorkflow, /actions\/upload-artifact@v4/, 'APK must be downloadable as a workflow artifact');
assert.match(buildWorkflow, /SUPABASE_URL/, 'Workflow must read the optional Supabase URL secret');
assert.match(mobileGuide, /ponsel/i, 'Mobile-only build instructions must be present');
assert.match(readme, /Netlify tidak diperlukan/i, 'README must document independent native installation');
try { await access('netlify.toml'); assert.fail('Netlify-specific deployment config should not exist'); } catch (error) { if (error.code !== 'ENOENT') throw error; }

console.log(`Source verification passed: ${ids.size} HTML IDs, offline-first local runtime design, marine survival systems, Supabase OAuth/Cloud/Host-save source, Capacitor native orientation/fullscreen/deep links, and phone-triggered APK workflow.`);
