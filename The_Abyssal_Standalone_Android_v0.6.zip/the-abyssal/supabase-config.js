// PUBLIC client configuration only. Never put a Supabase service_role/secret key here.
// Create a Supabase project, then replace both values below with the Project URL
// and the project's publishable key (sb_publishable_...). Local/offline gameplay
// works without these values; they only enable account, cloud save and multiplayer.
export const SUPABASE_URL = 'https://YOUR_PROJECT_REF.supabase.co';
export const SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_REPLACE_ME';

export const NATIVE_AUTH_REDIRECT = 'theabyssal://auth/callback';
