-- THE ABYSSAL: Supabase schema (run all of this in Supabase SQL Editor).
-- Keep the project's service/secret key server-side. The app uses only the publishable key.

create table if not exists public.game_saves (
  user_id uuid not null references auth.users(id) on delete cascade,
  slot smallint not null check (slot between 1 and 5),
  save_data jsonb not null,
  saved_at timestamptz not null default now(),
  primary key (user_id, slot)
);

create table if not exists public.game_rooms (
  id uuid primary key default gen_random_uuid(),
  invite_code text not null unique check (invite_code ~ '^[A-Z2-9]{6}$'),
  host_id uuid not null references auth.users(id) on delete cascade,
  world_seed bigint not null default 87431,
  created_at timestamptz not null default now(),
  closed_at timestamptz
);

alter table public.game_rooms add column if not exists closed_at timestamptz;

create table if not exists public.game_room_members (
  room_id uuid not null references public.game_rooms(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  display_name text not null default 'Diver',
  joined_at timestamptz not null default now(),
  primary key (room_id, user_id)
);
create index if not exists game_room_members_user_idx on public.game_room_members(user_id);

create table if not exists public.room_saves (
  room_id uuid not null references public.game_rooms(id) on delete cascade,
  slot smallint not null check (slot between 1 and 5),
  save_data jsonb not null,
  saved_at timestamptz not null default now(),
  primary key (room_id, slot)
);

alter table public.game_saves enable row level security;
alter table public.game_rooms enable row level security;
alter table public.game_room_members enable row level security;
alter table public.room_saves enable row level security;

revoke all on public.game_saves, public.game_rooms, public.game_room_members, public.room_saves from anon, authenticated;
grant select, insert, update, delete on public.game_saves to authenticated;
grant select, update on public.game_rooms to authenticated;
grant select, delete on public.game_room_members to authenticated;
grant select, insert, update, delete on public.room_saves to authenticated;

-- SECURITY DEFINER helper avoids recursive RLS when room policies check membership.
create or replace function public.is_game_room_member(p_room_id uuid)
returns boolean language sql stable security definer
set search_path = public, auth, pg_temp
as $$
  select exists (select 1 from public.game_room_members m
    where m.room_id = p_room_id and m.user_id = (select auth.uid()));
$$;
revoke all on function public.is_game_room_member(uuid) from public, anon;
grant execute on function public.is_game_room_member(uuid) to authenticated;

-- Make policy creation repeatable when the owner needs to re-run this migration.
drop policy if exists "personal saves select owner" on public.game_saves;
drop policy if exists "personal saves insert owner" on public.game_saves;
drop policy if exists "personal saves update owner" on public.game_saves;
drop policy if exists "personal saves delete owner" on public.game_saves;
drop policy if exists "room select member" on public.game_rooms;
drop policy if exists "room insert host" on public.game_rooms;
drop policy if exists "room update host" on public.game_rooms;
drop policy if exists "room delete host" on public.game_rooms;
drop policy if exists "roster select member" on public.game_room_members;
drop policy if exists "roster delete self" on public.game_room_members;
drop policy if exists "room save select member" on public.room_saves;
drop policy if exists "room save insert host" on public.room_saves;
drop policy if exists "room save update host" on public.room_saves;
drop policy if exists "room save delete host" on public.room_saves;
drop policy if exists "abyssal room realtime read members" on realtime.messages;
drop policy if exists "abyssal room realtime write members" on realtime.messages;

-- Personal cloud save rows are private to the owning account.
create policy "personal saves select owner" on public.game_saves
for select to authenticated using ((select auth.uid()) = user_id);
create policy "personal saves insert owner" on public.game_saves
for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "personal saves update owner" on public.game_saves
for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "personal saves delete owner" on public.game_saves
for delete to authenticated using ((select auth.uid()) = user_id);

-- A room is visible only to its members. The Host owns room administration.
create policy "room select member" on public.game_rooms
for select to authenticated using (public.is_game_room_member(id));
create policy "room insert host" on public.game_rooms
for insert to authenticated with check ((select auth.uid()) = host_id);
create policy "room update host" on public.game_rooms
for update to authenticated using ((select auth.uid()) = host_id) with check ((select auth.uid()) = host_id);
create policy "room delete host" on public.game_rooms
for delete to authenticated using ((select auth.uid()) = host_id);

create policy "roster select member" on public.game_room_members
for select to authenticated using (public.is_game_room_member(room_id));
create policy "roster delete self" on public.game_room_members
for delete to authenticated using ((select auth.uid()) = user_id);
-- Membership inserts are available only through the SECURITY DEFINER RPCs below.

-- Every player can load a shared save; ONLY the room Host can insert/update/delete it.
create policy "room save select member" on public.room_saves
for select to authenticated using (public.is_game_room_member(room_id));
create policy "room save insert host" on public.room_saves
for insert to authenticated with check (exists (
  select 1 from public.game_rooms r where r.id = room_id and r.host_id = (select auth.uid())
));
create policy "room save update host" on public.room_saves
for update to authenticated using (exists (
  select 1 from public.game_rooms r where r.id = room_id and r.host_id = (select auth.uid())
)) with check (exists (
  select 1 from public.game_rooms r where r.id = room_id and r.host_id = (select auth.uid())
));
create policy "room save delete host" on public.room_saves
for delete to authenticated using (exists (
  select 1 from public.game_rooms r where r.id = room_id and r.host_id = (select auth.uid())
));

create or replace function public.create_game_room(p_code text, p_world_seed bigint, p_display_name text)
returns table(room_id uuid, room_code text, host_id uuid, world_seed bigint)
language plpgsql security definer set search_path = public, auth, pg_temp
as $$
declare v_id uuid;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if p_code !~ '^[A-Z2-9]{6}$' then raise exception 'Invalid room code'; end if;
  insert into public.game_rooms(invite_code, host_id, world_seed)
    values (p_code, auth.uid(), coalesce(p_world_seed, 87431)) returning id into v_id;
  insert into public.game_room_members(room_id, user_id, display_name)
    values (v_id, auth.uid(), left(coalesce(nullif(p_display_name, ''), 'Host'), 32));
  return query select v_id, p_code, auth.uid(), coalesce(p_world_seed, 87431);
end;
$$;

create or replace function public.join_game_room(p_code text, p_display_name text)
returns table(room_id uuid, room_code text, host_id uuid, world_seed bigint)
language plpgsql security definer set search_path = public, auth, pg_temp
as $$
declare r public.game_rooms%rowtype;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select * into r from public.game_rooms where invite_code = upper(trim(p_code));
  if not found then raise exception 'Room not found'; end if;
  if r.closed_at is not null then raise exception 'Room is closed'; end if;
  insert into public.game_room_members(room_id, user_id, display_name)
    values (r.id, auth.uid(), left(coalesce(nullif(p_display_name, ''), 'Diver'), 32))
    on conflict (room_id, user_id) do update set display_name = excluded.display_name;
  return query select r.id, r.invite_code, r.host_id, r.world_seed;
end;
$$;
revoke all on function public.create_game_room(text, bigint, text) from public, anon;
revoke all on function public.join_game_room(text, text) from public, anon;
grant execute on function public.create_game_room(text, bigint, text) to authenticated;
grant execute on function public.join_game_room(text, text) to authenticated;

-- Private Realtime room topics. Only actual room members can read/write presence and broadcasts.
create policy "abyssal room realtime read members" on realtime.messages
for select to authenticated using (
  extension in ('broadcast', 'presence') and exists (
    select 1 from public.game_room_members m
    join public.game_rooms r on r.id = m.room_id
    where m.user_id = (select auth.uid())
      and ('abyssal-room:' || r.id::text) = (select realtime.topic())
  )
);
create policy "abyssal room realtime write members" on realtime.messages
for insert to authenticated with check (
  extension in ('broadcast', 'presence') and exists (
    select 1 from public.game_room_members m
    join public.game_rooms r on r.id = m.room_id
    where m.user_id = (select auth.uid())
      and ('abyssal-room:' || r.id::text) = (select realtime.topic())
  )
);

-- Supabase Dashboard > Realtime Settings: disable public access for private channels.
