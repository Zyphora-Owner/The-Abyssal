import { defineConfig } from 'vite';

export default defineConfig({
  base: './',
  publicDir: 'public',
  build: {
    outDir: 'www',
    emptyOutDir: true,
    target: 'es2022',
    sourcemap: false,
    // Three.js, Supabase JS and Capacitor plugins are bundled into local chunks.
    // The installed APK never needs a CDN to load the game runtime.
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (id.includes('node_modules/three/')) return 'three';
          if (id.includes('node_modules/@supabase/')) return 'supabase';
          if (id.includes('node_modules/@capacitor/')) return 'capacitor';
        }
      }
    }
  }
});
