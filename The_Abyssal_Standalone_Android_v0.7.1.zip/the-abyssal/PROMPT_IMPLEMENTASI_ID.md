# Prompt implementasi — THE ABYSSAL Standalone Android 0.7.1

Lanjutkan proyek THE ABYSSAL yang sudah ada. Jangan membangun ulang dari nol dan jangan menghapus fitur yang sudah dibuat: dunia lautan 3D prosedural, streaming chunk, karakter penyelam, kontrol sentuh, menu Play/Continue/Settings/Exit, lima slot, pengaturan real-time, fauna 25 spesies termasuk paus dan Abyssal Leviathan, sistem HP/O₂/Food/Water/temperatur, medkit, ration, scanner, supply cache, Supabase Auth, Cloud Save, Multiplayer Room, Presence/Broadcast, dan Host-only shared save.

## Tujuan utama

Jadikan proyek dapat dipaketkan sebagai APK Android mandiri yang tidak membutuhkan Netlify atau website untuk diinstal dan dimainkan. Pertahankan engine Three.js yang sudah digunakan; jangan menggantinya dengan engine lain atau menghapus sistem yang ada hanya demi menyederhanakan build.

## Persyaratan native/offline

1. Bundel Three.js, Supabase JS, Capacitor bridge/plugin, game.js, fauna.js, online.js, styles.css, dan seluruh runtime dependency ke aset lokal melalui Vite.
2. Hapus import map CDN dan semua runtime dependency ke jsDelivr/unpkg dari entry HTML.
3. APK harus menyimpan aset game di dalam paket aplikasi. Single Player, world generation, fauna, survival, dan lima local save slot harus dapat dipakai offline setelah instalasi.
4. Layanan yang memang online (login, cloud save, multiplayer) hanya diaktifkan saat Supabase dikonfigurasi dan perangkat memiliki internet. Jika backend tidak tersedia, jangan gagalkan boot game offline.
5. Jangan mendaftarkan Service Worker di shell Capacitor native. PWA/browser preview boleh tetap menjadi opsi terpisah, tetapi bukan persyaratan instalasi.
6. Android MainActivity wajib landscape, fullscreen immersive, internet permission, dan deep link `theabyssal://auth/callback`. Patch manifest harus idempotent pada build berulang.
7. Jangan mengandalkan Netlify, server website, remote CDN, atau file game yang harus diunduh setiap kali aplikasi dibuka.

## Build hanya menggunakan ponsel

Sediakan GitHub Actions manual workflow yang menyiapkan Node 22+, Java 21, Android SDK API 36, menginstal dependensi, menguji source, membuat Vite bundle lokal, menginisialisasi Capacitor Android, mengompilasi APK debug, memverifikasi file APK, lalu mengunggahnya sebagai artifact yang dapat diunduh dari ponsel. Tidak boleh membutuhkan Android Studio di ponsel.

## Online (opsional)

Pertahankan Supabase Auth Email/Password, Google OAuth, Facebook OAuth, Cloud Save lima slot pribadi, room multiplayer, dan database RLS. Guest tidak boleh menulis shared-world save; hanya Host. Jangan memasukkan service-role/secret key ke dalam APK. Konfigurasi backend harus melalui GitHub Secrets atau file konfigurasi lokal pemilik game.

## Verifikasi

Tambahkan pemeriksaan source untuk mencegah import map/CDN runtime, memastikan aset Vite lokal dihasilkan, memverifikasi manifest landscape, OAuth deep link, Host-only RLS, semua fitur survival/fauna, dan workflow APK. Jangan menyatakan APK, login, cloud, multiplayer, atau performa perangkat sudah diuji sebelum benar-benar ada hasil build dan uji perangkat nyata. Laporkan batasan secara jujur.

## Output

Serahkan ZIP proyek lengkap yang dapat diunggah ke repository GitHub dari ponsel, panduan Indonesia, workflow APK cloud build, schema Supabase, dan prompt implementasi ini. Jelaskan bahwa Netlify tidak diperlukan dan bedakan fitur yang sudah ada pada source dari fitur eksternal yang masih memerlukan konfigurasi dan pengujian.
