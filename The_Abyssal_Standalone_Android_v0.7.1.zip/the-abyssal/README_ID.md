# THE ABYSSAL — Standalone Android Build 0.7.1

**The Abyssal sekarang dipaketkan sebagai aplikasi Android mandiri. Netlify tidak diperlukan untuk memasang atau memainkan game.** Android APK memuat HTML, CSS, Three.js, fauna, dan seluruh modul runtime di dalam paket aplikasi. Saat APK sudah terpasang, mode Single Player dapat dijalankan tanpa koneksi internet.

## Build 0.7.1 — peningkatan mobile dan first-person

- Kamera first-person permanen dengan tangan/perangkat scanner di depan kamera.
- Material prosedural untuk pasir, batu, rumput laut, karang, kayu, dan logam; satwa memakai pola sisik ringan.
- Cahaya bawah laut, partikel, efek damage, ambience audio sintetis, dan efek suara aksi.
- Inventory, pengumpulan titanium/tembaga/quartz/kelp/karang, crafting medkit/rations, dan tiga blueprint habitat.
- Backup/restore lima slot dalam file JSON untuk migrasi instalasi.
- Android immersive fullscreen, landscape, dan `adjustPan` saat keyboard tampil.
- Pemeriksaan update APK opsional yang hanya aktif setelah URL manifest HTTPS dikonfigurasi.

## Isi proyek

- Dunia lautan 3D prosedural dengan streaming chunk.
- Karakter penyelam 3D dan kontrol sentuh/landscape.
- 25 spesies fauna: ikan karang dan predator, ubur-ubur, penyu, manta, hiu, paus, giant squid, serta Abyssal Leviathan.
- Sistem survival HP, O₂, Food, Water, suhu, medkit, ration, scan, dan supply cache.
- Menu Play, Continue, Settings, Exit; lima slot penyimpanan.
- Pengaturan grafik, jarak render, suara, FOV, dan bahasa.
- Penyimpanan lokal untuk permainan offline.
- Integrasi Supabase Auth (Email/Password, Google OAuth, Facebook OAuth), Cloud Save, Multiplayer Room, Presence/Broadcast, dan Host-only shared-world save.
- Android Capacitor wrapper: landscape, immersive fullscreen, internet permission, dan OAuth deep link.
- GitHub Actions untuk membangun APK dari ponsel menggunakan runner cloud.

## Mandiri dari Netlify

APK tidak memuat iframe atau ketergantungan terhadap situs game. Vite membundel Three.js, Capacitor JavaScript bridge, dan modul Supabase ke file lokal pada folder `www/`. Tidak ada import map CDN pada halaman game. Runtime game tidak mengambil engine dari jsDelivr atau unpkg.

Setelah APK terpasang:

- **Single Player, dunia, fauna, survival, dan save lokal:** bisa dimainkan offline.
- **Login, Google/Facebook OAuth, Cloud Save, dan Multiplayer:** memerlukan internet dan project Supabase yang dikonfigurasi.
- Wi-Fi, data seluler, dan hotspot internet dapat dipakai untuk online. Hotspot tanpa akses internet tidak dapat mencapai server Supabase publik.

Netlify/PWA tidak dipakai sebagai jalur instalasi. `www/` hanya folder build lokal yang dimasukkan ke dalam APK oleh Capacitor.

## Dependensi dan build

Persyaratan Capacitor 8: Node.js 22+, Android SDK, Android build-tools, dan JDK 21 pada runner cloud. Dokumentasi resmi: https://capacitorjs.com/docs/getting-started/environment-setup

Di GitHub Actions, workflow `.github/workflows/android-apk.yml` melakukan:

1. Menyiapkan Node 22, Java 21, dan Android SDK API 36.
2. Menginstal dependensi NPM.
3. Menjalankan `npm test` untuk memeriksa source.
4. Memasukkan URL + Publishable Key Supabase jika repository secrets tersedia.
5. Membundel semua modul runtime secara lokal dengan Vite.
6. Membuat proyek Android Capacitor dan menerapkan landscape/fullscreen/deep link.
7. Mengompilasi `app-debug.apk` dan mengunggahnya sebagai artifact yang dapat diunduh dari ponsel.

### Cara build dari ponsel Android

1. Buat repository GitHub baru yang kosong.
2. Ekstrak ZIP proyek ini di ponsel, lalu unggah **isi folder `the-abyssal`** ke root repository (bukan folder ZIP sebagai satu file).
3. Pastikan folder `.github/workflows/` ikut terunggah. Pada pemilih file HP, aktifkan tampilkan file tersembunyi bila diperlukan.
4. Commit file ke branch `main`.
5. Buka repository → **Actions** → **Build The Abyssal Native Android APK** → **Run workflow**.
6. Tunggu job selesai dengan status hijau **Success**.
7. Di halaman run, buka **Artifacts** dan unduh `the-abyssal-android-apk`.
8. Ekstrak file artifact ZIP, lalu pasang `app-debug.apk`. Android mungkin meminta izin instalasi dari browser atau file manager yang digunakan.

Tidak perlu menginstal Android Studio, Node, Gradle, atau Netlify di ponsel. Kompilasi berlangsung di server GitHub Actions.

## Mengaktifkan fitur online (opsional)

Mode offline bisa diuji tanpa Supabase. Untuk mengaktifkan login, cloud, dan multiplayer:

1. Buat project Supabase.
2. Di **Project Settings → API / Connect**, salin Project URL dan **Publishable Key** (`sb_publishable_...`).
3. Di GitHub repository, buka **Settings → Secrets and variables → Actions**, lalu buat:
   - `SUPABASE_URL`
   - `SUPABASE_PUBLISHABLE_KEY`
4. Jalankan `supabase/schema.sql` satu kali melalui Supabase **SQL Editor**.
5. Di Supabase **Authentication → URL Configuration**, tambahkan Redirect URL `theabyssal://auth/callback`.
6. Aktifkan Email provider. Untuk Google dan Facebook, siapkan OAuth Client ID/Secret di Google Cloud / Meta for Developers, lalu masukkan pada Authentication → Providers di Supabase. Gunakan callback Supabase yang ditampilkan di halaman provider sebagai callback pada penyedia OAuth; app deep link tetap `theabyssal://auth/callback`.
7. Aktifkan private Realtime channels sesuai kebijakan pada schema.
8. Jalankan ulang workflow APK agar konfigurasi publik Supabase masuk ke build.

**Kunci keamanan:** hanya masukkan Supabase **Publishable Key** ke aplikasi. Jangan pernah menaruh `service_role`, secret key, password, atau App Secret provider di source code atau aplikasi Android. Client ID yang memang bersifat publik boleh dikonfigurasi melalui dashboard provider; rahasia provider tetap disimpan di Supabase.

## Catatan tentang APK dan update

Workflow ini menghasilkan **debug APK** untuk instalasi dan pengujian, bukan rilis publik bertanda tangan penerbit. Debug APK dapat dipasang langsung, tetapi build debug dari runner yang berbeda tidak dijamin memiliki tanda tangan identik. Untuk memperbarui instalasi tanpa uninstall, tahap berikutnya adalah menyiapkan keystore release pribadi dan GitHub repository secrets. Jangan membagikan keystore atau password.

APK tidak dibuat di lingkungan percakapan ini karena Android SDK/Gradle runner tidak tersedia di sini. ZIP yang diserahkan adalah source lengkap dengan workflow cloud build; APK baru tersedia setelah workflow GitHub berjalan sampai Success.

## Batas pengujian

Pemeriksaan source dapat memastikan ID UI, konfigurasi, dan keberadaan komponen sistem. Namun hal berikut tetap memerlukan cloud build dan pengujian perangkat nyata:

- rendering WebGL dan performa pada HP Android;
- pemasangan dan orientasi fullscreen;
- login OAuth di Android dan callback deep link;
- Cloud Save lintas perangkat;
- Multiplayer pada minimal dua perangkat;
- ketahanan penyimpanan saat aplikasi ditutup/dibuka kembali.

Multiplayer saat ini memiliki fondasi room, Presence, dan Broadcast pemain. Fauna dan seluruh simulasi survival belum menjadi simulasi server-authoritative yang direplikasi identik untuk semua pemain.


## Build 0.7.1 — Mobile polish and backup/restore

Pembaruan ini mengubah kamera pemain menjadi First Person (tidak ada kamera third-person), menambahkan viewmodel tangan/scanner, crosshair, tekstur prosedural lokal, underwater light rays, ambient ocean noise, SFX interaksi, inventory material, resource gathering, crafting Medkit/Rations, dan Habitat Builder (Beacon, Foundation, Glass Compartment). Data inventory, resource yang sudah diambil, dan bangunan disimpan dalam setiap slot.

### Android display and keyboard

MainActivity dikunci landscape, immersive fullscreen diterapkan ulang ketika window kembali fokus, dan `windowSoftInputMode=adjustPan` mencegah keyboard mengubah tinggi viewport aplikasi secara drastis. Browser preview menggunakan full-bleed device viewport, bukan letterbox 16:9; orientasi native tetap landscape dan kamera mengikuti rasio layar aktual agar tidak memotong UI.

### Important limits

Build ini masih merupakan game indie prototype 3D berbasis Three.js dalam Capacitor WebView, bukan produksi setara Subnautica. Tekstur dibuat prosedural saat runtime; audio adalah ambience/SFX sintetis Web Audio, bukan rekaman profesional. Sistem building/material berfungsi pada modul dasar yang disediakan; belum ada base power, pressure, oxygen piping, vehicle, story campaign, atau simulation ecology penuh. Akun/Cloud/Multiplayer tetap membutuhkan konfigurasi Supabase sendiri.

### Update note

APK native tidak bisa memasang pembaruan kode native secara diam-diam. Pembaruan versi ini tetap dikirim sebagai APK yang ditandatangani dengan sertifikat yang sama. Pemeriksaan update opsional dapat memakai `window.ABYSSAL_UPDATE_MANIFEST_URL`; manifest harus HTTPS dan berisi `version`, `downloadUrl`, serta `notes`. Pengguna tetap harus menyetujui pemasangan Android. Jangan menganggap pemeriksaan update aktif sebelum URL manifest publik terkonfigurasi.


## Pembaruan aplikasi

- Source game dibangun ulang menjadi APK untuk setiap perubahan bundle yang ingin dipasang di Android.
- Pemeriksa update APK dapat menampilkan pemberitahuan dan membuka tautan unduhan HTTPS, tetapi manifest publik belum dikonfigurasi. Android tetap meminta persetujuan pengguna untuk memasang APK.
- Live/OTA replacement kode tidak diaktifkan pada build ini. Jangan menganggap perubahan di GitHub otomatis masuk ke APK terpasang.
- Gunakan Backup Progress (JSON) dari Settings sebelum migrasi atau instal ulang.

## Batas fitur saat ini

Build 0.7.1 adalah prototipe survival 3D yang diperluas, bukan replika penuh Subnautica. World masih procedural low-poly dengan material tekstur procedural; habitat memiliki tiga tipe struktur; survival meliputi HP, O₂, Food, Water, dan temperatur. Kendaraan, sistem daya basis, crafting tree besar, cerita lengkap, dan perilaku ekologis kompleks belum tersedia. Performa dan visual final tetap perlu diuji pada perangkat Android sasaran.
