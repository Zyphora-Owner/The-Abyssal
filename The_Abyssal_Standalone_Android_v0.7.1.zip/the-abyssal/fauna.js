import * as THREE from 'three';

// Stylized low-poly marine life. Shared geometry/materials keep draw calls and memory modest on Android.
const SPECIES = [
  { id:'clownfish', name:'Clownfish', kind:'fish', color:0xf28a38, belly:0xffe6c4, scale:0.52, speed:3.1, depth:[-5,-20], weight:10 },
  { id:'blue_tang', name:'Blue Tang', kind:'fish', color:0x2377d8, belly:0xe8d8a8, scale:0.62, speed:3.8, depth:[-4,-22], weight:9 },
  { id:'butterflyfish', name:'Butterflyfish', kind:'fish', color:0xf5d34d, belly:0xfff1c7, scale:0.55, speed:2.7, depth:[-4,-18], weight:8 },
  { id:'angelfish', name:'Angelfish', kind:'fish', color:0x7a8bd8, belly:0xf2d9a0, scale:0.65, speed:2.6, depth:[-8,-28], weight:7 },
  { id:'parrotfish', name:'Parrotfish', kind:'fish', color:0x36ae9a, belly:0xbfe8d1, scale:0.72, speed:2.2, depth:[-7,-25], weight:7 },
  { id:'lionfish', name:'Lionfish', kind:'fish', color:0xd66b48, belly:0xf3d7c8, scale:0.72, speed:1.9, depth:[-10,-32], weight:5 },
  { id:'yellowfin_tuna', name:'Yellowfin Tuna', kind:'fish', color:0xb9c8d1, belly:0xf4e8ca, scale:0.9, speed:5.3, depth:[-8,-32], weight:5 },
  { id:'barracuda', name:'Barracuda', kind:'predator', color:0x8399a0, belly:0xd6e1d9, scale:1.0, speed:4.7, depth:[-12,-35], weight:4, hostile:true, damage:7, aggro:22 },
  { id:'seahorse', name:'Seahorse', kind:'seahorse', color:0xe7b45e, belly:0xffe1a0, scale:0.48, speed:1.15, depth:[-6,-25], weight:4 },
  { id:'pufferfish', name:'Pufferfish', kind:'fish', color:0xdba94c, belly:0xf6df9a, scale:0.62, speed:1.35, depth:[-5,-24], weight:5 },
  { id:'moorish_idol', name:'Moorish Idol', kind:'fish', color:0xe8d8a0, belly:0xf4eee0, scale:0.66, speed:3.0, depth:[-5,-22], weight:4 },
  { id:'triggerfish', name:'Titan Triggerfish', kind:'fish', color:0x3a9b8a, belly:0xc9e2ba, scale:0.78, speed:2.1, depth:[-7,-26], weight:3 },
  { id:'moray_eel', name:'Moray Eel', kind:'fish', color:0x778e51, belly:0xb9c28f, scale:0.86, speed:1.75, depth:[-12,-34], weight:3 },
  { id:'bioluminescent_angler', name:'Bioluminescent Anglerfish', kind:'angler', color:0x344d5c, belly:0x82999a, scale:0.92, speed:1.45, depth:[-27,-41], weight:1.2 },
  { id:'jellyfish', name:'Jellyfish', kind:'jelly', color:0x9f8bea, belly:0xd9d0ff, scale:0.8, speed:0.8, depth:[-10,-38], weight:5 },
  { id:'sea_turtle', name:'Green Sea Turtle', kind:'turtle', color:0x528b68, belly:0xc1aa79, scale:1.0, speed:1.6, depth:[-4,-26], weight:4 },
  { id:'manta_ray', name:'Manta Ray', kind:'manta', color:0x344a61, belly:0x91b7bf, scale:1.55, speed:3.2, depth:[-8,-34], weight:3 },
  { id:'reef_shark', name:'Reef Shark', kind:'shark', color:0x657d8b, belly:0xcbd9d9, scale:1.45, speed:4.2, depth:[-12,-34], weight:3, hostile:true, damage:9, aggro:28 },
  { id:'hammerhead', name:'Hammerhead Shark', kind:'hammerhead', color:0x657b88, belly:0xd1dfda, scale:1.9, speed:4.7, depth:[-18,-40], weight:2, hostile:true, damage:12, aggro:32 },
  { id:'humpback_whale', name:'Humpback Whale', kind:'whale', color:0x425e6b, belly:0x9aafb0, scale:3.2, speed:1.8, depth:[-8,-30], weight:1.4 },
  { id:'sperm_whale', name:'Sperm Whale', kind:'whale', color:0x536b73, belly:0xaabbb7, scale:3.7, speed:1.55, depth:[-22,-41], weight:0.8 },
  { id:'blue_whale', name:'Blue Whale', kind:'whale', color:0x3e7180, belly:0xb2ccca, scale:4.8, speed:1.25, depth:[-12,-37], weight:0.45 },
  { id:'orca', name:'Orca', kind:'whale', color:0x182b37, belly:0xe5eeee, scale:3.25, speed:2.4, depth:[-7,-30], weight:0.7 },
  { id:'giant_squid', name:'Giant Squid', kind:'squid', color:0x966075, belly:0xd2a2a9, scale:2.4, speed:1.7, depth:[-25,-41], weight:0.65 },
  { id:'abyssal_leviathan', name:'Abyssal Leviathan', kind:'leviathan', color:0x172c3b, belly:0x45636c, scale:4.5, speed:3.0, depth:[-30,-42], weight:0.22, hostile:true, damage:22, aggro:58 }
];

const QUALITY_COUNTS = { low: 12, balanced: 20, high: 28 };
const rand = (a,b) => a + Math.random() * (b-a);
const choose = (items) => items[Math.floor(Math.random() * items.length)];
const clamp = (v,a,b) => Math.max(a,Math.min(b,v));

export class FaunaDirector {
  constructor(scene, onAttack = () => {}) {
    this.scene = scene;
    this.onAttack = onAttack;
    this.animals = [];
    this.discovered = new Set();
    this.quality = 'balanced';
    this.lastReplenish = 0;
    this.shared = {
      sphere: new THREE.SphereGeometry(1, 8, 6),
      cone: new THREE.ConeGeometry(0.45, 0.85, 4),
      fin: new THREE.ConeGeometry(0.42, 0.9, 3),
      smallSphere: new THREE.SphereGeometry(0.12, 6, 5),
      tentacle: new THREE.CylinderGeometry(0.035, 0.018, 1, 5)
    };
    this.materials = new Map();
    this.scaleTexture = this.createScaleTexture();
  }

  createScaleTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 128; canvas.height = 128;
    const ctx = canvas.getContext('2d');
    const gradient = ctx.createLinearGradient(0, 0, 0, 128);
    gradient.addColorStop(0, '#ffffff'); gradient.addColorStop(1, '#b9d5d7');
    ctx.fillStyle = gradient; ctx.fillRect(0, 0, 128, 128);
    ctx.strokeStyle = 'rgba(24,58,72,.20)'; ctx.lineWidth = 1;
    for (let row = 0; row < 9; row++) {
      const y = row * 16;
      for (let col = -1; col < 9; col++) {
        const x = col * 16 + (row % 2) * 8;
        ctx.beginPath(); ctx.arc(x, y, 9, 0.12, Math.PI - 0.12); ctx.stroke();
        ctx.beginPath(); ctx.arc(x, y + 2, 6.8, 0.18, Math.PI - 0.18);
        ctx.strokeStyle = 'rgba(255,255,255,.25)'; ctx.stroke();
        ctx.strokeStyle = 'rgba(24,58,72,.20)';
      }
    }
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(1.6, 1.2);
    texture.minFilter = THREE.LinearMipmapLinearFilter;
    texture.magFilter = THREE.LinearFilter;
    return texture;
  }

  setDiscoveries(ids = []) {
    this.discovered = new Set(Array.isArray(ids) ? ids.filter(id => SPECIES.some(s => s.id === id)) : []);
  }
  getDiscoveries() { return [...this.discovered]; }
  getSpeciesCount() { return this.discovered.size; }
  setQuality(value) { this.quality = value in QUALITY_COUNTS ? value : 'balanced'; }

  material(color, options = {}) {
    const key = `${color}-${options.emissive || 0}-${options.roughness ?? 0.82}`;
    if (!this.materials.has(key)) this.materials.set(key, new THREE.MeshStandardMaterial({ color, map: this.scaleTexture, roughness: options.roughness ?? 0.82, metalness: 0.02, emissive: options.emissive || 0, emissiveIntensity: options.emissive ? 0.8 : 0 }));
    return this.materials.get(key);
  }
  mesh(geometry, material, group, scale, position) {
    const m = new THREE.Mesh(geometry, material);
    if (scale) m.scale.set(...scale);
    if (position) m.position.set(...position);
    group.add(m);
    return m;
  }

  createModel(species) {
    const root = new THREE.Group();
    const main = this.material(species.color);
    const belly = this.material(species.belly || 0xbad0d0);
    const dark = this.material(0x071a25, { roughness:0.45 });
    const glow = this.material(0x6ce6e4, { emissive:0x1b8f9b, roughness:0.38 });
    let tail = null, wings = [];

    if (species.kind === 'jelly') {
      this.mesh(this.shared.sphere, main, root, [0.62,0.48,0.62], [0,0,0]);
      const dome = new THREE.Mesh(this.shared.sphere, glow); dome.scale.set(0.38,0.22,0.38); dome.position.y=0.22; root.add(dome);
      for (let i=0;i<6;i++) {
        const strand = this.mesh(this.shared.tentacle, belly, root, [1,rand(1.2,2.2),1], [Math.cos(i*Math.PI/3)*0.34,-0.95,Math.sin(i*Math.PI/3)*0.34]);
        strand.rotation.z = Math.cos(i*Math.PI/3)*0.14;
        strand.rotation.x = Math.sin(i*Math.PI/3)*0.14;
      }
    } else if (species.kind === 'squid') {
      this.mesh(this.shared.sphere, main, root, [0.62,0.72,1.35], [0,0,0.42]);
      this.mesh(this.shared.sphere, belly, root, [0.5,0.52,0.68], [0,-0.18,-0.5]);
      for (const side of [-1,1]) this.mesh(this.shared.smallSphere, glow, root, [1.6,1.6,1.6], [side*0.38,0.1,-0.9]);
      for (let i=0;i<8;i++) {
        const angle=(i/8)*Math.PI*2;
        const arm=this.mesh(this.shared.tentacle, main, root, [1,rand(2.1,3.5),1], [Math.cos(angle)*0.38,-0.62,Math.sin(angle)*0.38-0.55]);
        arm.rotation.z=Math.cos(angle)*0.48; arm.rotation.x=Math.sin(angle)*0.42; wings.push(arm);
      }
      tail=this.mesh(this.shared.cone, main, root, [0.72,1.3,0.72], [0,0,1.55]); tail.rotation.x=-Math.PI/2;
    } else if (species.kind === 'turtle') {
      this.mesh(this.shared.sphere, main, root, [0.78,0.36,1.05], [0,0,0]);
      this.mesh(this.shared.sphere, belly, root, [0.62,0.16,0.92], [0,-0.18,0]);
      const head = this.mesh(this.shared.sphere, main, root, [0.29,0.28,0.38], [0,0,-1.05]);
      head.rotation.x=-0.12;
      for (const side of [-1,1]) for (const front of [-1,1]) {
        const flipper=this.mesh(this.shared.sphere, main, root, [0.22,0.12,0.58], [side*0.75,0,front<0?-0.65:0.68]);
        flipper.rotation.y=side*0.42; flipper.rotation.x=front*0.18;
      }
      tail=this.mesh(this.shared.cone, main, root, [0.18,0.42,0.18], [0,-0.02,1.08]); tail.rotation.x=Math.PI/2;
    } else if (species.kind === 'manta') {
      this.mesh(this.shared.sphere, main, root, [0.72,0.17,1.2], [0,0,0]);
      this.mesh(this.shared.sphere, belly, root, [0.5,0.09,0.65], [0,-0.12,-0.05]);
      for (const side of [-1,1]) {
        const wing=this.mesh(this.shared.sphere, main, root, [1.35,0.075,0.74], [side*1.05,0,0.03]);
        wing.rotation.z=side*0.1; wings.push(wing);
      }
      tail=this.mesh(this.shared.cone, main, root, [0.12,1.2,0.12], [0,0,1.35]); tail.rotation.x=Math.PI/2;
    } else if (species.kind === 'whale') {
      this.mesh(this.shared.sphere, main, root, [1.12,0.88,2.2], [0,0,0]);
      this.mesh(this.shared.sphere, belly, root, [0.87,0.25,1.55], [0,-0.61,-0.05]);
      const head = this.mesh(this.shared.sphere, main, root, [1.05,0.72,0.95], [0,0.12,-1.45]);
      head.rotation.x=0.05;
      for (const side of [-1,1]) {
        const flipper=this.mesh(this.shared.sphere, main, root, [0.28,0.13,1.0], [side*0.92,-0.25,-0.1]);
        flipper.rotation.y=side*0.42; flipper.rotation.z=side*0.12; wings.push(flipper);
      }
      const tailFork = new THREE.Group(); tailFork.position.z=2.05; root.add(tailFork);
      for (const side of [-1,1]) {
        const l=this.mesh(this.shared.sphere, main, tailFork, [0.62,0.12,0.55], [side*0.48,0,0.2]);
        l.rotation.y=side*0.4; wings.push(l);
      }
      tail=tailFork;
    } else if (species.kind === 'leviathan') {
      this.mesh(this.shared.sphere, main, root, [1.0,0.88,2.75], [0,0,0]);
      this.mesh(this.shared.sphere, belly, root, [0.83,0.3,1.85], [0,-0.59,-0.1]);
      const jaw=this.mesh(this.shared.sphere, belly, root, [0.62,0.2,0.95], [0,-0.52,-1.95]); jaw.rotation.x=-0.15;
      for (const side of [-1,1]) {
        this.mesh(this.shared.smallSphere, glow, root, [1.35,1.35,1.35], [side*0.58,0.28,-2.15]);
        this.mesh(this.shared.sphere, dark, root, [0.12,0.1,0.16], [side*0.67,0.28,-2.28]);
        const fin=this.mesh(this.shared.sphere, main, root, [0.22,0.13,1.3], [side*0.83,-0.2,-0.15]); fin.rotation.y=side*0.45; wings.push(fin);
      }
      for (let i=0;i<8;i++) {
        const spine=this.mesh(this.shared.cone, glow, root, [0.16,rand(0.65,1.0),0.16], [0,0.78,0.95-i*0.42]);
        spine.rotation.x=-Math.PI/7;
      }
      tail=this.mesh(this.shared.cone, main, root, [0.6,1.35,0.5], [0,0.06,2.65]); tail.rotation.x=Math.PI/2;
    } else if (species.kind === 'seahorse') {
      this.mesh(this.shared.sphere, main, root, [0.35,0.7,0.3], [0,0.05,0]);
      const head=this.mesh(this.shared.sphere, main, root, [0.33,0.34,0.42], [0,0.62,-0.1]); head.rotation.x=-0.2;
      const snout=this.mesh(this.shared.cone, main, root, [0.13,0.5,0.13], [0.02,0.55,-0.5]); snout.rotation.x=Math.PI/2;
      const curl=this.mesh(this.shared.cone, main, root, [0.18,0.65,0.18], [0,-0.62,0.2]); curl.rotation.x=-Math.PI/2;
      tail=curl;
    } else {
      const elongated = species.kind === 'shark' || species.kind === 'hammerhead' || species.kind === 'predator';
      const bodyLen = elongated ? 1.65 : 1.15;
      this.mesh(this.shared.sphere, main, root, [elongated?0.47:0.55,elongated?0.42:0.62,bodyLen], [0,0,0]);
      this.mesh(this.shared.sphere, belly, root, [elongated?0.36:0.42,0.2,bodyLen*0.76], [0,-0.28,0.02]);
      if (species.kind === 'hammerhead') {
        const head=this.mesh(this.shared.sphere, main, root, [1.0,0.18,0.35], [0,0.03,-1.25]);
        for (const side of [-1,1]) this.mesh(this.shared.smallSphere, dark, root, [0.75,0.75,0.75], [side*0.87,0.11,-1.22]);
      } else {
        for (const side of [-1,1]) this.mesh(this.shared.smallSphere, dark, root, [0.75,0.75,0.75], [side*0.34,0.12,-0.78]);
      }
      const dorsal=this.mesh(this.shared.cone, main, root, [0.28,0.65,0.2], [0,0.5,-0.05]); dorsal.rotation.x=Math.PI/2;
      if (species.kind==='angler') {
        const stalk=this.mesh(this.shared.tentacle, main, root, [1,0.72,1], [0,0.75,-0.62]); stalk.rotation.x=-0.45;
        this.mesh(this.shared.smallSphere, glow, root, [2.2,2.2,2.2], [0,1.08,-0.88]);
      }
      tail=new THREE.Group(); tail.position.z=bodyLen*0.86; root.add(tail);
      const upper=this.mesh(this.shared.cone, main, tail, [0.34,0.82,0.22], [0,0.24,0.35]); upper.rotation.x=Math.PI/2;
      const lower=this.mesh(this.shared.cone, main, tail, [0.25,0.55,0.18], [0,-0.18,0.34]); lower.rotation.x=Math.PI/2;
      for (const side of [-1,1]) {
        const fin=this.mesh(this.shared.cone, main, root, [0.16,0.55,0.14], [side*0.42,-0.1,-0.15]); fin.rotation.z=side*0.95; fin.rotation.x=Math.PI/2; wings.push(fin);
      }
    }
    root.scale.setScalar(species.scale);
    return { group:root, tail, wings };
  }

  chooseSpecies(depth) {
    const candidates=SPECIES.filter(s => depth <= s.depth[0] && depth >= s.depth[1]);
    const pool=candidates.length?candidates:SPECIES.filter(s=>s.kind==='fish');
    let total=pool.reduce((sum,s)=>sum+s.weight,0), pick=Math.random()*total;
    for (const s of pool) { pick-=s.weight; if (pick<=0) return s; }
    return pool[0];
  }

  spawnOne(playerPosition, forceRare = false) {
    const angle=rand(0,Math.PI*2), distance=rand(26,118);
    const x=playerPosition.x+Math.cos(angle)*distance;
    const z=playerPosition.z+Math.sin(angle)*distance;
    const depth=clamp(playerPosition.y-rand(-3,22),-41,-4);
    let species;
    if (forceRare && depth < -28 && Math.random()<0.025) species=SPECIES.find(s=>s.id==='abyssal_leviathan');
    else species=this.chooseSpecies(depth);
    // Keep giant life at a readable distance so it appears as a discovery, not a surprise collision.
    if (species.kind==='leviathan' || species.kind==='whale') {
      const farAngle=rand(0,Math.PI*2), far=rand(85,150);
      const model=this.createModel(species);
      model.group.position.set(playerPosition.x+Math.cos(farAngle)*far,depth,playerPosition.z+Math.sin(farAngle)*far);
      this.scene.add(model.group);
      this.animals.push({ ...model, species, velocity:rand(0.65,1.25), direction:farAngle+Math.PI, phase:rand(0,Math.PI*2), attackCooldown:rand(1,4), roamTimer:rand(2,8) });
      return;
    }
    const model=this.createModel(species);
    model.group.position.set(x,depth,z);
    this.scene.add(model.group);
    this.animals.push({ ...model, species, velocity:rand(0.72,1.3), direction:angle+Math.PI, phase:rand(0,Math.PI*2), attackCooldown:rand(1,3), roamTimer:rand(1,5) });
  }

  ensurePopulation(playerPosition) {
    const radius=this.quality==='low'?165:this.quality==='high'?235:200;
    for (let i=this.animals.length-1;i>=0;i--) {
      const animal=this.animals[i];
      const distance=animal.group.position.distanceTo(playerPosition);
      if (distance>radius+45) {
        this.scene.remove(animal.group);
        this.animals.splice(i,1);
      }
    }
    const target=QUALITY_COUNTS[this.quality] || 20;
    while (this.animals.length>target) {
      const removed=this.animals.pop();
      this.scene.remove(removed.group);
    }
    while (this.animals.length<target) this.spawnOne(playerPosition,true);
  }

  update(dt, playerPosition) {
    this.lastReplenish-=dt;
    if (this.lastReplenish<=0) { this.lastReplenish=1.8; this.ensurePopulation(playerPosition); }
    let nearest=null, nearestDistance=Infinity;
    for (const animal of this.animals) {
      const species=animal.species;
      const pos=animal.group.position;
      const dx=playerPosition.x-pos.x, dy=playerPosition.y-pos.y, dz=playerPosition.z-pos.z;
      const dist=Math.hypot(dx,dy,dz);
      if (dist<nearestDistance) { nearestDistance=dist; nearest={ species, distance:dist }; }
      animal.roamTimer-=dt;
      const aggro=species.aggro||0;
      if (species.hostile && dist<aggro && dist>4.5) {
        const desired=Math.atan2(-dx,-dz);
        let diff=desired-animal.group.rotation.y;
        while(diff>Math.PI)diff-=Math.PI*2; while(diff<-Math.PI)diff+=Math.PI*2;
        animal.group.rotation.y+=diff*Math.min(1,dt*1.6);
        animal.direction=animal.group.rotation.y;
        const speed=species.id==='abyssal_leviathan'?species.speed:species.speed*0.78;
        pos.x+=Math.sin(animal.direction)*speed*dt;
        pos.z-=Math.cos(animal.direction)*speed*dt;
        pos.y+=clamp(dy,-4,4)*0.22*dt;
      } else {
        if (animal.roamTimer<=0) { animal.direction+=rand(-0.85,0.85); animal.roamTimer=rand(2.5,7); }
        const targetYaw=animal.direction;
        animal.group.rotation.y+=((targetYaw-animal.group.rotation.y+Math.PI*3)%(Math.PI*2)-Math.PI)*Math.min(1,dt*1.2);
        const speed=species.speed*animal.velocity;
        pos.x+=Math.sin(animal.direction)*speed*dt;
        pos.z-=Math.cos(animal.direction)*speed*dt;
        if (species.kind==='jelly' || species.kind==='whale' || species.kind==='leviathan') pos.y+=Math.sin((animal.phase+=dt)*0.7)*dt*(species.kind==='jelly'?1.2:0.35);
        else pos.y+=Math.sin((animal.phase+=dt)*1.15)*dt*0.22;
      }
      const wave=Math.sin((animal.phase+=dt*2.2))*0.16;
      if (animal.tail && animal.tail.rotation) animal.tail.rotation.y=wave*1.5;
      if (species.kind==='manta' && animal.wings.length) {
        animal.wings[0].rotation.z=Math.sin(animal.phase)*0.18+0.1;
        animal.wings[1].rotation.z=-Math.sin(animal.phase)*0.18-0.1;
      }
      if (species.hostile && dist<5.4 && animal.attackCooldown<=0) {
        animal.attackCooldown=species.id==='abyssal_leviathan'?3.8:2.7;
        this.onAttack(species.damage||8,species.name);
      } else animal.attackCooldown-=dt;
    }
    return { count:this.animals.length, nearest:nearest&&nearestDistance<95?nearest:null, threat:this.animals.filter(a=>a.species.hostile).reduce((best,a)=>{const d=a.group.position.distanceTo(playerPosition);return d<(best?.distance??Infinity)?{name:a.species.name,distance:d}:best;},null) };
  }

  scan(playerPosition, range=58) {
    let best=null, bestDistance=range;
    for (const animal of this.animals) {
      const distance=animal.group.position.distanceTo(playerPosition);
      if (distance<bestDistance) { bestDistance=distance; best=animal.species; }
    }
    if (!best) return null;
    const isNew=!this.discovered.has(best.id);
    this.discovered.add(best.id);
    return { id:best.id, name:best.name, kind:best.kind, distance:Math.round(bestDistance), isNew, total:this.discovered.size, maximum:SPECIES.length };
  }

  dispose() {
    for (const animal of this.animals) this.scene.remove(animal.group);
    this.animals.length=0;
    for (const geometry of Object.values(this.shared)) geometry.dispose();
    for (const material of this.materials.values()) material.dispose();
    this.materials.clear();
  }
}

export const FAUNA_SPECIES_COUNT = SPECIES.length;
