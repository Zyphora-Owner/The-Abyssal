import * as THREE from 'three';
import { OnlineService } from './online.js';
import { FaunaDirector, FAUNA_SPECIES_COUNT } from './fauna.js';

const $ = (id) => document.getElementById(id);
const canvas = $('world-canvas');
const UI = {
  boot: $('boot-screen'), main: $('main-menu'), newGame: $('new-game-screen'), load: $('load-screen'),
  settings: $('settings-screen'), online: $('online-screen'), inventory: $('inventory-screen'), build: $('build-screen'), hud: $('hud'), pause: $('pause-screen'), exit: $('exit-screen')
};
const STORAGE = { slots: 'the-abyssal-slots-v1', settings: 'the-abyssal-settings-v1' };
const CHUNK_SIZE = 64;
const WORLD_SEED = 87431;
const SURVIVAL_DEFAULTS = { hp: 100, oxygen: 100, food: 100, water: 100, medkits: 2, rations: 3 };
const SURVIVAL_STORAGE_VERSION = 2;
const INVENTORY_DEFAULTS = { titanium: 0, copper: 0, quartz: 0, kelp: 0, coral: 0 };
const RESOURCE_LABELS = { titanium: 'Titanium', copper: 'Copper Ore', quartz: 'Quartz', kelp: 'Creepvine', coral: 'Coral Sample' };
const BUILD_RECIPES = {
  beacon: { label: 'Seaglide Beacon', cost: { copper: 1, quartz: 1 } },
  foundation: { label: 'Habitat Foundation', cost: { titanium: 3 } },
  compartment: { label: 'Glass Habitat Module', cost: { titanium: 5, quartz: 2 } }
};
let inventory = { ...INVENTORY_DEFAULTS };
let collectedResources = new Set();
let placedStructures = [];
let resourceNodes = new Map();
let viewModel = null;
let lightRayGroup = null;
let terrainTexture = null, rockTexture = null, kelpTexture = null, coralTexture = null, woodTexture = null, metalTexture = null;
let soundNoiseGain = null;
let visualViewportResizeTimer = 0;
let updateCheckTimer = 0;

const copy = {
  id: {
    tagline: 'Lautan tak berujung. Rahasia yang menunggu ditemukan.', play: 'Play', continue: 'Continue', settings: 'Settings', exit: 'Exit',
    back: 'Kembali', newGame: 'Permainan Baru', newGameHint: 'Pilih slot untuk memulai ekspedisi baru. Slot berisi data lama akan ditimpa setelah konfirmasi.',
    load: 'Load', loadHint: 'Pilih salah satu dari lima slot untuk melanjutkan perjalanan.', graphics: 'Grafik', renderDistance: 'Jarak render',
    sound: 'Suara', fieldOfView: 'Field of view', language: 'Bahasa', display: 'Tampilan', fullscreen: 'Fullscreen',
    settingsNote: 'Perubahan grafik, suara, jarak render, bahasa, dan FOV diterapkan langsung.', sessionEnded: 'Sesi berakhir',
    exitHint: 'Progres telah disimpan. Kamu dapat kembali ke menu atau keluar ke Home Android.', mainMenu: 'Menu Utama'
  },
  en: {
    tagline: 'An endless ocean. Secrets waiting to be discovered.', play: 'Play', continue: 'Continue', settings: 'Settings', exit: 'Exit',
    back: 'Back', newGame: 'New Expedition', newGameHint: 'Choose a slot for a new expedition. Existing data will be replaced after confirmation.',
    load: 'Load', loadHint: 'Choose one of five slots to continue your journey.', graphics: 'Graphics', renderDistance: 'Render distance',
    sound: 'Sound', fieldOfView: 'Field of view', language: 'Language', display: 'Display', fullscreen: 'Fullscreen',
    settingsNote: 'Graphics, sound, render distance, language, and FOV changes apply immediately.', sessionEnded: 'Session ended',
    exitHint: 'Your progress has been saved. Return to the menu or leave to the Android home screen.', mainMenu: 'Main Menu'
  }
};

const defaults = { graphics: 'balanced', renderDistance: 2, volume: 55, fov: 70, language: 'id' };
let settings = loadJson(STORAGE.settings, defaults);
settings = { ...defaults, ...(settings && typeof settings === 'object' ? settings : {}) };
let slots = loadJson(STORAGE.slots, [null, null, null, null, null]);
if (!Array.isArray(slots) || slots.length !== 5) slots = [null, null, null, null, null];

let renderer, scene, camera, water, particleGroup, playerGroup, playerBody, leftArm, rightArm, leftFin, rightFin;
let faunaDirector = null;
let faunaStatus = { count: 0, nearest: null, threat: null };
let survival = { ...SURVIVAL_DEFAULTS };
let oxygenDamageTimer = 0, hungerDamageTimer = 0, thirstDamageTimer = 0;
let temperatureC = 28;
let respawnPoint = new THREE.Vector3(0, -7, 0);
let isRespawning = false;
let collectedCaches = new Set();
let terrainMaterial, rockGeometry, rockMaterial, kelpGeometry, kelpMaterial, coralGeometry, coralMaterial;
let chunks = new Map();
let gameActive = false;
let gamePaused = false;
let activeSlot = -1;
let personalSlotsBeforeRoom = null;
let settingsReturn = 'main';
let lastFrame = performance.now();
let lastHudUpdate = 0;
let autoSaveTimer = 0;
let chunkCenterX = NaN, chunkCenterZ = NaN;
let toastTimer = 0;
let ambientContext = null, ambientGain = null;
let rendererReady = false;
const online = new OnlineService();
let roomBroadcastTimer = 0;
const remotePlayers = new Map();

const player = { position: new THREE.Vector3(0, -7, 0), yaw: 0, pitch: 0.08, bob: 0 };
const input = { keys: new Set(), joyX: 0, joyY: 0, vertical: 0, forward: 0, strafe: 0 };
const look = { active: false, pointerId: null, x: 0, y: 0 };
const islandOfInterest = { x: 98, z: -58, name: 'Verdant Isle' };
const shipOfInterest = { x: -132, z: 150, name: 'Sunken Vessel' };
const supplyCacheLocations = [
  { id: 'verdant_cache', name: 'Verdant Isle Supply Cache', x: 205, y: -4, z: -58 },
  { id: 'wreck_cache', name: 'Sunken Vessel Supply Cache', x: -118, y: -35, z: 145 }
];
const tmpVector = new THREE.Vector3();
const tmpRight = new THREE.Vector3();
const tmpDirection = new THREE.Vector3();
const tmpCamera = new THREE.Vector3();
const clockState = { elapsed: 0 };

function loadJson(key, fallback) {
  try { const value = localStorage.getItem(key); return value ? JSON.parse(value) : fallback; }
  catch { return fallback; }
}
function saveJson(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); return true; }
  catch { showToast('Penyimpanan perangkat penuh atau tidak tersedia.'); return false; }
}
function clamp(value, min, max) { return Math.max(min, Math.min(max, value)); }
function getGameViewportSize() {
  const rect = $('game-shell').getBoundingClientRect();
  return { width: Math.max(1, Math.round(rect.width)), height: Math.max(1, Math.round(rect.height)) };
}
function lerp(a, b, t) { return a + (b - a) * t; }
function smoothstep(a, b, x) { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); }
function wrapAngle(a) { while (a > Math.PI) a -= Math.PI * 2; while (a < -Math.PI) a += Math.PI * 2; return a; }
function formatTime(value) {
  try { return new Intl.DateTimeFormat(settings.language === 'id' ? 'id-ID' : 'en-US', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)); }
  catch { return new Date(value).toLocaleString(); }
}
function showToast(message) {
  const toast = $('toast');
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2400);
}
function setVisibleScreen(name) {
  if (document.activeElement && /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName)) document.activeElement.blur();
  Object.values(UI).forEach(node => node.classList.add('hidden'));
  if (UI[name]) UI[name].classList.remove('hidden');
  document.body.classList.toggle('game-screen-open', name === 'hud');
}
function applyLanguage() {
  const words = copy[settings.language] || copy.id;
  document.documentElement.lang = settings.language === 'id' ? 'id' : 'en';
  document.querySelectorAll('[data-i18n]').forEach(node => {
    const key = node.dataset.i18n;
    if (words[key]) node.textContent = words[key];
  });
}
function exportSaveBackup() {
  const payload = {
    format: 'the-abyssal-save-backup',
    schemaVersion: 1,
    exportedAt: new Date().toISOString(),
    slots: slots,
    settings: settings
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `the-abyssal-backup-${new Date().toISOString().slice(0,10)}.json`;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
  showToast('Backup lima slot dibuat. Simpan file JSON di Downloads.');
}

async function importSaveBackup(file) {
  if (!file || file.size > 2 * 1024 * 1024) throw new Error('File backup tidak valid atau lebih dari 2 MB.');
  const payload = JSON.parse(await file.text());
  if (payload?.format !== 'the-abyssal-save-backup' || !Array.isArray(payload.slots) || payload.slots.length !== 5) {
    throw new Error('Format backup tidak dikenali. Pilih file backup THE ABYSSAL.');
  }
  if (!window.confirm('Pulihkan lima slot dari backup? Data slot yang sekarang akan diganti.')) return;
  slots = payload.slots.map(record => record && typeof record === 'object' ? record : null);
  saveJson(STORAGE.slots, slots);
  if (payload.settings && typeof payload.settings === 'object') {
    settings = { ...defaults, ...payload.settings };
    saveJson(STORAGE.settings, settings);
    syncSettingsInputs();
    applySettings();
    applyLanguage();
  }
  renderSlotCards('load-slots', 'load');
  showToast('Backup berhasil dipulihkan ke lima slot lokal.');
}

function syncSettingsInputs() {
  $('graphics-select').value = settings.graphics;
  $('render-select').value = String(settings.renderDistance);
  $('volume-range').value = String(settings.volume);
  $('volume-value').textContent = `${settings.volume}%`;
  $('fov-range').value = String(settings.fov);
  $('fov-value').textContent = `${settings.fov}°`;
  $('language-select').value = settings.language;
}
function applySettings() {
  if (!rendererReady) return;
  const pixelCap = settings.graphics === 'high' ? 1.5 : settings.graphics === 'low' ? 0.85 : 1.15;
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, pixelCap));
  renderer.shadowMap.enabled = settings.graphics === 'high';
  const viewport = getGameViewportSize();
  renderer.setSize(viewport.width, viewport.height, false);
  camera.fov = Number(settings.fov);
  camera.aspect = viewport.width / viewport.height;
  camera.updateProjectionMatrix();
  updateAmbientVolume();
  if (scene) scene.fog.density = settings.graphics === 'low' ? 0.0029 : settings.graphics === 'high' ? 0.00175 : 0.00225;
  updateChunks(true);
  faunaDirector?.setQuality(settings.graphics);
  saveJson(STORAGE.settings, settings);
}
function openSettings(from = 'main') {
  settingsReturn = from;
  syncSettingsInputs();
  setVisibleScreen('settings');
  applyLanguage();
}
function closeSettings() {
  if (settingsReturn === 'pause' && gameActive) setVisibleScreen('pause');
  else setVisibleScreen('main');
}
function updateNetworkLabels() {
  const connected = navigator.onLine;
  const room = online.room;
  $('network-label').textContent = !connected ? 'OFFLINE • LOCAL SESSION' : room ? `ONLINE • MULTIPLAYER · ${online.roomRole.toUpperCase()}` : online.isSignedIn() ? 'ONLINE • CLOUD SAVE' : 'ONLINE • GUEST';
  $('hud-network').textContent = !connected ? 'OFFLINE' : room ? 'MULTI' : online.isSignedIn() ? 'CLOUD' : 'ONLINE';
  $('hud-network').style.color = connected ? '#a6f0d8' : '#ffd08b';
}

function hash2(x, z) {
  const v = Math.sin(x * 127.1 + z * 311.7 + WORLD_SEED) * 43758.5453123;
  return v - Math.floor(v);
}
function valueNoise(x, z) {
  const ix = Math.floor(x), iz = Math.floor(z);
  const fx = x - ix, fz = z - iz;
  const sx = fx * fx * (3 - 2 * fx), sz = fz * fz * (3 - 2 * fz);
  const a = hash2(ix, iz), b = hash2(ix + 1, iz), c = hash2(ix, iz + 1), d = hash2(ix + 1, iz + 1);
  return lerp(lerp(a, b, sx), lerp(c, d, sx), sz) * 2 - 1;
}
function islandData(ix, iz) {
  const spacing = 280;
  if (ix === 0 && iz === 0) return { x: islandOfInterest.x, z: islandOfInterest.z, radius: 88, height: 27 };
  const rx = hash2(ix + 39, iz - 7);
  const rz = hash2(ix - 15, iz + 61);
  return {
    x: ix * spacing + (rx - 0.5) * 92,
    z: iz * spacing + (rz - 0.5) * 92,
    radius: 54 + hash2(ix + 7, iz + 91) * 34,
    height: 15 + hash2(ix - 55, iz + 8) * 18
  };
}
function heightAt(x, z) {
  const seaFloor = -43 + valueNoise(x * 0.017, z * 0.017) * 6.5 + valueNoise(x * 0.061, z * 0.061) * 1.8;
  const gx = Math.round(x / 280), gz = Math.round(z / 280);
  let height = seaFloor;
  for (let ix = gx - 1; ix <= gx + 1; ix++) {
    for (let iz = gz - 1; iz <= gz + 1; iz++) {
      const island = islandData(ix, iz);
      const dx = (x - island.x) / island.radius;
      const dz = (z - island.z) / (island.radius * (0.78 + hash2(ix + 8, iz + 3) * 0.36));
      const q = Math.sqrt(dx * dx + dz * dz);
      const blend = smoothstep(1.13, 0.86, q);
      if (blend > 0) {
        const hill = 2.4 + Math.pow(Math.max(0, 1 - q), 0.66) * island.height + valueNoise(x * 0.1, z * 0.1) * 2.3;
        height = Math.max(height, lerp(seaFloor, hill, blend));
      }
    }
  }
  return height;
}

function makeProceduralTexture(kind = 'stone', size = 128) {
  const canvasTexture = document.createElement('canvas');
  canvasTexture.width = canvasTexture.height = size;
  const ctx = canvasTexture.getContext('2d', { willReadFrequently: true });
  const image = ctx.createImageData(size, size);
  const palettes = {
    sand: [174, 153, 112], stone: [89, 116, 124], kelp: [40, 104, 82], coral: [158, 108, 135], wood: [104, 72, 48], metal: [75, 111, 119]
  };
  const base = palettes[kind] || palettes.stone;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = (y * size + x) * 4;
      const wave = Math.sin(x * 0.19 + Math.sin(y * 0.11) * 2) * 4 + Math.cos(y * 0.17) * 3;
      const grit = (Math.random() - 0.5) * (kind === 'sand' ? 48 : 34);
      const n = wave + grit;
      image.data[i] = clamp(base[0] + n, 0, 255);
      image.data[i + 1] = clamp(base[1] + n, 0, 255);
      image.data[i + 2] = clamp(base[2] + n, 0, 255);
      image.data[i + 3] = 255;
    }
  }
  ctx.putImageData(image, 0, 0);
  if (kind === 'wood') {
    ctx.strokeStyle = 'rgba(32,18,10,.22)'; ctx.lineWidth = 2;
    for (let y = 8; y < size; y += 18) { ctx.beginPath(); ctx.moveTo(0, y); ctx.bezierCurveTo(38, y - 5, 82, y + 5, size, y - 2); ctx.stroke(); }
  } else if (kind === 'coral') {
    ctx.strokeStyle = 'rgba(255,220,235,.12)'; ctx.lineWidth = 3;
    for (let i = 0; i < 9; i++) { ctx.beginPath(); ctx.arc((i * 37) % size, (i * 61) % size, 8 + i % 5 * 3, 0, Math.PI * 2); ctx.stroke(); }
  }
  const texture = new THREE.CanvasTexture(canvasTexture);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  texture.generateMipmaps = true;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.magFilter = THREE.LinearFilter;
  return texture;
}

function makeFirstPersonViewModel() {
  viewModel = new THREE.Group();
  const suit = new THREE.MeshStandardMaterial({ color: 0xd7e5df, roughness: 0.72, metalness: 0.12 });
  const glove = new THREE.MeshStandardMaterial({ color: 0x173b48, roughness: 0.52, metalness: 0.2 });
  const orange = new THREE.MeshStandardMaterial({ color: 0xd88c48, roughness: 0.56, metalness: 0.15 });
  const left = new THREE.Group();
  const right = new THREE.Group();
  const armGeo = new THREE.CapsuleGeometry(0.105, 0.38, 3, 7);
  const handGeo = new THREE.SphereGeometry(0.13, 10, 8);
  const armL = new THREE.Mesh(armGeo, suit), armR = new THREE.Mesh(armGeo, suit);
  armL.rotation.x = 0.45; armR.rotation.x = 0.45;
  armL.position.set(-0.48, -0.12, -0.52); armR.position.set(0.48, -0.12, -0.52);
  const handL = new THREE.Mesh(handGeo, glove), handR = new THREE.Mesh(handGeo, glove);
  handL.position.set(-0.48, -0.29, -0.64); handR.position.set(0.48, -0.29, -0.64);
  left.add(armL, handL); right.add(armR, handR);
  const scanner = new THREE.Group();
  const body = new THREE.BoxGeometry(0.18, 0.13, 0.42);
  const scannerBody = new THREE.Mesh(body, glove);
  scannerBody.position.set(0.57, -0.26, -0.88);
  scanner.add(scannerBody);
  const screen = new THREE.Mesh(new THREE.BoxGeometry(0.135, 0.012, 0.17), new THREE.MeshBasicMaterial({ color: 0x66e4df }));
  screen.position.set(0.57, -0.185, -0.84); scanner.add(screen);
  const lens = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.055, 0.05, 12), orange);
  lens.rotation.x = Math.PI / 2; lens.position.set(0.57, -0.25, -1.1); scanner.add(lens);
  viewModel.add(left, right, scanner);
  viewModel.position.set(0, 0, 0);
  viewModel.frustumCulled = false;
  camera.add(viewModel);
  viewModel.userData.left = left; viewModel.userData.right = right;
}

function makePlayer() {
  playerGroup = new THREE.Group();
  const suit = new THREE.MeshStandardMaterial({ color: 0xe0ded2, roughness: 0.82, metalness: 0.08 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x183f4d, roughness: 0.8 });
  const glass = new THREE.MeshStandardMaterial({ color: 0x5ed6df, roughness: 0.18, metalness: 0.35, transparent: true, opacity: 0.78 });
  const orange = new THREE.MeshStandardMaterial({ color: 0xd18b49, roughness: 0.7 });
  playerBody = new THREE.Group();
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.72, 1.25, 4, 8), suit);
  torso.rotation.x = Math.PI / 2;
  torso.position.y = 0.1;
  playerBody.add(torso);
  const chest = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.52, 0.28), dark);
  chest.position.set(0, 0.22, -0.55);
  playerBody.add(chest);
  const helmet = new THREE.Mesh(new THREE.SphereGeometry(0.55, 12, 9), suit);
  helmet.position.set(0, 1.24, -0.05);
  playerBody.add(helmet);
  const visor = new THREE.Mesh(new THREE.SphereGeometry(0.38, 12, 8), glass);
  visor.scale.set(1.08, 0.72, 0.55);
  visor.position.set(0, 1.26, -0.44);
  playerBody.add(visor);
  const tank = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.32, 1.4, 8), orange);
  tank.position.set(0, 0.16, 0.62);
  playerBody.add(tank);
  const armGeo = new THREE.CapsuleGeometry(0.19, 0.72, 3, 6);
  leftArm = new THREE.Group();
  rightArm = new THREE.Group();
  const armL = new THREE.Mesh(armGeo, suit), armR = new THREE.Mesh(armGeo, suit);
  armL.position.y = -0.39; armR.position.y = -0.39;
  leftArm.add(armL); rightArm.add(armR);
  leftArm.position.set(-0.78, 0.42, -0.1); rightArm.position.set(0.78, 0.42, -0.1);
  playerBody.add(leftArm, rightArm);
  const legGeo = new THREE.CapsuleGeometry(0.23, 0.75, 3, 6);
  const legL = new THREE.Mesh(legGeo, dark), legR = new THREE.Mesh(legGeo, dark);
  legL.position.set(-0.3, -0.92, 0.03); legR.position.set(0.3, -0.92, 0.03);
  playerBody.add(legL, legR);
  const finGeo = new THREE.BoxGeometry(0.32, 0.13, 0.83);
  leftFin = new THREE.Mesh(finGeo, orange); rightFin = new THREE.Mesh(finGeo, orange);
  leftFin.position.set(-0.3, -1.45, -0.38); rightFin.position.set(0.3, -1.45, -0.38);
  playerBody.add(leftFin, rightFin);
  playerGroup.add(playerBody);
  playerGroup.scale.setScalar(0.86);
  scene.add(playerGroup);
}

function makePalm(group, localX, localZ, baseY, scale = 1) {
  const trunkMaterial = new THREE.MeshStandardMaterial({ color: 0x77583b, roughness: 1 });
  const leafMaterial = new THREE.MeshStandardMaterial({ color: 0x2d755e, roughness: 0.9, flatShading: true });
  const palm = new THREE.Group();
  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.42, 6.2, 6), trunkMaterial);
  trunk.position.y = 3.1;
  palm.add(trunk);
  for (let i = 0; i < 7; i++) {
    const leaf = new THREE.Mesh(new THREE.ConeGeometry(0.48, 4.6, 5), leafMaterial);
    const angle = (i / 7) * Math.PI * 2;
    leaf.position.set(Math.cos(angle) * 1.2, 6.0, Math.sin(angle) * 1.2);
    leaf.rotation.z = Math.cos(angle) * 0.92;
    leaf.rotation.x = Math.sin(angle) * 0.92;
    leaf.rotation.y = angle;
    palm.add(leaf);
  }
  palm.position.set(localX, baseY, localZ);
  palm.scale.setScalar(scale);
  group.add(palm);
}

function makeWreck(group, baseX, baseZ) {
  const wreck = new THREE.Group();
  const hullMat = new THREE.MeshStandardMaterial({ color: 0x684934, roughness: 1, flatShading: true });
  const plankMat = new THREE.MeshStandardMaterial({ color: 0x947052, roughness: 1 });
  const metalMat = new THREE.MeshStandardMaterial({ color: 0x314b51, metalness: 0.5, roughness: 0.8 });
  const hull = new THREE.Mesh(new THREE.BoxGeometry(30, 6, 8), hullMat);
  hull.scale.set(1, 0.82, 1);
  wreck.add(hull);
  const bow = new THREE.Mesh(new THREE.ConeGeometry(4.2, 8, 4), hullMat);
  bow.rotation.z = Math.PI / 2;
  bow.rotation.y = Math.PI / 4;
  bow.position.x = 17.5;
  wreck.add(bow);
  const deck = new THREE.Mesh(new THREE.BoxGeometry(23, 0.65, 7.3), plankMat);
  deck.position.y = 3.1;
  wreck.add(deck);
  const cabin = new THREE.Mesh(new THREE.BoxGeometry(7, 4.3, 5.2), plankMat);
  cabin.position.set(-4, 5.4, 0);
  cabin.rotation.z = -0.12;
  wreck.add(cabin);
  const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.38, 15, 6), metalMat);
  mast.position.set(6, 9.5, 0);
  mast.rotation.z = 0.28;
  wreck.add(mast);
  const beam = new THREE.Mesh(new THREE.BoxGeometry(10, 0.28, 0.28), metalMat);
  beam.position.set(5.5, 11.8, 0);
  beam.rotation.z = 0.23;
  wreck.add(beam);
  const brokenPlank = new THREE.Mesh(new THREE.BoxGeometry(10, 0.45, 0.5), plankMat);
  brokenPlank.position.set(-12, 5.2, 5.4);
  brokenPlank.rotation.z = 0.4;
  wreck.add(brokenPlank);
  const beacon = new THREE.PointLight(0x63e0d6, 1.4, 28);
  beacon.position.set(-5, 7, 0);
  wreck.add(beacon);
  wreck.position.set(shipOfInterest.x - baseX, -37, shipOfInterest.z - baseZ);
  wreck.rotation.y = 0.72;
  wreck.rotation.z = 0.035;
  wreck.scale.setScalar(1.05);
  group.add(wreck);
}

function makeSupplyCache(group, cache, baseX, baseZ) {
  const crate = new THREE.Group();
  const hull = new THREE.MeshStandardMaterial({ color: 0x315e66, roughness: 0.72, metalness: 0.25 });
  const trim = new THREE.MeshStandardMaterial({ color: 0xd2a967, roughness: 0.52, metalness: 0.58 });
  const glow = new THREE.MeshStandardMaterial({ color: 0x79e8df, emissive: 0x168b91, emissiveIntensity: 1.1 });
  const body = new THREE.Mesh(new THREE.BoxGeometry(2.8, 1.45, 2.0), hull);
  crate.add(body);
  const lid = new THREE.Mesh(new THREE.BoxGeometry(2.94, 0.24, 2.12), trim);
  lid.position.y = 0.84;
  crate.add(lid);
  for (const side of [-1, 1]) {
    const band = new THREE.Mesh(new THREE.BoxGeometry(0.16, 1.58, 2.16), trim);
    band.position.x = side * 0.82;
    crate.add(band);
  }
  const beacon = new THREE.Mesh(new THREE.SphereGeometry(0.2, 8, 6), glow);
  beacon.position.set(0, 1.12, 0);
  crate.add(beacon);
  const lamp = new THREE.PointLight(0x61e5dc, 0.9, 16);
  lamp.position.set(0, 1.4, 0);
  crate.add(lamp);
  crate.position.set(cache.x - baseX, cache.y, cache.z - baseZ);
  crate.rotation.y = cache.id === 'wreck_cache' ? 0.4 : -0.3;
  group.add(crate);
}

function makeResourceNode(group, cx, cz, index, localX, localZ, groundY, type) {
  const id = `${cx}:${cz}:ore:${index}`;
  if (collectedResources.has(id)) return;
  const colors = { titanium: 0x9fb2b7, copper: 0xc47b4b, quartz: 0xb8eff0, kelp: 0x53be94, coral: 0xd47eae };
  const material = new THREE.MeshStandardMaterial({ color: colors[type], roughness: 0.42, metalness: type === 'titanium' || type === 'copper' ? 0.58 : 0.12, emissive: colors[type], emissiveIntensity: type === 'quartz' ? 0.22 : 0.06, map: type === 'coral' ? coralTexture : rockTexture });
  const node = new THREE.Group();
  const size = type === 'kelp' ? 0.9 : 0.65;
  const geo = type === 'kelp' ? new THREE.ConeGeometry(0.45, 2.6, 5) : new THREE.IcosahedronGeometry(size, 1);
  const mesh = new THREE.Mesh(geo, material);
  mesh.position.y = type === 'kelp' ? 1 : 0.55;
  mesh.rotation.set(0.12, hash2(cx + index, cz - index) * Math.PI, 0.12);
  node.add(mesh);
  const glow = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 6), new THREE.MeshBasicMaterial({ color: colors[type], transparent: true, opacity: 0.72 }));
  glow.position.set(0, type === 'kelp' ? 2.5 : 1.25, 0); node.add(glow);
  node.position.set(localX, groundY, localZ);
  node.userData.resourceId = id;
  node.userData.resourceType = type;
  node.userData.chunkKey = `${cx},${cz}`;
  group.add(node);
  resourceNodes.set(id, { mesh: node, type, chunkKey: `${cx},${cz}` });
}

function addBuiltStructure(group, structure, baseX, baseZ) {
  const root = new THREE.Group();
  const dark = new THREE.MeshStandardMaterial({ color: 0x183d4b, roughness: 0.5, metalness: 0.62, map: metalTexture });
  const glass = new THREE.MeshStandardMaterial({ color: 0x76d7dc, roughness: 0.18, metalness: 0.12, transparent: true, opacity: 0.32 });
  const glow = new THREE.MeshStandardMaterial({ color: 0x74f0e4, emissive: 0x168c8b, emissiveIntensity: 1.4 });
  if (structure.type === 'beacon') {
    const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.2, 2.5, 8), dark); mast.position.y = 1.2; root.add(mast);
    const orb = new THREE.Mesh(new THREE.SphereGeometry(0.28, 12, 8), glow); orb.position.y = 2.55; root.add(orb);
    const light = new THREE.PointLight(0x65e9df, 1.5, 25); light.position.y = 2.6; root.add(light);
  } else if (structure.type === 'foundation') {
    const base = new THREE.Mesh(new THREE.CylinderGeometry(3.4, 3.65, 0.42, 12), dark); base.position.y = 0.22; root.add(base);
    const rim = new THREE.Mesh(new THREE.TorusGeometry(3.1, 0.09, 6, 20), glow); rim.rotation.x = Math.PI / 2; rim.position.y = 0.48; root.add(rim);
  } else if (structure.type === 'compartment') {
    const shell = new THREE.Mesh(new THREE.CylinderGeometry(2.2, 2.2, 4.2, 12, 1, true), glass); shell.rotation.z = Math.PI / 2; shell.position.y = 2.2; root.add(shell);
    const ring1 = new THREE.Mesh(new THREE.TorusGeometry(2.2, 0.14, 8, 16), dark); ring1.rotation.y = Math.PI / 2; ring1.position.set(-2.1, 2.2, 0); root.add(ring1);
    const ring2 = ring1.clone(); ring2.position.x = 2.1; root.add(ring2);
    const lamp = new THREE.PointLight(0x5ccbd4, 0.8, 12); lamp.position.y = 3.6; root.add(lamp);
  }
  root.position.set(structure.x - baseX, structure.y, structure.z - baseZ);
  root.rotation.y = Number(structure.yaw) || 0;
  root.userData.structureId = structure.id;
  group.add(root);
}

function makeChunk(cx, cz) {
  const baseX = cx * CHUNK_SIZE, baseZ = cz * CHUNK_SIZE;
  const group = new THREE.Group();
  group.position.set(baseX, 0, baseZ);
  const segments = 16;
  const positions = [], colors = [], indices = [], uvs = [];
  const deep = new THREE.Color(0x0b3448), mid = new THREE.Color(0x286a78), sand = new THREE.Color(0xc1ad7c);
  const grass = new THREE.Color(0x527d63), rock = new THREE.Color(0x77796b);
  const color = new THREE.Color();
  for (let z = 0; z <= segments; z++) {
    for (let x = 0; x <= segments; x++) {
      const wx = baseX + (x / segments) * CHUNK_SIZE;
      const wz = baseZ + (z / segments) * CHUNK_SIZE;
      const h = heightAt(wx, wz);
      positions.push((x / segments) * CHUNK_SIZE, h, (z / segments) * CHUNK_SIZE);
      uvs.push((x / segments) * 5, (z / segments) * 5);
      if (h < -24) color.copy(deep).lerp(mid, clamp((h + 44) / 20, 0, 1));
      else if (h < -2) color.copy(mid).lerp(sand, clamp((h + 24) / 22, 0, 1));
      else if (h < 13) color.copy(sand).lerp(grass, clamp((h + 2) / 15, 0, 1));
      else color.copy(grass).lerp(rock, clamp((h - 13) / 17, 0, 1));
      const variation = 0.92 + (valueNoise(wx * 0.09, wz * 0.09) + 1) * 0.06;
      colors.push(color.r * variation, color.g * variation, color.b * variation);
    }
  }
  for (let z = 0; z < segments; z++) {
    for (let x = 0; x < segments; x++) {
      const a = z * (segments + 1) + x;
      const b = a + 1, c = a + segments + 1, d = c + 1;
      indices.push(a, c, b, b, c, d);
    }
  }
  const terrainGeometry = new THREE.BufferGeometry();
  terrainGeometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  terrainGeometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  terrainGeometry.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  terrainGeometry.setIndex(indices);
  terrainGeometry.computeVertexNormals();
  const terrain = new THREE.Mesh(terrainGeometry, terrainMaterial);
  terrain.frustumCulled = true;
  terrain.userData.chunkTerrain = true;
  group.add(terrain);

  // Small instanced seafloor details keep draw calls low as chunks stream in and out.
  const randoms = [];
  for (let i = 0; i < 20; i++) randoms.push(hash2(cx * 101 + i * 13, cz * 103 - i * 7));
  const rocks = new THREE.InstancedMesh(rockGeometry, rockMaterial, 12);
  const kelp = new THREE.InstancedMesh(kelpGeometry, kelpMaterial, 10);
  const coral = new THREE.InstancedMesh(coralGeometry, coralMaterial, 12);
  const coralPalette = [new THREE.Color(0xd27671), new THREE.Color(0x9c7bce), new THREE.Color(0xe0ad65), new THREE.Color(0x5eafa5)];
  const dummy = new THREE.Object3D();
  let rockCount = 0, kelpCount = 0, coralCount = 0;
  for (let i = 0; i < 12; i++) {
    const wx = baseX + randoms[i] * CHUNK_SIZE;
    const wz = baseZ + randoms[(i + 6) % randoms.length] * CHUNK_SIZE;
    const h = heightAt(wx, wz);
    if (h > -4) continue;
    const s = 0.45 + randoms[(i + 3) % 20] * 1.2;
    dummy.position.set(wx - baseX, h + s * 0.45, wz - baseZ);
    dummy.rotation.set(randoms[(i + 2) % 20], randoms[(i + 7) % 20] * Math.PI, 0.2);
    dummy.scale.set(s, s * (0.7 + randoms[(i + 9) % 20]), s);
    dummy.updateMatrix();
    rocks.setMatrixAt(rockCount++, dummy.matrix);
  }
  rocks.count = rockCount;
  rocks.instanceMatrix.needsUpdate = true;
  if (rockCount) group.add(rocks);
  for (let i = 0; i < 10; i++) {
    const wx = baseX + randoms[(i + 4) % 20] * CHUNK_SIZE;
    const wz = baseZ + randoms[(i + 12) % 20] * CHUNK_SIZE;
    const h = heightAt(wx, wz);
    if (h > -7 || randoms[i] < 0.25) continue;
    const s = 0.6 + randoms[(i + 8) % 20] * 0.9;
    dummy.position.set(wx - baseX, h + 2 * s, wz - baseZ);
    dummy.rotation.set(0, randoms[(i + 2) % 20] * 6, (randoms[(i + 5) % 20] - 0.5) * 0.25);
    dummy.scale.set(s, s, s);
    dummy.updateMatrix();
    kelp.setMatrixAt(kelpCount++, dummy.matrix);
  }
  kelp.count = kelpCount;
  kelp.instanceMatrix.needsUpdate = true;
  if (kelpCount) group.add(kelp);
  for (let i = 0; i < 12; i++) {
    const wx = baseX + randoms[(i + 2) % 20] * CHUNK_SIZE;
    const wz = baseZ + randoms[(i + 11) % 20] * CHUNK_SIZE;
    const h = heightAt(wx, wz);
    if (h > -7 || randoms[(i + 5) % 20] < 0.32) continue;
    const scale = 0.45 + randoms[(i + 9) % 20] * 0.85;
    dummy.position.set(wx - baseX, h + scale * 0.82, wz - baseZ);
    dummy.rotation.set(0, randoms[(i + 7) % 20] * Math.PI * 2, (randoms[(i + 3) % 20] - 0.5) * 0.28);
    dummy.scale.set(scale * 0.78, scale, scale * 0.78);
    dummy.updateMatrix();
    coral.setMatrixAt(coralCount, dummy.matrix);
    coral.setColorAt(coralCount, coralPalette[Math.floor(randoms[(i + 14) % 20] * coralPalette.length)]);
    coralCount++;
  }
  coral.count = coralCount;
  coral.instanceMatrix.needsUpdate = true;
  if (coral.instanceColor) coral.instanceColor.needsUpdate = true;
  if (coralCount) group.add(coral);

  // Palm trees are only created for island centers inside this streamed chunk.
  const minIslandX = Math.floor((baseX - 100) / 280), maxIslandX = Math.floor((baseX + CHUNK_SIZE + 100) / 280);
  const minIslandZ = Math.floor((baseZ - 100) / 280), maxIslandZ = Math.floor((baseZ + CHUNK_SIZE + 100) / 280);
  for (let ix = minIslandX; ix <= maxIslandX; ix++) {
    for (let iz = minIslandZ; iz <= maxIslandZ; iz++) {
      const island = islandData(ix, iz);
      if (island.x < baseX || island.x >= baseX + CHUNK_SIZE || island.z < baseZ || island.z >= baseZ + CHUNK_SIZE) continue;
      const treeCount = 2 + Math.floor(hash2(ix + 5, iz + 2) * 3);
      for (let t = 0; t < treeCount; t++) {
        const angle = hash2(ix * 13 + t, iz * 9 - t) * Math.PI * 2;
        const radius = island.radius * (0.18 + hash2(ix + t * 7, iz + t * 5) * 0.34);
        const tx = island.x + Math.cos(angle) * radius;
        const tz = island.z + Math.sin(angle) * radius;
        const th = heightAt(tx, tz);
        if (th > 3) makePalm(group, tx - baseX, tz - baseZ, th, 0.72 + hash2(t + ix, iz - t) * 0.5);
      }
    }
  }
  if (Math.floor(shipOfInterest.x / CHUNK_SIZE) === cx && Math.floor(shipOfInterest.z / CHUNK_SIZE) === cz) makeWreck(group, baseX, baseZ);
  for (const cache of supplyCacheLocations) {
    if (Math.floor(cache.x / CHUNK_SIZE) === cx && Math.floor(cache.z / CHUNK_SIZE) === cz) makeSupplyCache(group, cache, baseX, baseZ);
  }
  // Deterministic mineral and flora nodes are streamed with their terrain chunk.
  const resourceTypes = ['titanium', 'copper', 'quartz', 'kelp', 'coral'];
  for (let i = 0; i < 3; i++) {
    const rx = hash2(cx * 17 + i * 23, cz * 19 - i * 11);
    const rz = hash2(cx * 29 - i * 7, cz * 31 + i * 13);
    const wx = baseX + 5 + rx * (CHUNK_SIZE - 10);
    const wz = baseZ + 5 + rz * (CHUNK_SIZE - 10);
    const ground = heightAt(wx, wz);
    if (ground < -8) makeResourceNode(group, cx, cz, i, wx - baseX, wz - baseZ, ground + 0.1, resourceTypes[Math.floor(hash2(cx + i, cz - i) * resourceTypes.length)]);
  }
  for (const structure of placedStructures) {
    if (Math.floor(structure.x / CHUNK_SIZE) === cx && Math.floor(structure.z / CHUNK_SIZE) === cz) addBuiltStructure(group, structure, baseX, baseZ);
  }
  scene.add(group);
  chunks.set(`${cx},${cz}`, { group, terrainGeometry, cx, cz });
}

function disposeChunk(chunk) {
  scene.remove(chunk.group);
  for (const [id, node] of resourceNodes) if (node.chunkKey === `${chunk.cx},${chunk.cz}`) resourceNodes.delete(id);
  const sharedGeometries = new Set([rockGeometry, kelpGeometry, coralGeometry]);
  const sharedMaterials = new Set([terrainMaterial, rockMaterial, kelpMaterial, coralMaterial]);
  const disposedGeometries = new Set();
  const disposedMaterials = new Set();
  chunk.group.traverse(object => {
    if (!object.isMesh && !object.isInstancedMesh) return;
    if (object.geometry && object.geometry !== chunk.terrainGeometry && !sharedGeometries.has(object.geometry) && !disposedGeometries.has(object.geometry)) {
      object.geometry.dispose();
      disposedGeometries.add(object.geometry);
    }
    const materials = Array.isArray(object.material) ? object.material : [object.material];
    for (const material of materials) if (material && !sharedMaterials.has(material) && !disposedMaterials.has(material)) {
      material.dispose();
      disposedMaterials.add(material);
    }
  });
  chunk.terrainGeometry.dispose();
}

function updateChunks(force = false) {
  if (!scene || !gameActive && !rendererReady) return;
  const cx = Math.floor(player.position.x / CHUNK_SIZE);
  const cz = Math.floor(player.position.z / CHUNK_SIZE);
  if (!force && cx === chunkCenterX && cz === chunkCenterZ) return;
  chunkCenterX = cx; chunkCenterZ = cz;
  const radius = clamp(Number(settings.renderDistance) || 2, 1, 3);
  for (let z = cz - radius; z <= cz + radius; z++) {
    for (let x = cx - radius; x <= cx + radius; x++) {
      const key = `${x},${z}`;
      if (!chunks.has(key)) makeChunk(x, z);
    }
  }
  for (const [key, chunk] of chunks) {
    if (Math.abs(chunk.cx - cx) > radius || Math.abs(chunk.cz - cz) > radius) {
      disposeChunk(chunk);
      chunks.delete(key);
    }
  }
  if ($('chunk-label')) $('chunk-label').textContent = String(chunks.size);
}

function makeWaterAndParticles() {
  const waterGeometry = new THREE.PlaneGeometry(1900, 1900, 52, 52);
  const waterMaterial = new THREE.MeshBasicMaterial({ color: 0x247f91, transparent: true, opacity: 0.2, depthWrite: false, side: THREE.DoubleSide, map: terrainTexture });
  water = new THREE.Mesh(waterGeometry, waterMaterial);
  water.rotation.x = -Math.PI / 2;
  water.position.y = 0;
  water.renderOrder = 2;
  scene.add(water);

  const particlePositions = [];
  for (let i = 0; i < 260; i++) particlePositions.push((Math.random() - 0.5) * 190, (Math.random() - 0.5) * 70, (Math.random() - 0.5) * 190);
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(particlePositions, 3));
  const mat = new THREE.PointsMaterial({ color: 0xc2f5f3, size: 0.32, transparent: true, opacity: 0.54, depthWrite: false, sizeAttenuation: true });
  particleGroup = new THREE.Group();
  particleGroup.add(new THREE.Points(geo, mat));
  scene.add(particleGroup);

  // Soft underwater god-rays: lightweight textured planes, not expensive volumetric fog.
  lightRayGroup = new THREE.Group();
  const rayCanvas = document.createElement('canvas'); rayCanvas.width = 32; rayCanvas.height = 256;
  const rayCtx = rayCanvas.getContext('2d');
  const gradient = rayCtx.createLinearGradient(0, 0, 0, 256);
  gradient.addColorStop(0, 'rgba(146,244,239,0.34)');
  gradient.addColorStop(0.35, 'rgba(100,211,221,0.13)');
  gradient.addColorStop(1, 'rgba(66,177,196,0)');
  rayCtx.fillStyle = gradient; rayCtx.fillRect(0, 0, 32, 256);
  const rayTexture = new THREE.CanvasTexture(rayCanvas); rayTexture.colorSpace = THREE.SRGBColorSpace;
  const rayMaterial = new THREE.MeshBasicMaterial({ map: rayTexture, color: 0xc4ffff, transparent: true, opacity: 0.62, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide });
  for (let i = 0; i < 7; i++) {
    const ray = new THREE.Mesh(new THREE.PlaneGeometry(3.5 + (i % 3) * 1.5, 42), rayMaterial);
    const angle = i / 7 * Math.PI * 2;
    ray.position.set(Math.cos(angle) * (10 + i * 1.1), -16, Math.sin(angle) * (10 + i * 1.1));
    ray.rotation.y = angle * 0.37;
    lightRayGroup.add(ray);
  }
  scene.add(lightRayGroup);
}

function createWorld() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x0b3446);
  scene.fog = new THREE.FogExp2(0x0b4051, 0.00195);
  const viewport = getGameViewportSize();
  camera = new THREE.PerspectiveCamera(settings.fov, viewport.width / viewport.height, 0.08, 1300);
  camera.position.set(0, -2.5, 11);
  renderer = new THREE.WebGLRenderer({ canvas, antialias: settings.graphics !== 'low', alpha: false, powerPreference: 'high-performance', stencil: false, depth: true });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.2;
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, settings.graphics === 'high' ? 1.5 : settings.graphics === 'low' ? 0.8 : 1.05));
  renderer.setSize(viewport.width, viewport.height, false);
  rendererReady = true;

  const hemi = new THREE.HemisphereLight(0xb8f2f2, 0x071b2a, 1.9);
  scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xb9f7f0, 1.65);
  sun.position.set(-60, 110, 40);
  scene.add(sun);
  const fill = new THREE.PointLight(0x287f9e, 1.5, 220);
  fill.position.set(20, -10, 20); scene.add(fill);
  const rim = new THREE.PointLight(0x56c7c6, 0.85, 90); rim.position.set(-32, -22, -28); scene.add(rim);

  terrainTexture = makeProceduralTexture('sand'); terrainTexture.repeat.set(3, 3);
  rockTexture = makeProceduralTexture('stone'); rockTexture.repeat.set(1.3, 1.3);
  kelpTexture = makeProceduralTexture('kelp'); kelpTexture.repeat.set(1, 2);
  coralTexture = makeProceduralTexture('coral'); coralTexture.repeat.set(1, 1);
  woodTexture = makeProceduralTexture('wood'); woodTexture.repeat.set(2, 1);
  metalTexture = makeProceduralTexture('metal'); metalTexture.repeat.set(1, 1);
  terrainMaterial = new THREE.MeshStandardMaterial({ vertexColors: true, map: terrainTexture, roughness: 0.98, metalness: 0.01, side: THREE.DoubleSide, flatShading: false });
  rockGeometry = new THREE.DodecahedronGeometry(1.5, 1);
  rockMaterial = new THREE.MeshStandardMaterial({ color: 0x91aeb1, map: rockTexture, roughness: 0.96, flatShading: true });
  kelpGeometry = new THREE.ConeGeometry(0.62, 4.2, 7);
  kelpMaterial = new THREE.MeshStandardMaterial({ color: 0x5ab995, map: kelpTexture, roughness: 0.88, flatShading: true, side: THREE.DoubleSide });
  coralGeometry = new THREE.ConeGeometry(0.72, 2.1, 7);
  coralMaterial = new THREE.MeshStandardMaterial({ color: 0xffffff, map: coralTexture, roughness: 0.92, flatShading: true });
  makeWaterAndParticles();
  makePlayer();
  playerGroup.visible = false; // First-person only; no third-person diver model.
  makeFirstPersonViewModel();
  faunaDirector = new FaunaDirector(scene, applyDamage);
  faunaDirector.setQuality(settings.graphics);
  updateChunks(true);
  applySettings();
}

function startAmbient() {
  if (ambientContext) return;
  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  if (!AudioCtx) return;
  try {
    ambientContext = new AudioCtx();
    const osc = ambientContext.createOscillator();
    const filter = ambientContext.createBiquadFilter();
    ambientGain = ambientContext.createGain();
    osc.type = 'sine'; osc.frequency.value = 58;
    filter.type = 'lowpass'; filter.frequency.value = 130;
    ambientGain.gain.value = 0;
    osc.connect(filter); filter.connect(ambientGain); ambientGain.connect(ambientContext.destination);
    osc.start();
    const drone2 = ambientContext.createOscillator();
    const drone2Gain = ambientContext.createGain();
    drone2.type = 'triangle'; drone2.frequency.value = 87; drone2Gain.gain.value = 0.12;
    drone2.connect(drone2Gain); drone2Gain.connect(ambientGain); drone2.start();
    const lfo = ambientContext.createOscillator();
    const lfoGain = ambientContext.createGain();
    lfo.type = 'sine'; lfo.frequency.value = 0.11; lfoGain.gain.value = 0.008;
    lfo.connect(lfoGain); lfoGain.connect(ambientGain.gain); lfo.start();
    const buffer = ambientContext.createBuffer(1, ambientContext.sampleRate * 2, ambientContext.sampleRate);
    const channel = buffer.getChannelData(0);
    for (let i = 0; i < channel.length; i++) channel[i] = (Math.random() * 2 - 1) * 0.16;
    const noise = ambientContext.createBufferSource();
    const noiseFilter = ambientContext.createBiquadFilter();
    soundNoiseGain = ambientContext.createGain();
    noise.buffer = buffer; noise.loop = true; noiseFilter.type = 'lowpass'; noiseFilter.frequency.value = 320;
    soundNoiseGain.gain.value = 0.012;
    noise.connect(noiseFilter); noiseFilter.connect(soundNoiseGain); soundNoiseGain.connect(ambientContext.destination); noise.start();
    updateAmbientVolume();
  } catch { ambientContext = null; }
}
function updateAmbientVolume() {
  if (ambientGain && ambientContext) {
    const target = (settings.volume / 100) * 0.035;
    ambientGain.gain.setTargetAtTime(target, ambientContext.currentTime, 0.12);
    if (soundNoiseGain) soundNoiseGain.gain.setTargetAtTime(target * 0.38, ambientContext.currentTime, 0.16);
  }
}

function playSfx(kind = 'tap') {
  if (!ambientContext) return;
  try {
    if (ambientContext.state === 'suspended') ambientContext.resume().catch(() => {});
    const now = ambientContext.currentTime;
    const presets = { collect: [620, 920], craft: [420, 680], build: [310, 520], scan: [820, 1160], damage: [120, 76], tap: [360, 440] };
    const [startHz, endHz] = presets[kind] || presets.tap;
    const osc = ambientContext.createOscillator(); const gain = ambientContext.createGain();
    osc.type = kind === 'damage' ? 'sawtooth' : 'sine';
    osc.frequency.setValueAtTime(startHz, now); osc.frequency.exponentialRampToValueAtTime(Math.max(40, endHz), now + 0.22);
    gain.gain.setValueAtTime(0.0001, now); gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, settings.volume / 100 * 0.045), now + 0.025); gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.32);
    osc.connect(gain); gain.connect(ambientContext.destination); osc.start(now); osc.stop(now + 0.34);
  } catch { /* Audio is optional; gameplay must remain functional without it. */ }
}

async function enterFullscreenLandscape() {
  try {
    if (!document.fullscreenElement && document.documentElement.requestFullscreen) await document.documentElement.requestFullscreen({ navigationUI: 'hide' });
  } catch { /* Browser or installed-app policy may refuse; the PWA manifest still requests fullscreen. */ }
  try {
    if (screen.orientation && screen.orientation.lock) await screen.orientation.lock('landscape');
  } catch { /* Native Android Activity is already locked to landscape. */ }
  try { window.scrollTo(0, 0); } catch { /* no-op */ }
}

function renderInventory() {
  const root = $('inventory-list');
  root.replaceChildren();
  for (const [key, label] of Object.entries(RESOURCE_LABELS)) {
    const row = document.createElement('div'); row.className = 'inventory-item';
    const name = document.createElement('span'); name.textContent = label;
    const count = document.createElement('strong'); count.textContent = String(inventory[key] || 0);
    row.append(name, count); root.append(row);
  }
  for (const [label, value] of [['Medkit', survival.medkits], ['Rations', survival.rations]]) {
    const row = document.createElement('div'); row.className = 'inventory-item';
    const name = document.createElement('span'); name.textContent = label;
    const count = document.createElement('strong'); count.textContent = String(value);
    row.append(name, count); root.append(row);
  }
}

function openInventory() {
  if (!gameActive) return;
  gamePaused = true;
  renderInventory();
  setVisibleScreen('inventory');
}

function closeGamePanel() {
  if (!gameActive) { setVisibleScreen('main'); return; }
  gamePaused = false;
  setVisibleScreen('hud');
  enterFullscreenLandscape();
}

function nearestResource(maxDistance = 9) {
  let best = null;
  for (const [id, node] of resourceNodes) {
    const position = node.mesh.getWorldPosition(tmpVector);
    const distance = player.position.distanceTo(position);
    if (distance < maxDistance && (!best || distance < best.distance)) best = { id, ...node, position: position.clone(), distance };
  }
  return best;
}

function updateResourcePrompt() {
  const node = nearestResource(9);
  const button = $('gather-btn');
  if (!button) return;
  button.classList.toggle('hidden', !node);
  button.dataset.resourceId = node?.id || '';
  if (node) button.textContent = `COLLECT ${RESOURCE_LABELS[node.type].toUpperCase()}`;
}

function gatherNearbyResource() {
  const id = $('gather-btn').dataset.resourceId;
  const node = resourceNodes.get(id);
  if (!node) { showToast('Tidak ada sumber daya dalam jangkauan.'); return; }
  const position = node.mesh.getWorldPosition(tmpVector);
  if (player.position.distanceTo(position) > 9.5) { showToast('Dekati sumber daya terlebih dahulu.'); return; }
  inventory[node.type] = clamp((inventory[node.type] || 0) + 1, 0, 999);
  collectedResources.add(id);
  node.mesh.parent?.remove(node.mesh);
  resourceNodes.delete(id);
  renderInventory(); updateResourcePrompt(); playSfx('collect');
  saveCurrentSlot();
  showToast(`+1 ${RESOURCE_LABELS[node.type]}`);
}

function canAfford(cost) { return Object.entries(cost).every(([key, amount]) => (inventory[key] || 0) >= amount); }
function spendResources(cost) { for (const [key, amount] of Object.entries(cost)) inventory[key] -= amount; }

function craftSupply(kind) {
  const recipes = {
    medkit: { cost: { kelp: 1, copper: 1 }, label: 'Medkit' },
    ration: { cost: { kelp: 1, coral: 1 }, label: 'Rations' }
  };
  const recipe = recipes[kind];
  if (!recipe || !canAfford(recipe.cost)) { showToast('Material belum mencukupi.'); return; }
  spendResources(recipe.cost);
  if (kind === 'medkit') survival.medkits = clamp(survival.medkits + 1, 0, 20);
  else survival.rations = clamp(survival.rations + 1, 0, 20);
  updateSurvivalHud(); renderInventory(); playSfx('craft'); saveCurrentSlot();
  showToast(`${recipe.label} berhasil dibuat.`);
}

function openBuildMenu() {
  if (!gameActive) return;
  gamePaused = true;
  updateBuildButtons();
  setVisibleScreen('build');
}

function updateBuildButtons() {
  document.querySelectorAll('[data-build]').forEach(button => {
    const recipe = BUILD_RECIPES[button.dataset.build];
    button.disabled = !recipe || !canAfford(recipe.cost);
  });
}

function placeStructure(type) {
  const recipe = BUILD_RECIPES[type];
  if (!recipe) return;
  if (!canAfford(recipe.cost)) { showToast('Material pembangunan belum cukup.'); return; }
  const fx = Math.sin(player.yaw), fz = -Math.cos(player.yaw);
  const x = player.position.x + fx * 8, z = player.position.z + fz * 8;
  const ground = heightAt(x, z);
  if (ground > -7) { showToast('Bangunan laut dalam hanya dapat dipasang di dasar laut.'); return; }
  if (Math.abs(player.position.y - ground) > 15) { showToast('Dekati dasar laut untuk memasang bangunan.'); return; }
  spendResources(recipe.cost);
  const record = { id: `build-${Date.now()}-${Math.floor(Math.random()*9999)}`, type, x, y: ground + 0.08, z, yaw: player.yaw, builtAt: Date.now() };
  placedStructures.push(record);
  const cx = Math.floor(x / CHUNK_SIZE), cz = Math.floor(z / CHUNK_SIZE);
  const chunk = chunks.get(`${cx},${cz}`);
  if (chunk) addBuiltStructure(chunk.group, record, cx * CHUNK_SIZE, cz * CHUNK_SIZE);
  updateBuildButtons(); renderInventory(); playSfx('build'); saveCurrentSlot();
  showToast(`${recipe.label} ditempatkan di dasar laut.`);
}

function renderSlotCards(containerId, mode) {
  const root = $(containerId);
  root.replaceChildren();
  for (let index = 0; index < 5; index++) {
    const record = slots[index];
    const card = document.createElement('div');
    card.className = 'slot-card';
    const info = document.createElement('div');
    info.className = 'slot-info';
    const title = document.createElement('div');
    title.className = 'slot-title';
    title.textContent = `SLOT ${String(index + 1).padStart(2, '0')}`;
    const meta = document.createElement('div');
    meta.className = 'slot-meta';
    meta.textContent = record ? `Last saved: ${formatTime(record.savedAt)} · ${Math.round(record.position?.x || 0)}, ${Math.round(record.position?.z || 0)}` : 'EMPTY · No expedition data';
    info.append(title, meta);
    const actions = document.createElement('div');
    actions.className = 'slot-actions';
    const action = document.createElement('button');
    action.type = 'button';
    action.className = 'slot-action';
    action.textContent = mode === 'new' ? (record ? 'REPLACE' : 'START') : 'LOAD';
    action.disabled = mode === 'load' && !record;
    action.addEventListener('click', () => {
      if (mode === 'new') {
        if (record && !window.confirm(`Timpa data Slot ${index + 1}?`)) return;
        startGame(index, true);
      } else if (record) startGame(index, false);
    });
    actions.append(action);
    if (mode === 'load' && record) {
      const del = document.createElement('button');
      del.type = 'button'; del.className = 'slot-action'; del.textContent = 'DEL';
      del.setAttribute('aria-label', `Hapus Slot ${index + 1}`);
      del.addEventListener('click', () => {
        if (!window.confirm(`Hapus data Slot ${index + 1}?`)) return;
        slots[index] = null; saveJson(STORAGE.slots, slots);
        if (online.isSignedIn()) online.deletePersonalSlot(index + 1).catch(error => showToast(`Cloud delete gagal: ${error.message}`));
        renderSlotCards(containerId, mode);
      });
      actions.append(del);
    }
    card.append(info, actions);
    root.append(card);
  }
}

async function startGame(slotIndex, isNew) {
  startAmbient();
  if (ambientContext?.state === 'suspended') ambientContext.resume().catch(() => {});
  await enterFullscreenLandscape();
  activeSlot = slotIndex;
  const record = isNew ? null : slots[slotIndex];
  if (isNew) {
    player.position.set(0, -7, 0);
    player.yaw = 0;
    player.pitch = 0.08;
    survival = { ...SURVIVAL_DEFAULTS };
    collectedCaches = new Set();
    inventory = { ...INVENTORY_DEFAULTS };
    collectedResources = new Set();
    placedStructures = [];
    faunaDirector?.setDiscoveries([]);
  } else {
    player.position.set(record.position?.x || 0, clamp(record.position?.y ?? -7, -42, 12), record.position?.z || 0);
    player.yaw = record.yaw || 0;
    player.pitch = record.pitch ?? 0.08;
    survival = { ...SURVIVAL_DEFAULTS, ...(record.survival && typeof record.survival === 'object' ? record.survival : {}) };
    collectedCaches = new Set(Array.isArray(record.collectedCaches) ? record.collectedCaches : []);
    inventory = { ...INVENTORY_DEFAULTS, ...(record.inventory && typeof record.inventory === 'object' ? record.inventory : {}) };
    collectedResources = new Set(Array.isArray(record.collectedResources) ? record.collectedResources : []);
    placedStructures = Array.isArray(record.placedStructures) ? record.placedStructures : [];
    faunaDirector?.setDiscoveries(record.discoveries || []);
  }
  survival = Object.fromEntries(Object.entries(SURVIVAL_DEFAULTS).map(([key, fallback]) => {
    const value = Number(survival[key] ?? fallback);
    return [key, clamp(Number.isFinite(value) ? value : fallback, 0, key === 'medkits' || key === 'rations' ? 20 : 100)];
  }));
  respawnPoint.copy(player.position);
  oxygenDamageTimer = hungerDamageTimer = thirstDamageTimer = 0;
  temperatureC = 28;
  isRespawning = false;
  faunaDirector?.setQuality(settings.graphics);
  gameActive = true;
  gamePaused = false;
  autoSaveTimer = 0;
  for (const chunk of chunks.values()) disposeChunk(chunk);
  chunks.clear();
  resourceNodes.clear();
  chunkCenterX = NaN; chunkCenterZ = NaN;
  updateChunks(true);
  setVisibleScreen('hud');
  $('hud').classList.remove('hidden');
  updateNetworkLabels();
  updateSurvivalHud();
  showToast(isNew ? `Ekspedisi dimulai · Slot ${slotIndex + 1}` : `Progres Slot ${slotIndex + 1} dimuat`);
  if (isNew && (!online.room || online.isHost())) saveCurrentSlot();
}

function buildSaveRecord() {
  const previous = slots[activeSlot] || {};
  return {
    version: 4,
    savedAt: Date.now(),
    position: { x: player.position.x, y: player.position.y, z: player.position.z },
    yaw: player.yaw,
    pitch: player.pitch,
    survival: { ...survival, schemaVersion: SURVIVAL_STORAGE_VERSION },
    discoveries: faunaDirector?.getDiscoveries() || previous.discoveries || [],
    collectedCaches: [...collectedCaches],
    inventory: { ...inventory },
    collectedResources: [...collectedResources],
    placedStructures: placedStructures.map(item => ({ ...item }))
  };
}

function snapshotPersonalSlotsForRoom() {
  if (!personalSlotsBeforeRoom) {
    personalSlotsBeforeRoom = slots.map(record => record ? JSON.parse(JSON.stringify(record)) : null);
  }
}

function restorePersonalSlotsAfterRoom() {
  if (!personalSlotsBeforeRoom) return;
  slots = personalSlotsBeforeRoom;
  personalSlotsBeforeRoom = null;
  saveJson(STORAGE.slots, slots);
  if (!UI.load.classList.contains('hidden')) renderSlotCards('load-slots', 'load');
}

async function saveHostRoomProgress(slotIndex, record) {
  if (!online.isHost()) throw new Error('Hanya Host yang boleh menyimpan dunia multiplayer.');
  // Persist a local recovery checkpoint before attempting remote writes.
  if (personalSlotsBeforeRoom) {
    personalSlotsBeforeRoom[slotIndex] = record;
    saveJson(STORAGE.slots, personalSlotsBeforeRoom);
  } else {
    slots[slotIndex] = record;
    saveJson(STORAGE.slots, slots);
  }
  slots[slotIndex] = record;
  // Keep both the room's shared world and the Host's personal cloud slot.
  const results = await Promise.allSettled([
    online.saveRoomSlot(slotIndex + 1, record),
    online.savePersonalSlot(slotIndex + 1, record)
  ]);
  const failures = results.filter(result => result.status === 'rejected').map(result => result.reason?.message || 'unknown error');
  if (failures.length) throw new Error(failures.join(' · '));
  return true;
}

function saveCurrentSlot() {
  if (activeSlot < 0 || activeSlot > 4) return false;
  const record = buildSaveRecord();

  // Multiplayer shared-world saves are server-authorized for the Host only.
  if (online.room) {
    if (!online.isHost()) {
      showToast('Hanya Host yang dapat menyimpan dunia multiplayer.');
      return false;
    }
    saveHostRoomProgress(activeSlot, record)
      .then(() => showToast(`Shared world + Host cloud tersimpan · SLOT ${activeSlot + 1}`))
      .catch(error => showToast(`Cloud save gagal: ${error.message}`));
    return true;
  }

  slots[activeSlot] = record;
  const okay = saveJson(STORAGE.slots, slots);
  if (okay) showToast(`Progress tersimpan · Slot ${activeSlot + 1}`);
  if (okay && online.isSignedIn()) {
    online.savePersonalSlot(activeSlot + 1, record)
      .then(() => showToast(`Progress tersimpan di perangkat dan cloud · Slot ${activeSlot + 1}`))
      .catch(error => showToast(`Cloud save gagal: ${error.message}`));
  }
  return okay;
}

async function persistCurrentSlotNow() {
  if (activeSlot < 0 || activeSlot > 4) return false;
  const record = buildSaveRecord();
  if (online.room) {
    if (!online.isHost()) return false;
    await saveHostRoomProgress(activeSlot, record);
    return true;
  }
  slots[activeSlot] = record;
  const localOkay = saveJson(STORAGE.slots, slots);
  if (localOkay && online.isSignedIn()) await online.savePersonalSlot(activeSlot + 1, record);
  return localOkay;
}

function returnToMain() {
  if (gameActive && (!online.room || online.isHost())) saveCurrentSlot();
  gameActive = false; gamePaused = false;
  $('hud').classList.add('hidden');
  setVisibleScreen('main');
  updateAccountUI();
}
function pauseGame() {
  if (!gameActive || gamePaused) return;
  gamePaused = true;
  if (!online.room || online.isHost()) saveCurrentSlot();
  setVisibleScreen('pause');
}
function resumeGame() {
  if (!gameActive) return;
  gamePaused = false;
  setVisibleScreen('hud');
  $('hud').classList.remove('hidden');
}
async function exitGame() {
  if (gameActive && (!online.room || online.isHost())) {
    try { await persistCurrentSlotNow(); }
    catch (error) { showToast(`Cloud save gagal saat keluar: ${error.message}`); }
  }
  if (online.room) {
    for (const remote of remotePlayers.values()) scene?.remove(remote.group);
    remotePlayers.clear();
    await online.leaveRoom(true).catch(error => showToast(`Gagal menutup room: ${error.message}`));
    restorePersonalSlotsAfterRoom();
    activeSlot = -1;
  }
  gameActive = false; gamePaused = false;
  $('hud').classList.add('hidden');
  if (online.isNative()) {
    await online.exitNativeApp().catch(error => showToast(`Tidak dapat menutup aplikasi: ${error.message}`));
    return;
  }
  setVisibleScreen('exit');
  updateAccountUI();
}

function setAuthMessage(message, isError = false) {
  $('auth-message').textContent = message;
  $('auth-message').style.color = isError ? '#ffb2a8' : '#a8c9d0';
}
function setRoomMessage(message, isError = false) {
  $('room-message').textContent = message;
  $('room-message').style.color = isError ? '#ffb2a8' : '#a8c9d0';
}
function updateAccountUI() {
  const user = online.getUser();
  const configured = online.isConfigured();
  $('backend-status').textContent = configured
    ? 'Backend configured · Supabase Auth, Database, Cloud Save, Realtime.'
    : 'Backend belum dikonfigurasi. Isi supabase-config.js dan jalankan supabase/schema.sql sebelum login.';
  $('account-name').textContent = user ? (user.user_metadata?.display_name || user.email || 'Signed in') : 'Belum login';
  $('account-detail').textContent = user ? `${user.email || 'Akun sosial'} · Cloud save tersedia` : 'Login untuk cloud save dan multiplayer.';
  $('signout-btn').disabled = !user;
  $('play-btn').disabled = !!online.room;
  $('continue-btn').disabled = !!online.room;
  $('host-room-btn').disabled = !user || !configured || !!online.room;
  $('join-room-btn').disabled = !user || !configured || !!online.room;
  $('google-login-btn').disabled = !configured;
  $('facebook-login-btn').disabled = !configured;
  $('email-login-btn').disabled = !configured;
  $('email-register-btn').disabled = !configured;
  if (user) document.querySelector('.account-led')?.classList.add('is-online');
  else document.querySelector('.account-led')?.classList.remove('is-online');
  if (online.room) {
    $('room-code-display').textContent = online.room.code;
    $('room-role-label').textContent = online.isHost() ? 'HOST · You control shared-world saves' : 'GUEST · Host controls shared-world saves';
    $('leave-room-btn').disabled = false;
  } else {
    $('room-code-display').textContent = 'Not connected';
    $('room-role-label').textContent = user ? 'Create a room or join with an invite code.' : 'Login untuk bermain online.';
    $('leave-room-btn').disabled = true;
  }
  if ($('resume-room-btn')) $('resume-room-btn').disabled = !online.room || gameActive;
  const guestInRoom = !!online.room && !online.isHost();
  $('save-btn').disabled = guestInRoom;
  $('pause-save-btn').disabled = guestInRoom;
  updateNetworkLabels();
}

async function providerLogin(provider) {
  try { setAuthMessage(`Membuka ${provider} login...`, false); await online.signInWithProvider(provider); }
  catch (error) { setAuthMessage(error.message, true); }
}

async function syncCloudSlots() {
  if (!online.isSignedIn()) return;
  try {
    const cloudRows = await online.loadPersonalSlots();
    const cloudBySlot = new Map(cloudRows.map(row => [Number(row.slot), row]));
    for (let index = 0; index < 5; index++) {
      const cloud = cloudBySlot.get(index + 1);
      if (cloud?.record) {
        const cloudTime = Number(cloud.record.savedAt || Date.parse(cloud.savedAt) || 0);
        const localTime = Number(slots[index]?.savedAt || 0);
        if (!slots[index] || cloudTime > localTime) slots[index] = cloud.record;
        else if (localTime > cloudTime) await online.savePersonalSlot(index + 1, slots[index]);
      } else if (slots[index]) {
        // A local slot created before sign-in is uploaded on the first account sync.
        await online.savePersonalSlot(index + 1, slots[index]);
      }
    }
    saveJson(STORAGE.slots, slots);
    if (!UI.load.classList.contains('hidden')) renderSlotCards('load-slots', 'load');
    setAuthMessage('Cloud save tersinkronisasi dengan perangkat ini.', false);
  } catch (error) { setAuthMessage(`Cloud sync gagal: ${error.message}`, true); }
}

function receiveRemotePlayer(payload) {
  if (!payload?.user_id || payload.user_id === online.getUser()?.id || !scene || !playerGroup) return;
  const values = [payload.x, payload.y, payload.z, payload.yaw];
  if (!values.every(Number.isFinite)) return;
  let remote = remotePlayers.get(payload.user_id);
  if (!remote) {
    const group = playerGroup.clone(true);
    group.scale.setScalar(0.72);
    scene.add(group);
    remote = { group, target: new THREE.Vector3(), yaw: 0, name: payload.display_name || 'Diver' };
    remotePlayers.set(payload.user_id, remote);
  }
  remote.target.set(clamp(payload.x, -100000, 100000), clamp(payload.y, -42, 14), clamp(payload.z, -100000, 100000));
  remote.yaw = payload.yaw;
  remote.name = String(payload.display_name || 'Diver').slice(0, 32);
}

function updateRemotePlayers(dt) {
  for (const remote of remotePlayers.values()) {
    remote.group.position.lerp(remote.target, 1 - Math.pow(0.001, dt));
    if (remote.group.children[0]) remote.group.children[0].rotation.y = remote.yaw;
  }
}

async function createMultiplayerRoom() {
  if (!online.isSignedIn()) { setRoomMessage('Login terlebih dahulu.', true); return; }
  await enterFullscreenLandscape();
  try {
    $('host-room-btn').disabled = true;
    setRoomMessage('Membuat room dan menghubungkan pemain...', false);
    const room = await online.createRoom(online.displayName(), WORLD_SEED);
    $('room-code-input').value = room.code;
    const roomSaved = await online.loadRoomSlot(1);
    const saved = roomSaved || slots[0] || null;
    snapshotPersonalSlotsForRoom();
    slots[0] = saved;
    if (!roomSaved && saved) await online.saveRoomSlot(1, saved);
    activeSlot = 0;
    setRoomMessage(`Room ${room.code} siap. Bagikan kode ini kepada teman.`, false);
    updateAccountUI();
    await startGame(0, !saved);
  } catch (error) {
    if (online.room) await online.leaveRoom(true).catch(() => {});
    restorePersonalSlotsAfterRoom();
    setRoomMessage(error.message, true);
    $('host-room-btn').disabled = !online.isSignedIn();
    updateAccountUI();
  }
}

async function joinMultiplayerRoom() {
  if (!online.isSignedIn()) { setRoomMessage('Login terlebih dahulu.', true); return; }
  await enterFullscreenLandscape();
  const code = $('room-code-input').value.trim().toUpperCase();
  if (!/^[A-Z2-9]{6}$/.test(code)) { setRoomMessage('Masukkan kode room 6 karakter.', true); return; }
  try {
    $('join-room-btn').disabled = true;
    setRoomMessage('Mencari room dan menyambungkan pemain...', false);
    const room = await online.joinRoom(code, online.displayName());
    const saved = await online.loadRoomSlot(1);
    snapshotPersonalSlotsForRoom();
    slots[0] = saved || null;
    activeSlot = 0;
    setRoomMessage(`Bergabung ke ${room.code}. Hanya Host dapat menyimpan dunia bersama.`, false);
    updateAccountUI();
    await startGame(0, !saved);
  } catch (error) {
    if (online.room) await online.leaveRoom(false).catch(() => {});
    restorePersonalSlotsAfterRoom();
    setRoomMessage(error.message, true);
    $('join-room-btn').disabled = !online.isSignedIn();
    updateAccountUI();
  }
}

async function resumeMultiplayerWorld() {
  if (!online.room || gameActive) return;
  try {
    const index = activeSlot >= 0 && activeSlot < 5 ? activeSlot : 0;
    const saved = await online.loadRoomSlot(index + 1);
    if (saved) slots[index] = saved;
    activeSlot = index;
    await startGame(index, !saved);
  } catch (error) {
    setRoomMessage(`Tidak dapat melanjutkan room: ${error.message}`, true);
  }
}

async function leaveMultiplayerRoom() {
  if (!online.room) return;
  if (gameActive) {
    if (online.isHost()) {
      try { await saveHostRoomProgress(activeSlot, buildSaveRecord()); }
      catch (error) { showToast(`Cloud save gagal sebelum keluar: ${error.message}`); }
    }
    gameActive = false; gamePaused = false;
    $('hud').classList.add('hidden');
  }
  for (const remote of remotePlayers.values()) scene?.remove(remote.group);
  remotePlayers.clear();
  await online.leaveRoom(true);
  restorePersonalSlotsAfterRoom();
  activeSlot = -1;
  setRoomMessage('Keluar dari room multiplayer.', false);
  updateAccountUI();
  setVisibleScreen('main');
}

function setupControls() {
  $('play-btn').addEventListener('click', () => { renderSlotCards('new-slots', 'new'); setVisibleScreen('newGame'); });
  $('continue-btn').addEventListener('click', () => { renderSlotCards('load-slots', 'load'); setVisibleScreen('load'); });
  $('settings-btn').addEventListener('click', () => openSettings('main'));
  $('online-btn').addEventListener('click', () => { setVisibleScreen('online'); updateAccountUI(); });
  $('exit-btn').addEventListener('click', exitGame);
  document.querySelectorAll('[data-back]').forEach(button => button.addEventListener('click', () => {
    if (button.closest('#settings-screen')) closeSettings();
    else setVisibleScreen('main');
  }));
  $('pause-btn').addEventListener('click', pauseGame);
  $('resume-btn').addEventListener('click', resumeGame);
  $('pause-save-btn').addEventListener('click', saveCurrentSlot);
  $('pause-settings-btn').addEventListener('click', () => openSettings('pause'));
  $('main-menu-btn').addEventListener('click', returnToMain);
  $('save-btn').addEventListener('click', saveCurrentSlot);
  $('scan-btn').addEventListener('click', scanNearestFauna);
  $('medkit-btn').addEventListener('click', useMedkit);
  $('ration-btn').addEventListener('click', useRation);
  $('supply-btn').addEventListener('click', openSupplyCache);
  $('gather-btn').addEventListener('click', gatherNearbyResource);
  $('inventory-btn').addEventListener('click', openInventory);
  $('build-btn').addEventListener('click', openBuildMenu);
  $('inventory-close-btn').addEventListener('click', closeGamePanel);
  $('build-close-btn').addEventListener('click', closeGamePanel);
  $('craft-medkit-btn').addEventListener('click', () => craftSupply('medkit'));
  $('craft-ration-btn').addEventListener('click', () => craftSupply('ration'));
  document.querySelectorAll('[data-build]').forEach(button => button.addEventListener('click', () => placeStructure(button.dataset.build)));
  $('return-menu-btn').addEventListener('click', () => { setVisibleScreen('main'); updateAccountUI(); });
  $('fullscreen-btn').addEventListener('click', enterFullscreenLandscape);
  $('export-save-btn').addEventListener('click', exportSaveBackup);
  $('import-save-btn').addEventListener('click', () => $('import-save-file').click());
  $('import-save-file').addEventListener('change', async event => {
    try { await importSaveBackup(event.target.files?.[0]); }
    catch (error) { showToast(error.message || 'Gagal membaca file backup.'); }
    finally { event.target.value = ''; }
  });

  $('email-login-btn').addEventListener('click', async () => {
    try {
      setAuthMessage('Menghubungkan akun...', false);
      await online.signIn($('auth-email').value, $('auth-password').value);
      setAuthMessage('Login berhasil.', false);
    } catch (error) { setAuthMessage(error.message, true); }
  });
  $('email-register-btn').addEventListener('click', async () => {
    try {
      const email = $('auth-email').value.trim();
      const password = $('auth-password').value;
      if (password.length < 6) throw new Error('Password minimal 6 karakter.');
      await online.signUp(email, password, $('auth-name').value.trim());
      setAuthMessage('Akun dibuat. Periksa email untuk verifikasi apabila konfirmasi email aktif.', false);
    } catch (error) { setAuthMessage(error.message, true); }
  });
  $('google-login-btn').addEventListener('click', () => providerLogin('google'));
  $('facebook-login-btn').addEventListener('click', () => providerLogin('facebook'));
  $('signout-btn').addEventListener('click', async () => {
    try {
      if (online.room && online.isHost() && gameActive) await saveHostRoomProgress(activeSlot, buildSaveRecord());
      if (gameActive) { gameActive = false; gamePaused = false; $('hud').classList.add('hidden'); }
      await online.signOut();
      restorePersonalSlotsAfterRoom();
      activeSlot = -1;
      setAuthMessage('Berhasil sign out.', false);
      setVisibleScreen('online');
    } catch (error) { setAuthMessage(error.message, true); }
  });
  $('host-room-btn').addEventListener('click', createMultiplayerRoom);
  $('join-room-btn').addEventListener('click', joinMultiplayerRoom);
  $('leave-room-btn').addEventListener('click', leaveMultiplayerRoom);
  $('resume-room-btn').addEventListener('click', resumeMultiplayerWorld);

  $('graphics-select').addEventListener('change', event => { settings.graphics = event.target.value; applySettings(); });
  $('render-select').addEventListener('change', event => { settings.renderDistance = Number(event.target.value); applySettings(); });
  $('volume-range').addEventListener('input', event => { settings.volume = Number(event.target.value); $('volume-value').textContent = `${settings.volume}%`; updateAmbientVolume(); saveJson(STORAGE.settings, settings); });
  $('fov-range').addEventListener('input', event => { settings.fov = Number(event.target.value); $('fov-value').textContent = `${settings.fov}°`; applySettings(); });
  $('language-select').addEventListener('change', event => { settings.language = event.target.value; applyLanguage(); saveJson(STORAGE.settings, settings); });

  window.addEventListener('keydown', event => {
    const target = event.target;
    const typing = target && (target.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName));
    if (typing) return;
    if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(event.code)) event.preventDefault();
    input.keys.add(event.code);
    if (event.code === 'KeyI' && gameActive && !gamePaused) openInventory();
    if (event.code === 'KeyB' && gameActive && !gamePaused) openBuildMenu();
    if (event.code === 'Escape' && gameActive) { if (gamePaused) closeGamePanel(); else pauseGame(); }
  });
  window.addEventListener('keyup', event => input.keys.delete(event.code));
  window.addEventListener('blur', () => input.keys.clear());

  const joystick = $('joystick'), knob = $('joystick-knob');
  let joyPointer = null;
  const moveJoy = (event) => {
    if (event.pointerId !== joyPointer) return;
    const rect = joystick.getBoundingClientRect();
    const cx = rect.left + rect.width / 2, cy = rect.top + rect.height / 2;
    const dx = event.clientX - cx, dy = event.clientY - cy;
    const max = rect.width * 0.34;
    const length = Math.hypot(dx, dy) || 1;
    const factor = Math.min(1, max / length);
    const px = dx * factor, py = dy * factor;
    knob.style.transform = `translate(${px}px,${py}px)`;
    input.joyX = clamp(px / max, -1, 1);
    input.joyY = clamp(py / max, -1, 1);
  };
  joystick.addEventListener('pointerdown', event => { joyPointer = event.pointerId; joystick.setPointerCapture(joyPointer); moveJoy(event); });
  joystick.addEventListener('pointermove', moveJoy);
  const resetJoy = event => { if (event.pointerId !== joyPointer) return; joyPointer = null; input.joyX = 0; input.joyY = 0; knob.style.transform = 'translate(0,0)'; };
  joystick.addEventListener('pointerup', resetJoy); joystick.addEventListener('pointercancel', resetJoy); joystick.addEventListener('lostpointercapture', () => { joyPointer = null; input.joyX = 0; input.joyY = 0; knob.style.transform = 'translate(0,0)'; });

  const lookpad = $('lookpad');
  lookpad.addEventListener('pointerdown', event => { event.preventDefault(); look.active = true; look.pointerId = event.pointerId; look.x = event.clientX; look.y = event.clientY; lookpad.setPointerCapture(event.pointerId); });
  lookpad.addEventListener('pointermove', event => {
    if (!look.active || event.pointerId !== look.pointerId) return;
    const dx = event.clientX - look.x, dy = event.clientY - look.y;
    look.x = event.clientX; look.y = event.clientY;
    player.yaw -= dx * 0.006;
    player.pitch = clamp(player.pitch + dy * 0.0035, -1.1, 1.1);
  });
  const stopLook = event => { if (event.pointerId === look.pointerId) { look.active = false; look.pointerId = null; } };
  lookpad.addEventListener('pointerup', stopLook); lookpad.addEventListener('pointercancel', stopLook);

  const bindHold = (id, direction) => {
    const node = $(id);
    const down = event => { event.preventDefault(); input.vertical = direction; node.setPointerCapture?.(event.pointerId); };
    const up = event => { event.preventDefault(); if (input.vertical === direction) input.vertical = 0; };
    node.addEventListener('pointerdown', down); node.addEventListener('pointerup', up); node.addEventListener('pointercancel', up); node.addEventListener('lostpointercapture', up);
  };
  bindHold('ascend-btn', 1); bindHold('descend-btn', -1);
  window.addEventListener('online', updateNetworkLabels);
  window.addEventListener('offline', updateNetworkLabels);
  document.addEventListener('visibilitychange', () => { if (document.hidden && gameActive && (!online.room || online.isHost())) saveCurrentSlot(); });
  window.addEventListener('beforeunload', () => { if (gameActive && (!online.room || online.isHost())) saveCurrentSlot(); });
  window.addEventListener('resize', onResize);
  window.addEventListener('orientationchange', () => setTimeout(onResize, 160));
  document.addEventListener('focusin', event => {
    const target = event.target;
    if (target && /^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName)) {
      document.body.classList.add('keyboard-open');
      setTimeout(() => target.scrollIntoView({ block: 'center', behavior: 'smooth' }), 120);
    }
  });
  document.addEventListener('focusout', () => {
    clearTimeout(visualViewportResizeTimer);
    visualViewportResizeTimer = setTimeout(() => document.body.classList.remove('keyboard-open'), 180);
  });
}

function onResize() {
  if (!renderer || !camera) return;
  // Keep the render target stable while Android's IME is visible; adjustPan
  // pans the content without shrinking the native full-screen game surface.
  if (document.body.classList.contains('keyboard-open')) return;
  const viewport = getGameViewportSize();
  renderer.setSize(viewport.width, viewport.height, false);
  camera.aspect = viewport.width / viewport.height;
  camera.updateProjectionMatrix();
}

function updateMovement(dt) {
  const keyForward = (input.keys.has('KeyW') || input.keys.has('ArrowUp') ? 1 : 0) - (input.keys.has('KeyS') || input.keys.has('ArrowDown') ? 1 : 0);
  const keyStrafe = (input.keys.has('KeyD') || input.keys.has('ArrowRight') ? 1 : 0) - (input.keys.has('KeyA') || input.keys.has('ArrowLeft') ? 1 : 0);
  const forward = clamp(keyForward - input.joyY, -1, 1);
  const strafe = clamp(keyStrafe + input.joyX, -1, 1);
  const vertical = input.vertical + (input.keys.has('Space') ? 1 : 0) - (input.keys.has('ControlLeft') || input.keys.has('ControlRight') ? 1 : 0);
  const pitch = clamp(player.pitch, -0.45, 0.55);
  const fwd = tmpVector.set(Math.sin(player.yaw) * Math.cos(pitch), -Math.sin(pitch), -Math.cos(player.yaw) * Math.cos(pitch));
  const right = tmpRight.set(Math.cos(player.yaw), 0, Math.sin(player.yaw));
  const direction = tmpDirection.set(0, 0, 0).addScaledVector(fwd, forward).addScaledVector(right, strafe);
  if (direction.lengthSq() > 1) direction.normalize();
  const speed = settings.graphics === 'low' ? 10.5 : 13.5;
  player.position.addScaledVector(direction, speed * dt);
  player.position.y = clamp(player.position.y + (vertical * 9.5) * dt, -42, 14);
  // Keep the diver above the procedural sea floor and island terrain.
  const floorClearance = heightAt(player.position.x, player.position.z) + 2.1;
  if (player.position.y < floorClearance) player.position.y = floorClearance;
  const horizontalMotion = Math.hypot(direction.x, direction.z);
  // In first-person mode, heading is controlled by the look surface, never by strafing.
  player.bob += dt * (direction.lengthSq() > 0.015 ? 7.2 : 2.1);
}

function updateCamera(dt) {
  const eyeBob = Math.sin(player.bob) * 0.025;
  camera.position.set(player.position.x, player.position.y + 0.55 + eyeBob, player.position.z);
  if (viewModel) viewModel.visible = gameActive;
  const pitch = clamp(player.pitch, -1.15, 1.15);
  const forward = tmpDirection.set(Math.sin(player.yaw) * Math.cos(pitch), -Math.sin(pitch), -Math.cos(player.yaw) * Math.cos(pitch));
  camera.lookAt(tmpCamera.copy(camera.position).addScaledVector(forward, 22));
  camera.rotation.z = Math.sin(player.bob) * 0.004;
  if (viewModel) {
    const swim = Math.sin(player.bob) * 0.035;
    viewModel.userData.left.rotation.z = swim;
    viewModel.userData.right.rotation.z = -swim;
  }
  if (particleGroup) { particleGroup.position.set(player.position.x, player.position.y, player.position.z); particleGroup.rotation.y += dt * 0.012; }
  if (lightRayGroup) { lightRayGroup.position.set(player.position.x, Math.min(-3, player.position.y + 18), player.position.z); lightRayGroup.rotation.y += dt * 0.004; }
  const waterCellX = Math.floor(player.position.x / 500) * 500;
  const waterCellZ = Math.floor(player.position.z / 500) * 500;
  if (water) { water.position.x = waterCellX; water.position.z = waterCellZ; water.position.y = Math.sin(clockState.elapsed * 0.35) * 0.08; }
  if (scene?.fog) {
    const depth = Math.max(0, -player.position.y);
    scene.fog.density = (settings.graphics === 'low' ? 0.0030 : settings.graphics === 'high' ? 0.0014 : 0.0020) + Math.min(0.0017, depth * 0.000035);
    scene.fog.color.setHSL(0.53, 0.62, clamp(0.21 - depth * 0.0015, 0.07, 0.21));
  }
}

function setSurvivalBar(name, value) {
  const percent = clamp(Number(value) || 0, 0, 100);
  const fill = $(`${name}-fill`);
  const label = $(`${name}-value`);
  if (fill) {
    fill.style.width = `${percent}%`;
    fill.classList.toggle('is-low', percent <= 25);
    fill.classList.toggle('is-critical', percent <= 12);
  }
  if (label) label.textContent = String(Math.round(percent));
}

function updateSurvivalHud() {
  setSurvivalBar('hp', survival.hp);
  setSurvivalBar('oxygen', survival.oxygen);
  setSurvivalBar('food', survival.food);
  setSurvivalBar('water', survival.water);
  const critical = survival.hp <= 25 || survival.oxygen <= 20 || survival.water <= 15 || survival.food <= 10;
  $('survival-status').textContent = critical ? 'WARNING' : survival.oxygen < 45 ? 'LOW O₂' : 'STABLE';
  $('survival-status').classList.toggle('is-warning', critical || survival.oxygen < 45);
  $('temperature-value').textContent = `${Math.round(temperatureC)}°C`;
  $('species-value').textContent = `${faunaDirector?.getSpeciesCount() || 0}/${FAUNA_SPECIES_COUNT}`;
  $('medkit-btn').textContent = `MEDKIT ×${survival.medkits}`;
  $('ration-btn').textContent = `RATIONS ×${survival.rations}`;
  $('medkit-btn').disabled = survival.medkits <= 0 || survival.hp >= 96;
  $('ration-btn').disabled = survival.rations <= 0 || (survival.food >= 96 && survival.water >= 96);
  const nearbyCache = supplyCacheLocations.find(cache => !collectedCaches.has(cache.id) && Math.hypot(player.position.x-cache.x, player.position.y-cache.y, player.position.z-cache.z) < 14);
  $('supply-btn').classList.toggle('hidden', !nearbyCache);
  $('supply-btn').dataset.cacheId = nearbyCache?.id || '';
  updateResourcePrompt();
}

function applyDamage(amount, source = 'Bahaya bawah laut') {
  if (!gameActive || isRespawning || amount <= 0) return;
  playSfx('damage');
  survival.hp = clamp(survival.hp - amount, 0, 100);
  const flash = $('damage-flash');
  flash.classList.remove('active');
  void flash.offsetWidth;
  flash.classList.add('active');
  showToast(`${source} · -${Math.round(amount)} HP`);
  updateSurvivalHud();
  if (survival.hp <= 0) {
    isRespawning = true;
    setTimeout(() => {
      player.position.copy(respawnPoint);
      player.yaw = 0;
      player.pitch = 0.08;
      survival.hp = 65;
      survival.oxygen = Math.max(survival.oxygen, 55);
      survival.food = Math.max(survival.food, 30);
      survival.water = Math.max(survival.water, 30);
      oxygenDamageTimer = hungerDamageTimer = thirstDamageTimer = 0;
      isRespawning = false;
      chunkCenterX = NaN;
      updateChunks(true);
      updateSurvivalHud();
      showToast('Kamu pingsan dan kembali ke titik ekspedisi.');
    }, 850);
  }
}

function updateSurvival(dt) {
  const depth = Math.max(0, -player.position.y);
  const atSurface = player.position.y >= -1.4;
  if (atSurface) survival.oxygen = clamp(survival.oxygen + 24 * dt, 0, 100);
  else survival.oxygen = clamp(survival.oxygen - (0.62 + Math.max(0, depth - 25) * 0.012) * dt, 0, 100);
  survival.food = clamp(survival.food - 0.012 * dt, 0, 100);
  survival.water = clamp(survival.water - 0.018 * dt, 0, 100);
  temperatureC = clamp(28 - Math.max(0, depth - 18) * 0.43, 12, 28);

  if (survival.oxygen <= 0) {
    oxygenDamageTimer += dt;
    if (oxygenDamageTimer >= 2.2) { oxygenDamageTimer = 0; applyDamage(6, 'Kehabisan oksigen'); }
  } else oxygenDamageTimer = 0;
  if (survival.food <= 0) {
    hungerDamageTimer += dt;
    if (hungerDamageTimer >= 10) { hungerDamageTimer = 0; applyDamage(2, 'Kelaparan'); }
  } else hungerDamageTimer = 0;
  if (survival.water <= 0) {
    thirstDamageTimer += dt;
    if (thirstDamageTimer >= 8) { thirstDamageTimer = 0; applyDamage(2.5, 'Dehidrasi'); }
  } else thirstDamageTimer = 0;
}

function useMedkit() {
  if (survival.medkits <= 0 || survival.hp >= 96) return;
  survival.medkits -= 1;
  survival.hp = clamp(survival.hp + 38, 0, 100);
  updateSurvivalHud();
  saveCurrentSlot();
  showToast('Medkit digunakan · HP dipulihkan.');
}

function useRation() {
  if (survival.rations <= 0 || (survival.food >= 96 && survival.water >= 96)) return;
  survival.rations -= 1;
  survival.food = clamp(survival.food + 42, 0, 100);
  survival.water = clamp(survival.water + 38, 0, 100);
  updateSurvivalHud();
  saveCurrentSlot();
  showToast('Ransum digunakan · Food dan Water dipulihkan.');
}

function openSupplyCache() {
  const cacheId = $('supply-btn').dataset.cacheId;
  const cache = supplyCacheLocations.find(item => item.id === cacheId);
  if (!cache || collectedCaches.has(cache.id)) { showToast('Tidak ada supply cache yang dapat dijangkau.'); return; }
  const distance = Math.hypot(player.position.x-cache.x, player.position.y-cache.y, player.position.z-cache.z);
  if (distance >= 14) { showToast('Dekati peti suplai terlebih dahulu.'); return; }
  collectedCaches.add(cache.id);
  survival.medkits = clamp(survival.medkits + 1, 0, 20);
  survival.rations = clamp(survival.rations + 2, 0, 20);
  survival.oxygen = clamp(survival.oxygen + 18, 0, 100);
  inventory.titanium = clamp(inventory.titanium + 2, 0, 999);
  inventory.copper = clamp(inventory.copper + 1, 0, 999);
  updateSurvivalHud();
  saveCurrentSlot();
  showToast(`${cache.name} dibuka · +1 Medkit · +2 Rations`);
}

function scanNearestFauna() {
  playSfx('scan');
  const result = faunaDirector?.scan(player.position, 62);
  if (!result) { showToast('Tidak ada makhluk hidup dalam jangkauan pemindai.'); return; }
  const prefix = result.isNew ? 'SPESIES BARU' : 'TERDETEKSI';
  showToast(`${prefix}: ${result.name} · ${result.distance} m · ${result.total}/${result.maximum}`);
  updateSurvivalHud();
  if (activeSlot >= 0 && (!online.room || online.isHost())) saveCurrentSlot();
}

function updateHud() {
  $('coords-label').textContent = `X ${Math.round(player.position.x)} · Z ${Math.round(player.position.z)}`;
  $('depth-label').textContent = `${Math.max(0, Math.round(-player.position.y))} m`;
  $('chunk-label').textContent = String(chunks.size);
  $('fauna-label').textContent = faunaStatus.count ? String(faunaStatus.count) : '0';
  const dIsland = Math.hypot(player.position.x - islandOfInterest.x, player.position.z - islandOfInterest.z);
  const dShip = Math.hypot(player.position.x - shipOfInterest.x, player.position.z - shipOfInterest.z);
  if (dIsland < 115) {
    $('location-label').textContent = islandOfInterest.name;
    $('poi-banner').innerHTML = 'VERDANT ISLE <span>— Island ecosystem detected</span>';
  } else if (dShip < 95) {
    $('location-label').textContent = shipOfInterest.name;
    $('poi-banner').innerHTML = 'SUNKEN VESSEL <span>— Abandoned structure detected</span>';
  } else {
    $('location-label').textContent = 'Open Ocean';
    const nearest = Math.round(Math.min(dIsland, dShip));
    $('poi-banner').innerHTML = `OPEN OCEAN <span>— Nearest discovery ${nearest} m</span>`;
  }
  if (faunaStatus.threat && faunaStatus.threat.distance < 40) {
    $('poi-banner').innerHTML = `⚠ ${faunaStatus.threat.name.toUpperCase()} <span>— Threat detected · ${Math.round(faunaStatus.threat.distance)} m</span>`;
    $('poi-banner').classList.add('danger-signal');
  } else if (faunaStatus.nearest) {
    $('poi-banner').classList.remove('danger-signal');
    if (dIsland >= 115 && dShip >= 95) $('poi-banner').innerHTML = `LIFEFORM SIGNAL <span>— ${faunaStatus.nearest.species.name} · ${Math.round(faunaStatus.nearest.distance)} m</span>`;
  } else $('poi-banner').classList.remove('danger-signal');
  updateSurvivalHud();
}

function animate(now) {
  requestAnimationFrame(animate);
  const dt = Math.min((now - lastFrame) / 1000, 0.05);
  lastFrame = now;
  clockState.elapsed += dt;
  if (gameActive && !gamePaused) {
    updateMovement(dt);
    updateSurvival(dt);
    faunaStatus = faunaDirector?.update(dt, player.position) || faunaStatus;
    const cx = Math.floor(player.position.x / CHUNK_SIZE), cz = Math.floor(player.position.z / CHUNK_SIZE);
    if (cx !== chunkCenterX || cz !== chunkCenterZ) updateChunks();
    updateCamera(dt);
    updateRemotePlayers(dt);
    if (online.room) {
      roomBroadcastTimer += dt;
      if (roomBroadcastTimer >= 0.1) {
        roomBroadcastTimer = 0;
        online.sendPlayerState({ x: player.position.x, y: player.position.y, z: player.position.z, yaw: player.yaw });
      }
    }
    autoSaveTimer += dt;
    if (autoSaveTimer >= 30) { autoSaveTimer = 0; if (!online.room || online.isHost()) saveCurrentSlot(); }
    if (now - lastHudUpdate > 300) { lastHudUpdate = now; updateHud(); }
  } else if (rendererReady) {
    camera.position.x += Math.sin(now * 0.00007) * 0.012;
    camera.lookAt(0, -5, 0);
  }
  if (renderer) renderer.render(scene, camera);
}

async function checkForAppUpdate() {
  const manifestUrl = window.ABYSSAL_UPDATE_MANIFEST_URL || '';
  if (!manifestUrl || !/^https:\/\//i.test(manifestUrl)) return;
  try {
    const response = await fetch(manifestUrl, { cache: 'no-store', headers: { Accept: 'application/json' } });
    if (!response.ok) throw new Error(`Update server returned ${response.status}`);
    const manifest = await response.json();
    const current = '0.7.1';
    if (!manifest || typeof manifest.version !== 'string' || typeof manifest.downloadUrl !== 'string') return;
    const download = new URL(manifest.downloadUrl);
    if (download.protocol !== 'https:') return;
    if (manifest.version !== current && compareVersions(manifest.version, current) > 0) {
      const install = window.confirm(`The Abyssal ${manifest.version} tersedia. Buka unduhan pembaruan APK?\n\n${manifest.notes || ''}\n\nAndroid akan meminta persetujuan sebelum memasang APK.`);
      if (install) {
        if (online.isNative()) {
          const { Browser } = await import('@capacitor/browser');
          await Browser.open({ url: download.toString() });
        } else window.open(download.toString(), '_blank', 'noopener');
      }
    }
  } catch (error) {
    console.info('Abyssal update check skipped:', error.message);
  }
}
function compareVersions(a, b) {
  const aa = a.split('.').map(Number), bb = b.split('.').map(Number);
  for (let i = 0; i < Math.max(aa.length, bb.length); i++) {
    const diff = (aa[i] || 0) - (bb[i] || 0);
    if (diff) return diff;
  }
  return 0;
}

async function boot() {
  try {
    $('loading-bar').style.width = '28%';
    createWorld();
    $('loading-bar').style.width = '74%';
    setupControls();
    syncSettingsInputs();
    applyLanguage();
    online.initialize({
      onAuthChange: user => { updateAccountUI(); if (user) syncCloudSlots(); },
      onPlayerState: receiveRemotePlayer,
      onPresence: state => {
        const ids = new Set(Object.keys(state || {}));
        for (const [id, remote] of remotePlayers) {
          if (!ids.has(id)) { scene?.remove(remote.group); remotePlayers.delete(id); }
        }
      },
      onRoomChange: () => updateAccountUI(),
      onRoomClosed: async () => {
        if (gameActive) { gameActive = false; gamePaused = false; $('hud').classList.add('hidden'); }
        for (const remote of remotePlayers.values()) scene?.remove(remote.group);
        remotePlayers.clear();
        await online.leaveRoom(false);
        restorePersonalSlotsAfterRoom();
        activeSlot = -1;
        setRoomMessage('Host telah menutup room. Shared save tetap tersimpan.', false);
        updateAccountUI();
        setVisibleScreen('main');
      },
      onStatus: message => { $('backend-status').textContent = message; },
      onError: message => setAuthMessage(message, true),
      onNativeBack: () => { if (gameActive) pauseGame(); else setVisibleScreen('main'); }
    }).catch(error => { $('backend-status').textContent = `Online service error: ${error.message}`; });
    updateAccountUI();
    updateNetworkLabels();
    checkForAppUpdate().catch(() => {});
    $('loading-bar').style.width = '100%';
    // The APK contains its own offline-ready bundle. Service workers are only
    // used by an optional browser preview, never by the native Android shell.
    if (!online.isNative() && 'serviceWorker' in navigator && location.protocol.startsWith('http')) {
      navigator.serviceWorker.register('./sw.js').catch(() => {});
    }
    setTimeout(() => {
      setVisibleScreen('main');
      $('boot-screen').classList.add('hidden');
    }, 350);
    requestAnimationFrame(animate);
  } catch (error) {
    console.error(error);
    $('boot-message').textContent = `Gagal menyiapkan renderer 3D: ${error.message || error}`;
    $('loading-bar').style.width = '100%';
  }
}

boot();
