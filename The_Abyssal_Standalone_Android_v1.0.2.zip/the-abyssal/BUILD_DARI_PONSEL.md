# THE ABYSSAL 1.0.2 — build dan update hanya melalui ponsel Android

Kamu tidak membutuhkan laptop, Android Studio, Node.js, Gradle, atau Netlify di HP. GitHub Actions melakukan kompilasi pada runner cloud.

## Sebelum update: backup

1. Buka APK yang sedang terpasang.
2. Buka **Settings → Backup Progress (JSON)**.
3. Simpan file backup di folder Downloads dan jangan hapus.
4. Keluar dari room multiplayer sebelum backup pribadi.

## Upload ZIP update

1. Buka repository GitHub **The-Abyssal → Code**.
2. Hapus hanya ZIP proyek versi lama di root repository.
3. Jangan menghapus workflow root yang sudah berhasil: `.github/workflows/.../android-apk.yml`.
4. Unggah file **`The_Abyssal_Standalone_Android_v1.0.2.zip`** langsung ke root repository.
5. Jangan ekstrak ZIP di HP; workflow ZIP-extractor akan mengekstraknya pada runner GitHub.
6. Pastikan hanya satu file `The_Abyssal_Standalone*.zip` berada di root repository, lalu Commit changes ke branch `main`.

## Jalankan kompilasi

1. Buka tab **Actions**.
2. Pilih workflow **Build The Abyssal Native Android APK** yang sebelumnya sudah kamu buat.
3. Tekan **Run workflow**, pilih branch `main`, lalu jalankan.
4. Buka run terbaru dan periksa job `Compile Android APK`.
5. Status hijau **Success** berarti artifact APK selesai dibuat. Jika merah, tekan langkah pertama dengan tanda silang merah dan salin pesan error lengkap.
6. Pada hasil run, buka **Artifacts** dan download `the-abyssal-android-apk`.
7. Ekstrak ZIP artifact dan cari `app-debug.apk`.

## Instal APK

Coba pasang APK baru di atas instalasi lama. Jika Android memberi pesan signature mismatch atau App not installed, **jangan uninstall aplikasi lama**. Simpan backup JSON terlebih dahulu; menghapus aplikasi dapat menghapus save lokal.

Apabila pembaruan berhasil dipasang:

1. Buka game dan periksa versi serta layar menu.
2. Buka Continue dan periksa kelima slot.
3. Muat satu slot dan periksa posisi, inventory, equipment, bioma, bangunan, item drop, serta progres misi.
4. Lakukan Save, tutup aplikasi sepenuhnya, buka lagi, lalu periksa apakah data bertahan.
5. Uji PDA, tombol Back Android, cutscene pause/resume, joystick, naik/turun, dan batas permukaan air.
6. Uji multiplayer hanya jika Supabase dan OAuth/Realtime sudah dikonfigurasi, dengan dua perangkat dan dua akun.

## Yang diperbaiki di 1.0.2

- Save/backup sekarang divalidasi dan dinormalisasi sebelum dipakai oleh game.
- PDA terdaftar benar sebagai layar, avatar remote multiplayer terlihat, dan posisi pemain tidak bisa naik melewati permukaan air di laut terbuka.
- Tombol Back Android menutup layar/panel sesuai urutan.
- Cutscene berhenti ketika Pause aktif.
- Kegagalan sambungan room dibersihkan sehingga tidak meninggalkan state multiplayer palsu.
- Item drop, sumber daya hasil panen, dan lifepod dibersihkan dengan benar untuk mengurangi kebocoran memori.
- Backup hanya bisa dipulihkan dari menu utama, bukan saat permainan aktif atau berada di room.

## Batas penting

- Fitur online harus diaktifkan di Supabase. APK build saja tidak membuat login, Cloud Save, atau Multiplayer langsung aktif.
- Multiplayer saat ini menyinkronkan room, presence dan posisi penyelam, bukan seluruh simulasi dunia/funa/AI sebagai server-authoritative.
- Auto-update belum aktif: URL manifest di `app-update-config.js` masih kosong. Pemeriksa update hanya membuka unduhan APK setelah dikonfigurasi; Android tetap meminta persetujuan pemasangan. Update konten HTML/JS yang tertanam memerlukan APK baru pada alur saat ini.
- Voice radio memakai TTS Android, bukan voice actor rekaman.
- `npm test` adalah pemeriksaan source + tes modul save. Pengujian rendering, FPS, suara, sentuh, OAuth, Cloud Save, dan multiplayer sungguhan harus dilakukan pada perangkat/server setelah APK berhasil dibuat.
