# THE ABYSSAL — Standalone Android 1.0.2

**Rilis audit 1.0.2 berfokus pada integritas data, navigasi, batas dunia, stabilitas room multiplayer, dan pembersihan memori objek 3D.** Game tetap dapat berjalan secara lokal/offline dan Netlify tidak diperlukan.

## Perbaikan audit 1.0.2

- Menambahkan `save-schema.mjs`, yang sebelumnya dirujuk oleh `game.js` tetapi tidak ada di paket. Tanpa file ini, modul game gagal dimuat saat runtime.
- Menormalkan data lima slot dari penyimpanan lokal, backup, dan Cloud: angka dibatasi, daftar item/bioma/fauna divalidasi, struktur hanya menerima tipe yang dikenal, serta posisi dibatasi ke rentang dunia.
- Memperbaiki pemulihan backup: hanya dapat dilakukan dari menu utama, bukan saat sesi aktif/multiplayer; slot baru ditulis setelah seluruh isi backup lolos validasi.
- Ekspor backup sekarang menyimpan status slot aktif terbaru terlebih dahulu dan menolak ekspor ketika sedang berada di room multiplayer.
- Storage Locker dibatasi maksimal 99 unit per jenis, sama dengan aturan transfer permainan.
- Memperbaiki layar PDA yang sebelumnya tidak terdaftar di peta layar UI sehingga tombolnya dapat gagal menampilkannya.
- Memperbaiki avatar penyelam pemain lain yang mewarisi `visible=false` dari model first-person lokal; kini avatar remote ditampilkan dan yaw diterapkan ke root model.
- Membatasi posisi vertikal penyelam agar tidak dapat naik melewati permukaan laut di laut terbuka.
- Memperbaiki tombol Back Android untuk menutup panel Inventory/Building/PDA/Settings, melanjutkan permainan dari Pause, atau kembali ke menu yang tepat.
- Cutscene berhenti saat permainan dijeda dan kembali berjalan saat Resume.
- Kegagalan koneksi room multiplayer kini membersihkan channel dan state room; room Host yang gagal dibuat ditutup dan keanggotaan Guest yang gagal tersambung dibersihkan.
- Memperbaiki urutan payload broadcast agar `user_id` dan nama pemain tidak dapat tertimpa oleh properti state yang dikirim pemanggil.
- Memperbaiki kebocoran memori dari lifepod, node sumber daya yang dipanen, dan item drop yang diambil, dihapus, atau dipulihkan.
- Memperbarui nomor versi aplikasi menjadi 1.0.2 dan cache preview browser.

## Fitur yang tetap ada

- Dunia 3D Three.js dengan streaming chunk dan enam bioma.
- First-person, kontrol sentuh, joystick, look pad, naik/turun, Landscape, dan Fullscreen Android.
- 30 spesies fauna termasuk ikan, penyu, manta, hiu, paus, Giant Squid, dan Abyssal Leviathan.
- Survival: HP, O₂, Food, Water, kedalaman/tekanan, suhu, Medkit, Rations, dan air murni.
- Sumber daya fisik, item drop, gravitasi/drag/buoyancy, scanner, PDA, misi, cutscene pembuka, dan radio subtitle/TTS.
- Inventory, Equipment, Crafting, Habitat Building, Oxygen Station, Storage Locker, serta lima slot permainan.
- Backup/Restore JSON, penyimpanan lokal offline, dan integrasi opsional Supabase Auth/Cloud Save/Realtime Room.
- APK dibangun melalui GitHub Actions dari ponsel; tidak perlu Netlify atau Android Studio di HP.

## Catatan fitur online dan batasan yang belum selesai

- Login, Cloud Save, dan Multiplayer **tidak aktif hanya dengan mengompilasi APK**. Semuanya memerlukan project Supabase, schema SQL, secrets GitHub, OAuth provider, dan konfigurasi redirect yang benar.
- Multiplayer saat ini menyinkronkan keanggotaan room/presence dan posisi pemain. Fauna, item drop, AI, collision, survival tick, dan semua perubahan dunia **belum** direplikasi sebagai simulasi server-authoritative bersama. Host-only Shared Save dibatasi melalui policy RLS untuk tabel `room_saves`.
- `app-update-config.js` saat ini berisi URL manifest kosong. Pemeriksaan pembaruan tidak aktif sampai URL HTTPS manifest disediakan. Fitur tersebut hanya memeriksa dan membuka unduhan APK; Android tetap meminta persetujuan pemasangan. Ini bukan Live Update otomatis.
- APK workflow menghasilkan **debug APK**. Keystore debug proyek tersedia untuk build yang konsisten, tetapi jangan gunakan sebagai release key publik/Play Store. Simpan salinan aman dan jangan mengganti key antar-build jika ingin update di atas aplikasi yang sama.
- Radio menggunakan Text-to-Speech perangkat, bukan rekaman voice actor profesional. Ketersediaan suara bergantung pada voice pack Android.
- Visual dan tekstur dibuat secara prosedural/orisinal dan menggunakan model low-poly; ini bukan aset AAA atau salinan aset Subnautica. Habitat modular bebas, interior penuh, kendaraan yang dapat dikendarai, dan ekologi persisten belum lengkap.

## Build APK dari HP

Repository GitHub yang sudah dipakai user memiliki workflow ZIP-extractor di root repository. **Pertahankan workflow root tersebut.** Untuk pembaruan:

1. Ekspor backup dari Settings pada game lama dan simpan file JSON di Downloads.
2. Buka repository GitHub → Code. Hapus hanya ZIP proyek lama dari root; jangan hapus `.github/workflows` atau workflow yang sudah bekerja.
3. Unggah `The_Abyssal_Standalone_Android_v1.0.2.zip` langsung ke root repository. Tidak perlu mengekstraknya di HP.
4. Pastikan hanya ada satu file `The_Abyssal_Standalone*.zip` di root repository. Commit ke branch `main`.
5. Buka Actions → `Build The Abyssal Native Android APK` → Run workflow → `main`.
6. Jika job hijau **Success**, buka Artifacts dan unduh `the-abyssal-android-apk`, ekstrak, lalu pasang `app-debug.apk`.
7. Jika muncul `signature mismatch` atau `App not installed`, jangan uninstall aplikasi lama sebelum backup JSON tersimpan dan dapat dipulihkan.

## Pengujian

`npm test` menjalankan pemeriksaan source dan tes perilaku terhadap save-schema: lima slot, angka di luar batas, tipe struktur/material tidak dikenal, daftar fauna/bioma, backup rusak, dan konfigurasi UI/native. Pemeriksaan ini bukan pengganti pengujian WebGL atau APK pada perangkat Android.

Hal yang masih wajib diuji pada HP fisik: FPS/render WebGL di Low/Balanced/High, sentuhan joystick/look pad, keyboard dan fullscreen, instalasi update di atas APK lama, sesi save-load setelah force close, OAuth, Cloud Save lintas perangkat, dan multiplayer dengan dua perangkat. Build APK aktual baru dinyatakan berhasil setelah GitHub Actions selesai dengan status **Success**.

## Online setup (opsional)

1. Buat project Supabase.
2. Tambahkan GitHub Actions secrets `SUPABASE_URL` dan `SUPABASE_PUBLISHABLE_KEY` (gunakan publishable key, bukan service role/secret key).
3. Jalankan seluruh `supabase/schema.sql` melalui Supabase SQL Editor.
4. Tambahkan redirect `theabyssal://auth/callback` di Supabase Auth URL Configuration.
5. Aktifkan Email provider; siapkan Google/Facebook OAuth pada dashboard masing-masing lalu masukkan Client ID/Secret pada Supabase.
6. Konfigurasikan callback penyedia OAuth sesuai URL callback Supabase yang ditampilkan dashboard.
7. Jalankan ulang workflow agar URL dan publishable key dibundel ke APK.

**Jangan pernah menaruh Supabase service-role key, OAuth client secret, password, atau keystore password ke source code atau aplikasi.**
