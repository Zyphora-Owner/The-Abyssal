import { SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, NATIVE_AUTH_REDIRECT } from './supabase-config.js';

const configured = /^https:\/\/.+\.supabase\.co$/.test(SUPABASE_URL) &&
  SUPABASE_PUBLISHABLE_KEY.startsWith('sb_publishable_') &&
  !SUPABASE_URL.includes('YOUR_PROJECT_REF') &&
  !SUPABASE_PUBLISHABLE_KEY.includes('REPLACE_ME');

export class OnlineService {
  constructor() {
    this.client = null;
    this.user = null;
    this.room = null;
    this.roomChannel = null;
    this.roomRole = 'none';
    this.callbacks = {};
    this.listenersReady = false;
    this.backListenerReady = false;
    this.authLinkListenerReady = false;
    this.nativePlatform = false;
    this.App = null;
    this.Browser = null;
  }

  isConfigured() { return !!this.client; }
  isNative() { return this.nativePlatform; }
  isSignedIn() { return !!this.user; }
  isHost() { return !!this.room && this.roomRole === 'host'; }
  getUser() { return this.user; }

  async exitNativeApp() {
    if (this.nativePlatform && this.App?.exitApp) await this.App.exitApp();
  }

  requireClient() {
    if (!this.client) throw new Error('Backend belum siap. Periksa koneksi dan konfigurasi supabase-config.js.');
    return this.client;
  }

  async initialize(callbacks = {}) {
    this.callbacks = callbacks;

    // Detect the native shell even before Supabase is configured so Exit and Android
    // back-button behavior continue to work in an unconfigured development build.
    let capModule = null;
    try { capModule = await import('@capacitor/core'); } catch { /* web-only mode */ }
    try {
      this.nativePlatform = !!(capModule?.Capacitor?.isNativePlatform?.() || window.Capacitor?.isNativePlatform?.() || location.protocol === 'capacitor:');
    } catch { this.nativePlatform = location.protocol === 'capacitor:'; }

    if (this.nativePlatform) {
      try {
        const appModule = await import('@capacitor/app');
        this.App = appModule.App;
        if (!this.backListenerReady) {
          await this.App.addListener('backButton', () => this.callbacks.onNativeBack?.());
          this.backListenerReady = true;
        }
      } catch (error) {
        callbacks.onStatus?.(`Native App plugin belum siap: ${error.message}`);
      }
    }

    if (!configured) {
      callbacks.onStatus?.('Backend belum dikonfigurasi');
      return;
    }

    try {
      // Load the online SDK only when a Supabase project is configured. The 3D
      // game can still start locally while backend configuration is incomplete.
      const { createClient } = await import('@supabase/supabase-js');
      this.client = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
        auth: { autoRefreshToken: true, persistSession: true, detectSessionInUrl: !this.nativePlatform },
        realtime: { params: { eventsPerSecond: 20 } }
      });

      if (this.nativePlatform && !this.authLinkListenerReady) {
        try {
          const browserModule = await import('@capacitor/browser');
          this.Browser = browserModule.Browser;
          const consumeAuthUrl = async url => {
            if (!url || !url.startsWith(NATIVE_AUTH_REDIRECT.split('/callback')[0])) return;
            try {
              const parsed = new URL(url);
              const code = parsed.searchParams.get('code');
              if (!code) return;
              const { error } = await this.client.auth.exchangeCodeForSession(code);
              if (error) throw error;
              await this.Browser?.close?.().catch(() => {});
            } catch (error) {
              this.callbacks.onError?.(`Autentikasi native gagal: ${error.message}`);
            }
          };
          await this.App.addListener('appUrlOpen', ({ url }) => consumeAuthUrl(url));
          const launch = await this.App.getLaunchUrl?.();
          if (launch?.url) await consumeAuthUrl(launch.url);
          this.authLinkListenerReady = true;
        } catch (error) {
          this.callbacks.onStatus?.(`Native OAuth bridge belum siap: ${error.message}`);
        }
      }

      const { data, error } = await this.client.auth.getSession();
      if (error) this.callbacks.onError?.(error.message);
      this.user = data?.session?.user || null;
      this.callbacks.onAuthChange?.(this.user);

      this.client.auth.onAuthStateChange((_event, session) => {
        this.user = session?.user || null;
        // Defer callbacks so other Supabase requests are not started inside the auth lock.
        setTimeout(() => this.callbacks.onAuthChange?.(this.user), 0);
      });
    } catch (error) {
      this.client = null;
      callbacks.onStatus?.(`Online service tidak dapat dimuat: ${error.message}. Game lokal tetap dapat dimainkan.`);
    }
  }

  redirectUri() { return this.nativePlatform ? NATIVE_AUTH_REDIRECT : `${location.origin}${location.pathname}`; }

  async signUp(email, password, displayName) {
    const client = this.requireClient();
    const { data, error } = await client.auth.signUp({
      email: email.trim(), password,
      options: { emailRedirectTo: this.redirectUri(), data: { display_name: displayName || email.split('@')[0] } }
    });
    if (error) throw error;
    return data;
  }

  async signIn(email, password) {
    const { data, error } = await this.requireClient().auth.signInWithPassword({ email: email.trim(), password });
    if (error) throw error;
    return data;
  }

  async signInWithProvider(provider) {
    const client = this.requireClient();
    const { data, error } = await client.auth.signInWithOAuth({
      provider,
      options: { redirectTo: this.redirectUri(), skipBrowserRedirect: this.nativePlatform }
    });
    if (error) throw error;
    if (this.nativePlatform && data?.url) {
      if (this.Browser?.open) await this.Browser.open({ url: data.url, presentationStyle: 'popover' });
      else location.href = data.url;
    }
    return data;
  }

  async signOut() {
    if (!this.client) return;
    await this.leaveRoom();
    const { error } = await this.client.auth.signOut();
    if (error) throw error;
  }

  async loadPersonalSlots() {
    if (!this.client || !this.user) return [];
    const { data, error } = await this.client.from('game_saves')
      .select('slot, save_data, saved_at').eq('user_id', this.user.id);
    if (error) throw error;
    return (data || []).map(row => ({ slot: row.slot, record: row.save_data, savedAt: row.saved_at }));
  }

  async savePersonalSlot(slot, record) {
    if (!this.client || !this.user) return false;
    const { error } = await this.client.from('game_saves').upsert({
      user_id: this.user.id, slot, save_data: record,
      saved_at: new Date(record.savedAt || Date.now()).toISOString()
    }, { onConflict: 'user_id,slot' });
    if (error) throw error;
    return true;
  }

  async deletePersonalSlot(slot) {
    if (!this.client || !this.user) return false;
    const { error } = await this.client.from('game_saves').delete()
      .eq('user_id', this.user.id).eq('slot', slot);
    if (error) throw error;
    return true;
  }

  async createRoom(displayName, worldSeed) {
    if (!this.user) throw new Error('Login terlebih dahulu untuk membuat room.');
    const code = this.makeInviteCode();
    const { data, error } = await this.requireClient().rpc('create_game_room', {
      p_code: code, p_world_seed: worldSeed, p_display_name: displayName || this.displayName()
    });
    if (error) throw error;
    const row = Array.isArray(data) ? data[0] : data;
    const room = { id: row.room_id || row.id, code: row.room_code || code, hostId: this.user.id, worldSeed };
    try {
      await this.connectRoom(room, 'host');
      return room;
    } catch (error) {
      await this.client.from('game_rooms').update({ closed_at: new Date().toISOString() }).eq('id', room.id).catch(() => {});
      throw error;
    }
  }

  async joinRoom(code, displayName) {
    if (!this.user) throw new Error('Login terlebih dahulu untuk bergabung.');
    const { data, error } = await this.requireClient().rpc('join_game_room', {
      p_code: code.trim().toUpperCase(), p_display_name: displayName || this.displayName()
    });
    if (error) throw error;
    const row = Array.isArray(data) ? data[0] : data;
    if (!row?.room_id) throw new Error('Kode room tidak ditemukan.');
    const room = { id: row.room_id, code: row.room_code || code.trim().toUpperCase(), hostId: row.host_id, worldSeed: row.world_seed };
    try {
      await this.connectRoom(room, row.host_id === this.user.id ? 'host' : 'guest');
      return room;
    } catch (error) {
      await this.client.from('game_room_members').delete().eq('room_id', room.id).eq('user_id', this.user.id).catch(() => {});
      throw error;
    }
  }

  async connectRoom(room, role) {
    await this.leaveRoom(false);
    this.room = room;
    this.roomRole = role;
    const topic = `abyssal-room:${room.id}`;
    const channel = this.requireClient().channel(topic, {
      config: { private: true, presence: { key: this.user.id }, broadcast: { ack: true } }
    });
    this.roomChannel = channel;
    channel
      .on('broadcast', { event: 'player-state' }, ({ payload }) => this.callbacks.onPlayerState?.(payload))
      .on('broadcast', { event: 'room-closed' }, () => this.callbacks.onRoomClosed?.())
      .on('presence', { event: 'sync' }, () => this.callbacks.onPresence?.(channel.presenceState()));

    let timeoutId = 0;
    try {
      await new Promise((resolve, reject) => {
        timeoutId = setTimeout(() => reject(new Error('Koneksi multiplayer timeout. Periksa jaringan dan izin Realtime.')), 15000);
        channel.subscribe(async status => {
          if (status === 'SUBSCRIBED') {
            clearTimeout(timeoutId);
            try {
              await channel.track({ user_id: this.user.id, display_name: this.displayName(), role, online_at: new Date().toISOString() });
              resolve();
            } catch (error) { reject(error); }
          } else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
            clearTimeout(timeoutId);
            reject(new Error(`Multiplayer gagal tersambung: ${status}. Periksa kebijakan Realtime di Supabase.`));
          }
        });
      });
    } catch (error) {
      clearTimeout(timeoutId);
      await this.client.removeChannel(channel).catch(() => {});
      if (this.roomChannel === channel) {
        this.roomChannel = null;
        this.room = null;
        this.roomRole = 'none';
      }
      throw error;
    }
    this.callbacks.onRoomChange?.(this.room, this.roomRole);
  }

  async sendPlayerState(state) {
    if (!this.roomChannel || !this.room) return;
    try {
      await this.roomChannel.send({ type: 'broadcast', event: 'player-state', payload: {
        ...state, user_id: this.user.id, display_name: this.displayName()
      } });
    } catch (error) { console.warn('Gagal mengirim posisi pemain:', error); }
  }

  async loadRoomSlot(slot = 1) {
    if (!this.room || !this.client) return null;
    const { data, error } = await this.client.from('room_saves').select('save_data, saved_at')
      .eq('room_id', this.room.id).eq('slot', slot).maybeSingle();
    if (error) throw error;
    return data?.save_data || null;
  }

  async saveRoomSlot(slot, record) {
    if (!this.room || this.roomRole !== 'host') throw new Error('Hanya Host yang boleh menyimpan progres dunia multiplayer.');
    const { error } = await this.requireClient().from('room_saves').upsert({
      room_id: this.room.id, slot, save_data: record,
      saved_at: new Date(record.savedAt || Date.now()).toISOString()
    }, { onConflict: 'room_id,slot' });
    if (error) throw error;
    return true;
  }

  async leaveRoom(closeRoom = true) {
    if (!this.room) return;
    const room = this.room;
    const role = this.roomRole;
    const channel = this.roomChannel;
    this.room = null; this.roomRole = 'none'; this.roomChannel = null;
    if (role === 'host' && closeRoom && channel) {
      // Notify guests before closing; keep the room save rows for future archival.
      await channel.send({ type: 'broadcast', event: 'room-closed', payload: { reason: 'host-left' } }).catch(() => {});
    }
    if (this.client && this.user) {
      if (role === 'host') {
        // A Host leaving without a broadcast (for example, after a timeout or room switch)
        // still closes the room so it cannot remain joinable without its owner.
        await this.client.from('game_rooms').update({ closed_at: new Date().toISOString() }).eq('id', room.id).catch(() => {});
      } else {
        await this.client.from('game_room_members').delete().eq('room_id', room.id).eq('user_id', this.user.id).catch(() => {});
      }
    }
    if (channel) await this.client.removeChannel(channel).catch(() => {});
    this.callbacks.onRoomChange?.(null, 'none');
  }

  displayName() {
    return this.user?.user_metadata?.display_name || this.user?.user_metadata?.full_name || this.user?.email?.split('@')[0] || 'Diver';
  }

  makeInviteCode() {
    const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    const bytes = new Uint8Array(6);
    crypto.getRandomValues(bytes);
    return Array.from(bytes, value => alphabet[value % alphabet.length]).join('');
  }
}
