import { readFile, access, readdir } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';
import {
  normalizeGameSettings,
  normalizeSaveRecord,
  normalizeBackupPayload,
  SAVE_SCHEMA_VERSION,
  SLOT_COUNT
} from '../save-schema.mjs';

const root = resolve(fileURLToPath(new URL('..', import.meta.url)));
const read = path => readFile(join(root, path), 'utf8');
const html = await read('index.html');
const game = await read('game.js');
const fauna = await read('fauna.js');
const styles = await read('styles.css');
const online = await read('online.js');
const schemaSql = await read('supabase/schema.sql');
const manifest = JSON.parse(await read('manifest.webmanifest'));
const cap = JSON.parse(await read('capacitor.config.json'));
const pkg = JSON.parse(await read('package.json'));
const nativeBuilder = await read('scripts/build-native.mjs');
const nativePatcher = await read('scripts/patch-android.mjs');
const buildWorkflow = await read('.github/workflows/android-apk.yml');
const serviceWorker = await read('sw.js');
const mobileGuide = await read('BUILD_DARI_PONSEL.md');
const readme = await read('README_ID.md');
const updaterConfig = await read('app-update-config.js');

// 1) DOM integrity: unique IDs and statically referenced nodes must exist.
const allIds = [...html.matchAll(/\bid="([^"]+)"/g)].map(match => match[1]);
const idSet = new Set(allIds);
const duplicates = allIds.filter((id, index) => allIds.indexOf(id) !== index);
assert.deepEqual([...new Set(duplicates)], [], 'Duplicate HTML IDs exist');
const staticRefs = [...game.matchAll(/\$\('([^']+)'\)/g)].map(match => match[1]);
const missingRefs = [...new Set(staticRefs.filter(id => !idSet.has(id)))];
assert.deepEqual(missingRefs, [], `Missing HTML IDs: ${missingRefs.join(', ')}`);

// Every local module import and static HTML asset must resolve inside the archive.
for (const match of html.matchAll(/(?:src|href)=\"\.\/([^?#\"]+)/g)) {
  const asset = match[1];
  await access(join(root, asset));
}
for (const sourceFile of ['game.js','online.js','fauna.js','save-schema.mjs']) {
  const source = await read(sourceFile);
  for (const match of source.matchAll(/(?:from\s*|import\s*\()(['\"])(\.\/[^'\"]+)\1/g)) {
    const target = match[2];
    await access(join(root, sourceFile.split('/').slice(0,-1).join('/'), target));
  }
}

for (const id of [
  'hp-fill','oxygen-fill','food-fill','water-fill','pressure-fill','pressure-value','biome-label','pda-btn','pda-screen',
  'biome-log','species-log','craft-water-btn','water-btn','craft-tank-btn','craft-fins-btn','craft-rebreather-btn',
  'craft-suit-btn','storage-store-btn','storage-take-btn','scan-btn','medkit-btn','ration-btn','supply-btn',
  'damage-flash','fauna-label','inventory-btn','build-btn','gather-btn','inventory-screen','build-screen',
  'inventory-capacity','inventory-overflow','equipment-list','inventory-quickbar','hotbar','target-label',
  'interact-btn','use-item-btn','bed-btn','exit-habitat-btn','fabricator-screen','fabricator-close-btn','fabricator-tabs','fabricator-recipes','autosave-toggle',
  'aim-reticle','export-save-btn','import-save-btn','import-save-file','mission-title','mission-objective',
  'mission-progress','mission-log','mission-action-btn','harvest-btn','eat-fish-btn','cinematic-overlay',
  'cinematic-line','cinematic-speaker','cinematic-skip','radio-subtitle','radio-line'
]) assert.ok(idSet.has(id), `Required UI element missing: ${id}`);

// 2) Save-schema behavioural tests: corrupted values must never reach gameplay unchecked.
assert.equal(SLOT_COUNT, 5);
assert.equal(SAVE_SCHEMA_VERSION, 8);
assert.deepEqual(normalizeGameSettings({ graphics:'ultra', renderDistance:99, volume:-5, fov:140, language:'xx' }), {
  graphics:'balanced', renderDistance:3, volume:0, fov:90, language:'id', autoSave:true
});
const normalized = normalizeSaveRecord({
  version: 2,
  savedAt: 'bad-date',
  position: { x: 1e30, y: 200, z: -1e30 },
  yaw: 'NaN', pitch: 99,
  survival: { hp:-20, oxygen:9999, food:'bad', water:51, medkits:999, rations:-3 },
  inventory: { titanium:-9, copper: '4.7', quartz: 10000, invalid: 12 },
  equipment: { tankLevel: 8, fins: 1, rebreather:true },
  discoveries: ['clownfish','not-a-species','abyssal_leviathan'],
  knownBiomes: ['reef','bogus','abyss'],
  collectedCaches: ['verdant_cache','bogus'],
  collectedResources: ['1:2:ore:3','bad-key'],
  placedStructures: [
    { id:'build-1', type:'beacon', x:4, y:-8, z:9, yaw:2 },
    { id:'bad', type:'teleporter', x:0, y:0, z:0 }
  ],
  droppedItems: [
    { id:'drop-1', type:'glowcap', position:{x:2,y:-9,z:3} },
    { id:'bad', type:'explosive', position:{x:0,y:0,z:0} }
  ],
  story: { introSeen:true, missionIndex:999, counters:{materials:99}, completed:['lifepod','evil'] }
});
assert.ok(normalized, 'A valid legacy record should normalize');
assert.equal(normalized.version, SAVE_SCHEMA_VERSION);
assert.deepEqual(normalized.position, { x:1_000_000, y:28, z:-1_000_000 });
assert.equal(normalized.survival.hp, 0);
assert.equal(normalized.survival.oxygen, 185);
assert.equal(normalized.survival.medkits, 20);
assert.equal(normalized.inventory.titanium, 0);
assert.equal(normalized.inventory.copper, 5);
assert.equal(normalized.inventory.quartz, 999);
assert.equal(normalized.equipment.tankLevel, 2);
assert.equal(normalized.equipment.reinforcedSuitOwned, false);
assert.equal(normalized.equipment.helmetOwned, false);
assert.deepEqual(normalized.hotbar, ['scanner','knife','flashlight','explorer_pda',null]);
assert.deepEqual(normalized.discoveries, ['clownfish','abyssal_leviathan']);
assert.deepEqual(normalized.knownBiomes, ['reef','abyss']);
assert.deepEqual(normalized.collectedCaches, ['verdant_cache']);
assert.deepEqual(normalized.collectedResources, ['1:2:ore:3']);
assert.equal(normalized.placedStructures.length, 1);
assert.equal(normalized.droppedItems.length, 1);
assert.equal(normalized.story.missionIndex, 7);
assert.equal(normalized.story.counters.materials, 3);
assert.equal(normalizeSaveRecord({ totally:'invalid' }), null);
const validBackup = normalizeBackupPayload({
  format:'the-abyssal-save-backup', schemaVersion:1, slots:[normalized,null,null,null,null], settings:{volume:120}
});
assert.equal(validBackup.slots.length, 5);
assert.equal(validBackup.settings.volume, 100);
assert.throws(() => normalizeBackupPayload({ format:'wrong', slots:[] }), /Format backup/);
assert.throws(() => normalizeBackupPayload({ format:'the-abyssal-save-backup', slots:[null] }), /tepat lima slot/);
assert.throws(() => normalizeBackupPayload({ format:'the-abyssal-save-backup', slots:[{bad:true},null,null,null,null] }), /Slot 1/);

// 3) Game-state integrity fixes.
assert.ok(game.includes("pda: $('pda-screen')"), 'PDA screen must be registered in UI map');
assert.match(game, /function openPda\(\)[\s\S]*?setVisibleScreen\('pda'\)/, 'PDA must open through its registered screen');
assert.match(game, /group\.visible = true/, 'Remote multiplayer avatars must be visible');
assert.match(game, /remote\.group\.rotation\.y = remote\.yaw/, 'Remote yaw must apply to the avatar root');
assert.match(game, /function handleNativeBack\(\)/, 'Android back navigation handler missing');
assert.match(game, /onNativeBack: handleNativeBack/, 'Native back event not connected');
assert.match(game, /const upperBound=Math\.max\(-0\.45,floorClearance\)/, 'Player must not swim above the water surface');
assert.match(game, /if\(introSequence\.active && !gamePaused\)/, 'Cinematic timeline must stop while paused');
assert.match(game, /function disposeObjectTree\(/, 'Object disposal utility missing');
assert.match(game, /function disposeWorldDrop\(/, 'Dropped-item cleanup missing');
assert.match(game, /function normalizeBackupPayload|normalizeBackupPayload\(payload\)/, 'Backup validation is not wired');
assert.match(game, /version: 8/, 'New saves must be written using normalized schema v8');
assert.match(game, /const current = '1\.1\.0'/, 'App update comparison version does not match package version');

// 4) Fauna, survival, build, and cinematic wiring.
assert.equal([...fauna.matchAll(/\{ id:'[^']+', name:'[^']+'/g)].length, 30, 'Expected 30 distinct species records');
for (const name of ['Abyssal Leviathan','Humpback Whale','Hammerhead Shark','Giant Squid','Clownfish','Blue Tang','Jellyfish','Green Sea Turtle']) assert.ok(fauna.includes(name), `Fauna missing: ${name}`);
assert.match(fauna, /update\(dt, playerPosition/, 'Fauna update loop missing');
assert.match(game, /function updateSurvival\(dt\)/, 'Survival simulation missing');
assert.match(game, /function updateWorldPhysics\(dt\)/, 'Dropped item physics missing');
assert.match(game, /function placeStructure\(type\)/, 'Building interaction missing');
assert.match(game, /function craftEquipment\(kind\)/, 'Equipment crafting missing');
assert.match(game, /function packInventory\(entries = getInventoryEntries\(\)\)/, '27-slot footprint inventory packing missing');
assert.match(game, /function renderHotbar\(\)/, 'Five-slot hotbar is missing');
assert.match(game, /const SURVIVAL_DEFAULTS = \{ hp: 100, oxygen: 45/, 'Starting oxygen must be 45');
assert.match(game, /function useSelectedHotbarItem\(\)/, 'Selected consumable use action is missing');
assert.match(game, /selected==='habitat_builder'[\s\S]*?openBuildMenu\(\)/, 'Build interaction must require the Habitat Builder');
assert.match(game, /function openFabricator\(\)/, 'Interior fabricator access missing');
assert.match(game, /settings\.autoSave !== false[\s\S]*?autoSaveTimer >= 300/, 'Five-minute configurable auto-save missing');
assert.match(game, /2 \+ Math\.floor\(Math\.random\(\) \* 3\)/, 'Normal oxygen consumption must randomly use 2–4');
assert.match(game, /4 \+ Math\.floor\(Math\.random\(\) \* 5\)/, 'Overload oxygen consumption must randomly use 4–8');
assert.doesNotMatch(game.match(/function openSupplyCache\(\)[\s\S]*?\n\}/)?.[0] || '', /survival\.oxygen\s*=.*\+/ , 'Outside supply caches must not refill oxygen');
assert.match(game, /Pilih Survival Knife pada Hotbar/, 'Resource harvesting must require a selected knife');
assert.match(game, /function isNearHabitatBed\(/, 'Bed checkpoint proximity check missing');
assert.match(game, /function isNearFabricator\(/, 'Fabricator interior access check missing');
assert.match(game, /function updateCinematic\(dt\)/, 'Intro cinematic timeline missing');
assert.match(game, /function advanceMission\(eventId\)/, 'Mission progression missing');
assert.match(game, /speechSynthesis/, 'Device TTS integration missing');
assert.ok(styles.includes('.survival-panel') && styles.includes('.action-controls') && styles.includes('.cinematic-overlay'));
assert.ok(styles.includes('.inventory-slot-grid') && styles.includes('.hotbar-slot') && styles.includes('.fabricator-recipes'));

// 5) Native build, online safeguards and offline packaging.
assert.equal(manifest.orientation, 'landscape');
assert.equal(cap.appId, 'com.abyssal.game');
assert.equal(cap.webDir, 'www');
assert.ok(pkg.version === '1.1.0');
assert.ok(pkg.dependencies.three && pkg.dependencies['@supabase/supabase-js'] && pkg.dependencies['@capacitor/android']);
assert.ok(pkg.devDependencies.vite);
assert.match(nativeBuilder, /await build\(/);
assert.match(nativePatcher, /adjustPan/);
assert.match(nativePatcher, /screenOrientation="landscape"/);
assert.match(nativePatcher, /WindowInsetsController/);
assert.match(nativePatcher, /android\.permission\.INTERNET/);
assert.match(online, /exchangeCodeForSession\(code\)/);
assert.match(online, /saveRoomSlot\(slot, record\)/);
assert.match(online, /this\.roomRole !== 'host'/, 'Room save must be host-only in client code');
assert.match(online, /removeChannel\(channel\)/, 'Failed Realtime channel must be cleaned up');
assert.match(online, /role === 'host'\) \{[\s\S]*?closed_at/, 'A Host leaving must close their room');
assert.ok(schemaSql.includes('alter table public.room_saves enable row level security'));
assert.ok(schemaSql.includes('room save insert host') && schemaSql.includes('room save update host'));
assert.match(buildWorkflow, /workflow_dispatch:/);
assert.match(buildWorkflow, /actions\/upload-artifact@v4/);
assert.match(buildWorkflow, /SUPABASE_URL/);
assert.match(mobileGuide, /ponsel/i);
assert.match(readme, /Netlify tidak diperlukan/i);
assert.match(updaterConfig, /ABYSSAL_UPDATE_MANIFEST_URL = ''/);
assert.match(readme, /Live Update|pembaruan.*APK/i, 'Update limitations must be documented');

try { await access(join(root, 'netlify.toml')); assert.fail('Netlify deployment config should not exist'); }
catch (error) { if (error.code !== 'ENOENT') throw error; }

console.log(`Audit verification passed: ${allIds.length} unique HTML IDs, ${staticRefs.length} static DOM refs, v8 save migration, 27-slot inventory, 5-slot hotbar, habitat/fabricator/checkpoint, oxygen and five-minute auto-save, reticle interactions, Android navigation, survival/cinematic/fauna wiring, native configuration, and online host-save guards.`);
