# Build APK The Abyssal 1.5.0 dari HP

## Persiapan

1. Unduh `The_Abyssal_Standalone_Android_v1.5.0.zip`.
2. Ekspor Backup JSON dari versi lama dan simpan di Downloads.
3. Buka repository GitHub yang sebelumnya digunakan untuk build APK.

## Menjalankan build

1. Hapus ZIP proyek lama dari root repository (jangan menghapus workflow Actions).
2. Unggah ZIP v1.5.0 ke root repository tanpa mengekstraknya di HP.
3. Pastikan hanya ada satu ZIP `The_Abyssal_Standalone*.zip` di root.
4. Commit dan push ke `main`/`master`, atau jalankan workflow manual.
5. Buka **Actions → Build The Abyssal Native Android APK** dan tunggu status **Success**.
6. Unduh artifact `the-abyssal-android-apk`, ekstrak, lalu pasang `app-debug.apk`.

## Uji setelah pemasangan

- Pulihkan Backup JSON jika diperlukan.
- Uji joystick, kamera sentuh, HUD, lima Quick Slots, Backpack 6×8, PDA, Scanner, dan Interact.
- Kumpulkan Titanium, Creepvine, Copper Ore, dan Quartz; buat Silicone Rubber, Battery, kemudian Repair Tool di Fabricator Lifepod. Pilih Repair Tool dan perbaiki konsol.
- Buat Seaglide, pilih alat itu, bergerak hingga daya berkurang, lalu gunakan tombol Battery dengan baterai cadangan.
- Uji O₂: berkurang saat menyelam, pulih di permukaan, dan pulih hanya di bagian dalam habitat berdaya.
- Buat save manual, keluar, lalu Load slot tersebut.

## Catatan

- Rilis ini single-player offline dan tidak membutuhkan akun, Supabase, OAuth, Cloud Save, atau Multiplayer.
- APK debug belum dianggap berhasil sebelum GitHub Actions selesai dengan status **Success** dan aplikasi diuji langsung pada perangkat.
- Jangan uninstall versi lama sebelum Backup JSON diamankan. Jika signature berbeda, update APK lama dapat ditolak Android.
