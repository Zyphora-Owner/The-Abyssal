/**
 * Defensive normalization for local offline save data.
 * Save files are untrusted input: validate shapes and clamp numbers before they
 * reach Three.js objects, UI counters, or gameplay state.
 */

export const SAVE_SCHEMA_VERSION = 11;
export const SLOT_COUNT = 5;

const BIOMES = new Set(['reef', 'kelp', 'wreck', 'thermal', 'abyss', 'open']);
const SPECIES = new Set([
  'clownfish','blue_tang','butterflyfish','angelfish','parrotfish','lionfish','yellowfin_tuna','barracuda',
  'seahorse','pufferfish','moorish_idol','triggerfish','moray_eel','bioluminescent_angler','jellyfish',
  'sea_turtle','manta_ray','reef_shark','hammerhead','humpback_whale','sperm_whale','blue_whale','orca',
  'giant_squid','abyssal_leviathan','glass_shrimp','ribbon_eel','reef_cuttlefish','vent_crab','lantern_fish'
]);
const RESOURCE_TYPES = new Set(['titanium','copper','quartz','kelp','coral','lithium','sulfur','magnetite','salt','glowcap','fish_meat','glass','silicone','fiber_mesh','battery','wiring_kit','computer_chip','silver','power_cell','lubricant','bleach']);
const STRUCTURE_TYPES = new Set(['beacon','foundation','compartment','storage_locker','solar_array']);
const CACHE_IDS = new Set(['verdant_cache','wreck_cache']);
const MISSION_IDS = new Set(['lifepod','scan','materials','fish','craft','build','wreck','freeplay']);
const INVENTORY_KEYS = [...RESOURCE_TYPES];
const TOOL_TYPES = new Set(['explorer_pda','scanner','knife','flashlight','habitat_builder','repair_tool','seaglide']);

const isObject = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const finite = (value, fallback, min, max) => {
  const number = typeof value === 'number' || (typeof value === 'string' && value.trim() !== '') ? Number(value) : NaN;
  return Number.isFinite(number) ? Math.min(max, Math.max(min, number)) : fallback;
};
const integer = (value, fallback, min, max) => Math.round(finite(value, fallback, min, max));
const bool = (value, fallback = false) => typeof value === 'boolean' ? value : fallback;
const safeString = (value, max = 80, fallback = '') => typeof value === 'string' ? value.replace(/[\u0000-\u001f\u007f]/g, '').slice(0, max) : fallback;
const uniqueStrings = (value, allow, max = 1000) => Array.isArray(value)
  ? [...new Set(value.filter(item => typeof item === 'string' && allow.has(item)))].slice(0, max)
  : [];

function normalizeInventory(value, maxCount = 999) {
  const source = isObject(value) ? value : {};
  return Object.fromEntries(INVENTORY_KEYS.map(key => [key, integer(source[key], 0, 0, maxCount)]));
}

function normalizePosition(value, fallback = { x: 0, y: -7, z: 0 }) {
  const source = isObject(value) ? value : {};
  return {
    x: finite(source.x, fallback.x, -1_000_000, 1_000_000),
    y: finite(source.y, fallback.y, -42, 28),
    z: finite(source.z, fallback.z, -1_000_000, 1_000_000)
  };
}

export function normalizeGameSettings(value = {}) {
  const source = isObject(value) ? value : {};
  const graphics = ['low','balanced','high'].includes(source.graphics) ? source.graphics : 'balanced';
  return {
    graphics,
    renderDistance: integer(source.renderDistance, 2, 1, 3),
    volume: integer(source.volume, 55, 0, 100),
    fov: integer(source.fov, 70, 55, 90),
    language: ['id','en'].includes(source.language) ? source.language : 'id'
  };
}

export function normalizeSaveRecord(value) {
  if (!isObject(value)) return null;
  if (!isObject(value.position) && !isObject(value.survival) && !isObject(value.inventory)) return null;

  const source = value;
  const equipmentSource = isObject(source.equipment) ? source.equipment : {};
  const survivalSource = isObject(source.survival) ? source.survival : {};
  // Existing v7 saves used a 100-unit base tank. Preserve their capacity by
  // migrating them to the first upgrade instead of silently deleting oxygen.
  const legacyTank = finite(survivalSource.oxygen, 45, 0, 300) > 45 && Number(source.version || 0) < 8 ? 1 : 0;
  const tankLevel = integer(equipmentSource.tankLevel, legacyTank, 0, 3);
  const maxOxygen = 45 + tankLevel * 30;
  const survival = {
    hp: finite(survivalSource.hp, 100, 0, 100),
    oxygen: finite(survivalSource.oxygen, maxOxygen, 0, maxOxygen),
    food: finite(survivalSource.food, 100, 0, 100),
    water: finite(survivalSource.water, 100, 0, 100),
    medkits: integer(survivalSource.medkits, 2, 0, 20),
    rations: integer(survivalSource.rations, 3, 0, 20),
    waterBottles: integer(survivalSource.waterBottles, 2, 0, 20),
    schemaVersion: 3
  };

  const storySource = isObject(source.story) ? source.story : {};
  const countersSource = isObject(storySource.counters) ? storySource.counters : {};
  const missionIndex = integer(storySource.missionIndex, 0, 0, 7);
  const story = {
    introSeen: bool(storySource.introSeen, missionIndex > 0),
    missionIndex,
    counters: { materials: integer(countersSource.materials, 0, 0, 3) },
    completed: uniqueStrings(storySource.completed, MISSION_IDS, 8)
  };

  const structures = Array.isArray(source.placedStructures) ? source.placedStructures.slice(0, 500).flatMap((item, index) => {
    if (!isObject(item) || !STRUCTURE_TYPES.has(item.type)) return [];
    const position = normalizePosition(item, { x: 0, y: -8, z: 0 });
    return [{
      id: safeString(item.id, 80, `legacy-build-${index + 1}`),
      type: item.type,
      x: position.x,
      y: position.y,
      z: position.z,
      yaw: finite(item.yaw, 0, -Math.PI * 8, Math.PI * 8),
      builtAt: integer(item.builtAt, 0, 0, 9_999_999_999_999)
    }];
  }) : [];

  const drops = Array.isArray(source.droppedItems) ? source.droppedItems.slice(0, 80).flatMap((item, index) => {
    if (!isObject(item) || !RESOURCE_TYPES.has(item.type) || !isObject(item.position)) return [];
    const position = normalizePosition(item.position);
    return [{
      id: safeString(item.id, 100, `restored-drop-${index}`),
      type: item.type,
      position
    }];
  }) : [];

  const collectedResources = Array.isArray(source.collectedResources)
    ? [...new Set(source.collectedResources.filter(item => typeof item === 'string' && /^-?\d{1,6}:-?\d{1,6}:ore:\d{1,4}$/.test(item)))].slice(0, 20000)
    : [];

  const knownBiomeValues = uniqueStrings(source.knownBiomes, BIOMES, 6);
  const collectedCacheValues = uniqueStrings(source.collectedCaches, CACHE_IDS, 2);

  return {
    version: SAVE_SCHEMA_VERSION,
    savedAt: integer(source.savedAt, 0, 0, 9_999_999_999_999),
    position: normalizePosition(source.position),
    yaw: finite(source.yaw, 0, -Math.PI * 8, Math.PI * 8),
    pitch: finite(source.pitch, 0.08, -1.15, 1.15),
    survival,
    discoveries: uniqueStrings(source.discoveries, SPECIES, SPECIES.size),
    collectedCaches: collectedCacheValues,
    inventory: normalizeInventory(source.inventory),
    equipment: {
      tankLevel,
      fins: bool(equipmentSource.fins),
      rebreather: bool(equipmentSource.rebreather),
      seaglideCharge: integer(equipmentSource.seaglideCharge, Array.isArray(source.ownedTools) && source.ownedTools.includes('seaglide') ? 100 : 0, 0, 100)
    },
    ownedTools: Array.isArray(source.ownedTools)
      ? [...new Set(source.ownedTools.filter(item => TOOL_TYPES.has(item)))].slice(0, TOOL_TYPES.size)
      : ['explorer_pda','scanner','knife','flashlight'],
    hotbar: Array.isArray(source.hotbar)
      ? Array.from({ length: 5 }, (_, index) => { const item = source.hotbar[index]; return typeof item === 'string' && item !== 'explorer_pda' && (TOOL_TYPES.has(item) || RESOURCE_TYPES.has(item) || ['medkit','ration','water'].includes(item)) ? item : null; })
      : ['scanner','knife','flashlight',null,null],
    selectedHotbar: integer(source.selectedHotbar, 0, 0, 4),
    // Older saves may contain custom respawn coordinates; reset them to the Lifepod start.
    respawnPoint: Number(source.version) >= 10 ? normalizePosition(source.respawnPoint, { x: 0, y: -7, z: 0 }) : { x: 0, y: -7, z: 0 },
    lockerStorage: normalizeInventory(source.lockerStorage, 99),
    knownBiomes: knownBiomeValues,
    collectedResources,
    placedStructures: structures,
    story,
    droppedItems: drops
  };
}

export function normalizeBackupPayload(payload) {
  if (!isObject(payload) || payload.format !== 'the-abyssal-save-backup') {
    throw new Error('Format backup THE ABYSSAL tidak dikenali. Pilih file JSON hasil Export Save.');
  }
  if (!Array.isArray(payload.slots) || payload.slots.length !== SLOT_COUNT) {
    throw new Error('Backup harus berisi tepat lima slot penyimpanan.');
  }
  const slots = payload.slots.map((record, index) => {
    if (record === null) return null;
    const normalized = normalizeSaveRecord(record);
    if (!normalized) throw new Error(`Data Slot ${index + 1} rusak atau tidak valid.`);
    return normalized;
  });
  return {
    slots,
    settings: normalizeGameSettings(payload.settings),
    exportedAt: safeString(payload.exportedAt, 40, '')
  };
}
