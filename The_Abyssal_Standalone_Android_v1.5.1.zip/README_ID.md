# THE ABYSSAL — Android Standalone 1.5.1

**The Abyssal 1.5.1** menyelaraskan sistem survival dan interaksi ke pola game eksplorasi bawah laut single-player yang terinspirasi Subnautica. Identitas, cerita, fauna, bioma, dan aset orisinal The Abyssal tetap dipakai; proyek ini bukan salinan kode maupun aset Subnautica.

## Sistem gameplay 1.5.1

### Survival dan oksigen
- Oksigen awal **45**. Konsumsi dasar berlangsung kontinu sekitar **1 unit per detik**.
- Oksigen pulih di permukaan atau ketika penyelam benar-benar berada di dalam Lifepod/habitat yang berdaya. Tidak ada refill dari luar habitat.
- Tangki O₂ meningkatkan kapasitas sebesar 30 per upgrade. Rebreather mengurangi konsumsi pada kedalaman mulai 20 m.
- HP, Food, dan Water tetap menjadi statistik survival. Medkit, makanan, dan air dibuat melalui Fabricator.
- Tidak ada chestplate, armor tekanan, slot helmet terpisah, damage tekanan/suhu, atau Oxygen Station luar habitat.

### Inventory, peralatan, dan kendaraan ringan
- Backpack memakai grid **6 × 8 (48 sel)**. Item memiliki footprint berbeda: 1×1, 1×2, 2×1, 2×2, atau 2×3.
- Lima Quick Slots. Explorer PDA tetap disimpan di Backpack dan dibuka lewat tombol PDA, bukan Quick Slot.
- Equipment penyelam: O₂ Tank, Swim Fins, dan Rebreather. Peralatan tangan: Scanner, Survival Knife, Flashlight, Habitat Builder, Repair Tool, dan Seaglide.
- **Repair Tool** wajib dimiliki dan dipilih untuk memperbaiki konsol Lifepod pada direktif pertama. Konsol berubah dari indikator rusak menjadi aktif setelah diperbaiki.
- **Seaglide** meningkatkan kecepatan saat dipakai dan mengonsumsi daya ketika penyelam bergerak. Persentase daya terlihat pada Quick Slot. Tombol Battery mengganti baterai dengan satu Battery dari Backpack; baterai baru mengisi daya hingga 100%.

### Interaksi dan pembangunan
- Satu tombol **Interact** mengikuti target reticle: memasuki habitat, membuka Fabricator/Wall Locker/peti, mengambil drop, menangkap fauna kecil, memecahkan ore, memotong Creepvine, atau membuka Build.
- Scanner memerlukan alat dipilih dan fauna berada pada garis bidik tengah.
- Build hanya tersedia ketika Habitat Builder dimiliki dan dipilih. Struktur yang tersedia: Multipurpose Room, Foundation, Wall Locker, Solar Panel, dan Beacon.
- Lifepod memiliki interior, Fabricator, dan suplai O₂. Multipurpose Room memerlukan Solar Panel di dekatnya untuk memasok daya.
- Fabricator memakai empat kategori: **Sustenance, Personal, Resources, Electronics**.

### Dunia dan progres
- Dunia 3D memuat enam bioma, 30 spesies fauna, resource nodes, supply caches, wreck, misi, radio, dan cutscene pembuka.
- Permainan adalah **single-player offline**. Login, cloud save, multiplayer, dan layanan online tidak disertakan.
- Lima slot save. Progres disimpan manual melalui Pause; Auto Save dan checkpoint kasur telah dihapus. Setelah pingsan, penyelam kembali ke Lifepod atau habitat aman terakhir.
- Backup/Restore JSON tersedia di Settings. Save lama dimigrasikan ke schema **v11**. Pemilik Seaglide dari save lama menerima baterai awal 100% agar alat tidak menjadi tidak dapat digunakan setelah upgrade.

## Build Android

Proyek memakai Vite, Three.js, dan Capacitor. GitHub Actions membangun APK debug melalui workflow **Build The Abyssal Native Android APK**. Workflow versi ini juga memuat skrip kompatibilitas `configure-backend.mjs`; skrip tersebut sengaja melewati konfigurasi backend karena game offline tidak menggunakan backend. ZIP dapat diunggah ke root repository; workflow mencari folder proyek di dalam arsip.

Sebelum memasang versi baru, ekspor backup JSON. Pertahankan application ID `com.abyssal.game` dan gunakan signing key yang sama agar APK dapat memperbarui instalasi sebelumnya.

## Batasan yang diketahui

- Pemeriksaan source dan `npm test` berhasil, tetapi APK belum berhasil dikompilasi dan diuji pada perangkat Android di lingkungan ini.
- Kendaraan Seamoth/Cyclops/Prawn, fragment-blueprint progression, simulasi hull integrity habitat, dan ekologi persisten masih belum diimplementasikan. Seaglide adalah alat mobilitas bawah air, bukan kendaraan yang dapat dikendarai terpisah.
- Visual dan aset merupakan karya orisinal/prosedural The Abyssal; detailnya belum setara game komersial Subnautica.
