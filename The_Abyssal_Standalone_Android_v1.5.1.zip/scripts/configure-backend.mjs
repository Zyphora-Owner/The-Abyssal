/**
 * Compatibility entry point for older GitHub Actions workflows.
 * The Abyssal 1.5.x is an offline, single-player application and has no backend.
 * This script intentionally performs no network calls, secret lookup, file edits,
 * or environment mutation. Keeping the path prevents stale workflows from
 * failing with MODULE_NOT_FOUND while repositories are being updated.
 */
console.log('[The Abyssal] Backend setup skipped: this release is fully local/offline.');
console.log('[The Abyssal] No Supabase, OAuth, cloud-save, or backend secrets are required.');
