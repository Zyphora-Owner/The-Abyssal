import { readFile, access, readdir } from 'node:fs/promises';
import { resolve, join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';
import {
  normalizeGameSettings,
  normalizeSaveRecord,
  normalizeBackupPayload,
  SAVE_SCHEMA_VERSION,
  SLOT_COUNT
} from '../save-schema.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const read = path => readFile(join(root, path), 'utf8');
const [html, game, fauna, styles, schema, manifestText, capacitorText, packageText, workflow, serviceWorker, nativeBuilder, nativePatcher, readme, backendSetup, gitignore] = await Promise.all([
  read('index.html'), read('game.js'), read('fauna.js'), read('styles.css'), read('save-schema.mjs'),
  read('manifest.webmanifest'), read('capacitor.config.json'), read('package.json'),
  read('.github/workflows/android-apk.yml'), read('sw.js'), read('scripts/build-native.mjs'), read('scripts/patch-android.mjs'), read('README_ID.md'), read('scripts/configure-backend.mjs'), read('.gitignore')
]);
const manifest = JSON.parse(manifestText);
const capacitor = JSON.parse(capacitorText);
const pkg = JSON.parse(packageText);

// DOM IDs must be unique, and every static game.js lookup must point to an element.
const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map(match => match[1]);
const idSet = new Set(ids);
const duplicates = [...new Set(ids.filter((id, index) => ids.indexOf(id) !== index))];
assert.deepEqual(duplicates, [], `Duplicate DOM IDs: ${duplicates.join(', ')}`);
const staticRefs = [...game.matchAll(/\$\(['"]([^'"]+)['"]\)/g)].map(match => match[1]);
const missing = [...new Set(staticRefs.filter(id => !idSet.has(id)))];
assert.deepEqual(missing, [], `Missing DOM nodes: ${missing.join(', ')}`);

// Local assets and module imports must resolve from the archive itself.
for (const match of html.matchAll(/(?:src|href)="\.\/([^?#"]+)/g)) {
  const target = match[1];
  if (!target.startsWith('data:')) await access(join(root, target));
}
for (const sourceFile of ['game.js', 'fauna.js', 'save-schema.mjs']) {
  const source = await read(sourceFile);
  for (const match of source.matchAll(/(?:from\s*|import\s*\()(['"])(\.\/[^"]+?)\1/g)) {
    await access(join(root, dirname(sourceFile), match[2]));
  }
}
for (const match of game.matchAll(/icon:'([a-z0-9_-]+)'/gi)) {
  await access(join(root, 'icons', 'items', `${match[1]}.png`));
}
for (const match of html.matchAll(/\.\/icons\/([^"']+\.png)/g)) {
  await access(join(root, 'icons', match[1]));
}

// Save migration: old custom bed checkpoints and PDA hotbar assignments are retired.
assert.equal(SLOT_COUNT, 5);
assert.equal(SAVE_SCHEMA_VERSION, 11);
assert.deepEqual(normalizeGameSettings({ graphics: 'ultra', renderDistance: 99, volume: -5, fov: 140, language: 'xx', autoSave: true }), {
  graphics: 'balanced', renderDistance: 3, volume: 0, fov: 90, language: 'id'
});
const legacy = normalizeSaveRecord({
  version: 8,
  savedAt: 'bad-date',
  position: { x: 15, y: -12, z: -9 },
  respawnPoint: { x: 750, y: -24, z: -360 },
  yaw: 'NaN', pitch: 99,
  survival: { hp: -20, oxygen: 110, food: 'bad', water: 51, medkits: 999, rations: -3 },
  inventory: { titanium: -9, copper: '4.7', quartz: 10000, invalid: 12 },
  equipment: { tankLevel: 2, fins: 1, rebreather: true, reinforcedSuitOwned: true, helmetOwned: true },
  ownedTools: ['explorer_pda', 'scanner', 'knife', 'flashlight'],
  hotbar: ['explorer_pda', 'scanner', 'knife', 'flashlight', null],
  discoveries: ['clownfish', 'not-a-species', 'abyssal_leviathan'],
  knownBiomes: ['reef', 'bogus', 'abyss'],
  collectedCaches: ['verdant_cache', 'bogus'],
  collectedResources: ['1:2:ore:3', 'bad-key'],
  placedStructures: [
    { id: 'build-1', type: 'beacon', x: 4, y: -8, z: 9, yaw: 2 },
    { id: 'bad', type: 'teleporter', x: 0, y: 0, z: 0 }
  ],
  droppedItems: [
    { id: 'drop-1', type: 'glowcap', position: { x: 2, y: -9, z: 3 } },
    { id: 'bad', type: 'explosive', position: { x: 0, y: 0, z: 0 } }
  ],
  story: { introSeen: true, missionIndex: 999, counters: { materials: 99 }, completed: ['lifepod', 'evil'] }
});
assert.ok(legacy);
assert.equal(legacy.version, 11);
assert.deepEqual(legacy.respawnPoint, { x: 0, y: -7, z: 0 }, 'Legacy bed/checkpoint positions must not survive migration');
assert.equal(legacy.survival.hp, 0);
assert.equal(legacy.survival.oxygen, 105);
assert.equal(legacy.survival.medkits, 20);
assert.equal(legacy.inventory.titanium, 0);
assert.equal(legacy.inventory.copper, 5);
assert.equal(legacy.inventory.quartz, 999);
assert.equal(legacy.equipment.tankLevel, 2);
assert.equal('reinforcedSuitOwned' in legacy.equipment, false);
assert.equal('helmetOwned' in legacy.equipment, false);
assert.equal(legacy.equipment.seaglideCharge, 0, 'No legacy Seaglide should start charged unless it was owned');
assert.deepEqual(legacy.hotbar, [null, 'scanner', 'knife', 'flashlight', null]);
assert.deepEqual(legacy.discoveries, ['clownfish', 'abyssal_leviathan']);
assert.deepEqual(legacy.knownBiomes, ['reef', 'abyss']);
assert.deepEqual(legacy.collectedCaches, ['verdant_cache']);
assert.deepEqual(legacy.collectedResources, ['1:2:ore:3']);
assert.equal(legacy.placedStructures.length, 1);
assert.equal(legacy.droppedItems.length, 1);
assert.equal(legacy.story.missionIndex, 7);
assert.equal(normalizeSaveRecord({ totally: 'invalid' }), null);
const modern = normalizeSaveRecord({ version: 11, position: { x: 5, y: -9, z: 8 }, respawnPoint: { x: 20, y: -8, z: -10 }, survival: {}, inventory: {}, ownedTools:['seaglide'], equipment:{seaglideCharge:72} });
assert.deepEqual(modern.respawnPoint, { x: 20, y: -8, z: -10 });
assert.equal(modern.equipment.seaglideCharge, 72);
const migratedSeaglide = normalizeSaveRecord({ version: 10, position:{x:0,y:-7,z:0}, survival:{}, inventory:{}, ownedTools:['seaglide'] });
assert.equal(migratedSeaglide.equipment.seaglideCharge, 100, 'Legacy Seaglide owners should receive a full battery on migration');
const backup = normalizeBackupPayload({ format: 'the-abyssal-save-backup', schemaVersion: 1, slots: [legacy, null, null, null, null], settings: { volume: 120 } });
assert.equal(backup.slots.length, 5);
assert.equal(backup.settings.volume, 100);
assert.throws(() => normalizeBackupPayload({ format: 'wrong', slots: [] }), /Format backup/);
assert.throws(() => normalizeBackupPayload({ format: 'the-abyssal-save-backup', slots: [null] }), /tepat lima slot/);

// Subnautica-style core loop: backpack dimensions, quick slots, tool gating, survival and habitat systems.
assert.equal(pkg.version, '1.5.1');
assert.match(game, /const SURVIVAL_DEFAULTS = \{ hp: 100, oxygen: 45/);
assert.match(game, /const columns = 8, rows = 6/);
assert.match(game, /for \(let index=0; index<48; index\+\+\)/);
assert.match(html, /48 CELLS USED/);
assert.match(html, /5 slot Hotbar/);
assert.match(game, /let hotbarSlots = \['scanner','knife','flashlight',null,null\]/);
assert.match(game, /if \(itemId === 'explorer_pda'\)/);
assert.match(game, /explorer_pda:\{name:'PDA'/);
assert.match(game, /size:6,kind:'tool',width:2,height:3/);
assert.match(game, /function getMaxOxygen\(\) \{ return 45 \+ \(equipment\.tankLevel \|\| 0\) \* 30; \}/);
assert.match(game, /survival\.oxygen = clamp\(survival\.oxygen - oxygenRate \* dt, 0, getMaxOxygen\(\)\)/);
assert.match(game, /const oxygenRate = equipment\.rebreather && depth >= 20 \? 0\.75 : 1/);
assert.match(game, /if \(indoorHabitat && isHabitatPowered\(indoorHabitat\)\)/);
assert.match(game, /else if \(atSurface\)/);
assert.match(game, /function isHabitatPowered\(/);
assert.match(game, /function openFabricator\(\)/);
assert.match(game, /function craftFabricatorRecipe\(id\)/);
assert.match(game, /sustenance:\{title:'Sustenance'/);
assert.match(game, /personal:\{title:'Personal'/);
assert.match(game, /resources:\{title:'Resources'/);
assert.match(game, /electronics:\{title:'Electronics'/);
assert.match(game, /function openBuildMenu\(\)[\s\S]*?getSelectedHotbarItem\(\) !== 'habitat_builder'/);
assert.match(game, /function interactNearby\(\)/);
assert.match(game, /function gatherNearbyResource\(\)/);
assert.match(game, /function scanNearestFauna\(\)/);
assert.match(game, /minAlignment:0\.945/);
assert.match(game, /function makeFirstPersonViewModel\(\)/);
assert.match(game, /viewModel\.userData\.seaglide\.visible=selectedTool==='seaglide'/);
assert.match(game, /equipment\.seaglideCharge-0\.30\*dt/);
assert.match(game, /Ganti baterai Seaglide/);
assert.match(game, /function activateLifepod\([\s\S]*?getSelectedHotbarItem/);
assert.match(game, /ownedTools\.includes\('repair_tool'\)\|\|getSelectedHotbarItem\(\)!=='repair_tool'/);
assert.match(game, /CONTROL CONSOLE · FABRICATE REPAIR TOOL/);
assert.match(game, /consoleMaterial\.emissive\.setHex\(0x18c9b8\)/);
assert.match(game, /const speed=.*seaglideEquipped\?1\.75/);
assert.match(game, /function enterHabitat\(target\)/);
assert.match(game, /function exitHabitat\(\)/);
assert.match(game, /function saveCurrentSlot\(\)/);
assert.match(game, /No background saving: progress is committed only when the player selects Save/);

// Explicitly retired custom features are absent from runtime, schema, and interface.
for (const [label, source] of [['game.js', game], ['save-schema.mjs', schema], ['index.html', html], ['styles.css', styles]]) {
  assert.doesNotMatch(source, /autoSave|autosave-toggle|autosave-setting/i, `${label} still exposes autosave`);
  assert.doesNotMatch(source, /bed-btn|bed checkpoint|checkpoint kasur|isNearHabitatBed/i, `${label} still exposes bed checkpoints`);
  assert.doesNotMatch(source, /chestplate|helmetOwned|reinforcedSuitOwned|oxygen_station/i, `${label} still exposes retired armor/oxygen-station gear`);
  assert.doesNotMatch(source, /supabase|OnlineService|multiplayer|cloud save/i, `${label} still contains online/multiplayer systems`);
}
assert.doesNotMatch(game, /Math\.random\(\) \* 3|oxygenDrainTimer/, 'Random/timed oxygen drain must be removed');
assert.doesNotMatch(game, /pressureDamageTimer|thermalDamageTimer|temperatureC/, 'Custom pressure/temperature damage must be removed');
assert.ok(!idSet.has('supply-btn'), 'Separate supply button should be replaced by contextual Interact');
assert.ok(!idSet.has('autosave-toggle') && !idSet.has('bed-btn'));

// Android/offline packaging must not depend on an external backend.
assert.equal(manifest.orientation, 'landscape');
assert.equal(capacitor.appId, 'com.abyssal.game');
assert.equal(capacitor.webDir, 'www');
assert.match(serviceWorker, /the-abyssal-1-5-1-subnautica-style-singleplayer/);
assert.match(game, /const current = '1\.5\.1'/);
assert.match(backendSetup, /fully local\/offline/);
assert.match(workflow, /node scripts\/configure-backend\.mjs/);
assert.match(workflow, /native\/abyssal-debug-signing\.bin/);
assert.match(nativePatcher, /native\/abyssal-debug-signing\.bin/);
assert.doesNotMatch(gitignore, /abyssal-debug-signing\.bin/);
await access(join(root, 'native/abyssal-debug-signing.bin'));
assert.match(workflow, /dump badging/);
assert.match(workflow, /com\.abyssal\.game/);
assert.doesNotMatch(workflow, /SUPABASE_URL|SUPABASE_ANON_KEY/);
assert.doesNotMatch(nativePatcher, /auth\/callback|deepLinkFilter/);
assert.match(nativeBuilder, /await build\(/);
assert.match(workflow, /npm test/);
assert.match(workflow, /assembleDebug/);
assert.match(readme, /single-player/i);
assert.ok(styles.includes('.oxygen-gauge') && styles.includes('.depth-indicator') && styles.includes('.hotbar-slot'));
assert.ok(styles.includes('.inventory-slot-grid') && styles.includes('.fabricator-recipes') && styles.includes('.action-controls'));

console.log(`The Abyssal 1.5.1 verification passed: ${ids.length} unique DOM IDs, ${staticRefs.length} valid DOM references, local PNG assets, v11 legacy-save migration, 48-cell inventory, five quick slots, continuous oxygen, four Fabricator categories, Repair Tool Lifepod gate, charged Seaglide and battery replacement, habitat/interact loop, offline Android packaging, and removal of bed/autosave/armor/online features.`);
