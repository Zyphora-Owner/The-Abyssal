# Build APK The Abyssal 1.9.1 dari HP

1. Ekspor backup JSON save dari versi lama. Jangan hapus aplikasi lama sebelum yakin backup aman.
2. Ekstrak `The_Abyssal_Standalone_Android_v1.9.1.zip`.
3. Unggah isi folder proyek ke root repository GitHub, termasuk `.github/workflows`, `scripts`, `supabase`, `native`, dan aset.
4. Pertahankan `native/abyssal-debug-signing.bin` agar signature debug tetap sama.
5. Commit/push ke `main` atau `master`, atau jalankan workflow manual.
6. Buka Actions → **Build The Abyssal Native Android APK**.
7. Setelah job berhasil, unduh artifact `the-abyssal-android-apk-1.9.1` dan pasang APK di dalamnya.

## Penting
- Application ID tetap `com.abyssal.game`; signing key harus sama untuk update in-place.
- APK dianggap berhasil dibangun hanya setelah workflow selesai, artifact berisi APK valid, dan aplikasi berhasil dipasang.
- Simpan backup save sebelum update, terutama jika build ditandatangani dengan key berbeda.

## Uji gameplay setelah instalasi
- Coba gerak kamera kiri/kanan dan Split Touch dengan joystick + kamera.
- Sentuh bagian samping, atap, dan dasar Lifepod; bidik hatch atas untuk masuk/keluar.
- Pilih setiap tool, pastikan model tangan terlihat dan tombol aksi bekerja pada target valid.
- Buat tangki O₂ bertahap; tangki awal harus tetap 45. Tangki Mk V bersama Rebreather ditujukan untuk ekspedisi palung.
- Uji oksigen tiap 2 detik, habitat refill dari interior, inventory, crafting, PDA, save/load, fauna, dan bioma.
- Supabase memerlukan Project URL valid, migrations, Email Auth dan uji dua akun/perangkat.
