# The Abyssal 1.9.1

Game survival dan eksplorasi bawah laut untuk Android/Web. Versi ini memprioritaskan loop permainan yang dapat diselesaikan: menjelajah, mengumpulkan material, membuat alat, mengelola oksigen, menemukan bioma/fauna, lalu kembali dengan selamat.

## Fokus 1.9.1
- Menjaga kedalaman palung hingga 300 m tetap dapat dijangkau melalui progres equipment, bukan langsung terbuka tanpa persiapan.
- Tangki awal tetap 45 O₂. Empat peningkatan tangki membawa kapasitas akhir 345 O₂; Rebreather mengurangi konsumsi di kedalaman.
- Menguji anggaran oksigen perjalanan turun-naik konservatif hingga 296 m pada tangki maksimum dan Rebreather.
- Fauna kini dibatasi pada rentang kedalaman spesies dan tetap menjaga jarak dari dasar laut serta permukaan.
- Area awal, Lifepod, inventory, lima quick slots, PDA, crafting, habitat, tools, fauna, bioma, co-op, dan save v11 dipertahankan.

## Menjalankan dan memeriksa
`npm install`, `npm test`, lalu `npm run build`. Build Android mengikuti `.github/workflows/android-apk.yml`.

## Supabase
Project URL diambil dari Supabase Dashboard → Project Settings → API. Aplikasi memakai Publishable Key publik; jangan memasukkan `service_role` atau `sb_secret` ke klien. Login dan co-op perlu konfigurasi proyek Supabase serta migration sesuai panduan `SUPABASE_SETUP_ID.md`.

## Batas verifikasi
Tes otomatis menguji aturan inti dan source wiring. Tes ini bukan pengganti pengujian WebGL di perangkat, build APK nyata, autentikasi live, atau pengujian multiplayer dua perangkat. Event dunia bersama tersedia untuk event tertentu, tetapi ini **bukan simulasi shared-world penuh**: inventory, fauna AI, health/oxygen, dan seluruh simulasi belum sepenuhnya authoritative shared-world.
