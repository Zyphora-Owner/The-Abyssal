# Supabase — The Abyssal 1.9.1

Login/Register dan co-op hanya akan tersambung setelah Project URL berasal dari proyek Supabase yang benar serta migration selesai dijalankan.

1. Buka Supabase Dashboard dan pilih project.
2. Salin Project URL dari **Project Settings → API**.
3. Gunakan Publishable Key publik yang sudah disediakan di konfigurasi aplikasi. Jangan gunakan `sb_secret`, `service_role`, database password, atau access token pada frontend.
4. Jalankan migration SQL di `supabase/migrations/` sesuai urutan untuk project baru. Pada database lama yang sudah menerapkan migration 0001 sampai 0003, jalankan hanya migration baru jika ada.
5. Aktifkan Authentication → Providers → Email dan izinkan sign-ups. Atur URL redirect sesuai domain yang benar-benar diterbitkan.
6. Masukkan Project URL ke form backend di dalam aplikasi, tekan Simpan & Hubungkan, Register, verifikasi email bila diminta, lalu Login.
7. Uji Create Room/Join Room dengan dua akun pada dua perangkat.

Versi ini mempertahankan room privat, Presence, avatar, chat, reconnect, dan event dunia bersama untuk beberapa perubahan dunia. Ini belum shared-world penuh: inventory, fauna AI, health/oxygen, kendaraan, dan seluruh progres belum disimpan sebagai simulasi authoritative pada server.

## Urutan migration
- Project baru: `202611060001_multiplayer.sql` → `202611060002_room_recovery.sql` → `202611070001_shared_world_events.sql` → `202611070002_deep_world_coordinates.sql`.
- Database lama yang sudah menjalankan tiga migration pertama hanya perlu menjalankan `202611070002_deep_world_coordinates.sql`.
