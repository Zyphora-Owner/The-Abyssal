/** Pure, testable player/capsule mechanics shared by the runtime and audit suite. */
export function clampValue(value, min, max) {
  const number = Number(value);
  return Math.max(min, Math.min(max, Number.isFinite(number) ? number : min));
}

// Capacity progression: the starter tank remains 45 O₂; four craftable upgrades
// support long expeditions when paired with a Rebreather.
export const MAX_OXYGEN_TANK_LEVEL = 4;
export function oxygenTankCapacity(level = 0) {
  const tier = Math.max(0, Math.min(MAX_OXYGEN_TANK_LEVEL, Math.floor(Number(level) || 0)));
  return 45 + tier * 75;
}

/** Clamp a fauna actor to its species depth range and the local water column. */
export function clampFaunaDepth(positionY, terrainY, clearance = 1, speciesDepth = [-0.65, -300]) {
  const waterFloor = Number(terrainY) + Math.max(1, Number(clearance) || 1);
  const shallowLimit = Array.isArray(speciesDepth) && Number.isFinite(Number(speciesDepth[0])) ? Number(speciesDepth[0]) : -0.65;
  const deepLimit = Array.isArray(speciesDepth) && Number.isFinite(Number(speciesDepth[1])) ? Number(speciesDepth[1]) : -300;
  const lowerBound = Math.max(waterFloor, deepLimit);
  const upperBound = Math.min(-0.65, shallowLimit);
  const current = Number.isFinite(Number(positionY)) ? Number(positionY) : waterFloor;
  if (lowerBound <= upperBound) return clampValue(current, lowerBound, upperBound);
  // If a shallow seabed and an authored deep-water range do not overlap,
  // keep the animal in the available water column instead of inside terrain.
  return Math.min(-0.65, Math.max(waterFloor, current));
}

/** Positive horizontal pointer movement must rotate the view to the right. */
export function applyTouchLook(yaw, pitch, deltaX, deltaY, sensitivity = 0.0039, pitchSensitivity = 0.0027) {
  const nextYaw = Number(yaw || 0) + Number(deltaX || 0) * sensitivity;
  const nextPitch = clampValue(Number(pitch || 0) + Number(deltaY || 0) * pitchSensitivity, -0.98, 0.98);
  return { yaw: nextYaw, pitch: nextPitch };
}

export function worldToLifepodLocal(x, y, z, podPosition, yaw = 0) {
  const dx = x - podPosition.x;
  const dz = z - podPosition.z;
  const c = Math.cos(yaw);
  const s = Math.sin(yaw);
  // Inverse of Three.js Object3D Y rotation. This must be the exact inverse
  // of interiorPoint(), otherwise hatch aiming and hull collision drift when
  // the Lifepod is rotated.
  return {
    x: dx * c - dz * s,
    y: y - podPosition.y,
    z: dx * s + dz * c
  };
}

export function lifepodInteriorContains(localX, localY, localZ) {
  // Test the diver's centre against a clearance envelope, not the visible shell.
  // The capsule body radius is about 1.42 m; keeping the centre within 1.04 m
  // leaves room for the player's collision radius and prevents clipping through
  // the inside face of the side wall. The longitudinal limits leave clearance
  // from both tapered ends.
  return Math.hypot(localX, localY) < 1.04 && Math.abs(localZ) < 1.34 && localY > -0.78 && localY < 1.02;
}

/** Approximate the outer shell as a capsule body, nose hemisphere, and tapered tail. */
export function lifepodHullBlocksLocal(localX, localY, localZ, playerRadius = 0.38) {
  if (lifepodInteriorContains(localX, localY, localZ)) return false;
  const radial = Math.hypot(localX, localY);
  const bodyRadius = 1.42 + playerRadius;
  if (localZ >= -1.58 && localZ <= 1.86 && radial < bodyRadius) return true;
  if (localZ < -1.58 && localZ >= -3.04) {
    const noseDistance = Math.hypot(localX, localY, localZ + 1.58);
    if (noseDistance < bodyRadius) return true;
  }
  if (localZ > 1.72 && localZ <= 3.02) {
    const tailRadius = 1.52 * (1 - (localZ - 1.72) / 1.30) + playerRadius;
    if (radial < tailRadius) return true;
  }
  return false;
}

export function lifepodHullBlocksWorld(x, y, z, podPosition, yaw = 0, playerRadius = 0.38) {
  const local = worldToLifepodLocal(x, y, z, podPosition, yaw);
  return lifepodHullBlocksLocal(local.x, local.y, local.z, playerRadius);
}

/** Sweep the diver capsule between frames so fast movement cannot tunnel through the hull. */
export function lifepodSegmentBlocked(from, to, podPosition, yaw = 0, stepLength = 0.28) {
  const distance = Math.hypot(to.x - from.x, to.y - from.y, to.z - from.z);
  const steps = Math.max(1, Math.ceil(distance / Math.max(0.08, stepLength)));
  for (let index = 1; index <= steps; index += 1) {
    const t = index / steps;
    const x = from.x + (to.x - from.x) * t;
    const y = from.y + (to.y - from.y) * t;
    const z = from.z + (to.z - from.z) * t;
    if (lifepodHullBlocksWorld(x, y, z, podPosition, yaw)) return true;
  }
  return false;
}


/**
 * Resolve a requested movement against the Lifepod shell one axis at a time.
 * Axis-wise swept tests preserve wall sliding and, importantly, stop vertical
 * movement too. A previous runtime path only checked the combined segment and
 * restored X/Z on collision, accidentally allowing Y to pass through the roof.
 */
export function resolveLifepodMovement(from, to, podPosition, yaw = 0, playerRadius = 0.38) {
  const position = { x: Number(from.x), y: Number(from.y), z: Number(from.z) };
  const blocked = { x: false, y: false, z: false };
  for (const axis of ['x', 'z', 'y']) {
    const candidate = { ...position, [axis]: Number(to[axis]) };
    const hit = lifepodSegmentBlocked(position, candidate, podPosition, yaw, 0.16)
      || lifepodHullBlocksWorld(candidate.x, candidate.y, candidate.z, podPosition, yaw, playerRadius);
    if (hit) blocked[axis] = true;
    else Object.assign(position, candidate);
  }
  return { position, blocked };
}

/** A Lifepod may only be entered by aiming down at the dedicated roof hatch. */
export function getLifepodHatchAim(origin, direction, podPosition, yaw = 0, maxDistance = 7) {
  const localOrigin = worldToLifepodLocal(origin.x, origin.y, origin.z, podPosition, yaw);
  const c = Math.cos(yaw);
  const s = Math.sin(yaw);
  const dirX = direction.x * c - direction.z * s;
  const dirY = direction.y;
  const dirZ = direction.x * s + direction.z * c;
  const hatchY = 1.48;
  if (localOrigin.y <= hatchY || dirY >= -0.08) return null;
  const distance = (hatchY - localOrigin.y) / dirY;
  if (!Number.isFinite(distance) || distance <= 0 || distance > maxDistance) return null;
  const hitX = localOrigin.x + dirX * distance;
  const hitZ = localOrigin.z + dirZ * distance;
  if (Math.abs(hitX) > 0.48 || Math.abs(hitZ - 0.15) > 0.48) return null;
  return { distance, localX: hitX, localY: hatchY, localZ: hitZ };
}

/** Oxygen use is discrete at a two-second cadence, with deeper water increasing demand. */
export function oxygenUsePerTick(depth, rebreather = false, random = Math.random) {
  const roll = clampValue(Number(random()), 0, 0.999999);
  if (depth < 20) return 2 + Math.floor(roll * 3);
  // A square-root curve keeps the deep zone dangerous without emptying a
  // standard tank in seconds. Demand still starts at 4+ every two-second tick.
  const depthBase = 4 + Math.floor(Math.sqrt(Math.max(0, depth - 20) / 8));
  const deepDemand = depthBase + Math.floor(roll * 3);
  return rebreather ? Math.max(3, deepDemand - 2) : deepDemand;
}
