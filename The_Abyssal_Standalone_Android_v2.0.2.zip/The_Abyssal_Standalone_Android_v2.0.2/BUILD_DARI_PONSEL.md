# Build APK The Abyssal 2.0.2 dari HP

## Sebelum update
1. Buka game versi lama dan ekspor backup JSON save. Simpan backup di Downloads/Drive.
2. Jangan uninstall aplikasi lama sebelum APK baru berhasil dipasang dan save terverifikasi.
3. Pertahankan file `native/abyssal-debug-signing.bin` dari ZIP agar signature debug tetap sama. Jangan menggantinya dengan file signing lain.

## GitHub Actions
1. Unduh dan ekstrak `The_Abyssal_Standalone_Android_v2.0.2.zip`.
2. Unggah **isi folder proyek** ke root repository GitHub, bukan hanya ZIP. Pastikan folder tersembunyi `.github/workflows/` ikut terunggah.
3. Sertakan `scripts/`, `native/`, `supabase/`, `icons/`, `package.json`, `capacitor.config.json`, dan file root lainnya.
4. Commit/push ke `main` atau `master`, atau jalankan workflow manual.
5. Buka **Actions → Build The Abyssal Native Android APK**.
6. Jika workflow seluruhnya berhasil, unduh artifact `the-abyssal-android-apk-2.0.2`, ekstrak, lalu pasang `app-debug.apk`.

## Penting
- Application ID harus tetap `com.abyssal.game`.
- APK harus memakai signing key yang sama untuk memperbarui pemasangan lama.
- Jika GitHub Actions gagal pada dependency install atau Gradle, jangan pasang artifact lama seolah-olah itu hasil 2.0.2. Periksa log job yang gagal.
- Keberhasilan build hanya terkonfirmasi setelah artifact APK baru valid dan aplikasi berhasil dipasang. Pengujian source `npm test` bukan pengganti build APK.

## Riwayat perbaikan fungsional 2.0.1
- Kamera memakai orientasi dasar yang stabil; roll tidak lagi menumpuk dari frame sebelumnya.
- Tombol naik/turun aman untuk beberapa pointer.
- Item resource dan supply pada Quick Slots mempunyai model first-person prosedural.
- Attack hanya muncul untuk target fauna yang benar-benar dapat dijangkau.
- Populasi fauna direset secara aman ketika berganti slot.

## Uji setelah pemasangan
- Masuk menu utama, jalankan cutscene baru atau Replay, lalu masuk gameplay.
- Berenang ke permukaan dan kembali menyelam; periksa waterline, suara splash/dive, fog, sky, dan O₂.
- Uji Lifepod: dekati hull dari samping/atas/bawah; hanya hatch atas yang bisa digunakan melalui reticle + Interact. Periksa interior, Fabricator, dan oksigen.
- Pilih setiap alat melalui lima Quick Slots; pastikan viewmodel muncul dan tombol aksinya berfungsi.
- Dekati kura-kura; pastikan pola tempurung terlihat pada jarak dekat. Periksa fauna dan terrain pada preset Low/Medium/High.
- Uji inventory, crafting, PDA, fauna, biome, misi, save/load, serta kontrol Split Touch.
- Setelah backend disiapkan, tes Register/Login, kemudian Create Room/Join Room dengan dua akun dan dua perangkat.


## Pemeriksaan tambahan dari versi 2.0.1
Setelah APK dipasang, uji dua jari secara bersamaan: joystick + lookpad, lalu tombol naik/turun. Pilih resource (misalnya Titanium), medkit, dan baterai dari Quick Slot untuk memastikan model first-person muncul dan hilang saat item tidak dimiliki. Pilih pisau tanpa target dan pastikan tombol Attack tersembunyi; arahkan ke fauna dalam jangkauan untuk menampilkannya. Muat dua slot save secara bergantian dan pastikan fauna dari slot sebelumnya tidak tertinggal.


## Pembaruan visual dan animasi 2.0.2

1. Unggah isi folder proyek ke root repository GitHub, termasuk `.github/workflows`, `scripts`, `native`, dan `supabase`.
2. Commit dan push ke branch `main` atau `master`, atau jalankan workflow manual.
3. Buka **Actions → Build The Abyssal Native Android APK**.
4. Unduh artifact `the-abyssal-android-apk-2.0.2` jika job berhasil.
5. Pastikan APK ditandatangani dengan signing key yang sama untuk memperbarui pemasangan lama. Backup save sebelum pemasangan.

Pengaturan grafik mempengaruhi resolusi tekstur air: Low 512 px, Balanced 1024 px, High 2048 px. Rumput laut dibuat dari tuft 11 helai yang bergoyang melalui vertex shader. Animasi berenang, bubble pool, dan caustics bergerak juga diperbarui. Jika GPU perangkat terbatas, gunakan Low atau Balanced. Setelah memasang APK, periksa kualitas air, gerakan vegetasi, animasi tangan saat berenang, dan gelembung saat bergerak di bawah air.


## Pemeriksaan rilis visual 2.0.2
- Preset Low memakai tekstur air 512 px, Balanced 1024 px, dan High 2048 px. Preset juga mengubah subdivisi permukaan air serta cadence update vertex.
- Kelp memakai tuft 11 helai yang ditekuk di vertex shader; kepadatan High tidak boleh mengulang pola sampel 20 posisi.
- Animasi tangan first-person dan bubble pool aktif ketika bergerak di bawah air.
- Source verification harus lulus dengan `npm test`.
- Catatan lingkungan pengerjaan: `npm run build` belum dapat dikonfirmasi di lingkungan ini karena Vite tidak terpasang setelah instalasi dependency mengalami timeout. GitHub Actions akan memasang dependency dari `package.json`; tunggu hanya sampai job menunjukkan sukses sebelum menganggap APK tersedia.
