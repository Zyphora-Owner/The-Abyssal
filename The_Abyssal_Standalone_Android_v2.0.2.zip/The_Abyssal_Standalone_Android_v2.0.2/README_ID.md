# The Abyssal 2.0.2

Game survival dan eksplorasi bawah laut untuk Android/Web. Versi ini memprioritaskan loop permainan yang dapat diselesaikan: menjelajah, mengumpulkan material, membuat alat, mengelola oksigen, menemukan bioma/fauna, lalu kembali dengan selamat.

## Fondasi gameplay yang dipertahankan dari 2.0.1
- Menjaga kedalaman palung hingga 300 m tetap dapat dijangkau melalui progres equipment, bukan langsung terbuka tanpa persiapan.
- Tangki awal tetap 45 O₂. Empat peningkatan tangki membawa kapasitas akhir 345 O₂; Rebreather mengurangi konsumsi di kedalaman.
- Menguji anggaran oksigen perjalanan turun-naik konservatif hingga 296 m pada tangki maksimum dan Rebreather.
- Fauna kini dibatasi pada rentang kedalaman spesies dan tetap menjaga jarak dari dasar laut serta permukaan.
- Area awal, Lifepod, inventory, lima quick slots, PDA, crafting, habitat, tools, fauna, bioma, co-op, dan save v11 dipertahankan.

## Perbaikan fungsional sebelumnya (2.0.1)
- Mencegah roll kamera terakumulasi karena rotasi lokal kini dikomposisikan dari quaternion dasar yang stabil.
- Split-touch naik/turun melacak setiap pointer secara terpisah; satu jari yang dilepas tidak membatalkan jari lain.
- Semua item non-tool yang dapat ditempatkan pada Quick Slot kini memiliki procedural first-person viewmodel lokal.
- Tombol Attack hanya muncul saat Survival Knife dipilih dan fauna benar-benar berada pada bidikan serta jangkauan.
- Populasi fauna dibersihkan dan dibentuk ulang saat memulai atau memuat slot, sehingga fauna dari save sebelumnya tidak tertinggal.
- Dorongan collision fauna divalidasi ulang terhadap terrain dan struktur agar tidak mendorong pemain menembus Lifepod.

## Peningkatan visual sebelumnya (2.0.1)
- Memperluas Lifepod secara proporsional dan menambah rangka, rib, fastener, liner, ladder, serta fasilitas interior; transformasi collision, hatch, dan titik interaksi ikut menggunakan skala yang sama.
- Menambahkan pola scute heksagonal, bump texture, rim, plastron, kepala, mata, dan detail flipper pada kura-kura laut.
- Menambahkan gelombang permukaan air berbasis waktu, sky dome, siklus daylight, transisi visual waterline, perubahan fog/pencahayaan, serta pemulihan O₂ hanya saat posisi kepala jelas di atas air.
- Memperhalus relief terrain deterministik, pewarnaan sisi curam, tekstur batu, dan lapisan efek permukaan.
- Mempertahankan first-person tools, lima Quick Slots, Inventory, PDA, crafting, survival, fauna, biome, co-op, dan save schema v11.

## Menjalankan dan memeriksa
`npm install`, `npm test`, lalu `npm run build`. Build Android mengikuti `.github/workflows/android-apk.yml`.

## Supabase
Project URL diambil dari Supabase Dashboard → Project Settings → API. Aplikasi memakai Publishable Key publik; jangan memasukkan `service_role` atau `sb_secret` ke klien. Login dan co-op perlu konfigurasi proyek Supabase serta migration sesuai panduan `SUPABASE_SETUP_ID.md`.

## Batas verifikasi
Tes otomatis menguji aturan inti dan source wiring. Tes ini bukan pengganti pengujian WebGL di perangkat, build APK nyata, autentikasi live, atau pengujian multiplayer dua perangkat. Event dunia bersama tersedia untuk event tertentu, tetapi ini **bukan simulasi shared-world penuh**: inventory, fauna AI, health/oxygen, dan seluruh simulasi belum sepenuhnya authoritative shared-world.


## Rilis 2.0.2 — HD Ocean & Swim Animation

- Tekstur permukaan air seamless: Low 512 px, Balanced 1024 px, High 2048 px; memakai normal map tangent-space, mipmap, anisotropic filtering, dan material fisik ber-clearcoat.
- Gelombang permukaan multi-skala diperkuat dan mesh air memiliki resolusi yang mengikuti preset grafis.
- Caustics transparan bergerak pada terrain reef/kelp dan terrain dangkal.
- Kelp silindris diganti tuft rumput laut 11 helai yang bergoyang dengan fase berbeda per-instance melalui vertex shader GPU.
- Animasi first-person saat berenang diperkuat: kayuhan kiri/kanan bergantian, pergelangan, bob tubuh, dan peredaman stroke ketika memakai Seaglide atau memegang alat.
- Bubble pool 22 sprite digunakan ulang untuk gelembung ketika penyelam bergerak di bawah air.
- Perubahan preset grafis memperbarui resolusi tekstur air dan subdivisi mesh tanpa reload save.

Save schema v11, Application ID `com.abyssal.game`, inventory, lima Quick Slots, PDA, crafting, habitat, fauna, misi, akun, dan multiplayer tetap dipertahankan. Lihat `CHANGELOG_2.0.2_ID.md` dan `AUDIT_REPORT_2.0.2_ID.md`.


## Rilis 2.0.2 — Water, Seagrass & Swim Polish
- Permukaan air memakai color texture dan tangent-space normal map lokal beresolusi hingga 2048 px pada preset High.
- Gelombang, normal ripples, dan caustics bergerak; kualitas menyesuaikan preset grafis.
- Kelp menjadi tuft 11 helai dengan vertex sway GPU dan variasi fase per-instance. Bug pengulangan indeks sampling untuk kepadatan di atas 20 diperbaiki.
- Animasi first-person saat berenang diperkuat dan bubble pool digunakan ulang untuk menjaga alokasi objek tetap terkendali.
- Save schema v11, Application ID, fitur lama, backend, dan Quick Slots dipertahankan.

Verifikasi source `npm test` lulus. Build Vite/APK, rendering GPU Android, dan multiplayer live belum terverifikasi di lingkungan ini.
