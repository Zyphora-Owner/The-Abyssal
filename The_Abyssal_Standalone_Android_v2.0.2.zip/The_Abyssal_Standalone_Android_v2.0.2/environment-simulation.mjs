/** Deterministic, frame-rate independent environmental helpers. */
export function clamp01(value) {
  const n = Number(value);
  return Math.max(0, Math.min(1, Number.isFinite(n) ? n : 0));
}

export function smooth01(value) {
  const t = clamp01(value);
  return t * t * (3 - 2 * t);
}

/** Multi-scale, deterministic ocean wave field in metres. The several wave bands
 * keep the waterline coherent at any world coordinate without per-frame randomness. */
export function waterSurfaceHeightAt(x, z, elapsedSeconds = 0) {
  const px = Number.isFinite(Number(x)) ? Number(x) : 0;
  const pz = Number.isFinite(Number(z)) ? Number(z) : 0;
  const t = Number.isFinite(Number(elapsedSeconds)) ? Number(elapsedSeconds) : 0;
  const swell = Math.sin(px * 0.013 + t * 0.48) * 0.105
    + Math.sin(pz * 0.018 - t * 0.62) * 0.062;
  const crossWaves = Math.sin((px + pz) * 0.010 + t * 0.39) * 0.034
    + Math.sin((px * 0.72 - pz) * 0.0075 + t * 0.27) * 0.021;
  const ripples = Math.sin(px * 0.044 + pz * 0.031 + t * 1.08) * 0.012;
  return swell + crossWaves + ripples;
}

/** Smooth, instance-varied seagrass bend in local metres, strongest near each blade tip. */
export function computeSeagrassSway(x, z, elapsedSeconds = 0, bladeHeight = 1, phaseOffset = 0) {
  const px = Number.isFinite(Number(x)) ? Number(x) : 0;
  const pz = Number.isFinite(Number(z)) ? Number(z) : 0;
  const t = Number.isFinite(Number(elapsedSeconds)) ? Number(elapsedSeconds) : 0;
  const h = clamp01(bladeHeight);
  const phase = t * 0.82 + px * 0.037 + pz * 0.041 + (Number(phaseOffset) || 0);
  const bend = h * h;
  return {
    x: (Math.sin(phase) * 0.24 + Math.sin(phase * 0.67 + h * 2.1) * 0.045) * bend,
    z: (Math.cos(phase * 0.82) * 0.15 + Math.sin(phase * 1.1 + h) * 0.025) * bend
  };
}

/** Stable first-person swim pose; tool holding dampens the dominant hand stroke. */
export function computeSwimPose(phase, movement = 0, usingSeaglide = false, holdingTool = false) {
  const p = Number.isFinite(Number(phase)) ? Number(phase) : 0;
  const speed = clamp01(Number(movement) / 0.85);
  const blend = smooth01(speed);
  const stroke = Math.sin(p);
  const glideDamp = usingSeaglide ? 0.08 : 1;
  const rightDamp = holdingTool ? 0.28 : 1;
  return {
    blend,
    leftArmX: 0.08 + stroke * 0.34 * blend * glideDamp,
    rightArmX: 0.08 - stroke * 0.30 * blend * glideDamp * rightDamp,
    leftArmZ: 0.035 + Math.cos(p * 0.5) * 0.085 * blend,
    rightArmZ: -0.035 - Math.cos(p * 0.5) * 0.075 * blend * rightDamp,
    bob: Math.sin(p * 2) * 0.022 * blend
  };
}

/** Texture sizes are power-of-two to keep repeat wrapping and mipmaps reliable on WebGL. */
export function waterTextureResolution(quality = 'balanced') {
  if (quality === 'low') return 512;
  if (quality === 'high') return 2048;
  return 1024;
}

/** Surface blend from diver eye height relative to the animated water plane. */
export function computeSurfaceBlend(eyeY, waterY = 0) {
  const relative = (Number(eyeY) || 0) - (Number(waterY) || 0);
  return smooth01((relative + 0.18) / 0.36);
}

/** Breathing is allowed only when the diver's mouth/visor is clearly above water. */
export function canBreatheAtSurface(eyeY, waterY = 0, margin = 0.045) {
  return Number(eyeY) > Number(waterY) + Math.max(0, Number(margin) || 0);
}

/** A compact day/night curve. It returns stable values for a saved world clock. */
export function computeDaylight(elapsedSeconds, cycleSeconds = 900) {
  const cycle = Math.max(60, Number(cycleSeconds) || 900);
  const rawElapsed = Number(elapsedSeconds);
  const elapsed = Number.isFinite(rawElapsed) ? Math.max(0, rawElapsed) : 0;
  const phase = (elapsed % cycle) / cycle;
  const sun = Math.sin(phase * Math.PI * 2 - Math.PI / 2);
  const daylight = smooth01((sun + 0.16) / 1.12);
  return { phase, daylight, night: 1 - daylight, sunElevation: sun };
}
