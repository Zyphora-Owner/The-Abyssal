/**
 * Stable procedural world primitives.
 * Existing spawn-region terrain remains byte-for-byte deterministic; the
 * trench is an authored remote region so old bases and save coordinates stay put.
 */
export const WORLD_SEED = 0x0ab155a1;
export const MAX_DIVE_DEPTH = 300;
export const ABYSSAL_TRENCH = Object.freeze({ x: 760, z: -620, innerRadius: 145, outerRadius: 590, depth: 245 });

/** Deterministic pseudo-random value in [0, 1). */
export function hash2(x, z, seed = WORLD_SEED) {
  const value = Math.sin(x * 127.1 + z * 311.7 + seed) * 43758.5453123;
  return value - Math.floor(value);
}

/** Smooth, deterministic value noise in approximately [-1, 1]. */
export function valueNoise(x, z, seed = WORLD_SEED) {
  const ix = Math.floor(x);
  const iz = Math.floor(z);
  const fx = x - ix;
  const fz = z - iz;
  const sx = fx * fx * (3 - 2 * fx);
  const sz = fz * fz * (3 - 2 * fz);
  const mix = (a, b, t) => a + (b - a) * t;
  const a = hash2(ix, iz, seed);
  const b = hash2(ix + 1, iz, seed);
  const c = hash2(ix, iz + 1, seed);
  const d = hash2(ix + 1, iz + 1, seed);
  return mix(mix(a, b, sx), mix(c, d, sx), sz) * 2 - 1;
}

const smooth01 = value => {
  const t = Math.max(0, Math.min(1, value));
  return t * t * (3 - 2 * t);
};

/** 1 in the trench basin, smoothly fading to 0 outside its remote rim. */
export function trenchInfluenceAt(x, z) {
  const distance = Math.hypot(Number(x) - ABYSSAL_TRENCH.x, Number(z) - ABYSSAL_TRENCH.z);
  const t = (distance - ABYSSAL_TRENCH.innerRadius) / (ABYSSAL_TRENCH.outerRadius - ABYSSAL_TRENCH.innerRadius);
  return 1 - smooth01(t);
}

/**
 * Seafloor function shared by terrain streaming and fauna grounding.
 * The existing world keeps its former floor profile; only the remote trench
 * gets a deeper basin and deterministic ridges.
 */
export function seaFloorDepth(x, z) {
  const oldFloor = -43 + valueNoise(x * 0.017, z * 0.017) * 6.5 + valueNoise(x * 0.061, z * 0.061) * 1.8;
  const influence = trenchInfluenceAt(x, z);
  const basinRidge = valueNoise(x * 0.009, z * 0.009, WORLD_SEED + 913) * 13
    + valueNoise(x * 0.027, z * 0.027, WORLD_SEED + 173) * 4;
  // Secondary ridge and sediment scales add readable terrain variation without
  // moving the authored spawn island or changing the deterministic world seed.
  const fineRidges = valueNoise(x * 0.038, z * 0.038, WORLD_SEED + 421) * 1.35
    + valueNoise(x * 0.115, z * 0.115, WORLD_SEED + 719) * 0.42;
  const shelfCuts = (1 - Math.abs(valueNoise(x * 0.021, z * 0.021, WORLD_SEED + 887))) * 0.72;
  const generatedFloor = oldFloor + fineRidges + shelfCuts - influence * (ABYSSAL_TRENCH.depth + basinRidge);
  // Keep the deepest terrain above the diver hard limit, leaving capsule clearance.
  return Math.max(-MAX_DIVE_DEPTH + 4, generatedFloor);
}
