# The Abyssal 2.0.5

## Rilis 2.0.5 — Lifepod, Depth Progression & Cinematic Polish

- Lifepod kini mengapung pada garis air (bukan tenggelam seluruhnya), hatch berada di atas permukaan, lampu/beacon luar dan detail panel ditambah; titik keluar diselaraskan dengan hatch dan collision hull memakai radius luar sebenarnya.
- Rating kedalaman tangki bertingkat: Tank Mk I 50 m, Mk II 100 m, Mk III 200 m, Mk IV 300 m, Mk V 500 m. Melewati rating memicu peringatan dan pressure stress bertahap tiap 2 detik; kapasitas O₂ tetap mengikuti sistem lama.
- Palung Hadal diperluas hingga mendekati 500 m dan rentang habitat fauna abyssal diperbarui agar tier akhir punya area eksplorasi yang relevan.
- Model leviathan cutscene diperbesar dan diberi rahang, gigi, mata bioluminesen, sirip serta animasi tail/jaw; kamera kini mengambil framing mengikuti posisi monster.
- Subtitle cutscene dipindah ke tengah atas dengan font kecil, panel kontras, dan ukuran responsif.
- Mining Ore kini memiliki ayunan tangan, getaran deposit, fase retak, debris, suara hit dan suara pecah sebelum resource dijatuhkan.
- Habitat Builder memakai hologram 3D hijau/merah yang mengikuti dasar laut; tombol BUILD mengonfirmasi hanya saat slope, jarak, collision, dan material valid.
- Senter memakai SpotLight dunia yang lebih kuat, near-field light, lens glow dan cone visual; ON/OFF mengubah pencahayaan nyata dan efek visual.
- Tekstur prosedural mendapat sumber detail 2K pada tier 4K, lebih banyak micro-grain, cracks, pores, scratches dan stratifikasi material; model Ore mendapat facet serta kristal aksen.
- Menu utama memakai video lokal loop MP4 dengan scrim kontras; video hanya diputar saat menu utama tampil dan dijeda saat masuk permainan.
- Save schema v11 dan Application ID `com.abyssal.game` dipertahankan; tidak ada reset save.

## Rilis 2.0.4 — Graphics Texture Tiers

- Low menargetkan tekstur utama 1024×1024, Medium 2048×2048, dan High 4096×4096.
- High mengaktifkan tekstur 4K untuk permukaan air dan terrain utama jika GPU mendukung setidaknya 4096px dan memori perangkat memadai; detail pendukung memakai 2048px untuk menjaga konsumsi memori.
- Jika GPU atau memori tidak memadai, game menurunkan resolusi aktual dengan aman dan menampilkan alasan serta batas perangkat di Settings.
- Mengubah preset grafik saat runtime kini membangun ulang tekstur, memindahkan seluruh material ke tekstur baru, membuang tekstur lama, dan memperbarui fauna, bayangan, gelombang, serta chunk.
- Tekstur prosedural 2K/4K dibuat dengan sumber detail bertingkat dan lapisan mikro beresolusi penuh agar pembuatan aset tidak memblokir CPU terlalu lama.
- Detail tekstur kura-kura dan fauna mengikuti preset, dengan pembaruan material yang langsung terlihat tanpa membuat ulang populasi.
- Save schema v11, Application ID `com.abyssal.game`, inventory, PDA, crafting, habitat, fauna, misi, akun, dan multiplayer dipertahankan.

Lihat `CHANGELOG_2.0.4_ID.md` dan `AUDIT_REPORT_2.0.4_ID.md`.

---

Game survival dan eksplorasi bawah laut untuk Android/Web. Versi ini memprioritaskan loop permainan yang dapat diselesaikan: menjelajah, mengumpulkan material, membuat alat, mengelola oksigen, menemukan bioma/fauna, lalu kembali dengan selamat.

## Fondasi gameplay yang dipertahankan dari 2.0.1
- Palung Hadal kini membentang hingga kisaran 500 m dan progres kedalaman mengikuti rating perlindungan tangki: Mk I 50 m, Mk II 100 m, Mk III 200 m, Mk IV 300 m, Mk V 500 m.
- Tangki awal tetap 45 O₂. Empat peningkatan tangki membawa kapasitas akhir 345 O₂; Rebreather mengurangi konsumsi di kedalaman.
- Simulasi konservatif sebelumnya menguji perjalanan turun-naik hingga 296 m dengan tangki maksimum dan Rebreather. Untuk kedalaman lebih jauh, pantau kapasitas O₂ secara terpisah dari rating tekanan tank.
- Fauna kini dibatasi pada rentang kedalaman spesies dan tetap menjaga jarak dari dasar laut serta permukaan.
- Area awal, Lifepod, inventory, lima quick slots, PDA, crafting, habitat, tools, fauna, bioma, co-op, dan save v11 dipertahankan.

## Perbaikan fungsional sebelumnya (2.0.1)
- Mencegah roll kamera terakumulasi karena rotasi lokal kini dikomposisikan dari quaternion dasar yang stabil.
- Split-touch naik/turun melacak setiap pointer secara terpisah; satu jari yang dilepas tidak membatalkan jari lain.
- Semua item non-tool yang dapat ditempatkan pada Quick Slot kini memiliki procedural first-person viewmodel lokal.
- Tombol Attack hanya muncul saat Survival Knife dipilih dan fauna benar-benar berada pada bidikan serta jangkauan.
- Populasi fauna dibersihkan dan dibentuk ulang saat memulai atau memuat slot, sehingga fauna dari save sebelumnya tidak tertinggal.
- Dorongan collision fauna divalidasi ulang terhadap terrain dan struktur agar tidak mendorong pemain menembus Lifepod.

## Peningkatan visual sebelumnya (2.0.1)
- Memperluas Lifepod secara proporsional dan menambah rangka, rib, fastener, liner, ladder, serta fasilitas interior; transformasi collision, hatch, dan titik interaksi ikut menggunakan skala yang sama.
- Menambahkan pola scute heksagonal, bump texture, rim, plastron, kepala, mata, dan detail flipper pada kura-kura laut.
- Menambahkan gelombang permukaan air berbasis waktu, sky dome, siklus daylight, transisi visual waterline, perubahan fog/pencahayaan, serta pemulihan O₂ hanya saat posisi kepala jelas di atas air.
- Memperhalus relief terrain deterministik, pewarnaan sisi curam, tekstur batu, dan lapisan efek permukaan.
- Mempertahankan first-person tools, lima Quick Slots, Inventory, PDA, crafting, survival, fauna, biome, co-op, dan save schema v11.

## Menjalankan dan memeriksa
`npm install`, `npm test`, lalu `npm run build`. Build Android mengikuti `.github/workflows/android-apk.yml`.

## Supabase
Project URL diambil dari Supabase Dashboard → Project Settings → API. Aplikasi memakai Publishable Key publik; jangan memasukkan `service_role` atau `sb_secret` ke klien. Login dan co-op perlu konfigurasi proyek Supabase serta migration sesuai panduan `SUPABASE_SETUP_ID.md`.

## Batas verifikasi
Tes otomatis menguji aturan inti dan source wiring. Tes ini bukan pengganti pengujian WebGL di perangkat, build APK nyata, autentikasi live, atau pengujian multiplayer dua perangkat. Event dunia bersama tersedia untuk event tertentu, tetapi ini **bukan simulasi shared-world penuh**: inventory, fauna AI, health/oxygen, dan seluruh simulasi belum sepenuhnya authoritative shared-world.


## Rilis 2.0.2 — HD Ocean & Swim Animation

- Tekstur permukaan air seamless: Low 512 px, Balanced 1024 px, High 2048 px; memakai normal map tangent-space, mipmap, anisotropic filtering, dan material fisik ber-clearcoat.
- Gelombang permukaan multi-skala diperkuat dan mesh air memiliki resolusi yang mengikuti preset grafis.
- Caustics transparan bergerak pada terrain reef/kelp dan terrain dangkal.
- Kelp silindris diganti tuft rumput laut 11 helai yang bergoyang dengan fase berbeda per-instance melalui vertex shader GPU.
- Animasi first-person saat berenang diperkuat: kayuhan kiri/kanan bergantian, pergelangan, bob tubuh, dan peredaman stroke ketika memakai Seaglide atau memegang alat.
- Bubble pool 22 sprite digunakan ulang untuk gelembung ketika penyelam bergerak di bawah air.
- Perubahan preset grafis memperbarui resolusi tekstur air dan subdivisi mesh tanpa reload save.

Save schema v11, Application ID `com.abyssal.game`, inventory, lima Quick Slots, PDA, crafting, habitat, fauna, misi, akun, dan multiplayer tetap dipertahankan. Lihat `CHANGELOG_2.0.2_ID.md` dan `AUDIT_REPORT_2.0.2_ID.md`.


## Rilis 2.0.2 — Water, Seagrass & Swim Polish
- Permukaan air memakai color texture dan tangent-space normal map lokal beresolusi hingga 2048 px pada preset High.
- Gelombang, normal ripples, dan caustics bergerak; kualitas menyesuaikan preset grafis.
- Kelp menjadi tuft 11 helai dengan vertex sway GPU dan variasi fase per-instance. Bug pengulangan indeks sampling untuk kepadatan di atas 20 diperbaiki.
- Animasi first-person saat berenang diperkuat dan bubble pool digunakan ulang untuk menjaga alokasi objek tetap terkendali.
- Save schema v11, Application ID, fitur lama, backend, dan Quick Slots dipertahankan.

Verifikasi source `npm test` lulus. Build Vite/APK, rendering GPU Android, dan multiplayer live belum terverifikasi di lingkungan ini.
