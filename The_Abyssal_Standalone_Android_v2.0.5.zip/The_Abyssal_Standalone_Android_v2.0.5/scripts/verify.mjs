import { readFile, access, readdir } from 'node:fs/promises';
import { resolve, join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { WORLD_SEED, hash2, valueNoise, MAX_DIVE_DEPTH, ABYSSAL_TRENCH, trenchInfluenceAt, seaFloorDepth } from '../world-generation.mjs';
import { applyTouchLook, getLifepodHatchAim, lifepodHullBlocksLocal, lifepodHullBlocksWorld, lifepodInteriorContains, lifepodSegmentBlocked, oxygenUsePerTick, oxygenTankCapacity, oxygenTankDepthRating, depthStressDamage, OXYGEN_TANK_DEPTH_RATINGS, MAX_OXYGEN_TANK_LEVEL, clampFaunaDepth, resolveLifepodMovement, resolveVerticalInput, worldToLifepodLocal } from '../player-mechanics.mjs';
import { waterSurfaceHeightAt, computeSurfaceBlend, canBreatheAtSurface, computeDaylight, computeSeagrassSway, computeSwimPose, waterTextureResolution, resolveGraphicsTextureProfile, GRAPHICS_TEXTURE_TARGETS } from '../environment-simulation.mjs';
import { normalizeRoomCode, sanitizeChatText, sanitizeDisplayName, sanitizePlayerState, sanitizeWorldEventInput, normalizeWorldEvent, flattenPresence, validatePublicBackendConfig } from '../multiplayer-core.mjs';
import {
  normalizeGameSettings,
  normalizeSaveRecord,
  normalizeBackupPayload,
  SAVE_SCHEMA_VERSION,
  SLOT_COUNT
} from '../save-schema.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const read = path => readFile(join(root, path), 'utf8');
const [html, game, fauna, styles, schema, worldGeneration, playerMechanics, multiplayer, multiplayerCore, multiplayerSql, roomRecoverySql, sharedWorldSql, deepWorldSql, envExample, environmentSimulation, manifestText, capacitorText, packageText, workflow, serviceWorker, nativeBuilder, nativePatcher, readme, backendSetup, gitignore] = await Promise.all([
  read('index.html'), read('game.js'), read('fauna.js'), read('styles.css'), read('save-schema.mjs'), read('world-generation.mjs'), read('player-mechanics.mjs'),
  read('multiplayer.js'), read('multiplayer-core.mjs'), read('supabase/migrations/202611060001_multiplayer.sql'),
  read('supabase/migrations/202611060002_room_recovery.sql'), read('supabase/migrations/202611070001_shared_world_events.sql'), read('supabase/migrations/202611070002_deep_world_coordinates.sql'), read('.env.example'), read('environment-simulation.mjs'),
  read('manifest.webmanifest'), read('capacitor.config.json'), read('package.json'),
  read('.github/workflows/android-apk.yml'), read('sw.js'), read('scripts/build-native.mjs'), read('scripts/patch-android.mjs'), read('README_ID.md'), read('scripts/configure-backend.mjs'), read('.gitignore')
]);
const manifest = JSON.parse(manifestText);
const capacitor = JSON.parse(capacitorText);
const pkg = JSON.parse(packageText);
const setupGuide = await read('SUPABASE_SETUP_ID.md');

// Parse every runtime/build script with the same Node major used by CI. This
// catches syntax regressions before Vite or Gradle starts a longer build.
const scriptFiles = (await readdir(join(root, 'scripts'))).filter(file => file.endsWith('.mjs')).map(file => `scripts/${file}`);
const syntaxFiles = ['game.js', 'fauna.js', 'multiplayer.js', 'multiplayer-core.mjs', 'vite.config.js', 'app-update-config.js', 'sw.js', 'save-schema.mjs', 'world-generation.mjs', 'player-mechanics.mjs', 'environment-simulation.mjs', ...scriptFiles];
for (const file of syntaxFiles) {
  const result = spawnSync(process.execPath, ['--check', file], { cwd: root, encoding: 'utf8' });
  assert.equal(result.status, 0, `JavaScript syntax check failed for ${file}: ${result.stderr || result.stdout || result.error || 'unknown error'}`);
}

// DOM IDs must be unique, and every static game.js lookup must point to an element.
const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map(match => match[1]);
const idSet = new Set(ids);
const duplicates = [...new Set(ids.filter((id, index) => ids.indexOf(id) !== index))];
assert.deepEqual(duplicates, [], `Duplicate DOM IDs: ${duplicates.join(', ')}`);
const staticRefs = [...game.matchAll(/\$\(['"]([^'"]+)['"]\)/g)].map(match => match[1]);
const missing = [...new Set(staticRefs.filter(id => !idSet.has(id)))];
assert.deepEqual(missing, [], `Missing DOM nodes: ${missing.join(', ')}`);

// Local assets and module imports must resolve from the archive itself.
for (const match of html.matchAll(/(?:src|href)="\.\/([^?#"]+)/g)) {
  const target = match[1];
  if (!target.startsWith('data:')) await access(join(root, target));
}
for (const sourceFile of ['game.js', 'fauna.js', 'save-schema.mjs', 'world-generation.mjs', 'player-mechanics.mjs', 'environment-simulation.mjs', 'multiplayer.js', 'multiplayer-core.mjs']) {
  const source = await read(sourceFile);
  for (const match of source.matchAll(/(?:from\s*|import\s*\()(['"])(\.\/[^"]+?)\1/g)) {
    await access(join(root, dirname(sourceFile), match[2]));
  }
}
for (const match of game.matchAll(/icon:'([a-z0-9_-]+)'/gi)) {
  await access(join(root, 'icons', 'items', `${match[1]}.png`));
}
for (const match of html.matchAll(/\.\/icons\/([^"']+\.png)/g)) {
  await access(join(root, 'icons', match[1]));
}
for (const match of styles.matchAll(/url\(\s*['\"]?\.\/([^'\")]+)['\"]?\s*\)/g)) {
  await access(join(root, match[1]));
}

// Save migration: old custom bed checkpoints and PDA hotbar assignments are retired.
assert.equal(SLOT_COUNT, 5);
assert.equal(SAVE_SCHEMA_VERSION, 11);
assert.deepEqual(normalizeGameSettings({ graphics: 'ultra', renderDistance: 99, volume: -5, fov: 140, language: 'xx', autoSave: true }), {
  graphics: 'balanced', renderDistance: 3, volume: 0, fov: 90, cameraSensitivity: 1, hudScale: 100, language: 'id'
});
const legacy = normalizeSaveRecord({
  version: 8,
  savedAt: 'bad-date',
  position: { x: 15, y: -12, z: -9 },
  respawnPoint: { x: 750, y: -24, z: -360 },
  yaw: 'NaN', pitch: 99,
  survival: { hp: -20, oxygen: 110, food: 'bad', water: 51, medkits: 999, rations: -3 },
  inventory: { titanium: -9, copper: '4.7', quartz: 10000, invalid: 12 },
  equipment: { tankLevel: 2, fins: 1, rebreather: true, reinforcedSuitOwned: true, helmetOwned: true },
  ownedTools: ['explorer_pda', 'scanner', 'knife', 'flashlight'],
  hotbar: ['explorer_pda', 'scanner', 'knife', 'flashlight', null],
  discoveries: ['clownfish', 'not-a-species', 'abyssal_leviathan'],
  knownBiomes: ['reef', 'bogus', 'abyss'],
  collectedCaches: ['verdant_cache', 'bogus'],
  collectedResources: ['1:2:ore:3', 'bad-key'],
  placedStructures: [
    { id: 'build-1', type: 'beacon', x: 4, y: -8, z: 9, yaw: 2 },
    { id: 'bad', type: 'teleporter', x: 0, y: 0, z: 0 }
  ],
  droppedItems: [
    { id: 'drop-1', type: 'glowcap', position: { x: 2, y: -9, z: 3 } },
    { id: 'bad', type: 'explosive', position: { x: 0, y: 0, z: 0 } }
  ],
  story: { introSeen: true, missionIndex: 999, counters: { materials: 99 }, completed: ['lifepod', 'evil'] }
});
assert.ok(legacy);
assert.equal(legacy.version, 11);
assert.deepEqual(legacy.respawnPoint, { x: 0, y: -7, z: 0 }, 'Legacy bed/checkpoint positions must not survive migration');
assert.equal(legacy.survival.hp, 0);
assert.equal(legacy.survival.oxygen, 110, 'Save v11 oxygen must not be clipped when tank capacity expands');
assert.equal(legacy.survival.medkits, 20);
assert.equal(legacy.inventory.titanium, 0);
assert.equal(legacy.inventory.copper, 5);
assert.equal(legacy.inventory.quartz, 999);
assert.equal(legacy.equipment.tankLevel, 2);
assert.equal(oxygenTankCapacity(0), 45, 'Starter O₂ remains exactly 45');
assert.equal(oxygenTankCapacity(3), 270, 'Existing tank tiers retain their level and gain consistent capacity');
assert.equal(oxygenTankCapacity(4), 345, 'Final tank tier supports a deep expedition');
assert.equal(MAX_OXYGEN_TANK_LEVEL, 4);
const maxTankSave = normalizeSaveRecord({ version:11, position:{x:760,y:-275,z:-620}, survival:{oxygen:345}, inventory:{}, equipment:{tankLevel:4} });
assert.equal(maxTankSave.equipment.tankLevel, 4, 'Save v11 must preserve the new final tank tier');
assert.equal(maxTankSave.survival.oxygen, 345, 'Save normalization must preserve upgraded tank capacity');
let deepRoundTripOxygen = 0;
const deepDiveTicks = [];
for (let depth=14; depth<296; depth+=14) deepDiveTicks.push(depth);
deepDiveTicks.push(296);
for (const depth of [...deepDiveTicks, ...[...deepDiveTicks].reverse()]) deepRoundTripOxygen += oxygenUsePerTick(depth, true, () => 0.999);
assert.ok(deepRoundTripOxygen < oxygenTankCapacity(4), 'Max tank plus Rebreather must support a conservative 296 m return profile');
assert.equal('reinforcedSuitOwned' in legacy.equipment, false);
assert.equal('helmetOwned' in legacy.equipment, false);
assert.equal(legacy.equipment.seaglideCharge, 0, 'No legacy Seaglide should start charged unless it was owned');
assert.deepEqual(legacy.hotbar, [null, 'scanner', 'knife', 'flashlight', null]);
assert.deepEqual(legacy.discoveries, ['clownfish', 'abyssal_leviathan']);
assert.deepEqual(legacy.knownBiomes, ['reef', 'abyss']);
assert.deepEqual(legacy.collectedCaches, ['verdant_cache']);
assert.deepEqual(legacy.collectedResources, ['1:2:ore:3']);
assert.equal(legacy.placedStructures.length, 1);
assert.equal(legacy.droppedItems.length, 1);
assert.equal(legacy.story.missionIndex, 7);
assert.equal(normalizeSaveRecord({ totally: 'invalid' }), null);
const modern = normalizeSaveRecord({ version: 11, position: { x: 5, y: -9, z: 8 }, respawnPoint: { x: 20, y: -8, z: -10 }, survival: {}, inventory: {}, ownedTools:['seaglide'], equipment:{seaglideCharge:72} });
assert.deepEqual(modern.respawnPoint, { x: 20, y: -8, z: -10 });
assert.equal(modern.equipment.seaglideCharge, 72);
const migratedSeaglide = normalizeSaveRecord({ version: 10, position:{x:0,y:-7,z:0}, survival:{}, inventory:{}, ownedTools:['seaglide'] });
assert.equal(migratedSeaglide.equipment.seaglideCharge, 100, 'Legacy Seaglide owners should receive a full battery on migration');
const deepSave = normalizeSaveRecord({ version:11, position:{x:760,y:-275,z:-620}, respawnPoint:{x:760,y:-260,z:-620}, knownBiomes:['deep','abyss'], survival:{}, inventory:{} });
assert.equal(deepSave.position.y, -275, 'Save normalization must preserve legitimate trench depth');
assert.equal(deepSave.respawnPoint.y, -260, 'Deep habitat respawn position must remain valid');
assert.deepEqual(deepSave.knownBiomes, ['deep','abyss'], 'Deep biomes must persist in the existing save schema');
const backup = normalizeBackupPayload({ format: 'the-abyssal-save-backup', schemaVersion: 1, slots: [legacy, null, null, null, null], settings: { volume: 120 } });
assert.equal(backup.slots.length, 5);
assert.equal(backup.settings.volume, 100);
assert.throws(() => normalizeBackupPayload({ format: 'wrong', slots: [] }), /Format backup/);
assert.throws(() => normalizeBackupPayload({ format: 'the-abyssal-save-backup', slots: [null] }), /tepat lima slot/);

// Subnautica-style core loop: backpack dimensions, quick slots, tool gating, survival and habitat systems.
assert.equal(pkg.version, '2.0.5');
assert.match(game, /from '\.\/world-generation\.mjs'/);
assert.match(game, /from '\.\/multiplayer\.js'/);
assert.match(worldGeneration, /export const WORLD_SEED = 0x0ab155a1/);
assert.ok(Number.isInteger(WORLD_SEED) && WORLD_SEED > 0);
assert.equal(hash2(0, 0), hash2(0, 0), 'World seed output must be deterministic');
assert.notEqual(hash2(0, 0), hash2(1, 0), 'Adjacent world coordinates should produce varied terrain');
for (const [x, z] of [[0, 0], [1.25, -4.5], [-180, 92], [10000, -10000]]) {
  const value = hash2(x, z);
  const noise = valueNoise(x, z);
  assert.ok(Number.isFinite(value) && value >= 0 && value < 1, 'World hash must be a finite unit interval value');
  assert.ok(Number.isFinite(noise) && noise >= -1 && noise <= 1, 'Terrain noise must be finite and bounded');
}
assert.equal(MAX_DIVE_DEPTH, 500, 'World dive limit must support the final 500 m pressure tier');
assert.deepEqual([...OXYGEN_TANK_DEPTH_RATINGS],[50,100,200,300,500]);
assert.deepEqual([0,1,2,3,4].map(oxygenTankDepthRating),[50,100,200,300,500]);
assert.equal(depthStressDamage(50,0),0,'Starter tank is safe through 50 m');
assert.equal(depthStressDamage(75,0),2,'Starter tank pressure stress escalates after its 50 m rating');
assert.equal(depthStressDamage(100,1),0,'Tank Mk II is safe through 100 m');
assert.equal(depthStressDamage(125,1),2,'Tank Mk II pressure stress begins beyond 100 m');
assert.equal(depthStressDamage(500,4),0,'Tank Mk V is safe through 500 m');
assert.equal(trenchInfluenceAt(ABYSSAL_TRENCH.x, ABYSSAL_TRENCH.z), 1, 'Trench basin center must have full influence');
assert.equal(trenchInfluenceAt(ABYSSAL_TRENCH.x + 2000, ABYSSAL_TRENCH.z), 0, 'Trench must not modify the existing starter region');
assert.ok(seaFloorDepth(0, 0) > -55, 'Existing spawn-region sea floor must remain unchanged');
assert.ok(seaFloorDepth(ABYSSAL_TRENCH.x, ABYSSAL_TRENCH.z) < -480, 'Remote trench must provide a genuine hadal basin for the 500 m tank tier');
assert.ok(seaFloorDepth(ABYSSAL_TRENCH.x, ABYSSAL_TRENCH.z) > -496, 'Trench floor must remain above the hard dive limit with capsule clearance');
for (let ox=-200; ox<=200; ox+=50) for (let oz=-200; oz<=200; oz+=50) assert.ok(seaFloorDepth(ABYSSAL_TRENCH.x+ox,ABYSSAL_TRENCH.z+oz) >= -496, 'No trench sample may fall below the safe floor limit');
assert.ok(oxygenUsePerTick(490,false,()=>0.999) > oxygenUsePerTick(44,false,()=>0.999), 'Oxygen demand must increase at the deepest playable depth');
assert.match(game, /import \{ hash2, valueNoise, seaFloorDepth, trenchInfluenceAt, ABYSSAL_TRENCH, MAX_DIVE_DEPTH \} from '\.\/world-generation\.mjs'/);
assert.doesNotMatch(game, /WORLD_SEED is not defined/);
assert.ok(idSet.has('boot-retry-btn'), 'Boot recovery button is required');
assert.match(game, /boot-retry-btn/);
assert.match(game, /Dunia 3D gagal dimuat/);
assert.match(game, /const SURVIVAL_DEFAULTS = \{ hp: 100, oxygen: 45/);
assert.match(game, /const columns = 8, rows = 6/);
assert.match(game, /for \(let index=0; index<48; index\+\+\)/);
assert.match(html, /48 CELLS USED/);
assert.match(html, /aria-label="5 Quick Slots"/);
assert.match(game, /let hotbarSlots = \['scanner','knife','flashlight',null,null\]/);
assert.match(game, /if \(itemId === 'explorer_pda'\)/);
assert.match(game, /explorer_pda:\{name:'PDA'/);
assert.match(game, /size:6,kind:'tool',width:2,height:3/);
assert.match(game, /function getMaxOxygen\(\) \{ return oxygenTankCapacity\(equipment\.tankLevel \|\| 0\); \}/);
assert.match(game, /oxygenTickTimer >= 2/);
assert.match(game, /oxygenUsePerTick\(depth,Boolean\(equipment\.rebreather\)\)/);
assert.match(game, /seaFloorDepth\(x, z\)/);
assert.match(game, /MAX_DIVE_DEPTH/);
assert.match(game, /Twilight Trench/);
assert.match(game, /TRENCH ANOMALY/);
assert.match(game, /depthNow \/ MAX_DIVE_DEPTH/);
assert.match(game, /root\.position\.set\(0,-0\.45,-7\.5\)/, 'Lifepod must float at the waterline rather than sit fully submerged');
assert.match(game, /player\.yaw=0; player\.pitch=-0\.82/, 'New game camera must initially frame the roof hatch from the water');
assert.match(game, /player\.position\.y=inside\.y\+2\.05\*LIFEPOD_SCALE/, 'Lifepod exit must align with the roof hatch');
assert.match(game, /function updateBuildPreview\(/, 'Habitat Builder must show a world-space placement hologram');
assert.match(game, /function updateResourceBreakActions\(/, 'Ore destruction must have a timed impact animation');
assert.match(game, /playSfx\(node\.type==='kelp'\?'knife':'oreHit'\)/, 'Mining hit must have an audio event');
assert.match(game, /playSfx\('oreBreak'\)/, 'Ore break must have an audio event');
assert.match(game, /const flashlightBeam = new THREE\.SpotLight\(0xc8fbff, 42, 54/, 'Flashlight must use a real world SpotLight');
assert.match(game, /introSequence\.attacker\.userData\.tail/, 'Intro leviathan must animate its tail');
assert.match(game, /camera\.lookAt\(creature\.x,creature\.y-\.25,creature\.z-5\.0\)/, 'Cutscene camera must frame the leviathan');
assert.match(html, /id="menu-background-video"[^>]*autoplay muted loop playsinline/, 'Main menu must use a local looping cinematic video');
await access(join(root,'assets/menu-underwater-loop.mp4'));
await access(join(root,'assets/menu-underwater-frame.png'));
assert.match(game, /SAFE DEPTH/);
assert.match(game, /depthStressDamage\(depth,equipment\.tankLevel\)/);
assert.match(fauna, /depth:\[-220,-475\]/, 'Trench Leviathan must inhabit the extended 500 m trench');
assert.match(styles, /\.cinematic-caption\{position:absolute;top:/, 'Cutscene subtitle must sit in the upper centre area');
assert.match(fauna, /trench_leviathan/);
assert.match(fauna, /abyssal_stalker/);
assert.match(fauna, /instanceId/);
assert.match(fauna, /animal\.instanceId===targetId/);
assert.match(fauna, /clampFaunaDepth\(pos\.y,seabed,clearance,species\.depth\)/);
assert.equal(clampFaunaDepth(-42, -296, 2.5, [-178,-292]), -178, 'Trench fauna cannot float above its authored deep habitat');
assert.equal(clampFaunaDepth(-295, -296, 2.5, [-178,-292]), -292, 'Trench fauna cannot pass below its authored depth range');
assert.equal(clampFaunaDepth(-170, -40, 1.5, [-178,-292]), -38.5, 'Fauna must stay above shallow terrain when no depth-band overlap exists');
assert.match(playerMechanics, /Math\.sqrt\(Math\.max\(0, depth - 20\) \/ 8\)/);
assert.match(game, /survival\.oxygen=clamp\(survival\.oxygen-oxygenCost,0,getMaxOxygen\(\)\)/);
assert.doesNotMatch(game, /oxygenRate \* dt/);
assert.equal(oxygenUsePerTick(5, false, () => 0), 2, 'Normal-depth minimum oxygen use is 2 per tick');
assert.equal(oxygenUsePerTick(5, false, () => 0.999), 4, 'Normal-depth maximum oxygen use is 4 per tick');
assert.equal(oxygenUsePerTick(20, false, () => 0), 4, 'Deep-water oxygen use starts at 4 per tick');
assert.equal(oxygenUsePerTick(44, false, () => 0.999), 7, 'Deep-water demand rises smoothly with depth');
assert.ok(oxygenUsePerTick(44, true, () => 0.999) < oxygenUsePerTick(44, false, () => 0.999), 'Rebreather must reduce deep-water oxygen demand');
assert.match(game, /if \(indoorHabitat && isHabitatPowered\(indoorHabitat\)\)/);
assert.match(game, /else if \(atSurface\)/);
assert.match(game, /function isHabitatPowered\(/);
assert.match(game, /function openFabricator\(\)/);
assert.match(game, /function craftFabricatorRecipe\(id\)/);
assert.match(game, /sustenance:\{title:'Sustenance'/);
assert.match(game, /personal:\{title:'Personal'/);
assert.match(game, /resources:\{title:'Resources'/);
assert.match(game, /electronics:\{title:'Electronics'/);
assert.match(game, /function openBuildMenu\(\)[\s\S]*?getSelectedHotbarItem\(\) !== 'habitat_builder'/);
assert.match(game, /function interactNearby\(\)/);
assert.match(game, /function gatherNearbyResource\(\)/);
assert.match(game, /function scanNearestFauna\(\)/);
assert.match(game, /minAlignment:0\.945/);
assert.match(game, /function makeFirstPersonViewModel\(\)/);
assert.match(game, /makeWaterColorTexture/);
assert.match(game, /makeWaterNormalTexture/);
assert.match(game, /function applyWaterQualitySettings\(profile =/);
assert.match(game, /oldGeometry\.dispose\(\)/);
assert.match(game, /causticTexture\.offset\.x/);
assert.match(game, /makeSeagrassTuftGeometry/);
assert.match(game, /const randomCount = Math\.max\(20, kelpAttempts \+ 12\)/, 'Kelp density must have enough independent deterministic placement samples');
const kelpLoopStart = game.indexOf('for (let i = 0; i < kelpAttempts; i++) {');
const kelpLoopEnd = game.indexOf('\n  kelp.count', kelpLoopStart);
assert.ok(kelpLoopStart >= 0 && kelpLoopEnd > kelpLoopStart, 'Kelp placement loop must be present');
const kelpPlacementLoop = game.slice(kelpLoopStart, kelpLoopEnd);
assert.doesNotMatch(kelpPlacementLoop[1], /%\s*20/, 'High-density kelp placement must not wrap after 20 samples');
assert.match(game, /updateSwimBubbles\(dt\)/);
assert.match(game, /computeSwimPose\(player\.swimPhase/);
assert.match(game, /new THREE\.MeshPhysicalMaterial\(\{/);
assert.match(game, /const visualQuality = getActiveGraphicsQuality\(\);[\s\S]*?const waterSegments = visualQuality === 'low' \? 72 : visualQuality === 'high' \? 160 : 112/);
assert.match(game, /viewModel\.userData\.seaglide\.visible=selectedTool==='seaglide'/);
assert.match(game, /equipment\.seaglideCharge-0\.30\*dt/);
assert.match(game, /Ganti baterai Seaglide/);
assert.match(game, /function activateLifepod\([\s\S]*?getSelectedHotbarItem/);
assert.match(game, /ownedTools\.includes\('repair_tool'\)\|\|getSelectedHotbarItem\(\)!=='repair_tool'/);
assert.match(game, /CONTROL CONSOLE · FABRICATE REPAIR TOOL/);
assert.match(game, /consoleMaterial\.emissive\.setHex\(0x18c9b8\)/);
assert.match(game, /const speed=.*seaglideEquipped\?1\.75/);
assert.match(game, /function enterHabitat\(target\)/);
assert.match(game, /getAimedLifepodHatchTarget/);
assert.match(game, /ENTER THROUGH TOP HATCH/);
assert.match(game, /transparent:false, opacity:1, depthWrite:true/);
assert.match(game, /lifepodHullBlocksWorld/);
assert.match(game, /resolveLifepodMovement/);
assert.match(game, /function updateLifepodInteriorVisibility\(\)/);
assert.match(game, /function openLifepodHatch\(/);
assert.match(game, /function updateLifepodHatchAnimation\(/);
assert.match(game, /lostpointercapture', stopLook/);
assert.match(game, /if \(joyPointer !== null\) return/);
assert.match(game, /if \(look\.active\) return/);
assert.match(game, /const releaseTouchControls = \(\) =>/);
assert.match(game, /visibilitychange', \(\) => \{ if \(document\.hidden\) releaseTouchControls\(\); \}/);
assert.match(game, /applyTouchLook/);
assert.match(game, /function attackWithKnife\(\)/);
assert.match(fauna, /attackTarget\(playerPosition, origin, direction/);
assert.match(game, /flashlightEnabled/);
assert.match(game, /viewModel\.traverse\(object =>/);
assert.ok(idSet.has('attack-btn'), 'Knife action button must exist');
assert.ok(idSet.has('camera-sensitivity-range') && idSet.has('hud-scale-range'), 'Touch sensitivity and HUD scale controls must exist');
assert.ok(idSet.has('replay-intro-btn'), 'Intro cinematic replay control must exist');
assert.match(game, /startIntroCinematic\(\{replayOnly:true\}\)/);
assert.match(game, /if\(replayOnly\)\{/);
assert.match(game, /settings\.cameraSensitivity/);
assert.match(game, /settings\.hudScale/);
assert.equal(normalizeGameSettings({cameraSensitivity:99,hudScale:999}).cameraSensitivity,2);
assert.equal(normalizeGameSettings({cameraSensitivity:-1,hudScale:1}).cameraSensitivity,0.5);
assert.equal(normalizeGameSettings({cameraSensitivity:1,hudScale:999}).hudScale,130);
assert.equal(normalizeGameSettings({cameraSensitivity:1,hudScale:1}).hudScale,80);
assert.match(html, /icons\/hud\/attack\.png/);
assert.equal(applyTouchLook(0, 0, 20, 0).yaw > 0, true, 'A rightward swipe must turn the camera right');
assert.equal(applyTouchLook(0, 0, -20, 0).yaw < 0, true, 'A leftward swipe must turn the camera left');
assert.equal(applyTouchLook(0, 0, 0, 1000).pitch, 0.98, 'Camera pitch must be clamped');
assert.equal(resolveVerticalInput(1,0),1,'An active ascend pointer must move upward');
assert.equal(resolveVerticalInput(0,1),-1,'An active descend pointer must move downward');
assert.equal(resolveVerticalInput(1,1),0,'Opposing vertical controls must cancel safely');
assert.equal(resolveVerticalInput(2,1),0,'Releasing one pointer must not leave a stale vertical direction');
assert.equal(resolveVerticalInput(0,0),0,'No active vertical pointer must be neutral');
assert.match(game,/const verticalPointers = \{ ascend:new Set\(\), descend:new Set\(\) \}/);
assert.match(game,/pointerSet\.delete\(event\.pointerId\); updateVerticalInput\(\)/);
assert.match(game,/cameraBaseQuaternion\.slerp\(cameraTargetQuaternion,cameraBlend\)/);
assert.match(game,/camera\.quaternion\.copy\(cameraBaseQuaternion\)\.multiply\(cameraRollQuaternion\)/);
assert.doesNotMatch(game,/camera\.rotateZ\(/,'Camera roll must be composed from a clean base quaternion and never accumulated frame-to-frame');
assert.match(game,/function hasQuickSlotItem\(itemId\)/);
assert.match(game,/viewModel\.userData\.heldItems=heldItems/);
assert.match(game,/for \(const id of Object\.keys\(ITEM_DEFS\)\) makeHeldItem\(id\)/);
assert.match(game,/const hasSelectedItem=hasQuickSlotItem\(selectedTool\)/);
assert.match(game,/Slot Cepat \${selectedHotbarIndex \+ 1}/);
assert.doesNotMatch(game,/Hotbar \${selectedHotbarIndex/,'Player-facing Quick Slot feedback must not show legacy Hotbar labels');
assert.match(game,/faunaDirector\?\.resetPopulation\(player\.position\)/);
assert.match(fauna,/resetPopulation\(playerPosition = null\)/);
assert.match(fauna,/getAttackTarget\(playerPosition, origin, direction/);
assert.match(game,/getAttackTarget\(player\.position,origin,direction,3\.4\)/);
assert.match(game,/attackButton\?\.classList\.toggle\('hidden',!attackAim\)/);
assert.equal(lifepodInteriorContains(0, 0, 0), true);
assert.equal(lifepodHullBlocksLocal(0, 0, 0), false, 'The hatch-entered interior remains traversable');
assert.equal(lifepodHullBlocksLocal(1.3, 0, 0), true, 'The Lifepod side wall blocks the player capsule');
assert.equal(lifepodHullBlocksLocal(0, 1.6, 0), true, 'The Lifepod roof blocks upward/downward tunnelling');
assert.equal(lifepodHullBlocksLocal(0, -1.6, 0), true, 'The Lifepod underside blocks tunnelling');
assert.equal(lifepodHullBlocksLocal(4, 0, 0), false, 'Collision volume must not extend indefinitely');
const rotatedPod = { x: 12, y: -8, z: -4 };
const rotatedYaw = 0.42;
const podCenter={...rotatedPod};
const verticalEscape=resolveLifepodMovement(podCenter,{x:podCenter.x,y:podCenter.y+3.2,z:podCenter.z},rotatedPod,rotatedYaw);
assert.equal(verticalEscape.blocked.y,true,'Lifepod roof must block vertical movement, not only horizontal movement');
assert.ok(verticalEscape.position.y < podCenter.y+1.1,'The diver must remain below the Lifepod roof after a vertical collision');
const undersideEscape=resolveLifepodMovement(podCenter,{x:podCenter.x,y:podCenter.y-3.2,z:podCenter.z},rotatedPod,rotatedYaw);
assert.equal(undersideEscape.blocked.y,true,'Lifepod underside must block downward movement');
const sideEscape=resolveLifepodMovement(podCenter,{x:podCenter.x+3.2,y:podCenter.y,z:podCenter.z},rotatedPod,rotatedYaw);
assert.equal(sideEscape.blocked.x,true,'Lifepod side wall must block horizontal movement');
assert.ok(sideEscape.position.x < podCenter.x+1.1,'The diver must remain inside the hull after a side collision');
const localCenter = { x: 0, y: 0, z: 0 };
const rotatedWorldCenter = { x: rotatedPod.x + localCenter.x*Math.cos(rotatedYaw) + localCenter.z*Math.sin(rotatedYaw), y: rotatedPod.y, z: rotatedPod.z - localCenter.x*Math.sin(rotatedYaw) + localCenter.z*Math.cos(rotatedYaw) };
assert.deepEqual(worldToLifepodLocal(rotatedWorldCenter.x, rotatedWorldCenter.y, rotatedWorldCenter.z, rotatedPod, rotatedYaw), { x: 0, y: 0, z: 0 }, 'World/local transform must invert Three.js yaw rotation');
assert.equal(lifepodInteriorContains(...Object.values(worldToLifepodLocal(rotatedWorldCenter.x, rotatedWorldCenter.y, rotatedWorldCenter.z, rotatedPod, rotatedYaw))), true);
assert.equal(lifepodSegmentBlocked({x:10,y:-8,z:-4},{x:14,y:-8,z:-4},rotatedPod,rotatedYaw), true, 'Swept collision must stop movement through the hull');
const hatchOrigin = { x: rotatedPod.x + 0.15*Math.sin(rotatedYaw), y: rotatedPod.y + 4, z: rotatedPod.z + 0.15*Math.cos(rotatedYaw) };
const hatchDirection = { x: -Math.sin(rotatedYaw)*0, y: -1, z: 0 };
assert.ok(getLifepodHatchAim(hatchOrigin, hatchDirection, rotatedPod, rotatedYaw, 7), 'Top hatch should be aimable from above');
assert.equal(getLifepodHatchAim(hatchOrigin, {x:1,y:0,z:0}, rotatedPod, rotatedYaw, 7), null, 'Sideways aim cannot trigger hatch entry');
assert.match(game, /function exitHabitat\(\)/);
assert.match(game, /function saveCurrentSlot\(\)/);
assert.match(game, /No background saving: progress is committed only when the player selects Save/);

// Explicitly retired custom features are absent from runtime, schema, and interface.
for (const [label, source] of [['game.js', game], ['save-schema.mjs', schema], ['index.html', html], ['styles.css', styles]]) {
  assert.doesNotMatch(source, /autoSave|autosave-toggle|autosave-setting/i, `${label} still exposes autosave`);
  assert.doesNotMatch(source, /bed-btn|bed checkpoint|checkpoint kasur|isNearHabitatBed/i, `${label} still exposes bed checkpoints`);
  assert.doesNotMatch(source, /chestplate|helmetOwned|reinforcedSuitOwned|oxygen_station/i, `${label} still exposes retired armor/oxygen-station gear`);
}
assert.doesNotMatch(game, /Math\.random\(\) \* 3|oxygenDrainTimer/, 'Random/timed oxygen drain must be removed');
assert.doesNotMatch(game, /pressureDamageTimer|thermalDamageTimer|temperatureC/, 'Custom pressure/temperature damage must be removed');
assert.ok(!idSet.has('supply-btn'), 'Separate supply button should be replaced by contextual Interact');
assert.ok(!idSet.has('autosave-toggle') && !idSet.has('bed-btn'));

// Android/offline packaging must not depend on an external backend.
assert.equal(manifest.orientation, 'landscape');
assert.equal(capacitor.appId, 'com.abyssal.game');
assert.equal(capacitor.webDir, 'www');
assert.ok(pkg.dependencies['@capacitor/app'], 'Native Android back/lifecycle plugin must be installed');
assert.match(serviceWorker, /the-abyssal-2-0-5-depth-lifepod-cinematic-overhaul/);
assert.match(game, /const current = '2\.0\.5'/);
assert.match(backendSetup, /VITE_SUPABASE_URL/);
assert.match(workflow, /node scripts\/configure-backend\.mjs/);
assert.match(workflow, /native\/abyssal-debug-signing\.bin/);
assert.match(nativePatcher, /native\/abyssal-debug-signing\.bin/);
assert.doesNotMatch(gitignore, /abyssal-debug-signing\.bin/);
await access(join(root, 'native/abyssal-debug-signing.bin'));
assert.match(workflow, /dump badging/);
assert.match(workflow, /com\.abyssal\.game/);
assert.match(workflow, /VITE_SUPABASE_URL/);
assert.match(workflow, /VITE_SUPABASE_PUBLISHABLE_KEY/);
assert.doesNotMatch(nativePatcher, /auth\/callback|deepLinkFilter/);
assert.match(nativeBuilder, /await build\(/);
assert.match(workflow, /npm test/);
assert.match(workflow, /assembleDebug/);
assert.match(workflow, /if \[ -d android \]/);
assert.match(workflow, /npm run android:sync/);
assert.match(workflow, /npm run android:add/);
assert.match(workflow, /actions\/upload-artifact@v7/);
assert.doesNotMatch(workflow, /actions\/upload-artifact@v4/);
assert.match(readme, /multiplayer/i);
assert.match(readme, /Supabase/i);
assert.match(multiplayer, /signUp/);
assert.match(multiplayer, /get authReady\(\)/);
assert.match(multiplayer, /signInWithPassword/);
assert.match(multiplayer, /abyssal_create_room/);
assert.match(multiplayer, /abyssal_join_room/);
assert.match(multiplayer, /player_state/);
assert.match(multiplayer, /room_chat/);
assert.match(multiplayer, /trackStatus !== 'ok'/);
assert.match(multiplayer, /status !== 'ok'/);
assert.match(multiplayer, /status === 'SUBSCRIBED'/);
assert.match(game, /diver\.initialized/);
assert.match(game, /ROOM RECONNECTING/);
assert.match(game, /KONFIGURASI TERSIMPAN/);
assert.match(workflow, /VITE_SUPABASE_URL: \$\{\{ secrets\.SUPABASE_URL \}\}/);
assert.match(workflow, /VITE_SUPABASE_PUBLISHABLE_KEY: \$\{\{ secrets\.SUPABASE_PUBLISHABLE_KEY \}\}/);
assert.match(workflow, /the-abyssal-android-apk-2\.0\.5/);
assert.match(nativeBuilder, /configure-backend\.mjs/);
assert.match(multiplayerSql, /enable row level security/i);
assert.match(multiplayerSql, /abyssal_is_room_member/);
assert.match(multiplayerSql, /realtime\.messages/);
assert.match(multiplayerSql, /realtime\.topic\(\)/i);
assert.match(sharedWorldSql,/abyssal_room_world_events/);
assert.match(sharedWorldSql,/enable row level security/i);
assert.match(sharedWorldSql,/abyssal_is_room_member/);
assert.match(sharedWorldSql,/abyssal_push_world_event/);
assert.match(sharedWorldSql,/abyssal_read_world_events/);
assert.match(sharedWorldSql,/unique \(room_id, actor_id, client_event_id\)/i);
assert.match(sharedWorldSql,/on conflict \(room_id, actor_id, client_event_id\) do nothing/i,'World event RPC must tolerate an idempotent retry race');
assert.match(sharedWorldSql,/jsonb_build_object\('type', v_payload->>'type'\)/,'Server stores only a canonical event payload');
assert.match(multiplayer,/abyssal_push_world_event/);
assert.match(multiplayer,/abyssal_read_world_events/);
assert.match(multiplayer,/worldOutboxKey/);
assert.match(multiplayer,/refreshWorldEvents/);
assert.match(multiplayer,/const latestQueue = this\.readWorldOutbox\(roomId\)/,'Outbox flush must merge acknowledgements with concurrently appended events');
assert.match(multiplayer,/Do not clear in-flight locks here/,'Room changes must not unlock still-pending world sync requests');
assert.match(game,/applySharedWorldEvent/);
assert.match(game,/publishSharedWorldEvent\('resource_collected'/);
assert.match(game,/publishSharedWorldEvent\('structure_placed'/);
assert.match(game,/publishSharedWorldEvent\('cache_collected'/);
assert.match(game,/resolveLifepodMovement\(from,requested/,'Runtime movement must use the swept 3-axis collision resolver');
assert.match(game,/player\.position\.y=clamp\(player\.position\.y,floorClearance,upperBound\)/,'Floor clamp must preserve collision-resolved Y, never restore the blocked target');
assert.doesNotMatch(game,/player\.position\.y=clamp\(nextY,floorClearance,upperBound\)/);
assert.match(multiplayerSql, /abyssal_is_realtime_room_member/i);
assert.match(multiplayerSql, /\[\^A-Za-z0-9\]/, 'Server room-code sanitizer must accept lowercase codes before uppercase normalization');
assert.match(envExample, /VITE_SUPABASE_URL/);
assert.match(envExample, /VITE_SUPABASE_PUBLISHABLE_KEY/);
assert.doesNotMatch(envExample, /VITE_[A-Z0-9_]+=(?:sb_secret_|[^\n]*service_role)/i, 'The environment template must never contain a secret key value');
assert.match(workflow, /secrets\.SUPABASE_URL/);
assert.match(workflow, /secrets\.SUPABASE_PUBLISHABLE_KEY/);
assert.match(game, /MULTIPLAYER ROOM/);
assert.match(html, /id="online-login-form"/);
assert.match(html, /id="online-register-form"/);
assert.match(html, /id="create-room-btn"/);
assert.match(html, /id="join-room-btn"/);
assert.match(html, /id="online-chat-form"/);
assert.match(html, /id="backend-config-form"/);
assert.match(html, /id="backend-project-url"/);
assert.match(html, /id="backend-publishable-key"/);
assert.match(multiplayer, /configureBackend/);
assert.match(multiplayer, /the-abyssal-supabase-config-v1/);
assert.match(game, /online\.configureBackend/);
assert.match(game, /!online\.authReady/);
assert.match(game, /explainOnlineError/);
assert.match(game, /Email belum diverifikasi/);
assert.deepEqual(validatePublicBackendConfig('https://abyssal-demo.supabase.co', 'sb_publishable_example_public_key'), { url:'https://abyssal-demo.supabase.co', publishableKey:'sb_publishable_example_public_key' });
assert.throws(() => validatePublicBackendConfig('http://abyssal-demo.supabase.co', 'sb_publishable_example_public_key'), /HTTPS/);
assert.throws(() => validatePublicBackendConfig('https://abyssal-demo.supabase.co', 'sb_secret_do_not_use'), /secret/);
assert.throws(() => validatePublicBackendConfig('https://abyssal-demo.supabase.co', 'not-a-key'), /Key tidak dikenali/);
assert.equal(normalizeRoomCode(' ab-12cd '), 'AB12CD');
assert.equal(normalizeRoomCode('A!B?'), 'AB');
assert.equal(sanitizeChatText('  hi\nthere\u0000  '), 'hi there');
assert.equal(sanitizeDisplayName('  <Diver>  '), 'Diver');
assert.equal(sanitizePlayerState({ userId:'u1', x:1, y:-7, z:2, yaw:0.5, pitch:0.2 }).depth, 7);
assert.equal(sanitizePlayerState({ userId:'u1', x:760, y:-275, z:-620, yaw:0.5, pitch:0.2 })?.y, -275, 'Deep-diver player state must pass multiplayer sanitizer');
assert.equal(sanitizeWorldEventInput('structure_placed','trench-build',{type:'compartment',x:760,y:-270,z:-620,yaw:0.5})?.payload.y, -270, 'Deep habitat build event must pass client sanitizer');
assert.equal(sanitizePlayerState({ userId:'u1', x:Infinity, y:-7, z:2, yaw:0, pitch:0 }), null);
assert.deepEqual(flattenPresence({u1:[{user_id:'u1',display_name:'Diver 1'}],u2:[{user_id:'u2',display_name:'Diver 2'}]}).map(member=>member.userId), ['u1','u2']);
assert.deepEqual(sanitizeWorldEventInput('resource_collected','12:8:ore:2',{type:'copper'}), {eventType:'resource_collected',entityId:'12:8:ore:2',payload:{type:'copper'}});
assert.equal(sanitizeWorldEventInput('structure_placed','build-1',{type:'compartment',x:12,y:-8,z:4,yaw:0.5})?.payload.type,'compartment');
assert.equal(sanitizeWorldEventInput('structure_placed','build-1',{type:'teleporter',x:0,y:0,z:0,yaw:0}),null);
assert.equal(sanitizeWorldEventInput('resource_collected','x'.repeat(150),{type:'copper'}).entityId.length,120);
assert.equal(sanitizeWorldEventInput('structure_placed','build-blank',{type:'compartment',x:'',y:0,z:0,yaw:0}),null,'Blank coordinates must not be coerced to zero');
assert.equal(sanitizeWorldEventInput('structure_placed','build-bool',{type:'compartment',x:true,y:0,z:0,yaw:0}),null,'Boolean coordinates must not be coerced to numbers');
assert.equal(normalizeWorldEvent({event_id:'7',actor_id:'user-2',event_type:'biome_discovered',entity_id:'reef',payload:{biomeId:'reef'},created_at:'2026-11-07T00:00:00Z'}).eventId,7);
assert.equal(normalizeWorldEvent({event_id:'bad',actor_id:'user-2',event_type:'biome_discovered',entity_id:'reef',payload:{biomeId:'reef'}}),null);
assert.ok(styles.includes('.oxygen-gauge') && styles.includes('.depth-indicator') && styles.includes('.hotbar-slot'));
assert.ok(styles.includes('.inventory-slot-grid') && styles.includes('.fabricator-recipes') && styles.includes('.action-controls'));


const configureScript = join(root, 'scripts/configure-backend.mjs');
const cleanEnv = { ...process.env };
for (const key of ['VITE_SUPABASE_URL','SUPABASE_URL','VITE_SUPABASE_PUBLISHABLE_KEY','SUPABASE_PUBLISHABLE_KEY','VITE_SUPABASE_ANON_KEY','SUPABASE_ANON_KEY']) delete cleanEnv[key];
const offlineConfig = spawnSync(process.execPath, [configureScript], { cwd: root, env: cleanEnv, encoding: 'utf8' });
assert.equal(offlineConfig.status, 0, `Offline config should remain buildable: ${offlineConfig.stderr}`);
const configuredEnv = { ...cleanEnv, VITE_SUPABASE_URL:'https://abyssal-demo.supabase.co', VITE_SUPABASE_PUBLISHABLE_KEY:'sb_publishable_example_public_key' };
const validConfig = spawnSync(process.execPath, [configureScript], { cwd: root, env: configuredEnv, encoding: 'utf8' });
assert.equal(validConfig.status, 0, `Public Supabase configuration should validate: ${validConfig.stderr}`);
const partialConfig = spawnSync(process.execPath, [configureScript], { cwd: root, env: { ...cleanEnv, VITE_SUPABASE_URL:'https://abyssal-demo.supabase.co' }, encoding: 'utf8' });
assert.notEqual(partialConfig.status, 0, 'Partial Supabase config must fail closed');
const secretConfig = spawnSync(process.execPath, [configureScript], { cwd: root, env: { ...cleanEnv, VITE_SUPABASE_URL:'https://abyssal-demo.supabase.co', VITE_SUPABASE_PUBLISHABLE_KEY:'sb_secret_never_bundle' }, encoding: 'utf8' });
assert.notEqual(secretConfig.status, 0, 'Supabase secret keys must never be bundled');
const unknownKeyConfig = spawnSync(process.execPath, [configureScript], { cwd: root, env: { ...cleanEnv, VITE_SUPABASE_URL:'https://abyssal-demo.supabase.co', VITE_SUPABASE_PUBLISHABLE_KEY:'not-a-supabase-key' }, encoding: 'utf8' });
assert.notEqual(unknownKeyConfig.status, 0, 'Unknown key formats must fail closed');

// 2.0.0 deep-expedition, waterline, scaled Lifepod, and fauna habitat constraints: verify Auth endpoint wiring/config validation,
// app lifecycle source, stale room-membership recovery source, and actual native launcher icon assets.
assert.match(multiplayer, /\/auth\/v1\/settings/);
assert.match(multiplayer, /headers:\s*\{\s*apikey:\s*this\.publishableKey/);
assert.match(multiplayer, /data === false/);
assert.match(multiplayer, /abyssal_join_room/);
assert.match(multiplayer, /heartbeatInFlight/);
assert.match(game, /bindNativeLifecycle/);
assert.match(game, /addListener\('backButton'/);
assert.match(game, /addListener\('appStateChange'/);
assert.match(game, /Keluar dari The Abyssal/);
assert.match(roomRecoverySql, /create or replace function public\.abyssal_join_room/);
assert.match(roomRecoverySql, /Promote the oldest[\s\S]*active member/);
assert.match(roomRecoverySql, /grant execute on function public\.abyssal_join_room\(text\) to authenticated/);
assert.match(nativePatcher, /native\/android-icons\/mipmap-\$\{density\}/);
assert.match(nativePatcher, /android:roundIcon="@mipmap\/ic_launcher_round"/);
assert.ok(nativePatcher.includes('manifest.match(/<application\\b'), 'Android manifest application tag must use a word-boundary regex');
for (const relative of [
  'icons/icon-192.png', 'icons/icon-512.png', 'icons/icon-maskable-512.png',
  'native/android-icons/ic_launcher_foreground.png',
  'native/android-icons/mipmap-anydpi-v26/ic_launcher.xml',
  'native/android-icons/mipmap-anydpi-v26/ic_launcher_round.xml',
  'native/android-icons/abyssal_launcher_colors.xml',
  'native/android-icons/mipmap-mdpi/ic_launcher.png',
  'native/android-icons/mipmap-hdpi/ic_launcher.png',
  'native/android-icons/mipmap-xhdpi/ic_launcher.png',
  'native/android-icons/mipmap-xxhdpi/ic_launcher.png',
  'native/android-icons/mipmap-xxxhdpi/ic_launcher.png'
]) await access(join(root, relative));
for (const [relative, expectedSize] of [
  ['icons/icon-192.png', 192],
  ['icons/icon-512.png', 512],
  ['icons/icon-maskable-512.png', 512],
  ['native/android-icons/ic_launcher_foreground.png', 432],
  ['native/android-icons/mipmap-mdpi/ic_launcher.png', 48],
  ['native/android-icons/mipmap-hdpi/ic_launcher.png', 72],
  ['native/android-icons/mipmap-xhdpi/ic_launcher.png', 96],
  ['native/android-icons/mipmap-xxhdpi/ic_launcher.png', 144],
  ['native/android-icons/mipmap-xxxhdpi/ic_launcher.png', 192]
]) {
  const png = await readFile(join(root, relative));
  assert.equal(png.subarray(0, 8).toString('hex'), '89504e470d0a1a0a', `${relative} must be a PNG`);
  assert.equal(png.readUInt32BE(16), expectedSize, `${relative} width is incorrect`);
  assert.equal(png.readUInt32BE(20), expectedSize, `${relative} height is incorrect`);
}

// 2.0.0 environment, Lifepod scale, and texture regression tests.
assert.match(game, /const LIFEPOD_SCALE = 1\.32/);
assert.match(game, /root\.scale\.setScalar\(LIFEPOD_SCALE\)/);
assert.match(game, /waterSurfaceHeightAt\(player\.position\.x,player\.position\.z,clockState\.elapsed\)/);
assert.match(game, /updateSurfacePresentation\(eyeY,localWaterHeight,biome\)/);
assert.match(game, /updateWaterSurface\(dt\)/);
assert.match(game, /PlaneGeometry\(1900, 1900, waterSegments, waterSegments\)/);
assert.match(game, /surfaceSky\.userData\.dome\.material\.opacity=surfaceBlend/);
assert.match(game, /surfaceWaterTint/);
assert.match(fauna, /createTurtleShellTexture\(bump = false, size = 512\)/);
assert.match(fauna, /Hexagonal scutes/);
assert.match(fauna, /turtleShellBumpTexture/);
assert.match(fauna, /new THREE\.TorusGeometry\(0\.76, 0\.075, 8, 36\)/);
assert.match(styles, /surface-transition::after/);
assert.match(html, /aria-label="Quick Slot 1"/);
assert.match(html, /ANDROID BUILD 2\.0\.5/);
assert.match(html, /Low · 1024×1024/);
assert.match(html, /Medium · 2048×2048/);
assert.match(html, /High · 4096×4096/);
assert.match(html, /id="graphics-detail"/);
assert.match(environmentSimulation, /export function waterSurfaceHeightAt/);
assert.match(environmentSimulation, /export function canBreatheAtSurface/);
assert.match(environmentSimulation, /export function computeDaylight/);
assert.match(environmentSimulation, /export function computeSeagrassSway/);
assert.match(environmentSimulation, /export function computeSwimPose/);
assert.match(environmentSimulation, /export function waterTextureResolution/);
const waterA = waterSurfaceHeightAt(12.5, -7.25, 18);
const waterB = waterSurfaceHeightAt(12.5, -7.25, 18);
const waterLater = waterSurfaceHeightAt(12.5, -7.25, 19);
assert.equal(waterA, waterB, 'Water waves must be deterministic at the same world coordinate and time');
assert.ok(Number.isFinite(waterA) && Math.abs(waterA) < 0.25, 'Water wave displacement must remain bounded');
assert.notEqual(waterA, waterLater, 'Water surface must animate over time');
assert.deepEqual(GRAPHICS_TEXTURE_TARGETS, { low: 1024, balanced: 2048, high: 4096 });
assert.equal(waterTextureResolution('low'), 1024);
assert.equal(waterTextureResolution('balanced'), 2048);
assert.equal(waterTextureResolution('high'), 4096);
const lowTextureProfile = resolveGraphicsTextureProfile('low', 8192, 8);
assert.equal(lowTextureProfile.primaryTextureSize, 1024, 'Low preset must render main textures above 512px');
assert.equal(lowTextureProfile.waterTextureSize, 1024, 'Low preset water texture must be above 512px');
assert.equal(lowTextureProfile.effectivePreset, 'low');
const mediumTextureProfile = resolveGraphicsTextureProfile('balanced', 8192, 8);
assert.equal(mediumTextureProfile.primaryTextureSize, 2048, 'Medium preset must render main textures above 1024px');
assert.equal(mediumTextureProfile.waterTextureSize, 2048, 'Medium preset water texture must be above 1024px');
assert.equal(mediumTextureProfile.effectivePreset, 'balanced');
const highTextureProfile = resolveGraphicsTextureProfile('high', 8192, 8);
assert.equal(highTextureProfile.primaryTextureSize, 4096, 'High preset must activate 4K main textures on capable devices');
assert.equal(highTextureProfile.waterTextureSize, 4096, 'High preset must activate 4K water textures on capable devices');
assert.equal(highTextureProfile.supportingTextureSize, 2048, 'High preset keeps secondary maps at a memory-safe 2K tier');
assert.equal(highTextureProfile.effectivePreset, 'high');
const midMemoryHighProfile = resolveGraphicsTextureProfile('high', 8192, 6);
assert.equal(midMemoryHighProfile.primaryTextureSize, 2048, 'High preset must avoid 4K allocations on 6GB-class mobile devices');
assert.ok(midMemoryHighProfile.fallbackReason.includes('Memori'));
assert.equal(midMemoryHighProfile.effectivePreset, 'balanced');
const unknownMemoryHighProfile = resolveGraphicsTextureProfile('high', 8192, 0);
assert.equal(unknownMemoryHighProfile.waterTextureSize, 2048, 'Unknown device memory must use a safe 2K fallback');
assert.equal(resolveGraphicsTextureProfile('low', 8192, 4).primaryTextureSize, 1024);
assert.equal(resolveGraphicsTextureProfile('balanced', 8192, 4).waterTextureSize, 2048);
assert.equal(resolveGraphicsTextureProfile('low', 512, 4).waterTextureSize, 512, 'A GPU below the requested tier must report its hardware-limited texture size');
assert.equal(resolveGraphicsTextureProfile('balanced', Number.POSITIVE_INFINITY, 4).waterTextureSize, 2048, 'Non-finite GPU reports must not produce infinite texture dimensions');
const gpuFallbackProfile = resolveGraphicsTextureProfile('high', 2048, 8);
assert.equal(gpuFallbackProfile.primaryTextureSize, 2048, 'High preset must fall back to GPU maximum when 4K is unsupported');
assert.ok(gpuFallbackProfile.fallbackReason.includes('GPU'));
assert.equal(gpuFallbackProfile.effectivePreset, 'balanced');
const memoryFallbackProfile = resolveGraphicsTextureProfile('high', 8192, 4);
assert.equal(memoryFallbackProfile.waterTextureSize, 2048, 'High preset must avoid 4K allocations on low-memory devices');
assert.ok(memoryFallbackProfile.fallbackReason.includes('Memori'));
assert.match(game, /function makeGraphicsTextureSet\(profile\)/);
assert.match(game, /function makeGraphicsTextureSetWithFallback\(requestedProfile\)/);
assert.match(game, /Semua tingkat tekstur gagal dibuat/);
assert.match(game, /activeGraphicsTextureSetKey|activeGraphicsProfileKey/);
assert.match(game, /texture\.anisotropy = anisotropy/);
assert.match(game, /function applyGraphicsTextureSet\(set, disposePrevious = true\)/);
assert.match(game, /applyGraphicsTextureSet\(built\.textureSet\)/);
assert.match(game, /updateGraphicsResolutionLabel\(profile\)/);
assert.match(game, /applyWaterQualitySettings\(profile, visualQuality\)/);
assert.match(game, /renderer\.shadowMap\.enabled = visualQuality !== 'low'/);
assert.match(game, /sunLight\.castShadow = visualQuality === 'high'/);
assert.match(game, /faunaDirector\?\.setQuality\(visualQuality, profile\.faunaTextureSize\)/);
assert.doesNotMatch(game, /const speed=\(settings\.graphics/, 'Graphics presets must not change swimming gameplay speed');
assert.match(environmentSimulation, /memory >= 8/);
assert.match(fauna, /createTurtleShellTexture\(bump = false, size = 512\)/);
assert.match(fauna, /setQuality\(value, textureSize = null\)/);
for (const [x,z,t] of [[0,0,0],[100,-80,42],[-250,310,120]]) {
  const h=waterSurfaceHeightAt(x,z,t);
  assert.ok(Number.isFinite(h) && Math.abs(h) < 0.25, 'Water wave height must stay bounded and finite');
  const sway=computeSeagrassSway(x,z,t,0.9);
  assert.ok(Number.isFinite(sway.x) && Number.isFinite(sway.z) && Math.abs(sway.x)<0.3 && Math.abs(sway.z)<0.2);
}
const stillPose=computeSwimPose(0.7,0,false,false);
const swimPose=computeSwimPose(0.7,0.8,false,false);
const glidePose=computeSwimPose(0.7,0.8,true,true);
assert.equal(stillPose.blend,0);
assert.ok(Math.abs(swimPose.leftArmX)>Math.abs(stillPose.leftArmX));
assert.ok(Math.abs(glidePose.rightArmX-0.08)<Math.abs(swimPose.rightArmX-0.08), 'Seaglide pose should damp free-swim strokes');
assert.equal(canBreatheAtSurface(0.2, 0, 0.045), true, 'Breathing requires the diver eye to be clearly above the surface');
assert.equal(canBreatheAtSurface(-0.2, 0, 0.045), false, 'A diver below the waterline cannot breathe');
assert.ok(computeSurfaceBlend(0.2, 0) > computeSurfaceBlend(-0.2, 0), 'Waterline transition must blend continuously across the surface');
assert.ok(Math.abs(computeDaylight(35, 900).daylight - computeDaylight(935, 900).daylight) < 1e-12, 'Day/night cycle must repeat for the same world-clock phase');
assert.ok(Number.isFinite(computeDaylight(Number.NaN).daylight), 'Invalid world time must not poison daylight math');

// World-to-local and collision must remain correct after uniform Lifepod scaling and yaw.
const podPosition = { x: 44, y: -8, z: -31 };
const podYaw = 0.73;
const podScale = 1.24;
const localPoint = { x: 0.22, y: 0.15, z: -0.31 };
const cosYaw = Math.cos(podYaw), sinYaw = Math.sin(podYaw);
const worldPoint = {
  x: podPosition.x + podScale * (localPoint.x * cosYaw + localPoint.z * sinYaw),
  y: podPosition.y + podScale * localPoint.y,
  z: podPosition.z + podScale * (-localPoint.x * sinYaw + localPoint.z * cosYaw)
};
const recoveredLocal = worldToLifepodLocal(worldPoint.x, worldPoint.y, worldPoint.z, podPosition, podYaw, podScale);
assert.ok(Math.abs(recoveredLocal.x - localPoint.x) < 1e-9);
assert.ok(Math.abs(recoveredLocal.y - localPoint.y) < 1e-9);
assert.ok(Math.abs(recoveredLocal.z - localPoint.z) < 1e-9);
const wallLocal = { x: 1.55, y: 0, z: 0 };
const wallWorld = {
  x: podPosition.x + podScale * (wallLocal.x * cosYaw + wallLocal.z * sinYaw),
  y: podPosition.y,
  z: podPosition.z + podScale * (-wallLocal.x * sinYaw + wallLocal.z * cosYaw)
};
assert.equal(lifepodHullBlocksWorld(wallWorld.x, wallWorld.y, wallWorld.z, podPosition, podYaw, 0.38, podScale), true, 'Scaled Lifepod side shell must remain solid');
const hatchOriginLocal = { x: 0, y: 3, z: 0.15 };
const scaledHatchOrigin = { x: podPosition.x + podScale * hatchOriginLocal.z * sinYaw, y: podPosition.y + podScale * hatchOriginLocal.y, z: podPosition.z + podScale * hatchOriginLocal.z * cosYaw };
const hatchAim = getLifepodHatchAim(scaledHatchOrigin, { x: 0, y: -1, z: 0 }, podPosition, podYaw, 7, podScale);
assert.ok(hatchAim, 'Scaled Lifepod roof hatch must remain aimable');
assert.ok(Math.abs(hatchAim.localZ - 0.15) < 1e-6);
const moveFrom = { x: podPosition.x, y: podPosition.y, z: podPosition.z };
const moveTo = { x: podPosition.x, y: podPosition.y + 2.6 * podScale, z: podPosition.z };
const resolvedRoof = resolveLifepodMovement(moveFrom, moveTo, podPosition, podYaw, 0.38, podScale);
const resolvedRoofLocal = worldToLifepodLocal(resolvedRoof.position.x, resolvedRoof.position.y, resolvedRoof.position.z, podPosition, podYaw, podScale);
assert.equal(resolvedRoof.blocked.y, true, 'Vertical swept collision must stop movement through the scaled roof');
assert.ok(resolvedRoofLocal.y < 1.2, 'Player must remain inside the collision boundary when moving into the roof');
const moveToFloor = { x: podPosition.x, y: podPosition.y - 2.6 * podScale, z: podPosition.z };
const resolvedFloor = resolveLifepodMovement(moveFrom, moveToFloor, podPosition, podYaw, 0.38, podScale);
const resolvedFloorLocal = worldToLifepodLocal(resolvedFloor.position.x, resolvedFloor.position.y, resolvedFloor.position.z, podPosition, podYaw, podScale);
assert.equal(resolvedFloor.blocked.y, true, 'Vertical swept collision must stop movement through the scaled floor/bottom hull');
assert.ok(resolvedFloorLocal.y > -1.2, 'Player must remain inside the collision boundary when moving into the floor');

assert.match(setupGuide, /202611060002_room_recovery\.sql/);
assert.match(setupGuide, /202611070001_shared_world_events\.sql/);
assert.match(deepWorldSql, /abyssal_push_world_event/);
assert.match(deepWorldSql, /numeric < -320 or \(v_payload->>'y'\)::numeric > 100/);
assert.match(deepWorldSql, /grant execute on function public\.abyssal_push_world_event/);
assert.match(setupGuide, /202611070002_deep_world_coordinates\.sql/);
assert.match(workflow, /the-abyssal-android-apk-2\.0\.5/);
assert.match(serviceWorker, /the-abyssal-2-0-5-depth-lifepod-cinematic-overhaul/);
assert.match(readme, /event dunia bersama/i);
assert.match(readme, /bukan simulasi shared-world penuh/i);
assert.match(readme, /The Abyssal 2\.0\.5/i);
console.log(`The Abyssal 2.0.5 verification passed: ${ids.length} unique DOM IDs, ${staticRefs.length} valid DOM references, local asset paths, deterministic terrain, v11 save migration, waterline/daylight helpers, scaled Lifepod transforms/collision/hatch regression, turtle shell texture source checks, survival/inventory/camera/tool checks, Supabase/Auth and SQL/RLS source checks, Android lifecycle/icon/signing/workflow checks.`);
