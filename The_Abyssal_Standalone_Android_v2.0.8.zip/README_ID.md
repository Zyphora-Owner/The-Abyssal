# The Abyssal 2.0.8

## Rilis 2.0.8 — Underwater Vehicle Fleet & Vehicle Bay

- Menambahkan tiga kendaraan original: Pelagic Skimmer (sub eksplorasi), Pelagic Carrier (kapal selam ekspedisi/basis bergerak), dan Nautilus Exosuit (rangka mekanis laut dalam).
- Vehicle Fabrication Bay, crafting kendaraan, peluncuran, pilot, exit aman, repair, recharge, cargo, sonar, drill/grapple, dan upgrade terintegrasi dengan material serta save lokal.
- Upgrade depth bertingkat, hull/chassis, storage, sonar, efisiensi, thermal reactor, Mining Drill Arm, dan Grappling Arm memiliki efek gameplay.
- Kendaraan memakai swept collision per-sumbu, footprint terrain sampling, collision struktur/Lifepod/wreck/kendaraan, HUD hull/power, dan validasi area launch.
- Carrier Command Deck menyediakan transfer cargo saat Carrier dikemudikan jika Cargo Compartment terpasang; bengkel dan upgrade tetap memerlukan Vehicle Bay.
- Memperbaiki interaction prompt saat pilot, hatch Lifepod untuk hull kendaraan, posisi exit, validasi active vehicle pada save, dan batas recharge Carrier.
- Save schema v11, Application ID `com.abyssal.game`, inventory, lima Quick Slots, PDA, Fabricator, tools, dunia, fauna, misi, backend, dan fitur lama dipertahankan. Autentikasi, room, presence, chat, dan co-op sebelumnya tetap memakai Supabase.

**Batas:** armada, upgrade, posisi, dan cargo kendaraan tersimpan lokal. Data kendaraan belum menjadi shared-world multiplayer. Akun, room, dan co-op sebelumnya tetap dipertahankan.

## Rilis 2.0.7 — Full 3D First-Person Equipment & Hand Grip

- Tool dan item Quick Slot menggunakan viewmodel 3D lokal; tangan penyelam memiliki jari bersegmen dan grip mengikuti alat terpilih; Seaglide memakai pose dua tangan.
- Layer render first-person dipisahkan agar alat dan tangan tidak tertutup geometri dunia.

Kendaraan memakai desain original The Abyssal. Tidak ada model, tekstur, musik, suara, atau kode proprietary Subnautica yang disalin. Riwayat rilis sebelumnya tersedia pada changelog tiap versi.

Fitur **event dunia bersama** yang sudah ada tetap dipertahankan melalui Supabase. Kendaraan versi 2.0.8 belum ikut tersinkron, jadi ini **bukan simulasi shared-world penuh** untuk seluruh armada dan state kendaraan.
