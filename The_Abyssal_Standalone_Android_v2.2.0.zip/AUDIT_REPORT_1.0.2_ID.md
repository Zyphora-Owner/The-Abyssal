# Laporan Audit THE ABYSSAL 1.0.2

Audit ini memperbaiki masalah yang dapat dibuktikan dari source paket 1.0.0 dan menandai batas yang tidak dapat diselesaikan hanya dari sisi klien.

## Defect yang ditemukan dan diperbaiki

1. **Import runtime terputus:** `game.js` mengimpor `./save-schema.mjs`, tetapi file itu tidak ada di paket audit awal. Ini dapat menggagalkan pemuatan modul game sebelum renderer dibuat. File sekarang ada dan memiliki uji unit.
2. **PDA tidak ditampilkan:** `openPda()` meminta layar `pda`, tetapi UI map tidak mendaftarkan elemen PDA. UI map sekarang mencatat `pda-screen`.
3. **Avatar remote tersembunyi:** clone model pemain mewarisi `visible=false` dari model first-person lokal. Clone sekarang ditampilkan.
4. **Penyelam dapat naik di atas laut:** batas posisi Y terlalu longgar. Batas laut sekarang sekitar `-0.45` pada area air terbuka; daratan memakai clearance terrain.
5. **Back Android tidak menutup panel:** callback sebelumnya hanya memanggil Pause. Handler baru menutup Inventory/Building/PDA/Settings terlebih dahulu, lalu Resume/Pause/menu.
6. **Cutscene tetap berjalan saat Pause:** update timeline kini dihentikan selama state pause.
7. **Room multiplayer gagal meninggalkan state macet:** koneksi gagal sekarang membersihkan subscription, room, dan role; pembersihan row room/membership dilakukan oleh pembuat/joiner.
8. **Save/backup tidak divalidasi:** data lokal/cloud/backup sekarang dinormalisasi, angka dibatasi, tipe data disaring, dan backup harus memiliki lima slot.
9. **Backup bisa menimpa permainan aktif:** restore sekarang ditolak selama sesi game/room aktif; ekspor menyimpan snapshot aktif setelah local storage write berhasil.
10. **Storage Locker dapat melebihi batas normal:** konten locker dibatasi ke 99 unit per item.
11. **Memory leak dari objek runtime:** item drop yang diambil/dihapus, node resource yang dipanen, dan lifepod yang diregenerasi sekarang membuang geometri/material tidak bersama.
12. **Paket uji mengandung pemeriksaan versi lama:** verifikasi ditulis ulang agar menguji versi, backup, UI, konfigurasi Android, dan perilaku normalisasi.

## Defect/feature gap yang belum dapat diklaim selesai

- **APK/native build:** tidak dikompilasi di lingkungan audit ini. Jalankan workflow GitHub Actions. `npm test` bukan bukti APK berhasil.
- **Rendering/performa Android:** harus diuji pada perangkat nyata; tidak ada pengujian GPU/thermal/FPS di sini.
- **Supabase:** konfigurasi OAuth, database policy, Cloud Save lintas perangkat, dan callback Android belum dapat diuji tanpa project pengguna.
- **Multiplayer:** sistem saat ini menyinkronkan room/presence/transform pemain; fauna, drop item, AI, collision dan survival tidak tersinkron sebagai authoritative world. Jangan menganggap multiplayer survival penuh telah selesai.
- **Auto update:** URL manifest masih kosong. Tidak ada OTA live update aktif. Android tetap membutuhkan persetujuan pengguna untuk memasang APK baru; perubahan native memerlukan rebuild.
- **Voice acting:** saat ini TTS device dengan subtitle, bukan rekaman aktor.
- **Konten 3D:** tekstur dan mesh procedural/low-poly, bukan hasil produksi AAA atau aset Subnautica; kendaraan, habitat modular berinterior, serta ekologi persisten belum lengkap.

## Prosedur uji minimum di ponsel

1. Backup JSON dari game lama.
2. Upload ZIP v1.0.2 ke root repo (hapus ZIP proyek lama saja), jalankan workflow yang sudah ada.
3. Pastikan GitHub Actions hijau dan APK artifact berhasil diunduh.
4. Pasang update tanpa uninstall. Jika signature mismatch, hentikan; jangan hapus aplikasi sebelum backup diuji.
5. Uji PDA, Back Android, pause cutscene, batas permukaan, pickup/drop, restart aplikasi, dan lima slot.
6. Setelah Supabase siap, uji login dan save pada dua perangkat; guest tidak boleh menulis shared save.

Audit ini tidak menyatakan seluruh game sudah bebas bug. Temuan baru dari log atau pengujian perangkat harus ditangani sebagai laporan terpisah dengan bukti reproduksi.
