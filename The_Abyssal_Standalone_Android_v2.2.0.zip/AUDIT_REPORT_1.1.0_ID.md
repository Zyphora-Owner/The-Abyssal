# THE ABYSSAL 1.1.0 — laporan audit source

Tanggal pengerjaan: 6 November 2026

## Perubahan yang masuk ke paket

- Save schema v8, migrasi data lama, kapasitas oksigen dasar 45, dan penyimpanan state equipment/hotbar/checkpoint.
- Inventory 27 slot (9 × 3) dengan footprint item 1, 2, 4, 6, dan 8 slot; stack dan daftar overflow.
- Lima hotbar; equipment tank/chestplate/helmet disimpan di state equipment.
- Explorer PDA sebagai item inventaris; Habitat Builder wajib dimiliki dan dipilih sebelum build.
- Kapsul darurat dan Ocean Habitat Capsule dengan ruang interior, bed checkpoint, Fabricator empat kategori, dan pengisian O₂ dari dalam.
- Reticle target untuk item drop, cache, dan resource; Survival Knife dibutuhkan untuk node resource/fauna kecil.
- Konsumsi O₂ acak 2–4 normal dan 4–8 pada inventory overflow atau kondisi tekanan di luar rating gear, per interval lima detik.
- Auto Save lima menit dengan toggle Settings.
- Perapian smoothing kamera, animasi tangan/renang, caption cutscene, dan PNG icons.

## Hasil pemeriksaan yang benar-benar dijalankan

- `node --check` untuk modul utama dan skrip build/verifikasi: lulus.
- `npm test`: lulus.
- Audit terakhir: 149 ID HTML unik, 231 referensi DOM statis, migration/save schema v8, dan cek alur gameplay yang disebut di atas.

## Batas verifikasi

Pemasangan dependensi `npm install` tidak selesai pada lingkungan pengerjaan ini. Karena itu bundling Vite, sinkronisasi Capacitor, kompilasi APK, dan pengujian rendering/performa pada Android **belum diverifikasi di sini**. Paket menyertakan workflow GitHub Actions yang sudah ada untuk membangun APK. Verifikasi akhir tetap memerlukan workflow sukses dan uji perangkat fisik.

## Batas ruang lingkup gameplay

Ini adalah pengembangan The Abyssal dengan sistem survival dan habitat orisinal yang terinspirasi genre eksplorasi bawah laut, bukan salinan penuh Subnautica. Sistem kendaraan, world simulation server-authoritative, dan banyak sistem lanjutan masih berada di luar perubahan ini.
