# Audit The Abyssal 1.2.0

Tanggal audit: 6 November 2026

## Ringkasan
Rilis 1.2.0 berfokus pada HUD Android landscape. Tampilan lama yang berupa panel status horizontal diganti menjadi susunan mobile: gauge O₂ bundar, ring mini HP/Food/Water, kedalaman di tengah, klaster menu/PDA/Inventory di kanan atas, joystick kiri, tombol vertikal, kontrol aksi bundar, reticle, dan hotbar.

## Validasi source
- `node --check game.js`: lulus.
- `npm test`: lulus setelah memperbarui assertion untuk versi, gauge, kelompok tombol UI, tool card, dan ikon HUD.
- HTML: 157 ID unik dan 234 referensi DOM statis; tidak ditemukan ID duplikat.
- Referensi aset HTML/CSS lokal: 39; seluruh file ditemukan.
- Aset HUD PNG lokal baru: 17 ikon.
- Data save tidak berubah: tetap menggunakan schema v8. Inventory 27 slot, hotbar lima slot, equipment, habitat, fabricator, checkpoint, oksigen dan Auto Save tetap menggunakan alur gameplay existing.

## Batas verifikasi
Build Vite/APK **belum terverifikasi**. Paket `vite` tidak tersedia di lingkungan pengerjaan; `npm install --ignore-scripts --no-audit --no-fund` tidak selesai dalam batas waktu lingkungan. Karena itu rilis ini tidak diklaim telah berhasil dikompilasi sebagai APK. Pengujian visual WebGL, kontrol sentuh, dan performa wajib dilakukan di perangkat Android setelah GitHub Actions berhasil.

## Catatan implementasi
- Ikon dibuat khusus untuk The Abyssal sebagai PNG lokal; tidak mengambil logo atau aset UI Subnautica.
- Tombol aksi tetap memakai event handler lama untuk scan, interaksi, pakai item, menghancurkan node, harvest, checkpoint, dan keluar habitat.
- HUD mempertahankan landscape-only orientation yang sudah digunakan game.
