# Audit The Abyssal 1.3.0

Tanggal: 6 November 2026

## Ringkasan
Rilis 1.3.0 memoles presentasi penyelam first-person dan HUD mobile agar lebih dekat dengan gaya survival bawah laut: visor vignette dinamis, depth progress, gauge oksigen responsif, reticle dengan status target, Scanner yang terkunci pada bidikan tengah, animasi peralatan, serta sorot Flashlight. Tombol Save manual di HUD ditampilkan kembali.

## Validasi source
- `node --check game.js`: lulus.
- `node --check fauna.js`: lulus.
- `node --check scripts/verify.mjs`: lulus.
- `npm test`: lulus.
- HTML: 158 ID unik dan 239 referensi DOM statis; tidak ada ID duplikat atau referensi DOM hilang.
- CSS: 14 referensi `url()` lokal diperiksa; tidak ada aset yang hilang. Pasangan kurung CSS seimbang.
- Ikon HUD dan item tetap berupa aset PNG lokal.
- Versi package, updater, dan service worker: 1.3.0.
- Save schema tetap v8; migrasi lama, lima slot save, 27-slot inventory, lima-slot hotbar, equipment, habitat, Fabricator, checkpoint, oxygen, dan Auto Save tetap terverifikasi oleh test.

## Pelestarian fitur
Tidak ada fitur sebelumnya yang sengaja dihapus. Perubahan gameplay yang tampak adalah validasi Scanner yang kini mengharuskan fauna berada di garis bidik tengah, dan tindakan scan diblokir bila ada objek interaktif lebih dekat pada garis pandang. Semua sistem survival, crafting, building, habitat, misi, cutscene, fauna, storage, backup/restore, dan integrasi online opsional tetap ada.

## Batas verifikasi
Build Vite/APK belum dijalankan karena `node_modules`/dependensi build tidak tersedia di lingkungan ini. Karena itu APK final tidak diklaim telah terkompilasi atau diuji. Rendering WebGL, sorot Flashlight, kontrol sentuh, frame rate, dan update APK di atas instalasi lama perlu diverifikasi melalui GitHub Actions dan perangkat Android.
