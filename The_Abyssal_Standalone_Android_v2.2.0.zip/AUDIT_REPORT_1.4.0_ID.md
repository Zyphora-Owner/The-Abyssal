# Laporan Audit The Abyssal 1.4.0

## Ruang lingkup

Pemeriksaan source untuk perubahan single-player survival bawah laut: backpack 48 sel, lima Quick Slots, PDA, O₂ kontinu, equipment O₂/fins/rebreather, Fabricator empat kategori, Habitat Builder, interaksi reticle, migrasi save v10, serta penghapusan fitur autosave/kasur/armor/online.

## Pengujian otomatis

Dijalankan melalui `npm test`:

- keunikan ID HTML dan kecocokan semua referensi DOM statis;
- keberadaan file PNG dan modul lokal;
- normalisasi pengaturan, lima slot, backup JSON, dan migrasi save schema v10;
- migrasi posisi respawn lama kembali ke Lifepod dan penolakan PDA di Quick Slots;
- ukuran backpack 6×8, item footprint, dan lima Quick Slots;
- konsumsi oksigen kontinu, refill permukaan/interior habitat, serta empat kategori Fabricator;
- interaksi terpusat, gating Habitat Builder, dan alat Seaglide;
- workflow Android tanpa langkah backend atau auth online.

Pemeriksaan sintaks modul dijalankan terpisah dengan `node --check --input-type=module` untuk `game.js`, `fauna.js`, `save-schema.mjs`, `scripts/verify.mjs`, dan skrip build.

## Batasan verifikasi

Audit source bukan bukti bahwa build APK berhasil. APK perlu dibangun oleh GitHub Actions lalu diuji pada perangkat Android untuk validasi WebGL, kontrol sentuh, performa, audio, navigasi, dan save/load. Kendaraan Seamoth/Cyclops/Prawn, fragment-blueprint progression, dan simulasi hull-integrity habitat masih belum diimplementasikan.
