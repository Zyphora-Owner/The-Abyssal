# Laporan Audit The Abyssal 1.5.0

## Cakupan

Source audit untuk revisi single-player offline: Backpack 48 sel, Quick Slots, PDA, konsumsi O₂ kontinu, equipment, Fabricator empat kategori, Habitat Builder, Repair Tool untuk konsol awal Lifepod, Seaglide dengan daya/baterai, migrasi save v11, dan penghapusan fitur custom yang tidak sesuai arah gameplay.

## Pengujian otomatis

`npm test` lulus:
- 108 ID HTML unik dan 136 referensi DOM statis valid.
- Referensi PNG lokal dan import modul lokal ditemukan.
- Normalisasi save, 5 slot, backup JSON, dan migrasi schema v11 diuji.
- Save lama dengan Seaglide dimigrasikan dengan daya 100%; save tanpa Seaglide tetap 0%.
- Backpack 6×8, lima Quick Slots, footprint item, O₂ kontinu, refill permukaan/interior, dan empat kategori Fabricator diuji melalui static assertions.
- Gating Repair Tool untuk konsol Lifepod, drain charge Seaglide, penggantian baterai, habitat/interact loop, dan konfigurasi Android offline diperiksa.
- Tidak ada lagi fitur runtime Auto Save, checkpoint kasur, armor/helmet, oxygen station, multiplayer, atau backend online.

Pemeriksaan sintaks `node --check --input-type=module` lulus untuk `game.js`, `fauna.js`, `save-schema.mjs`, `scripts/verify.mjs`, `scripts/build-native.mjs`, `scripts/patch-android.mjs`, dan `vite.config.js`.

## Belum diverifikasi

Dependensi Vite/Capacitor belum terpasang pada lingkungan pengerjaan; percobaan instalasi sebelumnya timeout. Karena itu build APK tidak diklaim berhasil. APK harus dibangun melalui GitHub Actions dan diuji pada perangkat Android untuk kontrol sentuh, WebGL, audio, performa, navigasi, dan save/load.

Kendaraan Seamoth/Cyclops/Prawn, fragment-blueprint progression, hull integrity habitat, dan ekologi persisten belum tersedia.
