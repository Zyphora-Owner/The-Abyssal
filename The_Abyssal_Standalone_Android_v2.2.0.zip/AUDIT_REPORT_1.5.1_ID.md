# Laporan Audit The Abyssal 1.5.1

## Fokus audit

Perbaikan CI Android dari log kegagalan `MODULE_NOT_FOUND` untuk `scripts/configure-backend.mjs`, penemuan root proyek dalam ZIP, stabilitas signing debug, dan validasi artifact APK. Gameplay tidak diubah; save schema tetap v11.

## Pemeriksaan otomatis lokal

- `npm test` memvalidasi ID DOM, referensi DOM, aset lokal, migrasi save v11, sistem gameplay v1.5, serta aturan workflow build.
- `node --check` dijalankan pada semua skrip `.mjs`, `game.js`, `fauna.js`, dan `vite.config.js`.
- `keytool -list` memvalidasi keystore debug dan alias `androiddebugkey`.
- Arsip ZIP diperiksa dengan `unzip -t`.

## Perbaikan CI

- File `scripts/configure-backend.mjs` sekarang ada. Skrip adalah shim kompatibilitas tanpa akses jaringan/secret, sebab proyek ini offline dan tidak membutuhkan backend.
- Workflow baru memanggil skrip kompatibilitas pada working directory proyek yang sudah terdeteksi.
- Sumber kunci signing tidak lagi bergantung pada file `*.keystore` yang di-ignore Git; sumber tracked bernama `native/abyssal-debug-signing.bin`.
- Pengecekan sebelum build memastikan sumber key ada dan dapat dibaca.
- Setelah build, workflow memeriksa APK tidak kosong, ZIP internalnya valid, serta application ID tepat.

## Batasan

Dependensi npm tidak dapat dipasang di lingkungan pembuatan ZIP karena timeout jaringan. Karena itu, kompilasi Gradle/APK tidak diklaim berhasil di sini. Keberhasilan final hanya dapat dipastikan setelah workflow GitHub Actions dijalankan sampai artifact APK berhasil diunggah dan APK diuji pada perangkat Android.
