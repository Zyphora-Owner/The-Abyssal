# Laporan Audit The Abyssal 1.5.2

## Temuan utama dari screenshot

Pesan yang terlihat adalah:

```text
Gagal menyiapkan renderer 3D: WORLD_SEED is not defined
```

Akar masalah bukan karena file gambar, driver grafis, ataupun renderer Three.js. Fungsi `hash2(x, z)` di `game.js` menggunakan identifier `WORLD_SEED`, tetapi identifier itu tidak pernah dideklarasikan atau diimpor. Ketika `createWorld()` memanggil `updateChunks(true)`, chunk pertama menjalankan `heightAt()` → `valueNoise()` → `hash2()`. JavaScript melempar `ReferenceError` sehingga boot berhenti sebelum menu utama.

## Perubahan yang dilakukan

1. Membuat `world-generation.mjs` sebagai sumber tunggal generator procedural.
2. Mengekspor seed tetap `WORLD_SEED`, `hash2()` dan `valueNoise()` dari modul tersebut.
3. Mengimpor `hash2` dan `valueNoise` secara eksplisit di `game.js`; tidak ada lagi ketergantungan pada global seed yang hilang.
4. Menguji bahwa hash selalu berada pada `[0, 1)`, noise terbatas pada `[-1, 1]`, dan nilai untuk koordinat yang sama selalu identik.
5. Menambah pesan boot yang informatif dan tombol retry jika inisialisasi masih gagal.
6. Memperjelas pesan saat browser/WebView tidak mendukung WebGL.
7. Memperbaiki workflow supaya proyek Android existing di-sync, bukan mencoba dibuat ulang.
8. Memperbarui aksi upload artifact ke v7 dan semua label versi aktif ke 1.5.2.

## Pemeriksaan lokal yang berhasil

- `npm test` — lulus.
- 111 ID HTML unik; 142 referensi DOM statis valid.
- Aset ikon PNG lokal dan import modul lokal terverifikasi.
- Regression test seed/hash/noise — lulus.
- Migrasi dan normalisasi save schema v11 — lulus.
- Pemeriksaan sintaks `node --check` untuk skrip runtime, service worker, konfigurasi Vite, serta seluruh skrip `.mjs` — lulus.
- TypeScript checker tidak menemukan diagnostic `TS2304` (identifier tidak dikenal) pada source. Pengecekan tipe tidak penuh karena dependency `three` dan `@capacitor/browser` tidak tersedia secara lokal.
- `keytool -list` memvalidasi debug signing key `androiddebugkey`.
- Workflow memeriksa APK, ZIP integrity, dan application ID `com.abyssal.game` sebelum artifact diunggah.

## Yang belum dapat diverifikasi

- `npm install` tidak selesai karena DNS ke `registry.npmjs.org` tidak dapat di-resolve di lingkungan pengerjaan.
- `vite build`, `npx cap add/sync`, Gradle `assembleDebug`, dan instalasi pada ponsel Android tidak dijalankan di lingkungan ini.
- Karena itu keberhasilan rendering runtime setelah perbaikan seed sangat mungkin menghapus crash yang ditunjukkan screenshot, tetapi belum dikonfirmasi lewat sesi browser/WebGL atau perangkat sungguhan.

## Risiko dan kompatibilitas

- Save schema tetap v11 dan Application ID tetap `com.abyssal.game`.
- Seed dunia dibuat tetap agar koordinat save lama tidak berpindah akibat perubahan seed antar versi.
- Aset dan identitas The Abyssal tetap orisinal. Game mempertahankan arah survival bawah laut yang terinspirasi genre Subnautica; ini bukan salinan kode maupun aset asli Subnautica.
