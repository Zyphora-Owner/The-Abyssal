# Laporan Audit — The Abyssal 1.6.0

## Pemeriksaan source yang dijalankan

- Pemeriksaan sintaks Node untuk `game.js`, `multiplayer.js`, `multiplayer-core.mjs`, serta skrip build/verify.
- Validasi ID HTML dan lookup DOM statis.
- Validasi referensi aset lokal dan modul lokal.
- Pengujian sanitizer kode ruang, chat, nama tampilan, koordinat pemain, dan Presence.
- Pemeriksaan source wiring Supabase Auth, RPC room lifecycle, private channels, Presence, Broadcast, dan RLS migration.
- Uji konfigurasi backend tanpa credential, konfigurasi URL+publishable key, konfigurasi parsial, serta penolakan key secret/service_role.
- Pemeriksaan workflow untuk memetakan GitHub Actions Secrets ke environment Vite.
- Pemeriksaan kompatibilitas Application ID serta save schema v11.

## Perbaikan penting yang dilakukan pada multiplayer

1. Hasil `RealtimeChannel.send()` dan `track()` berupa status string, bukan objek `{ error }`. Penanganan diubah agar kegagalan kirim atau tracking Presence tidak dianggap sukses.
2. Status channel yang berulang setelah reconnect sekarang ditangani. Presence ditrack kembali setiap kali channel berhasil subscribe ulang.
3. Kode ruang yang dikirim dengan huruf kecil sekarang dinormalisasi di SQL dengan urutan uppercase sebelum filter alfanumerik.
4. Kebijakan private channel menggunakan `realtime.topic()` dan helper membership fail-closed, membatasi akses bagi anggota ruang terdaftar.
5. Avatar remote diposisikan langsung ke paket posisi pertama sebelum interpolasi untuk menghindari perpindahan visual dari titik awal dunia.
6. Konfigurasi build menolak URL non-HTTPS/path yang tidak didukung serta kunci Supabase secret/service_role.

## Batasan pengujian

- Tidak ada URL/key Supabase milik pengguna di lingkungan ini, jadi migrasi belum dieksekusi pada database nyata dan Auth/Realtime belum dites end-to-end.
- `npm install` mengalami timeout koneksi registry. Karena itu Vite bundling, Gradle APK compile, dan pengujian GPU/dua perangkat belum terverifikasi.
- `npm test` adalah pengujian source/regresi lokal; hasilnya tidak membuktikan layanan cloud milik pengguna sudah dikonfigurasi.
- Mode online baru benar-benar aktif setelah pengguna menjalankan SQL migration, menambahkan Actions Secrets, membangun APK baru, dan menguji dua akun pada dua perangkat.

## Ruang lingkup co-op saat ini

Penyinkronan: Presence, posisi/arah/avatar penyelam, dan radio chat teks dalam ruang privat maksimal empat anggota.

Belum tersinkron: inventory, resource nodes, fauna, misi, health/oxygen, bangunan, kendaraan, atau save. Belum ada validasi gerakan server-authoritative.
