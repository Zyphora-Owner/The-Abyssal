# Laporan Audit The Abyssal 1.6.1

## Pengujian yang berhasil dijalankan

Perintah:

```sh
node --check game.js
node --check multiplayer.js
node --check multiplayer-core.mjs
node --check scripts/configure-backend.mjs
node --check scripts/build-native.mjs
node --check scripts/verify.mjs
npm test
```

Hasil akhir:

```text
The Abyssal 1.6.1 verification passed: 152 unique DOM IDs, 203 valid DOM references, local assets, deterministic world generation, v11 save migration, survival/inventory/habitat regression checks, Supabase Auth + private co-op room wiring, room-code/chat/player-state sanitizers, RLS SQL migration, safe public-key configuration, and Android packaging checks.
```

YAML workflow diperiksa menggunakan parser YAML. Arsip ZIP diuji setelah dibuat.

## Batas audit

- Tidak ada URL/key Supabase milik pengguna, sehingga migrasi SQL tidak dijalankan pada database sungguhan.
- Tidak ada dua akun/perangkat Android yang tersedia untuk menguji register, verifikasi email, login, room, Broadcast, Presence, chat, dan reconnect end-to-end.
- Instalasi dependency npm pada lingkungan pengerjaan sebelumnya mengalami timeout. Vite production build dan Gradle APK build belum dapat dinyatakan lulus.
- `npm test` adalah pemeriksaan source/regresi statis, bukan bukti bahwa backend atau APK sudah berjalan.

## Cakupan multiplayer 1.6.1

Fitur online yang diimplementasikan: Supabase Auth email/password, konfigurasi backend dari dalam aplikasi, room privat berkode, Presence anggota, transformasi avatar melalui Broadcast, dan chat. Inventory, resource, fauna, HP/O₂, misi, struktur, kendaraan, serta save belum menjadi state bersama/server-authoritative. Ini belum merupakan shared-world multiplayer penuh.

## Keamanan konfigurasi

Aplikasi hanya menerima HTTPS URL dan key publishable/legacy anon. `sb_secret_...` dan `service_role` ditolak. Publishable key tetap merupakan konfigurasi publik dan tidak boleh disamakan dengan password atau secret server. Database harus menjalankan migration dan tetap memakai RLS serta private-channel authorization.
