# Laporan Audit — The Abyssal 1.6.2

Tanggal pekerjaan: 6 November 2026.

## Temuan yang diperbaiki

1. **Tombol Login/room dapat ditekan ketika inisialisasi Auth masih berjalan.** Status tombol sekarang menunggu klien auth selesai dibuat.
2. **Tombol Back Android belum ditangani oleh aplikasi.** Menambahkan listener Capacitor App yang menutup panel, melakukan pause, dan meminta konfirmasi keluar di menu utama.
3. **Sesi dapat terus menerima input ketika aplikasi masuk background.** Menambahkan listener appStateChange untuk mereset input dan menjeda sesi; timestamp frame disegarkan saat aplikasi aktif kembali.
4. **Status konfigurasi backend terlalu mudah disalahartikan sebagai server benar-benar tersambung.** Aplikasi sekarang meminta Auth public settings endpoint setelah konfigurasi disimpan. Status yang ditampilkan membedakan konfigurasi tersimpan dari koneksi yang berhasil.
5. **Register bisa tetap terlihat aktif saat sign-up dinonaktifkan di Supabase.** Tombol Register kini mengikuti nilai `disable_signup` dari Auth settings.
6. **Room dapat kehilangan owner aktif setelah pembersihan anggota yang stale.** Migrasi 0002 mempromosikan anggota aktif tertua setelah pembersihan.
7. **Room dapat kehilangan keanggotaan server setelah perangkat tidur/offline terlalu lama.** Heartbeat sekarang mencoba bergabung kembali menggunakan kode undangan yang tersimpan bila server menyatakan keanggotaan sudah hilang.
8. **Ikon PWA dan ikon launcher Android tidak dijamin sama.** Patcher kini menyalin aset density, adaptive icon XML, warna latar, dan atribut `icon`/`roundIcon` ke proyek Android.

## Hasil verifikasi yang dijalankan

| Pemeriksaan | Hasil |
|---|---|
| `node scripts/verify.mjs` | LULUS |
| `node --check game.js` | LULUS |
| `node --check multiplayer.js` | LULUS |
| `node --check scripts/patch-android.mjs` | LULUS |
| 152 DOM ID unik | LULUS |
| 207 referensi DOM statis | LULUS |
| Save migration schema v11 | Dipertahankan |
| Supabase public-key validator | LULUS |
| SQL migration 0001 + 0002 static checks | LULUS |
| PNG signatures and dimensions | LULUS |
| Android manifest icon patch smoke test | LULUS |
| Android patcher idempotency test | LULUS |

## Batas verifikasi

- `npm install --no-audit --no-fund` mengalami timeout dalam lingkungan pengerjaan. Karena dependency tidak terpasang, build Vite dan Gradle tidak dapat dijalankan di sini.
- APK belum dikompilasi dan belum diuji pada Android nyata.
- Koneksi ke proyek Supabase milik pengguna, verifikasi email sungguhan, dua akun aktif, dan reconnect dua perangkat belum dapat diuji tanpa URL/key dan perangkat pengguna.
- Multiplayer masih co-op dasar: akun, room privat, presence, transformasi pemain, chat, dan pemulihan keanggotaan. Inventory, fauna/AI, health/oxygen, resource, habitat, kendaraan, misi, serta save belum menjadi shared-world authoritative.

## Integritas data

- Application ID tetap `com.abyssal.game`.
- Signing key debug tetap memakai `native/abyssal-debug-signing.bin` dari proyek.
- Save schema tetap v11.
- Tidak ada penghapusan fitur game atau reset progres yang disengaja.
- Perbarui APK dengan memasangnya di atas versi lama menggunakan signing key yang sama. Jangan uninstall atau menghapus data aplikasi sebelum membuat backup.
