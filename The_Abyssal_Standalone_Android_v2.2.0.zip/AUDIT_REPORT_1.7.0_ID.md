# Laporan Audit The Abyssal 1.7.0

## Sumber audit
Proyek sumber 1.6.2 yang tersedia pada percakapan, diperbarui secara non-destructive. Fitur yang telah ada dipertahankan; save schema v11 dan Application ID `com.abyssal.game` tidak diubah.

## Bug yang dikoreksi
1. **Arah kamera terbalik** — tanda delta-X pada yaw dikoreksi dan dipisahkan sebagai fungsi `applyTouchLook`; pengujian memeriksa swipe kanan dan kiri.
2. **Tabrakan Lifepod tidak konsisten saat pod diputar** — rumus world-to-local sebelumnya memakai arah rotasi yang sama dengan local-to-world, bukan inversnya. Kini transformasi posisi dan arah ray memakai invers rotasi Y Three.js.
3. **Pemain bisa menembus bagian shell** — ditambahkan bentuk capsule hull, radius diver, swept segment checks, dan pengujian sisi/atap/bawah.
4. **Akses Lifepod dari sembarang sisi** — target masuk Lifepod hanya dihasilkan bila ray dari atas mengenai hatch; tombol Interact memvalidasi ulang target sebelum memindahkan pemain.
5. **Bagian luar terlihat transparan** — shell luar menggunakan material opaque, opacity 1, depth write, dan sisi depan; liner interior ditampilkan hanya saat berada di dalam.
6. **Item first-person hilang/tertutup** — mesh tangan dan alat memakai render order terpisah, frustum culling dimatikan dan depth test dikontrol untuk viewmodel.
7. **Senter dan pisau belum punya aksi langsung di HUD** — tombol serang pisau ditautkan ke damage fauna/animasi; tombol Use menyalakan/mematikan lampu sorot.
8. **Oksigen memakai pengurangan kontinu** — diganti tick tunggal dua detik dengan random 2–4 normal dan 4+ pada kedalaman 20m+, naik seiring kedalaman; rebreather memberi mitigasi.
9. **Kontrol sulit disesuaikan** — ditambahkan slider sensitivitas kamera dan ukuran HUD. Setting lama tetap dinormalisasi dengan default aman.
10. **Split Touch kadang kehilangan pointer** — joystick dan lookpad sekarang mengunci satu pointer masing-masing, tetap dapat digunakan bersamaan dengan jari berbeda, dan seluruh input dilepas saat pointer cancel/lost capture atau aplikasi masuk background.

## Pengujian otomatis
Perintah yang dijalankan: `npm test` (mencakup pemeriksaan sintaks dan pengujian regresi modul) serta `node --check game.js`.

Hasil `npm test` terakhir:
- 158 ID HTML unik.
- 220 referensi DOM statis valid.
- Path aset lokal yang direferensikan ditemukan.
- Pemeriksaan syntax modul dan skrip.
- Determinisme generator dunia.
- Migrasi save v11.
- Pengujian pure function kamera, transformasi koordinat Lifepod berotasi, hatch, hull collision, swept collision, batas oksigen, sensitivitas kamera, dan ukuran HUD.
- Pemeriksaan tracking pointer joystick/lookpad, Split Touch dua zona, serta reset input saat background.
- Pemeriksaan keberadaan tombol serang, fungsi fauna attack, Spotlight senter, dan viewmodel.
- Pemeriksaan SQL RLS, auth configuration, workflow, native icon resources, dan integritas struktur proyek.

**Hasil: LULUS.** `npm test` lulus pada 6 November 2026. `npm run build` dicoba tetapi gagal karena paket `vite` tidak tersedia (`ERR_MODULE_NOT_FOUND`); instalasi dependensi sebelumnya tidak berhasil diselesaikan. Pengujian ini adalah pemeriksaan source dan fungsi murni, bukan simulasi browser/GPU penuh.

## Belum dapat diverifikasi di lingkungan ini
- `npm run build` tidak berhasil karena `vite` belum terpasang. `npm install` tidak selesai di lingkungan ini, sehingga Vite production bundle tidak dibuat.
- APK Gradle belum dikompilasi; `ANDROID_HOME` tidak tersedia dan perintah `gradle` tidak ditemukan pada runtime ini.
- Rendering GPU, collision di WebView, sentuhan dua jari pada perangkat fisik, dan kualitas audio belum diuji langsung di Android.
- Repository saat ini berisi 54 ikon PNG dan material/geometry prosedural; tidak ada paket audio `.mp3/.wav/.ogg` atau model `.glb/.gltf` eksternal. Efek audio yang dipakai adalah Web Audio sintetis dan sebagian besar dunia dirakit secara prosedural. Paket model/audio produksi yang belum ada tidak diklaim sudah ditambahkan.
- Login/Register belum dapat diuji ke Supabase nyata karena Project URL belum tersedia.
- Multiplayer dua perangkat dan sinkronisasi shared-world belum diuji. Versi ini mempertahankan co-op akun/room/presence/posisi/chat; inventory, fauna, habitat, dan progres dunia belum server-authoritative/shared.

Tidak ada status build atau perangkat yang diklaim lulus tanpa menjalankan pengujian tersebut.
