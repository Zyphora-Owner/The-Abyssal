# Laporan Audit — The Abyssal 1.8.0

## Ringkasan

Source diturunkan dari The Abyssal 1.7.0. Audit menemukan satu bug nyata yang tidak tertangkap oleh klaim pengujian sebelumnya pada alur collision vertikal Lifepod, serta dua risiko pada antrean event co-op. Perbaikan dimasukkan tanpa mengganti proyek dari nol dan tanpa menaikkan save schema.

## Temuan dan perbaikan

### 1. Collision vertikal Lifepod

**Akar masalah:** runtime menghentikan koordinat gerak horizontal saat terjadi collision, tetapi langkah floor clamp berikutnya menggunakan `nextY` lama. Nilai vertikal yang sudah diblokir dapat diterapkan kembali sehingga pemain berpotensi menembus atap/bawah.

**Perbaikan:** movement sekarang menggunakan `resolveLifepodMovement()` yang melakukan swept test pada sumbu X, Z, dan Y. Kecepatan sumbu yang tertahan dihentikan; floor clamp menggunakan nilai Y hasil resolusi collision.

### 2. Sinkronisasi dunia co-op hanya sebatas presence/posisi/chat pada versi sebelumnya

**Perbaikan:** ditambahkan migrasi SQL 0003 dan RPC untuk event dunia persisten. Event yang diselaraskan meliputi pengambilan node resource (penghapusan node pada klien lain), cache yang dibuka, struktur yang ditempatkan, fauna yang dipindai, biome yang ditemukan, dan misi yang diselesaikan.

**Keamanan:** tabel mengaktifkan RLS, anggota room dapat membaca event, penulisan hanya melalui RPC authenticated dengan validasi tipe/payload, batas laju, dan idempotency key.

### 3. Race condition antrean offline

**Akar masalah:** saat RPC sedang berlangsung, event baru dapat ditambahkan ke localStorage. Menulis array `remaining` dari snapshot lama dapat menghapus event baru tersebut.

**Perbaikan:** setelah RPC, klien membaca ulang antrean terbaru dan hanya menghapus event yang sudah diakui server. Lock request tidak dilepas secara prematur ketika room berganti.

### 4. Validasi data event

String kosong sekarang tidak lagi dikonversi menjadi angka nol pada payload struktur. Sanitizer klien dan validasi SQL sama-sama membatasi event serta koordinat.

## Pemeriksaan yang benar-benar dijalankan

- `node scripts/verify.mjs` / `npm test`: **LULUS**, termasuk satu kali lagi setelah ZIP diekstrak ke direktori bersih.
- `keytool -list` pada `native/abyssal-debug-signing.bin` dengan alias debug proyek: **LULUS**.
- Pemeriksaan `node --check` untuk seluruh JavaScript/MJS yang tercantum di suite: **LULUS**.
- Unit checks fungsi murni kamera, koordinat Lifepod, collision sumbu vertikal/samping, hatch aim, oksigen, save migration v11, dan sanitasi event: **LULUS**.
- Pemeriksaan statis 158 ID HTML unik, 220 referensi DOM, referensi aset HTML/CSS/ikon, import relatif lokal, versioning, konfigurasi Capacitor, workflow, SQL/RLS/RPC source: **LULUS**.
- `unzip -t` pada arsip final dan uji ekstraksi: **LULUS**, tidak ada kerusakan arsip.

## Kondisi aset visual dan audio

- ZIP memuat ikon UI/launcher PNG yang dapat diverifikasi sebagai file lokal.
- Geometri dunia, fauna, alat, dan beberapa objek dibentuk melalui kode Three.js/prosedural; proyek ini tidak memuat paket model eksternal `.glb`, `.gltf`, atau `.obj`.
- Tidak ditemukan berkas audio `.mp3`, `.wav`, atau `.ogg` dalam repository. Suara runtime saat ini dihasilkan melalui Web Audio API dan sebagian narasi memakai Speech Synthesis browser.
- Karena itu, release ini **tidak** mengklaim sudah memiliki model 3D high-detail dan sound bank rekaman khusus untuk setiap objek. Peningkatan aset 3D/audio khusus tetap menjadi pekerjaan terpisah dan harus diuji pada perangkat.
- UI/HUD dan ikon sebelumnya dipertahankan; perubahan visual besar tidak menjadi fokus patch 1.8.0.

## Belum terverifikasi — jangan dianggap lulus

- **Vite production build:** dicoba dengan `npm run build`, tetapi gagal pada `ERR_MODULE_NOT_FOUND: Cannot find package 'vite'`. `node_modules` tidak tersedia karena upaya instalasi dependency sebelumnya timeout; ini berarti build belum berhasil diverifikasi, bukan berarti build dinyatakan lulus.
- **Gradle / APK:** belum dibangun dan belum ada artifact APK yang dapat diperiksa.
- **Android nyata / WebView / GPU:** belum diuji pada perangkat fisik, jadi stabilitas rendering, sentuhan, suara, dan performa FPS belum dapat disertifikasi.
- **Supabase:** Project URL pemilik belum tersedia. SQL 0003 belum dijalankan di database sungguhan; Auth/room/event RPC belum diuji terhadap server hidup.
- **Multiplayer dua perangkat:** belum diverifikasi. Event-world plumbing ada di source, tetapi deployment SQL dan tes dua akun/perangkat masih wajib.
- **Shared-world penuh:** belum ada sinkronisasi server-authoritative untuk reward inventory, fauna AI/health/posisi, status survival pemain, kendaraan, daya/kerusakan habitat, atau save. Fitur-fitur itu tidak dinyatakan selesai.

## Kompatibilitas dan mitigasi

- Android Application ID `com.abyssal.game` tidak berubah.
- Save schema tetap v11. Tidak ada migrasi atau reset save pemain.
- Backup JSON sebelum instalasi tetap disarankan.
- Signing key sumber proyek harus dipertahankan agar debug APK hasil build dapat memperbarui pemasangan yang memakai key sama.

## Kesimpulan

Source release lolos pengujian otomatis yang tersedia, termasuk regresi collision dan sanitasi event. Release belum layak disebut APK teruji atau multiplayer produksi sampai Vite/Gradle build, migrasi Supabase, dan pengujian perangkat nyata lulus.
