# Laporan Audit — The Abyssal 1.9.0

## Temuan akar masalah
1. Dunia sebelumnya memiliki dasar laut sekitar 43 m dan gerak vertikal dibatasi ke -42 m. Akibatnya, label biome abyss tidak mewakili eksplorasi laut dalam yang sesungguhnya.
2. Pemilihan biome chunk memakai koordinat tetap -20 m, sehingga biome/material chunk tidak konsisten dengan kedalaman terrain.
3. Fauna spawn dibatasi pada kedalaman -41 m dan tidak memiliki rentang habitat untuk palung dalam.
4. Save dan sanitizer multiplayer membatasi Y hingga -42/-100 m, sehingga basis atau avatar di lokasi sangat dalam tidak dapat dipulihkan/dikirim dengan benar.
5. Hasil target panen fauna menggunakan ID spesies; jika beberapa individu dari spesies yang sama berada di sekitar pemain, target yang dihapus dapat berbeda dari individu yang dibidik.
6. RPC Supabase sebelumnya menolak koordinat bangunan di luar ±100 m.

## Perbaikan
- Menambahkan generator dasar laut dalam deterministik khusus area palung jauh; area lama tetap pada bentuk yang sama di luar area authored trench.
- Menyetel ulang batas selam, normalisasi save, multiplayer state, event sanitizer, serta SQL RPC incremental untuk mendukung palung hingga 300 m.
- Menambahkan biome deep dan spesies laut dalam; menautkan biome chunk ke elevasi dasar laut lokal.
- Membatasi kedalaman lantai trench hingga -296 m supaya penyelam dapat berhenti di atas terrain sebelum hard limit -300 m.
- Membatasi kelp/coral pada biome yang sesuai agar flora dangkal tidak muncul di dasar palung.
- Mengatur ulang fog, lampu lingkungan, dan god-rays berdasarkan kedalaman.
- Menurunkan kurva konsumsi oksigen dalam menjadi pertumbuhan akar-kuadrat yang tetap 4+ per tick di zona dalam.
- Menggunakan instance ID unik untuk target panen sehingga individu yang dibidik adalah individu yang dipanen.

## Pemeriksaan otomatis yang dijalankan
- `npm test` / `node scripts/verify.mjs` dijalankan setelah patch dan memeriksa syntax, ID DOM, referensi aset, fungsi save, koordinat, biome palung, fauna, kontrol, HUD, RPC, dan workflow.
- `node --check` untuk modul runtime dan skrip.
- `unzip -t` untuk integritas ZIP rilis.

## Belum terverifikasi (tidak diklaim lulus)
- Vite production build dan Gradle APK: dependency install tidak berhasil selesai di lingkungan lokal, sehingga APK tidak dibuat di sini.
- Renderer WebGL, tekstur, collision, dan kontrol sentuh pada Android fisik: belum ada perangkat uji tersambung.
- Login/Register, RLS, SQL migration, dan shared-world dua akun: perlu Project URL Supabase valid serta server hidup; pengujian live belum dijalankan.
- Multiplayer event durability dan konflik resource lintas-perangkat perlu uji dua klien; saat ini migration menyiapkan validasi koordinat deep, bukan klaim bahwa seluruh simulasi fauna/inventory sudah authoritative.

## Kompatibilitas
- Android Application ID: `com.abyssal.game` (tetap).
- Save schema: v11 (tetap; posisi lama sah, limit baru lebih longgar).
- Signing asset dan ikon launcher lama dipertahankan.
