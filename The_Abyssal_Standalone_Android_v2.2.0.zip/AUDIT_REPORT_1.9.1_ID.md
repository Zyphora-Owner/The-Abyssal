# Laporan Audit — The Abyssal 1.9.1

## Temuan yang ditangani
1. Batas tangki lama hanya tiga upgrade dan kapasitas 135 O₂ tidak konsisten dengan palung yang bisa dicapai hingga 296 m. Progres kini menyediakan empat upgrade (maksimum 345 O₂) dan Rebreather mengurangi konsumsi dalam. Kapasitas starter tetap 45.
2. Rumus kapasitas sebelumnya terduplikasi antara gameplay dan normalisasi save, berisiko membuat HUD, crafting, dan load save tidak selaras. Rumus kini dipusatkan pada `oxygenTankCapacity()`.
3. Fauna sebelumnya hanya dibatasi dasar laut dan permukaan, bukan rentang kedalaman spesies. Update sekarang menghormati kedalaman spesies dan menangani kondisi terrain yang tidak memiliki overlap.

## Pengujian otomatis
- `npm test` menjalankan pemeriksaan syntax JavaScript untuk file runtime/script, validitas DOM, path aset lokal, save v11, validasi input, kamera, hatch, collision, oksigen, world generation, fauna, Supabase source wiring, migration checks, dan Android workflow.
- Simulasi konservatif untuk perjalanan turun-naik menuju 296 m menggunakan tick oksigen terburuk dan Rebreather harus berada di bawah kapasitas tangki Mk V.
- Tes save memeriksa `tankLevel=4`, oxygen 345, serta mempertahankan level dan data save lama.

## Belum terverifikasi
- Build produksi Vite/Gradle dan pembuatan APK, sampai dependency install/build berhasil pada runner.
- Rendering WebGL, kontrol dua jari, collision fisik, audio, animasi, dan layout pada perangkat Android nyata.
- Register/Login Supabase live serta room multiplayer dua akun/perangkat.
- Sinkronisasi penuh seluruh simulasi dunia; event resource/cache/struktur tertentu sudah didukung, tetapi inventory, AI fauna, health/oxygen, kendaraan, dan progression belum sepenuhnya authoritative server.

## Kompatibilitas
- Android Application ID: `com.abyssal.game` (tetap).
- Save schema: v11 (tetap). Save tidak direset; tier tank tambahan diterima oleh normalizer.
- Proyek tidak menambahkan Secret Key/service_role Supabase.

## Status build saat pengerjaan
- `npm install --no-audit --no-fund --fetch-retries=1 --fetch-timeout=30000` tidak selesai dalam batas waktu lingkungan, sehingga `vite` tidak terpasang.
- `npm run build` kemudian gagal dengan `ERR_MODULE_NOT_FOUND: Cannot find package 'vite'`. Ini dicatat sebagai gagal/belum dibangun, bukan lulus.
- Workflow GitHub tetap menggunakan `npm install` (bukan `npm ci`, karena repository sumber tidak menyediakan `package-lock.json`). Build harus dikonfirmasi melalui GitHub Actions setelah dependency berhasil diunduh.
