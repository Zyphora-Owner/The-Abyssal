# Laporan Audit — The Abyssal 2.0.0

## Basis dan pelestarian fitur
- Basis source: The Abyssal 1.9.1 yang tersedia di arsip proyek.
- Application ID: `com.abyssal.game` (dipertahankan).
- Save schema: v11 (dipertahankan; tidak ada perubahan format atau reset).
- Lima Quick Slots, inventory, PDA, tools, survival, crafting, Fabricator, Lifepod/habitat, fauna, biome, misi, save/load, Supabase auth, co-op room, dan event dunia yang telah ada tetap disertakan.

## Perbaikan yang diaudit
1. Skala Lifepod 1,24× dipakai konsisten pada objek 3D, world-to-local, hatch aim, interior point, dan collision.
2. Collider Lifepod diuji pada skala dan yaw non-nol, termasuk sweep gerakan vertikal menuju atap.
3. Waterline helpers diuji untuk gelombang deterministik, amplitudo terbatas, transisi surface blend, syarat bernapas di atas air, dan daylight cycle yang berulang.
4. Runtime menyambungkan water mesh, sky dome, daylight, fog/lights blend, transisi audio, dan pemulihan O₂ di permukaan.
5. Turtle shell texture dan bump texture beserta detail model diperiksa keberadaannya di source.
6. Terrain memakai segment count sesuai preset grafis dan geometri batu memiliki deformasi deterministik.
7. Cutscene capsule mendapat detail mekanis tambahan.
8. Quick Slots tetap lima; label terlihat/aksesibilitas diseragamkan.
9. Warna transisi air menggunakan objek warna bersama untuk menghindari alokasi per frame yang tidak perlu.

## Pengujian otomatis yang dijalankan
Perintah: `npm test` (menjalankan `scripts/verify.mjs`).

Hasil: **LULUS** pada pemeriksaan source dan helper otomatis. Pemeriksaan meliputi:
- 158 ID HTML unik.
- 223 referensi DOM statis valid.
- Referensi aset lokal HTML/CSS dan ikon item yang diperiksa.
- Sintaks runtime JavaScript serta seluruh skrip `.mjs` yang didaftarkan oleh verifikasi.
- Determinisme world generation dan batas kedalaman.
- Save/load normalizer dan migrasi schema v11.
- Kamera, survival, inventory, tools, hatch, dan collision.
- Koordinat Lifepod skala 1,24× pada yaw non-nol; hull samping tetap solid; hatch atas tetap dapat dibidik; gerak vertikal ke atap terblokir.
- Gelombang permukaan air deterministik dan berubah berdasarkan waktu; breathing check dan daylight cycle.
- Source checks untuk turtle scute texture/bump map, mesh permukaan, dan transisi waterline.
- Validasi source Supabase, migrasi SQL/RLS, konfigurasi public key, native lifecycle, ikon launcher, signing resource, dan workflow.
- Pemeriksaan integritas arsip ZIP dilakukan setelah paket dibuat.

## Belum terverifikasi
- Rendering WebGL sesungguhnya pada browser/WebView dan perangkat Android.
- Visual final dari terrain, water shader, sky dome, model Lifepod, viewmodel, fauna, dan cutscene pada GPU perangkat.
- Audio timing/volume di perangkat.
- Build Vite/produksi, sinkronisasi Capacitor, kompilasi Gradle, dan APK.
- Login/Register dengan proyek Supabase live.
- Multiplayer dua akun/dua perangkat dan sinkronisasi shared-world penuh.
- Performa FPS, pemakaian RAM, suhu perangkat, dan kestabilan sesi panjang.

Pengujian otomatis tidak membuktikan renderer atau APK berjalan di perangkat.

## Build yang dicoba pada sesi ini
- `npm install --no-audit --no-fund --fetch-retries=1 --fetch-timeout=30000`: **GAGAL/TIMEOUT** setelah batas waktu tool 90 detik. `node_modules/.bin/vite` tidak tersedia.
- `npm run build`: **GAGAL** dengan `ERR_MODULE_NOT_FOUND: Cannot find package 'vite'` dari `scripts/build-native.mjs`.
- Gradle/APK build: **TIDAK DIJALANKAN**, karena bundle web belum dapat dibangun tanpa dependency Vite.
- Instalasi dan rendering perangkat Android: **BELUM DIVERIFIKASI**.

Kesimpulan: pemeriksaan source otomatis lulus, tetapi build produksi dan APK belum berhasil. Jangan menggunakan APK versi lama sebagai artifact 2.0.0.
