# Laporan Audit — The Abyssal 2.0.1

## Basis dan ruang lingkup
- Basis source: The Abyssal 2.0.0 yang tersedia di Library dan berhasil diekstrak ke workspace.
- Fokus rilis: stabilitas kamera, Split Touch, first-person item, tombol serang kontekstual, lifecycle fauna per-slot, serta validasi collision setelah dorongan fauna.
- Tidak mengubah save schema v11, Application ID `com.abyssal.game`, Supabase SQL, maupun file signing debug.

## Bug yang ditemukan dan diperbaiki
1. **Roll kamera terakumulasi:** `camera.rotateZ()` diterapkan ke quaternion yang sudah diubah pada frame sebelumnya. Orientasi kini disimpan sebagai quaternion dasar yang dihaluskan; efek roll kecil dikomposisikan dari quaternion dasar tiap frame sehingga tidak bertambah tanpa batas.
2. **Pointer naik/turun saling membatalkan:** kedua tombol sebelumnya menulis satu nilai `input.vertical`. Kini setiap arah melacak pointer ID secara terpisah melalui `Set`; arah efektif dihitung dari status kedua set. Blur/background membersihkan semua pointer.
3. **Item non-tool tidak terlihat di first-person:** Quick Slot dapat berisi resource dan supply, tetapi sebelumnya viewmodel hanya dibuat untuk alat. Kini resource/supply yang terdaftar di `ITEM_DEFS` memperoleh model prosedural Three.js lokal dan hanya terlihat saat item benar-benar dimiliki.
4. **Attack selalu terlihat saat pisau dimiliki:** kini tombol Attack hanya muncul jika pisau dipilih dan query target fauna non-mutating menemukan fauna di arah bidikan serta jarak yang sama dengan aturan serangan.
5. **Fauna lintas-slot tertinggal:** `FaunaDirector` digunakan lintas sesi; populasi kini dibersihkan dan dibuat ulang di sekitar pemain setelah New Game/Load Slot. Daftar discovery fauna tidak dihapus saat memuat save.
6. **Dorongan fauna dapat memasukkan pemain ke struktur:** posisi pemain kini diperiksa ulang terhadap struktur dan terrain setelah soft collision; posisi aman sebelumnya dipulihkan jika dorongan menghasilkan posisi tertutup.
7. **Umpan balik Quick Slot:** teks pemain diganti dari label “Hotbar” menjadi “Slot Cepat”; lima slot dan format save tidak diubah.
8. **Konsumsi supply:** Quick Slot dirender ulang setelah medkit, ransum, air, atau ikan digunakan agar tampilan slot tidak tertinggal dari jumlah item.

## Pengujian yang benar-benar dijalankan
- `npm test` — **LULUS** dari source hasil ekstraksi.
- Suite menjalankan `node --check` pada game, fauna, modul, konfigurasi, service worker, dan seluruh skrip `.mjs`.
- Suite memeriksa 158 ID HTML unik dan 223 referensi DOM statis valid.
- Pemeriksaan path aset HTML/CSS dan import modul lokal.
- Unit test helper `resolveVerticalInput`: ascend, descend, dua arah aktif, pointer lebih dari satu, dan netral.
- Pemeriksaan regresi source untuk quaternion kamera tanpa rotasi akumulatif, pointer sets, item viewmodel, validasi kepemilikan item, target serangan kontekstual, reset fauna, dan label Quick Slot.
- Uji save schema v11, migrasi legacy, world generation deterministik, waterline helpers, Lifepod transform/collision/hatch, texture kura-kura, Supabase/SQL source, ikon Android, signing resource, dan workflow tetap dijalankan.

## Build dan pengujian yang belum berhasil/terverifikasi
- `npm install` **GAGAL** karena DNS registry npm tidak tersedia pada sesi ini (`EAI_AGAIN registry.npmjs.org`).
- `npm run build` **GAGAL** karena dependency `vite` tidak tersedia (`ERR_MODULE_NOT_FOUND`). Ini bukan kegagalan sintaks source; dependency tidak berhasil diunduh.
- Gradle/APK **BELUM DIJALANKAN**.
- Rendering WebGL, kualitas viewmodel, Split Touch, collision, dan performa **BELUM DIUJI PADA ANDROID FISIK**.
- Login/Register dan multiplayer **BELUM DIUJI TERHADAP SUPABASE LIVE** karena Project URL belum tersedia.
- FPS, penggunaan RAM, dan sesi bermain panjang **BELUM DIUKUR**.

## Status kesimpulan
Rilis ini lulus pengujian source otomatis yang tersedia. Hasil tersebut tidak membuktikan build Vite/APK, rendering GPU, integrasi Supabase, atau multiplayer dua perangkat telah berhasil. Pengujian tersebut tetap harus diselesaikan melalui GitHub Actions dan perangkat Android.
