# Laporan Audit — The Abyssal 2.0.2

## Ruang lingkup
Rilis pemeliharaan visual dengan fokus pada permukaan air HD, caustics bergerak, rumput laut bergoyang, animasi berenang first-person, dan gelembung penyelam. Source 2.0.1 dipertahankan sebagai fondasi.

## Perbaikan yang diterapkan
- Tekstur warna air seamless dan normal map tangent-space dibuat lokal secara prosedural, power-of-two, repeat-wrapped, mipmapped, dan anisotropic.
- Resolusi tekstur permukaan air mengikuti preset: Low 512 px, Balanced 1024 px, High 2048 px.
- Water plane memakai `MeshPhysicalMaterial`, clearcoat, normal map, subdivisi geometri 72/112/160, serta pembaruan gelombang sesuai preset.
- Caustics transparan yang dapat diulang bergerak pada terrain dangkal, reef, dan kelp.
- Rumput laut berupa tuft 11 helai pita bertaper dengan gradasi warna dan vertex sway di GPU; fase berbeda per-instance.
- Audit lanjutan menemukan bug pengulangan indeks ketika jumlah tuft >20. Sampel deterministik kini disediakan sebanyak `kelpAttempts + 12`, sementara pola sampling batu lama tetap memakai 20 sampel.
- Normal vertex rumput laut dikoreksi secara pendekatan mengikuti perubahan arah helai saat ditekuk.
- Animasi berenang first-person memiliki kayuhan lengan bergantian, gerak pergelangan, bob tubuh, serta peredaman saat memegang alat atau memakai Seaglide.
- Gelembung memakai pool tetap 22 sprite yang digunakan ulang.

## Pengujian otomatis yang benar-benar dijalankan
- `npm test`: LULUS pada source yang telah diekstrak.
- Verifikasi mencakup pemeriksaan sintaks Node, 158 ID HTML unik, 223 referensi DOM valid, path aset lokal dan import statis, helper gelombang, resolusi tekstur, sway rumput, pose berenang, migrasi save v11, serta regression check agar loop kelp tidak membungkus sampling pada indeks 20.
- Integritas ZIP final dan `npm test` dari hasil ekstraksi ZIP akan diperiksa setelah packaging.

## Belum terverifikasi
- `npm run build` belum berhasil di lingkungan ini karena paket `vite` tidak tersedia (`ERR_MODULE_NOT_FOUND`). Instalasi dependency sebelumnya terhenti karena timeout jaringan.
- APK Gradle belum dikompilasi.
- Shader, kualitas air, goyangan rumput, caustics, dan bubble belum diuji pada GPU Android fisik.
- FPS, RAM, thermal throttling, dan stabilitas sesi panjang belum diukur pada perangkat.
- Supabase live, Login/Register, dan multiplayer dua perangkat tidak diubah atau diuji dalam rilis visual ini.

## Kompatibilitas
- Android Application ID: `com.abyssal.game` (tetap).
- Save schema: v11 (tetap; tidak ada migrasi/reset).
- Inventory, lima Quick Slots, PDA, Fabricator, Lifepod, habitat, fauna, biome, misi, Seaglide, akun, Supabase, dan multiplayer dipertahankan.
