# Laporan Audit — The Abyssal 2.0.4

## Ruang lingkup

Audit difokuskan pada implementasi preset grafis Low/Medium/High, perubahan tekstur saat runtime, fallback kemampuan perangkat, dan kompatibilitas dengan sistem proyek yang sudah ada.

## Bug/risiko yang ditangani

1. Sebelumnya ukuran target tekstur masih 256/512/1024 pada material lingkungan dan pemilihan preset tidak membangun ulang seluruh tekstur world. Sekarang target utama Low/Medium/High adalah 1024/2048/4096 pada perangkat yang mendukung.
2. `applySettings()` sebelumnya hanya memperbarui sebagian kualitas air. Sekarang perubahan preset membuat texture set baru dan memindahkan referensi material scene ke tekstur baru.
3. Alokasi tekstur besar berpotensi gagal pada Android/WebView. Sekarang ada fallback bertingkat dan pembersihan tekstur parsial; kegagalan total mempertahankan profil aktif sebelumnya.
4. High 4K dapat terlalu berat jika hanya mengandalkan batas ukuran GPU. Sekarang 4K mensyaratkan GPU minimal 4096 dan kelas memori browser terlapor minimal 8 GB; jika tidak, resolusi aktual diturunkan dan dijelaskan kepada pemain.
5. Saat fallback grafis terjadi, tingkat performa efektif ikut disesuaikan untuk bayangan, tessellation, chunk, fauna, pixel ratio, dan fog.
6. Detail mikro fauna dan tempurung kura-kura ditambahkan pada resolusi output agar tekstur fauna tidak hanya berupa pola kecil yang diperbesar.

## Pengujian yang benar-benar dijalankan

- `node --check game.js` — lulus.
- `node --check fauna.js` — lulus.
- `node --check environment-simulation.mjs` — lulus.
- `npm test` — lulus.
- `scripts/verify.mjs` — 159 ID HTML unik dan 224 referensi DOM valid; pemeriksaan aset lokal, modul, save schema v11, collision Lifepod, waterline, Supabase/SQL, ikon, signing, dan workflow tetap lulus.
- Pengujian helper profil Low/Medium/High — lulus untuk target 1024/2048/4096.
- Pengujian fallback GPU 2K, memori 6 GB, memori tidak diketahui, dan batas GPU 512 — lulus.
- Integritas arsip ZIP akan diverifikasi kembali setelah paket dibuat.

## Pengujian gagal / belum terverifikasi

- `npm run build` **gagal** karena paket `vite` tidak tersedia (`ERR_MODULE_NOT_FOUND`). Tidak ada `node_modules` yang disertakan dalam rilis; instalasi dependency sebelumnya mengalami timeout jaringan.
- Build Vite produksi dan kompilasi Gradle/APK belum berhasil diverifikasi.
- Alokasi tekstur dan kualitas sampling belum diuji langsung pada GPU Android fisik.
- FPS, penggunaan RAM/VRAM, thermal throttling, dan stabilitas sesi panjang belum diukur pada perangkat.
- Login/Register dan multiplayer live tidak berubah pada rilis ini dan tidak diuji terhadap Supabase sungguhan.

## Kompatibilitas

- Application ID: `com.abyssal.game`.
- Save schema: v11, tanpa migrasi baru.
- Signing source: `native/abyssal-debug-signing.bin` dipertahankan.
- Backend, SQL migration, offline play, fitur gameplay, dan alur update dipertahankan.

Status source test yang lulus tidak boleh dianggap sebagai bukti build APK atau rendering GPU Android.
