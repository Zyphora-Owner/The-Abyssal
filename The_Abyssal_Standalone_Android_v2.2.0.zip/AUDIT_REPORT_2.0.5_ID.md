# Laporan Audit — The Abyssal 2.0.5

## Basis dan kompatibilitas

- Basis source: The Abyssal 2.0.4.
- Package version: 2.0.5.
- Android Application ID: `com.abyssal.game` (tetap).
- Save schema: v11 (tetap, tidak ada reset/migrasi baru).
- Signing asset dan GitHub Actions dipertahankan; artifact workflow dinaikkan ke `the-abyssal-android-apk-2.0.5`.

## Perbaikan yang diterapkan

1. Lifepod: posisi di waterline, shell/rangka dan lampu eksternal lebih terbaca, ukuran 1.32×, collision hull disinkronkan dengan geometri, sweep memakai radius pemain, dan visibility interior/exterior diperbarui ketika masuk/keluar.
2. Depth progression: safe-depth Tank Mk I–V = 50/100/200/300/500 m. Melewati rating menampilkan peringatan dan pressure stress tick 2 detik. Kapasitas oksigen lama tidak diubah.
3. World: palung diperluas hingga kisaran 500 m; rentang fauna deep-trench ditambah.
4. Cutscene: leviathan dibuat lebih terang dan memiliki jaw/teeth/eye glow/markings/fins/tail animation; kamera mengikuti creature. Subtitle diposisikan upper-centre.
5. Builder: hologram world-space mengikuti lokasi dasar, validasi slope/overlap/material dan konfirmasi BUILD.
6. Resource: mining animasi, debris bertahap, drop setelah animasi berakhir, dan SFX hit/break.
7. Flashlight: SpotLight, near-light, visible cone dan lensa emissive diaktifkan bersama state ON/OFF.
8. Textures: detail retak, pori, grain, scratches, serta source-detail 2K pada preset 4K.
9. Main menu: video lokal loop dan poster fallback.

## Tes otomatis yang dijalankan

- `npm test` — PASS.
- 161 unique HTML IDs; 227 static DOM references valid.
- Deterministic world, save-schema v11, Lifepod transform/collision/hatch, depth ratings and pressure stress, waterline/daylight, texture profile, Supabase/RLS source checks, Android signing/workflow checks — PASS.
- `node --check` seluruh file JavaScript utama dan modul `.mjs` — PASS.
- `ffprobe`: menu video H.264, 1280×720, 24 fps, 8.0 s — PASS.
- ZIP integrity — checked at packaging step.

## Belum terverifikasi

- `npm install` tidak selesai karena timeout koneksi; paket Vite tidak tersedia.
- `npm run build` dan APK Gradle belum berhasil dibangun di lingkungan ini.
- Rendering GPU, flashlight illumination pada scene Android, shader/texture memory, collision Lifepod fisik, subtitle dan leviathan framing pada layar perangkat belum diuji secara langsung.
- Login/Register live dan multiplayer dua perangkat tidak berubah dan tidak diuji ulang pada rilis ini.

Source test pass tidak dianggap sebagai bukti APK atau GPU Android sudah berhasil.
