# Laporan Audit The Abyssal 2.0.6

## Cakupan
Basis yang diperiksa: source The Abyssal 2.0.5 yang tersedia di Library, kemudian diperbarui ke source 2.0.6. Pemeriksaan mencakup modul gameplay, mekanik Lifepod, kontrol, cutscene, world generation, fauna, save schema, Supabase source/SQL, aset, ikon, dan workflow Android.

## Masalah yang ditangani

1. **Hatch tidak mudah ditemukan/diaktifkan:** jangkauan aim/interaksi diperluas, ditambah petunjuk ketika dekat kapsul, dan aperture/shaft visual diselaraskan dengan bukaan collision.
2. **Collision hatch tidak konsisten:** koridor hatch kini bergantung pada keadaan hatch; tertutup = solid, terbuka melalui Interact = jalur vertikal diizinkan. Tes mencakup sweep X/Y/Z, sisi, bawah, atap, yaw, dan skala.
3. **Lompatan tidak memiliki state darat yang tegas:** validasi dry-ground, grounded tolerance, dan vertical velocity dipakai sebelum menerima lompatan; kontrol naik di air tetap terpisah.
4. **Kapsul cutscene berpindah mendadak:** kapsul sekarang mempertahankan offset terhadap kapal transfer sampai dilepas, lalu melanjutkan lintasan ke koordinat Lifepod gameplay. Reveal Leviathan dan splash landing diperjelas.
5. **Interaksi dunia:** verifikasi source mencakup cave entrances, thermal/lava vents, oxygen flora, dan sulfur nest fish/resource.
6. **Feedback Quick Slot:** assertion memastikan label/toast lama tidak muncul.

## Pengujian otomatis yang dijalankan

- `node --check game.js` — lulus.
- `node --check fauna.js` — lulus.
- `node --check player-mechanics.mjs` — lulus.
- `node --check scripts/verify.mjs` — lulus.
- `npm test` — lulus setelah pengujian diperbarui untuk hatch tertutup/terbuka, lintasan masuk, target hatch di waterline, lompatan, dan cutscene 8142C.
- `npm test` memverifikasi 162 ID HTML unik, 229 referensi DOM, aset lokal, determinisme world generation, migrasi save v11, transformasi/collision Lifepod, fungsi waterline/daylight, fauna dan sulfur nest, sistem oxygen plant, kontrol, tools, Supabase/RLS, signing resources, serta workflow.
- ZIP final juga diperiksa dengan `unzip -t` setelah dibuat.

## Build dan verifikasi yang belum selesai

- `npm run build` **gagal** karena dependensi Vite belum terpasang di lingkungan ini: `ERR_MODULE_NOT_FOUND: Cannot find package 'vite' imported from scripts/build-native.mjs`.
- Tidak dapat menyatakan APK berhasil dikompilasi.
- Rendering WebGL, collision fisik, visual hatch, kualitas animasi, FPS dan memori belum diuji langsung pada GPU/perangkat Android.
- Register/Login Supabase dan multiplayer belum diuji terhadap Project URL nyata atau dua perangkat.

## Batas klaim
Tes collision dan cutscene di sini adalah pengujian helper/source otomatis, bukan bukti uji fisika/rendering pada Android. Gua/lorong dan ventilasi termal adalah tambahan dunia prosedural yang tersedia; jangan menganggap setiap lorong sudah memiliki sistem cave-navmesh penuh. Ikan sarang sulfur dan tanaman oksigen tersedia dalam sistem world-generation, namun keseimbangan gameplay perlu diuji saat bermain.

## Kompatibilitas
- Application ID tetap `com.abyssal.game`.
- Save schema tetap `v11`.
- Tidak ada migrasi SQL baru.
- Signing source `native/abyssal-debug-signing.bin` dipertahankan.
