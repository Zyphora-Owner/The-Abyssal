# Laporan Audit The Abyssal 2.0.7

## Dasar perubahan
Source proyek `The_Abyssal_Standalone_Android_v2.0.6.zip` diekstrak dan digunakan sebagai fondasi. Perubahan difokuskan pada `makeFirstPersonViewModel()` dan `updateCamera()` tanpa mengubah struktur inventory maupun format save.

## Bug/kelemahan yang ditangani
1. Beberapa item masih tampak seperti primitive sederhana dan kurang menyerupai alat yang benar-benar dipegang.
2. Model alat berada terlalu jauh dari telapak tangan, sehingga dapat terlihat melayang di depan tangan.
3. Tangan kanan tidak memiliki pose genggaman yang mengikuti alat terpilih.
4. Lapisan render lengan, alat, dan grip tidak dipisahkan secara eksplisit.
5. Seaglide belum memiliki pose pegangan dua tangan yang terselaraskan.
6. Pergerakan model item generik dapat mengembalikan posisi Y ke nilai tetap saat animasi digunakan; sekarang posisi dasar tiap model disimpan dan digunakan kembali.

## Perbaikan source
- Model khusus diberi nama dan registrasi: `ScannerViewModel`, `SurvivalKnifeViewModel`, `FlashlightViewModel`, `HabitatBuilderViewModel`, `RepairToolViewModel`, dan `SeaglideViewModel`.
- Setiap alat memakai beberapa komponen geometri/material, bukan satu mesh warna dasar.
- Semua item non-tool di `ITEM_DEFS` tetap memperoleh model procedural 3D melalui factory `makeHeldItem()`.
- Overlay grip memakai TubeGeometry/CatmullRomCurve3 dan mengikuti `position`, `rotation`, `scale`, serta `gripOffset` model yang sedang dipilih.
- Model yang tidak dipilih disembunyikan; model yang dipilih harus lolos `hasQuickSlotItem()`.
- Layer rendering eksplisit: arm `1000`, item `1001`, grip `1002`.
- Seaglide dirapikan menjadi posisi di tengah dengan handle kiri/kanan dan dua grip overlay.
- Animasi ring scan, emitter builder, coil repair tool, propeller Seaglide, equip dip, dan penggunaan item tetap terhubung ke state runtime.

## Kompatibilitas
- `package.json`: 2.0.7.
- `game.js` version check: 2.0.7.
- Service Worker cache dan artifact GitHub Actions: 2.0.7.
- `Application ID`: `com.abyssal.game`.
- Save schema: `v11`; tidak ada reset/migrasi.
- Inventory dan lima Quick Slots tidak berubah.

## Pengujian yang berhasil
- `node --check game.js` — lulus.
- `node --check scripts/verify.mjs` — lulus.
- `npm test` — lulus dari source folder: 162 ID HTML unik, 229 referensi DOM statis valid, path aset lokal, syntax checks, save migration v11, Lifepod/collision, kamera/touch, survival, fauna, Supabase source/RLS, Android signing/workflow, serta assertion tambahan untuk dedicated viewmodel, grip, render layers, dan pose dua tangan Seaglide.
- Regression test dijalankan ulang setelah perubahan posisi Seaglide — lulus.
- Pemeriksaan struktur arsip ZIP dilakukan setelah packaging.

## Belum terverifikasi
- `npm run build` **gagal** karena dependency `vite` belum terpasang di lingkungan ini (`ERR_MODULE_NOT_FOUND: Cannot find package 'vite'`).
- APK Android belum dikompilasi.
- Tampilan viewmodel belum dirender dan diperiksa langsung pada GPU/WebView Android.
- Posisi genggaman, clipping, ukuran alat, dan animasi perlu diuji pada orientasi/resolusi perangkat fisik.
- Flashlight lighting, scanner effect, dan Seaglide visual belum diuji saat runtime pada GPU nyata.
- Login/Register dan multiplayer live tidak diuji ulang karena bukan fokus perubahan dan membutuhkan Project URL/backend nyata.

## Kesimpulan
Source dan pemeriksaan otomatis lulus. Build produksi, kompilasi APK, dan pengujian rendering Android belum terverifikasi. Jangan menganggap source test sebagai bukti bahwa APK sudah berhasil dibuat atau bahwa hasil visual sudah terkonfirmasi pada perangkat.
