# Laporan Audit — The Abyssal 2.0.8

## Dasar dan kompatibilitas

- Basis source: The Abyssal 2.0.7 yang tersedia di Library.
- Application ID dipertahankan: `com.abyssal.game`.
- Save schema dipertahankan: `v11`.
- Save lama dinormalisasi dengan armada kendaraan kosong; data lama yang tidak terkait kendaraan tetap dipertahankan.
- Inventory, lima Quick Slots, PDA, Fabricator, crafting, Lifepod, habitat, Seaglide, fauna, biome, misi, Auth, dan co-op sebelumnya tidak sengaja dihapus.

## Fitur kendaraan yang ditambahkan

- **Pelagic Skimmer**: sub eksplorasi satu penyelam dengan Depth Module I/II, Reinforced Hull, Expanded Storage, Active Sonar, dan Efficient Thrusters.
- **Pelagic Carrier**: kapal selam ekspedisi/basis bergerak dengan Pressure Hull I/II, Heavy Reinforcement, Cargo Compartment, Long-Range Sonar, dan Thermal Recharge Core. Saat mengemudikannya, pemain dapat membuka Carrier Command Deck untuk memindahkan kargo; fabrikasi, repair, upgrade, dan recharge tetap membutuhkan Vehicle Bay tetap.
- **Nautilus Exosuit**: rangka mekanis laut dalam dengan Depth Module I/II, Reinforced Chassis, Cargo Mount, Mining Drill Arm, dan Grappling Arm.
- Ketiganya memiliki model 3D prosedural lokal, material, lampu, propeller/thruster atau bagian mekanis, HUD hull/power, kontrol gerak, daya, kerusakan tekanan, cargo, save lokal, dan upgrade yang memengaruhi gameplay.
- Vehicle Fabrication Bay menjadi struktur yang dapat dibangun menggunakan Habitat Builder.

## Bug yang ditemukan dan ditangani

1. **Temporal-dead-zone pada prompt interaksi saat mengemudikan kendaraan** — elemen tombol Attack/Use dideklarasikan sebelum cabang kendaraan dijalankan.
2. **Kendaraan dapat menganggap hatch Lifepod terbuka sebagai jalur** — hull Lifepod tetap dianggap penghalang kendaraan meskipun hatch penyelam terbuka.
3. **Potensi tunnelling kendaraan** — gerak kendaraan kini melalui swept collision per sumbu X/Z/Y dan mempertahankan wall sliding.
4. **Terrain clearance hanya diperiksa di titik tengah** — sampling lantai menggunakan beberapa titik pada footprint kendaraan dan transformasi yaw.
5. **Launch berpotensi menempatkan kendaraan ke geometri padat/area dangkal** — validasi kedalaman air dan collision dilakukan sebelum status deployed disimpan.
6. **Exit kendaraan dapat menempatkan pemain di dalam geometri** — sistem mencoba sejumlah titik keluar aman dan menolak exit jika tidak ada ruang.
7. **Referensi active vehicle pada save dapat tidak konsisten** — active vehicle hanya dipulihkan jika kendaraan owned dan deployed setelah normalisasi.
8. **Health save dapat melebihi kapasitas hull yang dimiliki** — normalisasi membatasi health ke kapasitas aktual; data pengujian diperbaiki agar status Reinforced Hull dinyatakan eksplisit.
9. **Carrier recharge dapat berhenti di 100 meski kapasitasnya 250** — tombol dan validasi recharge memakai kapasitas kendaraan sebenarnya.
10. **Cargo UI Carrier tidak dapat diakses dari kapal** — ditambahkan Carrier Command Deck untuk transfer kargo saat Carrier dikemudikan; layanan bengkel tetap di Vehicle Bay.

## Hasil pengujian otomatis yang benar-benar dijalankan

Perintah:

- `node --check game.js`
- `node --check vehicle-systems.mjs`
- `node --check save-schema.mjs`
- `node --check scripts/verify.mjs`
- `npm test`

Hasil:

- Keempat pemeriksaan sintaks JavaScript lulus.
- `npm test` lulus: **176 ID DOM unik**, **254 referensi DOM valid**, pemeriksaan path aset lokal, world generation deterministik, migrasi save v11, definisi armada/upgrade/cargo/swept collision, waterline/daylight, Lifepod/hatch, lompatan darat, gua/tanaman oksigen/sarang sulfur, cutscene 8142C, tekstur tempurung kura-kura, survival/inventory/kamera/tools, Supabase/Auth/SQL/RLS, Android lifecycle/icon/signing/workflow.
- ZIP rilis diperiksa dengan `unzip -t` dan kemudian diekstrak ke direktori kosong; `node --check` untuk modul utama dan `npm test` dijalankan ulang dari hasil ekstraksi bersih dan lulus.

## Build produksi dan APK — status gagal/belum selesai

- `npm run build` **gagal dijalankan** karena dependency `vite` tidak tersedia (`ERR_MODULE_NOT_FOUND`).
- Upaya `npm install --no-audit --no-fund --ignore-scripts` **timeout**; environment tidak berhasil mengunduh dependency dari registry.
- Karena Vite tidak tersedia, bundle produksi tidak dihasilkan dan kompilasi Gradle/APK tidak dijalankan.
- Keberadaan skrip build, konfigurasi Capacitor, workflow, dan sumber signing key diperiksa; keberadaan file tersebut bukan bukti APK berhasil dikompilasi.

## Belum terverifikasi

- Renderer WebGL/Three.js dan geometri kendaraan pada GPU Android fisik.
- Fisika/collision kendaraan terhadap model dunia pada runtime nyata (helper sweep diuji otomatis, bukan simulasi perangkat penuh).
- Kontrol kendaraan dengan multi-touch pada berbagai layar.
- FPS, suhu perangkat, dan penggunaan RAM pada sesi panjang.
- APK berhasil dikompilasi dan dipasang.
- Login/Register Supabase live, room dua akun/perangkat, dan reconnect live.
- Sinkronisasi armada, upgrade, posisi, dan cargo kendaraan ke shared-world multiplayer.

## Batas fitur yang dinyatakan secara eksplisit

Nama dan model kendaraan adalah desain original The Abyssal yang mengambil inspirasi dari arketipe umum: sub kecil untuk pengintaian, kapal selam besar sebagai basis bergerak, dan exosuit mekanis laut dalam. Ini bukan salinan model, nama dagang, kode, tekstur, musik, suara, atau animasi proprietary Subnautica. Armada baru disimpan per-slot secara lokal dan belum menjadi entitas shared-world.
