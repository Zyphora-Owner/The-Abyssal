# Laporan Audit — The Abyssal 2.0.9

## Dasar dan kompatibilitas

- Basis source: The Abyssal 2.0.8 dari Library.
- Application ID dipertahankan: `com.abyssal.game`.
- Save schema dipertahankan: `v11`.
- Tidak ada file save yang direset atau dimigrasikan pada pembaruan ini.
- Seluruh sistem inventory, Quick Slots, PDA, Fabricator, tools, Lifepod, habitat, fauna, biome, kendaraan, akun, dan multiplayer dipertahankan.

## Akar masalah yang ditemukan

### 1. Keluar Lifepod dapat membuat pemain stuck

Posisi exit sebelumnya ditempatkan tepat di atas hatch. Swimming controller membatasi pusat tubuh pada waterline (`surfaceY - 0.42`), sehingga posisi akhir masih berada pada channel collision hatch. Ketika timer hatch berakhir, volume hull kembali solid dan pemain dapat tertahan pada collision di area atap.

**Perbaikan:** exit dihitung melalui helper koordinat lokal-ke-world yang memakai yaw dan skala Lifepod. Posisi akhir berada di sisi luar hull pada waterline, bukan tetap di channel hatch. Runtime menguji kedua sisi dan clearance tambahan, lalu memastikan calon posisi tidak berada di interior/hatch/hull, tidak menabrak struktur, dan tidak berada di bawah clearance terrain. Jika semua kandidat terhalang, pemain tidak dipindahkan dan mendapat pesan.

### 2. Validasi masuk/keluar kapsul harus atomik

Jika validasi interior setelah snap gagal, posisi pemain sebelumnya tidak dikembalikan; dan pemeriksaan egress akhir juga perlu membatalkan perpindahan apabila runtime masih menganggap pemain berada di kabin.

**Perbaikan:** posisi, velocity, yaw, pitch, dan checkpoint disimpan sebelum entry. Entry yang gagal memulihkan seluruh keadaan sebelumnya. Kandidat keluar diuji terhadap interior, hatch channel, hull tertutup, struktur lain, serta clearance terrain. Jika validasi runtime setelah perpindahan keluar masih gagal, posisi dan velocity diver dikembalikan ke pose aman di dalam kabin.

### 3. Inventory/Fabricator tidak dapat scroll dengan baik di sentuhan

Root `html, body` memakai `touch-action:none`, sementara panel memakai overflow scroll. Aturan gesture pada ancestor dapat memblokir pan vertikal pada panel Android.

**Perbaikan:** root menggunakan `touch-action:pan-y`; `world-canvas` dan control pads tetap menggunakan aturan sentuh khusus. Panel dan kartu game diberi scroll containment, safe-area, tinggi responsif, serta `-webkit-overflow-scrolling`. Grid backpack tetap 8×6.

### 4. Cutscene Leviathan kurang mudah terlihat

Approach monster baru berlangsung setelah pertengahan sequence, sementara kamera terlalu lama fokus pada kapsul.

**Perbaikan:** gerakan approach dimulai lebih awal, pencahayaan bioluminesen diperkuat, dan kamera mulai mengikuti monster lebih awal dengan framing yang lebih lebar.

## Pengujian otomatis yang dijalankan

Perintah:

- `node --check game.js`
- `node --check player-mechanics.mjs`
- `node --check scripts/verify.mjs`
- `node scripts/verify.mjs` (`npm test`)

Hasil:

- JavaScript syntax checks lulus.
- `npm test` lulus dari direktori source yang diekstrak.
- 176 ID HTML unik.
- 254 referensi DOM valid.
- Asset lokal dan module path yang direferensikan tersedia.
- Pengujian koordinat exit untuk Lifepod pada beberapa yaw/skala lulus.
- Source regression checks memastikan exit berada di luar interior dan channel hatch serta melakukan rollback bila validasi runtime akhir gagal.
- Source regression check memastikan checkpoint lama dipulihkan bila entry gagal.
- Posisi exit diuji harus berada di luar interior, hull tertutup, dan channel hatch.
- Transformasi local-to-world dan world-to-local diuji bolak-balik.
- Regression test collision hatch, dinding, atap, dan bagian bawah tetap lulus.
- Regression test 8×6 Backpack dan touch scrolling panel lulus.
- Pemeriksaan source audio panel dan framing monster lulus.
- Save schema v11 dan pemeriksaan lama tetap lulus.

## Build produksi dan APK

Belum diklaim berhasil. Instalasi dependency sebelumnya mengalami kendala jaringan dan paket Vite tidak tersedia pada lingkungan pemeriksaan. Percobaan `npm run build` pada lingkungan pemeriksaan ini gagal karena `vite` belum terpasang (`ERR_MODULE_NOT_FOUND: Cannot find package 'vite'`). Build produksi dan APK harus dibuktikan lewat GitHub Actions atau build lokal setelah dependency terpasang.

## Belum terverifikasi

- Keluar/masuk Lifepod pada perangkat Android fisik dan seluruh sudut kamera.
- Scroll Inventory/Fabricator pada berbagai resolusi, rasio layar, notch, dan WebView.
- Kualitas framing cutscene/Leviathan pada GPU Android.
- APK berhasil dikompilasi dan dipasang.
- Login/Register Supabase live dan multiplayer dua perangkat.
- FPS, RAM, panas perangkat, dan stabilitas sesi panjang.

Pengujian helper/source bukan pengganti uji perangkat fisik. Fitur yang belum diuji langsung tetap berstatus belum terverifikasi.
