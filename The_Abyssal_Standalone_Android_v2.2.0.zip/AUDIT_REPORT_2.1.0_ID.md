# Laporan Audit — The Abyssal 2.1.0

## Dasar dan ruang lingkup

- Source dasar: `The_Abyssal_Standalone_Android_v2.0.9.zip` yang tersedia di Library.
- Perubahan bersifat inkremental; proyek tidak dibangun ulang dari nol.
- Application ID dipertahankan: `com.abyssal.game`.
- Save schema dipertahankan: `v11`; tidak ada reset atau migrasi save.
- Fitur lama dan file sumber dipertahankan. Tidak ada migrasi SQL baru.
- Fokus perubahan aktual: suspend/resume aplikasi, pemulihan konteks WebGL, pengamanan error pada animation frame, audio resume, preset Ultra adaptif, dan metadata/cache rilis 2.1.0.

## Perubahan teknis yang diperiksa

### Lifecycle dan kontrol input

- Saat background/blur/pagehide, pointer/joystick/vertical input dibersihkan agar input yang tertahan tidak membuat penyelam terus bergerak ketika aplikasi kembali.
- Ketika aplikasi tidak aktif, gameplay dijeda dan RAF dihentikan; ketika kembali aktif, timestamp frame di-reset agar tidak ada lonjakan delta waktu.
- Pengelolaan native memakai listener Capacitor `appStateChange`; browser memakai `visibilitychange`, `pagehide`, dan `pageshow`.
- Audio ambient disuspensi saat aplikasi masuk background dan dicoba diaktifkan kembali ketika sesi dilanjutkan.

### Rendering dan pemulihan WebGL

- Listener `webglcontextlost` mencegah default teardown browser, menjeda sesi, dan menghentikan loop.
- Listener `webglcontextrestored` mengatur ulang state renderer, menerapkan kembali pengaturan, dan membuka jalan untuk pemain menekan Resume.
- Exception pada update/render frame ditangkap; input dilepas dan game dijeda agar exception tidak dibiarkan menghasilkan sesi yang tampak berjalan tetapi state-nya rusak.
- Ini adalah pemeriksaan source dan regresi otomatis; pemulihan context GPU fisik belum diuji di perangkat.

### Preset Ultra

- Target tekstur: Low 1024, Medium 2048, High 4096 (sesuai kemampuan), Ultra 4096 (khusus perangkat yang memenuhi syarat).
- Ultra asli memerlukan batas tekstur GPU minimal 4096 dan `navigator.deviceMemory` minimal 12 GB.
- Ultra pada perangkat kelas 8 GB dengan GPU 4K turun ke High. Jika memori tidak diketahui atau GPU tidak mendukung 4K, fallback ke Medium yang lebih aman.
- Texture maps sekunder tetap 2048 agar alokasi GPU tidak berlipat secara berlebihan.
- Efek preset juga mencakup level detail, bayangan, anisotropy, air, fauna, dan pixel ratio. Nilai tersebut tidak mengubah kecepatan atau balancing gameplay.
- Pelaporan kemampuan 4K sudah disesuaikan agar sejalan dengan ukuran tekstur yang dialokasikan.

## Pengujian yang benar-benar dijalankan

Perintah:

- `node --check game.js`
- `node --check scripts/verify.mjs`
- `node --check environment-simulation.mjs`
- `npm test`

Hasil `npm test`:

- **LULUS** — 176 ID DOM unik.
- **LULUS** — 256 referensi DOM statis valid.
- **LULUS** — pemeriksaan path aset lokal dan import modul.
- **LULUS** — pemeriksaan syntax JavaScript untuk runtime, modul, dan skrip proyek.
- **LULUS** — pengujian determinisme world generation dan helper air/daylight.
- **LULUS** — pemeriksaan save migration/schema v11 dan normalisasi preset Ultra tanpa menaikkan schema save.
- **LULUS** — regression checks Lifepod, hatch, collision, rollback, dan exit.
- **LULUS** — pemeriksaan inventory 8×6, touch scrolling, tools, kamera, survival, fauna, kendaraan, cargo, dan upgrade yang ada.
- **LULUS** — pemeriksaan source autentikasi, Supabase SQL/RLS, room, serta event dunia bersama.
- **LULUS** — pemeriksaan Android Application ID, signing asset, workflow, dan cache Service Worker 2.1.0.
- **LULUS** — pemeriksaan profil grafis Ultra 12 GB, fallback 8 GB, fallback memori tidak diketahui, dan flag 4K.
- **LULUS** — pemeriksaan source lifecycle suspend/resume, WebGL context recovery, dan runtime frame guard.

Hasil aktual terminal:

`The Abyssal 2.1.0 verification passed: 176 unique DOM IDs, 256 valid DOM references, local asset paths, deterministic terrain, v11 save migration and vehicle fleet/upgrades/cargo/swept collision, waterline/daylight helpers, scaled Lifepod transforms/collision/hatch regression, dry-ground jump gating, cave/oxygen-plant/sulfur-nest systems, 8142C cinematic source checks, turtle shell texture source checks, survival/inventory/camera/tool checks, Supabase/Auth and SQL/RLS source checks, Android lifecycle/icon/signing/workflow checks.`

## Build produksi dan APK

- **BELUM BERHASIL / BELUM TERVERIFIKASI.** `npm run build` dijalankan, tetapi gagal karena paket `vite` tidak tersedia (`ERR_MODULE_NOT_FOUND`).
- Instalasi dependency dicoba dengan `npm install --no-audit --no-fund --fetch-retries=1 --fetch-timeout=20000`, tetapi proses instalasi timeout pada lingkungan ini dan tidak menghasilkan `node_modules` yang dapat digunakan.
- Karena itu, tidak ada klaim bahwa production bundle, Android APK, atau APK install berhasil dibuat.

## Belum terverifikasi

- Rendering dan gameplay melalui browser/WebGL nyata setelah semua perubahan.
- Pemulihan WebGL context pada GPU fisik.
- Lifecycle pause/resume pada beberapa versi Android System WebView dan perangkat fisik.
- Preset Ultra pada perangkat 12 GB+ nyata serta stabilitas termal/FPS sesi panjang.
- APK compile, install, update di atas APK lama menggunakan signing key yang sama.
- Login/register Supabase live, room multiplayer dua akun/perangkat, reconnect, dan event dunia bersama di backend nyata.
- Animasi, tekstur, model 3D, dan seluruh suara belum menjalani remaster konten penuh dalam rilis ini.

## Catatan rilis

- Backup lima slot save ke JSON sebelum memasang update.
- Pertahankan `native/abyssal-debug-signing.bin` untuk update APK debug yang kompatibel.
- Project URL Supabase harus berasal dari Dashboard pemilik proyek. Publishable key boleh ada di client; Secret/Service Role key tidak boleh.
- Jangan menandai pengujian perangkat, backend live, atau APK sebagai berhasil sampai benar-benar dilakukan.
