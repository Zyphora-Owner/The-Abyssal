# Laporan Audit — The Abyssal 2.2.0

## Dasar pengerjaan

- Source dasar: ZIP proyek `The_Abyssal_Standalone_Android_v2.1.0.zip` yang tersedia pada sesi ini.
- Pembaruan inkremental; bukan rebuild dari nol.
- Application ID dipertahankan: `com.abyssal.game`.
- Save schema dipertahankan: v11. Tidak ada migrasi atau reset save.
- Fitur dan sistem backend lama dipertahankan.

## Perubahan yang diperiksa pada source

### Cutscene

- Modul baru `cinematic-systems.mjs` mendefinisikan tujuh shot dengan range waktu, fokus objek, offset kamera/target, FOV, dan kecepatan follow.
- Timing subtitle dipisah dan diuji menggunakan helper timeline.
- `updateCinematic()` menggunakan shot director, smoothing posisi dan target, serta FOV sinematik. FOV awal dikembalikan setelah cutscene.
- `cancelIntroCinematic()` membersihkan scene temporer dan overlay tanpa mengubah status cerita/save; `returnToMain()` memanggil pembatalan bila cutscene sedang aktif.
- Ketika gameplay dijeda, kamera tidak lagi bergerak mengikuti idle-camera menu.

### Leviathan dan First-Person

- Leviathan intro menambahkan animasi sirip pektoral, gerak badan, pulse mata dan cahaya.
- Item resource/supply yang sudah direpresentasikan sebagai mesh lokal memperoleh profil ukuran/posisi tangan per item. Tidak menggantikan item, model, Quick Slot, atau fungsi inventory.
- Pose lengan mendapat respons tambahan selama aksi item.

### Audio

- Sistem audio sintetis offline tetap menjadi basis. Layer noise terfilter mendapat profil khusus untuk impact, re-entry, roar, launch, warp, splash, repair, dan event terpilih.
- Tidak ada file rekaman dialog, foley, atau musik baru yang ditambahkan. Karena itu, ini bukan remaster audio studio.

## Pengujian yang benar-benar dijalankan

Perintah:

- `node --check game.js`
- `node --check cinematic-systems.mjs`
- `node --check scripts/verify.mjs`
- `npm test`

Hasil `npm test`:

- **LULUS** — 176 ID HTML unik.
- **LULUS** — 258 referensi DOM statis valid.
- **LULUS** — seluruh path aset lokal dan import modul yang diperiksa.
- **LULUS** — syntax JavaScript untuk runtime, modul, dan skrip proyek.
- **LULUS** — pemeriksaan determinisme terrain, waterline/daylight, save schema v11, Lifepod/hatch/collision, inventory/tools, kendaraan/upgrade, Supabase/SQL/RLS, Android lifecycle/signing/workflow.
- **LULUS** — 7 shot cutscene dan rentang waktu subtitle.
- **LULUS** — pemeriksaan pemulihan FOV dan pembatalan cutscene dari menu.
- **LULUS** — pemeriksaan animasi tambahan Leviathan.
- **LULUS** — pemeriksaan profil model item First-Person dan lapisan audio terfilter untuk event sinematik.

Output terminal aktual:

`The Abyssal 2.2.0 verification passed: 176 unique DOM IDs, 258 valid DOM references, local asset paths, deterministic terrain, v11 save migration and vehicle fleet/upgrades/cargo/swept collision, waterline/daylight helpers, scaled Lifepod transforms/collision/hatch regression, dry-ground jump gating, cave/oxygen-plant/sulfur-nest systems, 8142C cinematic source checks, 7-shot cutscene director/timeline and cancellation recovery checks, animated Leviathan fin/eye/light checks, held-item hand-fit profiles and layered cinematic audio checks, turtle shell texture source checks, survival/inventory/camera/tool checks, Supabase/Auth and SQL/RLS source checks, Android lifecycle/icon/signing/workflow checks.`

## Production build dan APK

- **BELUM BERHASIL / BELUM TERVERIFIKASI.** `npm run build` gagal karena dependency `vite` belum tersedia (`ERR_MODULE_NOT_FOUND`). Folder `node_modules` tidak ada pada source material yang dikerjakan.
- Karena build produksi tidak selesai, APK belum dikompilasi atau diuji instalasinya pada perangkat.

## Belum terverifikasi

- Kualitas visual cutscene dan animasi secara langsung di browser/WebGL.
- Pengalaman kamera dan viewmodel pada rasio layar Android fisik.
- Performa/fps dan penggunaan memori selama sesi panjang.
- Audio aktual pada speaker/headphone perangkat.
- Kompilasi APK, instalasi, dan update di atas aplikasi sebelumnya.
- Login Supabase live dan multiplayer dua akun/perangkat.

## Catatan kualitas aset

Proyek 2.1.0 memakai banyak geometri Three.js dan material/tekstur prosedural untuk karakter, item, dunia, serta cutscene. Perubahan 2.2.0 menyempurnakan director kamera, animasi runtime, profil tampilan item, dan sintesis efek suara; perubahan ini **tidak** mengubah seluruh aset prosedural menjadi paket model/tekstur PBR eksternal atau suara rekaman baru. Status remaster penuh model, texture, dan audio: **BELUM DILAKUKAN**.
