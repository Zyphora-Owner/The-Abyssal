# Build APK The Abyssal 2.0.5 dari HP

1. Ekspor backup JSON dari versi lama dan simpan aman.
2. Ekstrak `The_Abyssal_Standalone_Android_v2.0.5.zip`.
3. Unggah isi folder proyek ke root repository GitHub, termasuk `.github/workflows`, `scripts`, `native`, dan `supabase`.
4. Pertahankan `native/abyssal-debug-signing.bin`; signing key yang sama diperlukan untuk update APK debug lama.
5. Commit dan push ke `main`/`master`, atau jalankan workflow manual.
6. Buka **Actions → Build The Abyssal Native Android APK**.
7. Jika job berhasil, unduh artifact `the-abyssal-android-apk-2.0.5`, ekstrak, lalu pasang `app-debug.apk`.

## Uji penting setelah APK terpasang

- Menu utama: pastikan video latar laut diputar, loop, dan berhenti saat masuk gameplay/panel.
- Cutscene: subtitle berada di tengah atas dan leviathan terlihat saat kamera cut ke monster.
- Lifepod: mulai game, berenang ke kapsul yang mengapung di waterline, bidik hatch di atas; uji collision sisi/atap/lantai serta masuk/keluar.
- Tank: rating tekanan Mk I 50 m, Mk II 100 m, Mk III 200 m, Mk IV 300 m, Mk V 500 m. Uji warning dan pressure stress di atas rating. Kapasitas O₂ tidak berubah; rating tekanan bukan persediaan napas.
- Builder: pilih modul, pindahkan hologram ke dasar rata/kosong (hijau), lalu tekan BUILD; lokasi tak valid (merah) harus menolak penempatan.
- Ore: bidik dan hancurkan; amati ayunan tangan, getaran, debris, suara hit/break dan item drop.
- Flashlight: pilih senter, ON/OFF; periksa penerangan objek dan cone beam di air gelap.
- Uji inventory, lima Quick Slots, PDA, Fabricator, Seaglide, fauna, biome, misi, save/load, Login/Register dan co-op.

## Supabase

Tidak ada migration baru pada 2.0.5. Project URL diambil dari Supabase Dashboard → Project Settings → API. Jangan memasukkan Secret Key atau Service Role Key ke aplikasi.

## Batas verifikasi rilis

`npm test` dan pemeriksaan sintaks lulus. Instalasi dependency npm timeout sehingga Vite/APK build belum dapat diverifikasi dalam lingkungan ini. Rendering GPU, FPS, memori, dan interaksi fisik wajib diuji di perangkat Android setelah workflow build sukses.
