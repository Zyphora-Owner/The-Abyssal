# Build APK The Abyssal 2.0.6 dari HP

## Sebelum memasang
1. Buka game versi lama dan ekspor backup JSON save. Simpan di folder Downloads/cloud pribadi.
2. Gunakan ZIP ini sebagai source proyek. Jangan menghapus `native/abyssal-debug-signing.bin`; signing key yang sama dibutuhkan untuk memperbarui APK debug lama.
3. Pastikan GitHub repository memakai branch `main` atau `master`.

## Build melalui GitHub Actions
1. Unduh dan ekstrak `The_Abyssal_Standalone_Android_v2.0.6.zip`.
2. Unggah **isi folder proyek** ke root repository. Sertakan folder tersembunyi `.github`, `scripts`, `supabase`, `native`, `icons`, `assets`, serta `package.json` dan `capacitor.config.json`.
3. Jangan unggah ZIP proyek lain ke root repository. Workflow mengharapkan tepat satu ZIP proyek jika source tidak langsung berada di root.
4. Commit dan push, atau pilih **Actions → Build The Abyssal Native Android APK → Run workflow**.
5. Tunggu sampai seluruh job selesai. Jika sukses, unduh artifact `the-abyssal-android-apk-2.0.6`.
6. Ekstrak artifact dan pasang `app-debug.apk`.

APK harus ditandatangani dengan key yang sama untuk memperbarui instalasi lama. Jangan uninstall versi lama sebelum backup save diamankan.

## Pemeriksaan setelah instalasi
- Mulai permainan dan dekati Lifepod.
- Berenang ke atas hingga posisi mata di atas permukaan; lihat hatch dari atas, arahkan reticle ke pusat hatch, lalu tekan Interact. Saat kapsul belum dibidik dengan tepat, teks bantuan akan muncul tetapi tombol masuk tidak aktif.
- Uji hatch tertutup dari sisi/atap dan pastikan karakter tidak menembus hull.
- Keluar kembali lewat hatch dan periksa posisi karakter.
- Lompat hanya muncul saat berdiri di daratan kering; di air tombol naik tetap untuk berenang ke atas.
- Jalankan cutscene dari awal: Bumi → kapal transfer → pelepasan kapsul → atmosfer 8142C → pendaratan → reveal Leviathan.
- Cari gua, ventilasi termal, tanaman oksigen, dan sarang sulfur.
- Pastikan tidak ada toast “Slot Cepat 1/2/3...” saat item dipilih.
- Uji inventory, PDA, Fabricator, crafting, tools, fauna, save/load, akun dan room multiplayer.

## Batas pengujian lokal
Source sudah melewati `npm test`. Build produksi belum dapat diuji di lingkungan ini karena paket `vite` tidak tersedia; GitHub Actions melakukan instalasi dependency sebelum build. APK dan rendering perangkat tetap perlu diverifikasi dari artifact dan HP Android.
