# Build APK The Abyssal 2.0.7 dari HP

## Sebelum memasang
1. Ekspor backup JSON save dari versi yang sedang digunakan.
2. Pertahankan `native/abyssal-debug-signing.bin` di repository/ZIP. APK debug harus memakai signing key yang sama agar dapat memperbarui pemasangan lama.
3. Unduh `The_Abyssal_Standalone_Android_v2.0.7.zip` dan ekstrak.

## GitHub Actions
1. Unggah **isi proyek** ke root repository GitHub, termasuk `.github/workflows`, `scripts`, `native`, `supabase`, `icons`, `assets`, `package.json`, dan `capacitor.config.json`.
2. Jangan letakkan beberapa ZIP proyek berbeda di root repository.
3. Commit/push ke `main` atau `master`, atau jalankan workflow manual.
4. Buka **Actions → Build The Abyssal Native Android APK**.
5. Jika semua job berhasil, unduh artifact `the-abyssal-android-apk-2.0.7` dan pasang `app-debug.apk`.

## Pengujian first-person setelah instalasi
- Mulai game dan masukkan beberapa item resource serta tool ke Quick Slots.
- Pilih Scanner, Knife, Flashlight, Habitat Builder, dan Repair Tool satu per satu. Pastikan setiap model terlihat pada tangan kanan dan grip glove menutupi bagian pegangan.
- Pilih item resource/supply seperti Titanium, Quartz, Battery, Water, dan Medkit. Model 3D harus muncul dan berbeda sesuai item.
- Pilih slot kosong. Tidak boleh ada model item yang tertinggal di tangan.
- Ganti slot dengan cepat. Model dan grip harus mengikuti item aktif tanpa tertinggal.
- Pilih Seaglide. Pastikan model berada di depan tubuh, kedua handle terlihat, dan kedua tangan mengarah ke posisi pegangan.
- Uji animasi Knife, Scanner, Builder, Repair Tool, Flashlight, dan Seaglide.
- Periksa clipping saat melihat lurus, ke atas, ke bawah, saat berenang, ketika masuk Lifepod, dan pada resolusi layar berbeda.
- Pastikan indikator Quick Slots tetap lima dan tidak muncul toast lama `Slot Cepat 1:` dan seterusnya.

## Batas verifikasi
`npm test` dan syntax check telah lulus. Build lokal belum dapat dijalankan pada lingkungan penyusunan karena paket Vite tidak tersedia. APK harus dikonfirmasi melalui GitHub Actions dan diuji langsung pada perangkat Android sebelum dinyatakan siap.
