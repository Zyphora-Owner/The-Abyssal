# Build APK The Abyssal 2.0.8 dari HP

## Sebelum memperbarui

1. Ekspor backup JSON dari versi lama dan simpan di Downloads/Drive.
2. Pertahankan `native/abyssal-debug-signing.bin` dari ZIP. Signing key yang sama dibutuhkan agar Android dapat memperbarui APK debug yang sudah terpasang.
3. Ekstrak `The_Abyssal_Standalone_Android_v2.0.8.zip`.

## Build melalui GitHub Actions

1. Unggah **isi folder proyek** ke root repository GitHub, bukan folder luarnya saja.
2. Pastikan `.github/workflows/`, `scripts/`, `native/`, `supabase/`, `icons/`, `assets/`, `package.json`, dan `capacitor.config.json` ikut terunggah.
3. Hapus ZIP proyek versi sebelumnya dari root repository agar workflow tidak menemukan lebih dari satu arsip proyek.
4. Commit dan push ke `main`/`master`, atau jalankan workflow manual.
5. Buka **Actions → Build The Abyssal Native Android APK**.
6. Jika job selesai sukses, unduh artifact `the-abyssal-android-apk-2.0.8`, ekstrak, lalu pasang `app-debug.apk`.

**Catatan build lokal:** dalam lingkungan pemeriksaan ini `npm run build` belum berhasil karena paket `vite` tidak tersedia dan instalasi dependency mengalami timeout. Karena itu APK belum diklaim berhasil dikompilasi. GitHub Actions harus menyelesaikan langkah Install dependencies, Verify source, Bundle, Compile APK, dan Verify APK sampai hijau.

## Kendaraan 2.0.8

1. Buat **Vehicle Fabrication Bay** menggunakan Habitat Builder.
2. Dekati bay dan bidik/tekan Interact untuk membuka panel Vehicle Fabrication Bay.
3. Kumpulkan material resep lalu pilih Fabricate.
4. Tekan Launch. Peluncuran ditolak jika air terlalu dangkal atau area di depan bay terhalang.
5. Bidik badan kendaraan yang sudah diluncurkan lalu tekan Interact untuk masuk.
6. Gunakan joystick untuk maju/bergeser, kamera untuk mengubah arah, serta tombol naik/turun untuk gerak vertikal. Tekan Exit Vehicle untuk keluar.
7. Pasang Depth Module I sebelum Depth Module II. Upgrade lain membuka hull reinforcement, cargo, sonar, efisiensi, thermal recharge, drill, atau grapple sesuai kendaraan.
8. Repair, Recharge, serta upgrade dilakukan dekat Vehicle Bay. Untuk Carrier, tombol Cargo membuka Carrier Command Deck saat kapal sedang dikemudikan; fungsi ini untuk transfer cargo, bukan bengkel penuh.

### Kendaraan

- **Pelagic Skimmer** — sub satu penyelam untuk eksplorasi cepat; upgrade sonar, kedalaman, hull, storage, efisiensi.
- **Pelagic Carrier** — kapal selam ekspedisi/basis bergerak; upgrade pressure hull, cargo, sonar, reinforcement, dan thermal recharge.
- **Nautilus Exosuit** — rangka mekanis laut dalam; upgrade kedalaman, chassis, cargo, Mining Drill Arm, Grappling Arm.

Model dan identitas kendaraan original The Abyssal. Kendaraan/upgrade/cargo tersimpan pada save lokal, belum disinkronkan ke shared-world multiplayer.

## Uji setelah APK terpasang

- Buat Vehicle Bay dan pastikan modelnya dapat ditargetkan serta panelnya terbuka.
- Fabricate ketiga kendaraan, launch, bidik, masuk, kemudikan, dan keluar.
- Uji gerakan maju, mundur, strafing, naik, turun, turning, dan kamera saat mengemudi.
- Uji collision dengan terrain, habitat, Lifepod (termasuk saat hatch terbuka), wreck, supply cache, dan kendaraan lain.
- Uji kedalaman, pressure damage, hull, daya, sonar, drill/grapple, cargo, repair, recharge, dan urutan upgrade.
- Uji Carrier Command Deck dan pastikan transfer cargo bekerja dengan Cargo Compartment.
- Save saat di luar kendaraan dan saat mengemudi; muat ulang slot dan periksa status deployed/active.
- Regression test inventory, Quick Slots, PDA, Fabricator, habitat, Seaglide, fauna, misi, survival, menu, dan save/load.

## Batas verifikasi saat paket dibuat

Pengujian otomatis source dapat lulus tanpa membuktikan render GPU atau simulasi fisika pada perangkat nyata. APK, GPU Android, kontrol multi-touch, sesi panjang, Login/Register live, dan multiplayer dua perangkat harus ditandai belum terverifikasi sampai benar-benar diuji.
