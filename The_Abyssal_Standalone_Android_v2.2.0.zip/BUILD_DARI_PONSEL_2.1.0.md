# Build APK The Abyssal 2.1.0 dari HP

## Sebelum memperbarui

1. Ekspor backup JSON save dari versi lama dan simpan di Downloads/Drive.
2. Pertahankan `native/abyssal-debug-signing.bin` dari ZIP. Signing key yang sama dibutuhkan agar Android dapat memperbarui APK debug yang sudah terpasang.
3. Ekstrak `The_Abyssal_Standalone_Android_v2.1.0.zip`.

## Build melalui GitHub Actions

1. Unggah **isi folder proyek** ke root repository GitHub, bukan folder luarnya saja.
2. Pastikan `.github/workflows/`, `scripts/`, `native/`, `supabase/`, `icons/`, `assets/`, `package.json`, dan `capacitor.config.json` ikut terunggah.
3. Hapus ZIP proyek versi lama dari root repository agar workflow tidak menemukan lebih dari satu arsip proyek.
4. Commit dan push ke `main`/`master`, atau jalankan workflow secara manual.
5. Buka **Actions → Build The Abyssal Native Android APK**.
6. Jika seluruh job sukses, unduh artifact `the-abyssal-android-apk-2.1.0`, ekstrak, lalu pasang `app-debug.apk`.

Jangan menganggap APK berhasil sebelum artifact benar-benar muncul dan dapat dipasang. Jika workflow gagal, simpan log error lengkap dan perbaiki akar masalahnya.

## Uji Lifepod, Inventory, dan Fabricator

1. Mulai permainan baru atau muat slot backup.
2. Berenang ke atas Lifepod, bidik hatch atap, lalu tekan Interact.
3. Pastikan interior tampil, player dapat bergerak, dan Fabricator dapat ditargetkan.
4. Tekan tombol keluar habitat. Pastikan pemain muncul di sisi kapsul, bukan tersangkut di hatch/atap.
5. Bergerak menjauh dari kapsul dan kembali mendekat. Pastikan collision tidak menahan karakter setelah hatch menutup. Jika area egress terhalang, game harus mempertahankan posisi aman di kabin dan memberi pesan, bukan memindahkan pemain ke dalam hull.
6. Buka Inventory. Gulir isi panel dari atas ke bawah; uji backpack 8×6, equipment, dan Quick Slots.
7. Pilih item di Backpack dan pastikan masuk ke Quick Slot tanpa merusak jumlah item.
8. Buka Fabricator, pindah ke empat kategori, gulir resep, lalu buat item yang bahannya tersedia.
9. Tutup Inventory/Fabricator memakai tombol panel dan tombol Back Android. Pastikan kontrol gameplay kembali aktif.
10. Tonton cutscene pembuka sampai kemunculan Leviathan; periksa framing kamera, subtitle, suara, dan transisi ke gameplay.
11. Simpan, tutup aplikasi, buka lagi, lalu muat slot. Periksa posisi, inventory, kendaraan, struktur, dan progres.

## Changelog 2.1.0

- Lifecycle aplikasi kini menjeda game dan menghentikan RAF ketika background; input sentuh dilepas dan frame delta direset saat kembali.
- Pemulihan konteks WebGL dan pengaman error frame ditambahkan.
- Preset Ultra 4K adaptif tersedia untuk perangkat 12 GB+ yang GPU-nya mendukung; perangkat lain mendapat fallback aman.
- Exit Lifepod memakai posisi world di luar hull/hatch channel; kedua sisi dicoba dan posisi ditolak jika terhalang.
- Entry Lifepod memvalidasi interior dan melakukan rollback pose jika gagal.
- Inventory/Fabricator mendukung scroll sentuh Android dan safe-area; backpack tetap 8×6.
- Panel diberi audio feedback; reveal dan framing Leviathan pada cutscene diperkuat.
- Save schema v11 dan Application ID `com.abyssal.game` tetap dipertahankan.

## Status verifikasi saat paket dibuat

Unit/source checks dapat dijalankan melalui `npm test`. Build Vite/produksi dan APK untuk paket 2.1.0 belum berhasil diverifikasi pada lingkungan penyusunan. `npm run build` membutuhkan dependency Vite; lihat `AUDIT_REPORT_2.1.0_ID.md`. Jangan menyatakan APK berhasil sebelum GitHub Actions menghasilkan artifact dan APK diuji pemasangannya.
