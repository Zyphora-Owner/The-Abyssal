# Panduan Build The Abyssal 2.2.0 dari Ponsel

## Sebelum build

1. Ekstrak `The_Abyssal_Standalone_Android_v2.2.0.zip` ke folder kerja.
2. Buka folder proyek yang berisi `package.json`, `index.html`, dan `capacitor.config.json`.
3. Pastikan koneksi internet tersedia untuk mengunduh dependency.
4. Jangan menghapus `native/abyssal-debug-signing.bin` jika APK debug harus dapat memperbarui instalasi debug lama dengan signing yang sama.

## Verifikasi source

```bash
node --version
npm --version
npm install --no-audit --no-fund
npm test
```

`npm test` harus menampilkan `The Abyssal 2.2.0 verification passed` sebelum melanjutkan.

## Build web/native bundle

```bash
npm run build
```

Jika build gagal, simpan output lengkap. Jangan menghapus test atau mengganti konfigurasi untuk memaksa build tampak berhasil.

## Build APK

Cara termudah pada ponsel adalah menjalankan workflow GitHub Actions `Build The Abyssal Native Android APK` dari repository yang sudah berisi seluruh source atau satu ZIP proyek di root. Workflow akan memasang dependency, menjalankan `npm test`, menyiapkan Capacitor, membangun APK debug, dan memverifikasi Application ID.

Perintah lokal pada lingkungan dengan Java 21, Android SDK, dan dependency terpasang:

```bash
npm run android:add
# Untuk proyek Android yang sudah ada:
npm run android:sync
cd android
./gradlew --no-daemon assembleDebug
```

APK debug dihasilkan di `android/app/build/outputs/apk/debug/app-debug.apk`.

## Catatan penting

- Application ID tetap `com.abyssal.game`.
- Save schema tetap v11; backup lima slot save sebelum update tetap disarankan.
- Jangan mengubah atau mengganti signing key yang dipakai untuk update APK debug lama.
- Project URL dan publishable key Supabase harus dikonfigurasi melalui GitHub Secrets atau `.env` sesuai panduan Supabase. Jangan memasukkan `service_role` key ke client.
- APK dan build produksi pada rilis ini belum dibuktikan berhasil di lingkungan penyusunan paket karena `vite` belum terpasang. Jalankan seluruh langkah di atas pada lingkungan build Android yang lengkap.
