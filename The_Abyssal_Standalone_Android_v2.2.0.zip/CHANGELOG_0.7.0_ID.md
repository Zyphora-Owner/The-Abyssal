# THE ABYSSAL 0.7.0

- Kamera pemain dipindahkan ke First Person dengan viewmodel tangan dan scanner.
- Fix layout fullscreen/landscape: game menggunakan seluruh area layar, tanpa letterbox paksa.
- Android keyboard menggunakan adjustPan agar game tidak mengecil saat kolom input difokuskan.
- Menambahkan tekstur prosedural untuk terrain, batu, flora, karang, kayu, dan metal.
- Menambahkan underwater light rays, ambient ocean noise, dan SFX scanner/collect/craft/build/damage.
- Menambahkan inventory, resource gathering, crafting Medkit/Rations, dan Habitat Builder.
- Inventory, node resource yang sudah diambil, dan struktur yang dibangun ikut tersimpan di 5 slot.
- Logo aplikasi/menu menggunakan emblem yang diberikan dalam paket upgrade.

Catatan: ini masih prototipe indie, bukan aset/fitur produksi setara Subnautica.
