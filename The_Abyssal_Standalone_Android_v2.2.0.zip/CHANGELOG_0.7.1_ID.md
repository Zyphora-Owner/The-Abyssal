# THE ABYSSAL 0.7.1 — Mobile polish

- Kamera permainan ditetapkan First Person; model penyelam third-person tidak ditampilkan dan tangan/scanner ada pada kamera.
- Tampilan Android memakai immersive fullscreen, landscape, dan penanganan keyboard `adjustPan`.
- Menghapus letterboxing 16:9 yang mengecilkan area game; renderer mengikuti viewport perangkat landscape yang sebenarnya.
- Menambahkan material procedural bertekstur untuk terrain, batu, flora, karang, kayu, logam, dan pola sisik fauna.
- Memperkuat ambience bawah laut sintetis, sfx scan/collect/craft/build/damage, partikel dan god-rays ringan.
- Menambahkan inventory, resource gathering, crafting medkit/rations, habitat beacon/foundation/compartment.
- Menambahkan backup/restore JSON lima slot.
- Memperbaiki rekonstruksi chunk saat memuat slot, agar resource dan bangunan mengikuti save yang dipilih.
- Menambahkan signing debug key tetap untuk build berikutnya dan menaikkan versionCode ke 701.
- Menambahkan pemeriksa rilis APK opsional melalui manifest HTTPS. Pemeriksa belum aktif sampai URL publik diatur.

## Batasan

Build ini masih prototipe stylized low-poly, bukan game dengan kedalaman konten setara Subnautica. Live OTA update, kendaraan, power grid habitat, fauna dengan AI kompleks, dan multiplayer yang menyinkronkan setiap entitas dunia belum diimplementasikan penuh.
