# THE ABYSSAL — Changelog 0.8.0

## Tujuan
Memperdalam pengalaman eksplorasi-survival bawah laut dengan dunia berzona, progresi peralatan, catatan ekspedisi, dan habitat yang punya fungsi. Seluruh elemen visual/audio menggunakan aset dan implementasi orisinal.

## Ditambahkan
- Luminous Reef, Sapphire Kelp Forest, Wreckfall Shelf, Ember Vent Fields, The Hadal Reach, Pelagic Expanse.
- Fauna berbasis habitat; 5 spesies baru (30 total).
- Explorer PDA: biome log dan katalog fauna hasil scan.
- Tekanan kedalaman, tank O2 bertingkat, fins, rebreather, pressure suit.
- Lithium, sulfur, magnetite, salt.
- Oxygen Refill Station, Storage Locker, Surface Power Relay.
- Thermal vents, fan corals, glowing crystal clusters in hot/deep zones, caustic texture, tint/fog biome.
- Air murni: crafting dari salt + quartz + copper, botol dapat diminum untuk memulihkan hidrasi.
- Paparan suhu ekstrem kini menjadi hazard survival yang dapat dikurangi dengan Pressure-Weave Suit.
- Perbaikan fallback pemilihan fauna pada batas kedalaman agar populasi tidak gagal ketika penyelam berada sangat dekat permukaan/dasar.

## Dipertahankan
First-person, streaming chunk, 5 save slots, save lama, survival HUD, fauna sebelumnya, inventory, crafting, building dasar, backup JSON, Supabase source, multiplayer room source, native Android packaging, landscape/fullscreen, GitHub cloud build.

## Belum setara game komersial
Tidak ada klaim kualitas setara Subnautica. Belum ada kendaraan drivable, story campaign, arsitektur server-authoritative untuk fauna/survival, freeform modular base snapping, power grid penuh, atau device profiling. Perlu diuji pada ponsel target.
