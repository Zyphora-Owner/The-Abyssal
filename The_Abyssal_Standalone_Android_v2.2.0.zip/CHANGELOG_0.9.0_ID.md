# The Abyssal 0.9.0 — Immersive Ocean Update

## Visual dan material
- Tekstur procedural resolusi 256px dengan pola pasir beriak, grain batu, pori karang, serat kayu dan goresan metal.
- Height/bump maps terpisah memberi detail permukaan tanpa menambah asset download.
- Terrain mesh 14/20/26 segmen untuk Low/Balanced/High.
- Kelp menggunakan deformasi vertex shader untuk gerak arus ringan.

## Karakter dan fisika
- Rig first-person menampilkan bahu, upper arm, forearm, cuff, palm, jari sarung tangan dan scanner.
- Animasi lengan mengikuti fase renang dan kecepatan gerak.
- Akselerasi, drag air, dan kecepatan renang yang lebih halus.
- Collision terrain berbasis capsule sampling, slide pada lereng curam, dan collision bangunan kecil.

## Ekosistem
- Bentuk tubuh ikan lebih streamline, sirip ekor bercabang, gill detail dan bump scale texture.
- Animasi manta, paus, kura-kura, cumi, ubur-ubur, dan sirip ikan disempurnakan.
- Fauna dikoreksi agar tidak menembus dasar laut atau permukaan.

## Kompatibilitas
- Semua sistem versi 0.8.0 dipertahankan: bioma, 30 fauna, survival, PDA, inventory, crafting, equipment, building, slot save, backup, OAuth/Cloud/Multiplayer source, dan workflow Android.
- Versi package dinaikkan ke 0.9.0 agar Android memberi versionCode lebih tinggi.

## Batasan pengujian
- Pemeriksaan source dan build web perlu dijalankan pada GitHub Actions.
- Belum diuji pada perangkat fisik; shader/material bump dan frame rate perlu dievaluasi di HP pengguna.
- Ini peningkatan orisinal dengan estetika survival bawah laut; bukan salinan aset, kode, atau model Subnautica.


## Pelestarian fitur dan migrasi
- Format lima slot lama tidak diubah; velocity renang tidak dimasukkan ke save sehingga progres lama tetap dapat dimuat.
- Inventory, equipment, cache, biome log, species discoveries, habitat placements, cloud save dan room save tetap menggunakan record lama.
- Nomor versi paket dinaikkan ke 0.9.0; native versionCode dihasilkan oleh patch Android dari package version.
