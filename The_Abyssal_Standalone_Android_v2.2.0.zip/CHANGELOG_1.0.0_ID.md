# THE ABYSSAL 1.0.0 — Emergency Story & Physical Salvage Update

## Cerita pembuka 3D
- New Expedition now starts with an original in-engine cinematic: Pelagic Research Array is attacked by a gigantic unknown ocean entity, emergency systems fail, and the diver escapes in a launch capsule before reaching the sea.
- The cinematic is assembled from original Three.js geometry and animated camera moves, lights, impact flashes, and falling debris. It can be skipped and is shown only for a new expedition (or a save created before the sequence was completed).
- After landing, a damaged lifepod is placed in the world with a proximity-based console interaction.

## Misi dan PDA
- Added a primary mission chain: stabilize the lifepod, scan a life-form, gather resources, collect fresh fish, craft a medkit, build a seabed structure, and investigate the abandoned vessel.
- Mission progress, counters, and completed directives are saved with each of the five slots and therefore travel with the existing Cloud Save record.
- Explorer PDA now includes a mission log while retaining all biome and species discovery records.

## Physical harvesting and wildlife
- Resource nodes are now broken/harvested rather than instantly converted into inventory.
- Destroyed nodes emit non-graphic debris fragments and physical item drops. Drops fall under underwater gravity, experience drag/buoyancy, bounce and settle against the procedural seabed, and can then be picked up.
- Added Glowcap Mushroom nodes in suitable biomes; the mushroom cap/stem break into collectible drops.
- Small non-hostile fish can be stunned/harvested through a close-range interaction. Large animals, sharks, whales, squid, and Leviathans remain scan-only/creature encounters in this version.
- Fresh Fish drops can be collected and eaten to restore Food. World drops are serialized into slot saves.

## Radio and audio
- Added radio dialogue for the opening sequence and mission updates.
- Voice playback uses the Android/WebView device speech-synthesis voice when available; subtitles always remain available as a fallback. This is device-generated TTS, not a recorded professional voice cast.
- Added impact/radio sound cues while retaining biome ambience and all existing game SFX.

## Compatibility and preservation
- Preserved existing biomes, 30 species, survival meters, equipment, inventory, crafting, structures, scanner, five save slots, JSON backup/restore, Supabase Auth/Cloud Save, multiplayer host/join source, and standalone Capacitor Android workflow.
- Save record version advanced to 6. Legacy records without story data are migrated to the post-intro mission state so existing expeditions do not unexpectedly replay the opening cinematic.
- Package/app version advanced to 1.0.0; Android versionCode is generated from package version by the existing native patcher.

## Honest limits
- This update adds a stylized procedural cinematic and mission chain; it is not a fully motion-captured cinematic or AAA production.
- Voice acting relies on installed device TTS voices. Availability, accent, and sound quality vary by Android device and language pack. Subtitles are the reliable fallback.
- Small fish collection is intentionally non-graphic. Large fauna are not killable/harvestable.
- New item drops use stylized procedural materials and physics, not high-resolution hand-authored asset packs. Real-device FPS, touch interactions, TTS, and APK installation must still be tested on the target Android phone.
