# THE ABYSSAL 1.0.2 — Audit & Integrity Fixes

## Masalah kritis yang diperbaiki

- Modul `save-schema.mjs` yang diimpor game tidak ada pada paket sebelumnya. Modul kini ditambahkan, dan menguji/menormalkan setting, slot, backup, survival, inventory, equipment, story, daftar fauna/bioma, struktur, dan item drop.
- Pemeriksaan source lama hanya memeriksa sebagian besar keberadaan teks. Script `verify.mjs` diganti dengan pemeriksaan duplicate DOM IDs, referensi DOM, struktur native, serta tes perilaku normalisasi data dan backup.
- Backup tidak boleh menimpa save saat permainan masih aktif atau room multiplayer. Ekspor kini memasukkan snapshot slot aktif setelah penyimpanan lokal sukses.
- Local save failure tidak lagi dilaporkan sebagai sukses; checkpoint Host harus berhasil ditulis secara lokal sebelum save bersama dilanjutkan.
- Storage Locker mematuhi batas 99 item per jenis.

## Gameplay, navigasi, dan kestabilan

- Peta layar UI sekarang mendaftarkan PDA dan tombol PDA membuka layar yang benar.
- Avatar pemain multiplayer dibuat visible walaupun model lokal disembunyikan untuk first-person; yaw diarahkan pada root model.
- Batas gerak vertikal mengizinkan pemain mencapai permukaan, tetapi tidak terbang di atas air terbuka.
- Android hardware Back menutup panel terbuka sesuai prioritas dan kembali dari submenu dengan benar.
- Intro cutscene berhenti saat Pause, tidak terus memajukan timeline di belakang menu Pause.
- Room multiplayer gagal tersambung: timer/channel/state dibersihkan. Room Host yang gagal konek ditutup, dan keanggotaan Guest yang gagal dikoneksikan dihapus.
- Broadcast mengunci `user_id` dan `display_name` setelah state input agar tidak bisa tertimpa.
- Item drop, node sumber daya yang dipanen, dan lifepod lama dibersihkan melalui disposal geometri/material untuk mengurangi memory leak.
- Focusout keyboard memicu resize ulang ketika keyboard ditutup.

## Versi dan kompatibilitas

- Package/app version: `1.0.2`.
- Save schema: versi 7, slot lama dimigrasikan dengan default yang tervalidasi.
- Backup JSON menerima format sebelumnya `the-abyssal-save-backup` dengan lima slot.
- Cache preview browser dinaikkan.
- Tidak mengubah `appId` Android atau storage key lokal agar progres yang sudah ada tetap dapat ditemukan.

## Pengujian

- `node --check`: `game.js`, `online.js`, `fauna.js`, `save-schema.mjs`, `scripts/verify.mjs`.
- `npm test`: memeriksa DOM unique/reference integrity, save-schema boundary tests, backup rejection tests, native settings, UI navigation wiring, fauna/cinematic/survival hooks, Supabase host-save guards, dan workflow.
- Belum menjalankan build Vite/Gradle atau menguji APK pada perangkat Android fisik. Login/OAuth, Supabase Cloud Save dan multiplayer dua perangkat juga belum dapat diuji tanpa kredensial dan perangkat.
