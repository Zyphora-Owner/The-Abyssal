# CHANGELOG THE ABYSSAL 1.1.0

## Inventory dan kontrol
- Backpack disusun sebagai 27 slot (9 × 3) dengan footprint per item 1, 2, 4, 6, atau 8 slot dan stack yang dibatasi.
- PDA sekarang termasuk item awal di inventory; hotbar berjumlah lima slot.
- Equipment tank, chestplate/armor, dan helmet berada di slot terpisah dan tidak dapat dipasang ke hotbar.
- Item drop dan supply cache harus ditargetkan menggunakan reticle tengah. Harvest node menggunakan Survival Knife dan tombol HANCURKAN.
- Memilih Habitat Builder mengubah Interact menjadi BUILD; menu Build menolak akses bila alat tidak dimiliki atau tidak sedang dipilih.

## Habitat, Fabricator, survival
- Lifepod dan habitat modular memiliki interior dengan kasur, workstation Fabricator, outlet oksigen, dan pencahayaan.
- Oksigen dipulihkan di area interior habitat; supply cache luar tidak lagi menambah O₂.
- Fabricator memiliki kategori Sustenance, Personal, Resources, dan Electronics.
- O₂ awal disetel ke 45. Konsumsi normal acak 2–4 dan konsumsi overload 4–8 tiap interval lima detik.
- Tangki O₂ meningkatkan kapasitas; fins, rebreather, chestplate, dan helmet dapat dibuat di Fabricator.
- Kasur menyimpan checkpoint; respawn mengutamakan checkpoint kasur, lalu save terakhir jika belum ada checkpoint.
- Auto Save aktif secara default dengan interval lima menit dan toggle Settings.

## Presentasi dan kompatibilitas
- Perbaikan smoothing kamera, animasi tangan/renang, reticle, dan layout caption cutscene.
- Ikon item baru disediakan sebagai PNG di `icons/items/`.
- Save schema naik ke v8 dengan migrasi kapasitas oksigen untuk save lama.
- Cache service worker dan nomor versi disetel ke 1.1.0.

## Verifikasi
- `npm test` berhasil pada source hasil update.
- `npm install` tidak selesai di lingkungan edit ini, jadi bundling Vite dan APK belum diklaim berhasil. Lanjutkan build melalui GitHub Actions lalu uji pada perangkat Android.
