# The Abyssal 1.2.0 — Mobile HUD

## Fokus rilis
Memperbarui presentasi HUD agar lebih dekat dengan tata letak kontrol survival bawah laut pada Subnautica versi mobile, dengan aset antarmuka orisinal untuk The Abyssal. Tidak menyalin logo, karakter, atau aset game lain.

## Perubahan
- Gauge O₂ berbentuk lingkaran dengan indikator progres dinamis dan angka kapasitas saat ini.
- Gauge mini HP, Food, dan Water menggunakan ring berwarna dengan ikon PNG.
- Indikator kedalaman dipusatkan di bagian atas layar.
- Menu jeda, Explorer PDA, Inventory, serta tombol Save ditempatkan dalam klaster UI kanan atas.
- Joystick kiri, area drag-look kanan, kontrol vertikal panah, reticle tengah, dan hotbar lima slot disusun untuk landscape Android.
- Scan, Interact/Build, Use, Hancurkan, Harvest, Bed, dan Exit memakai tombol lingkaran berikon PNG. Tindakan tetap mengarah ke handler existing.
- Kartu alat memperlihatkan item yang sedang dipilih di Hotbar.
- Peringatan ancaman fauna memakai label teks, bukan emoji.
- Versi aplikasi menjadi 1.2.0 dan cache service worker diperbarui untuk menghindari penggunaan HUD lama.

## Pengujian
- `npm test`: lulus setelah penambahan validasi HUD dan aset PNG.
- `node --check game.js`: lulus.
- Build Vite/APK: belum dapat diverifikasi karena paket `vite` tidak tersedia di lingkungan ini.
- Pengujian sentuh, rendering WebGL, dan performa akhir masih perlu dilakukan pada perangkat Android fisik.
