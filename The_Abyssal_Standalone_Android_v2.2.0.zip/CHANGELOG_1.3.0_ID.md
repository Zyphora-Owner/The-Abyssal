# The Abyssal 1.3.0 — Diver Immersion Update

Tanggal: 6 November 2026

## Fokus rilis
Mendekatkan pengalaman mobile ke game survival penyelam first-person melalui HUD visor, depth feedback, interaksi yang benar-benar mengikuti reticle, dan animasi peralatan. Rilis ini merupakan peningkatan non-destruktif di atas 1.2.0.

## Pembaruan
- Menambahkan visor vignette yang bereaksi pada kedalaman, tekanan, dan oksigen kritis tanpa menutup area pandang utama.
- Menambahkan progress bar kedalaman dan perubahan warna gauge O₂ ketika status rendah/kritis.
- Reticle menunjukkan jenis target yang sedang dibidik; label target dan warna reticle konsisten untuk resource, fauna, drop, cache, habitat, fabricator, dan build.
- Scanner sekarang memerlukan fauna berada di tengah bidikan, tidak lagi memindai spesies secara sembarang di sekitar pemain.
- Animasi equip, swipe Survival Knife, pulse Scanner, dan aktivasi Habitat Builder diperhalus.
- Flashlight dilengkapi sorot cahaya berbentuk cone yang hanya aktif saat dipilih.
- Tombol Save manual di HUD ditampilkan kembali dan tetap terhubung ke save handler.
- Layout tetap responsif untuk landscape Android; motion tambahan menghormati pengaturan reduced-motion perangkat.
- Service worker cache dan versi aplikasi diperbarui ke 1.3.0.

## Fitur yang dipertahankan
27 slot backpack dengan footprint item, lima slot Hotbar, Explorer PDA, equipment tank/chestplate/helmet, Habitat Builder, capsule/interior, Fabricator empat kategori, oksigen interior, checkpoint bed, fallback ke save terakhir, Auto Save 5 menit yang dapat diatur, fauna, bioma, misi, cutscene, audio, penyimpanan lokal, backup/restore, dan integrasi online opsional.

## Kompatibilitas save
Schema save tetap **v8**. Tidak ada penghapusan atau reset slot save. Perubahan hanya menambah feedback presentasi dan validasi target scanner.
