# Changelog The Abyssal 1.4.0

Rilis ini menyelaraskan fitur survival inti dengan pola permainan survival bawah laut ala Subnautica. Sistem dan istilah spesifik milik The Abyssal tetap dipertahankan.

## Diganti atau dihapus

- Inventory 27 sel diganti dengan backpack 6×8 berkapasitas 48 sel dan footprint item berbasis ukuran.
- Pengurangan oksigen acak 2–4/4–8 per interval diganti dengan konsumsi kontinu sekitar 1 O₂ per detik.
- Auto Save lima menit dan toggle Auto Save dihapus. Progres hanya ditulis melalui Save manual dan backup yang diminta pemain.
- Checkpoint kasur dihapus. Save lama yang menyimpan respawn checkpoint khusus dimigrasikan kembali ke lokasi awal Lifepod.
- Equipment chestplate/armor dan helmet terpisah, damage suhu/tekanan pemain, serta Oxygen Station luar habitat dihapus.
- Tombol Supply Cache terpisah dihapus; peti sekarang dibuka melalui tombol Interact kontekstual.
- Sistem login, Cloud Save, Realtime Room, Multiplayer, konfigurasi Supabase, dan deep-link auth tidak disertakan.

## Sistem yang dipertahankan dan diselaraskan

- Quick Slots lima slot. PDA tetap menjadi item backpack, tetapi dibuka melalui tombol PDA khusus.
- Tangki O₂, Swim Fins, dan Rebreather menjadi peralatan utama. Tangki menaikkan kapasitas; Rebreather memberi efisiensi tambahan pada kedalaman.
- Oksigen pulih di permukaan dan hanya di interior habitat yang berdaya. Lifepod selalu aman; Multipurpose Room memerlukan Solar Panel di dekatnya.
- Fabricator memakai empat kategori: Sustenance, Personal, Resources, Electronics.
- Habitat Builder harus dimiliki dan dipilih sebelum Build. Interact tengah layar menangani ore, Creepvine, drop, fauna kecil, peti, habitat, dan Fabricator.
- Seaglide mendapat model alat first-person dan bonus kecepatan renang saat dipilih.
- Save schema dinaikkan ke v10 dengan migrasi data lama. Lima slot dan Backup/Restore JSON tetap tersedia.

## Verifikasi source

`npm test` menjalankan audit DOM, referensi aset lokal, footprint backpack, validasi/migrasi save, mekanik O₂, Fabricator, habitat, UI interaksi, dan konfigurasi Android offline. Build APK dan pengujian perangkat fisik tetap harus diverifikasi lewat GitHub Actions dan perangkat Android.
