# Changelog The Abyssal 1.5.0

Rilis ini meneruskan penyesuaian gameplay survival bawah laut agar alat dan sistem memiliki fungsi yang lebih konsisten dengan pola Subnautica, tanpa menyalin aset atau kode game tersebut.

## Mekanik baru dan diubah

- Direktif pertama kini meminta pemain mengumpulkan Titanium, Creepvine, Copper Ore, dan Quartz; membuat Silicone Rubber dan Battery; lalu memfabrikasi Repair Tool, memilihnya di Quick Slot, dan memperbaiki konsol Lifepod.
- Konsol Lifepod memiliki tampilan rusak sebelum diperbaiki dan berubah aktif setelah aksi Repair Tool berhasil.
- Seaglide sekarang memiliki daya 0–100%, mengonsumsi daya ketika digunakan untuk bergerak, dan kehilangan bonus kecepatan ketika baterai habis.
- Persentase daya tampil di label Quick Slot Seaglide. Tombol Battery menggantikan baterai dari inventori dengan biaya satu Battery dan mengisi daya hingga 100%.
- Save schema dinaikkan ke v11. Pemilik Seaglide pada save v10 atau lebih lama mendapat daya 100% ketika pertama kali dimigrasikan.
- Tombol ganti baterai menampilkan status ketika daya Seaglide belum penuh; bila tidak ada baterai cadangan, aksi memberi pesan yang menjelaskan kebutuhan item.

## Sistem 1.4.0 yang tetap dipertahankan

- Backpack 48 sel dengan footprint berbeda dan lima Quick Slots.
- PDA khusus, Scanner, Survival Knife, Flashlight, Habitat Builder, Repair Tool, Seaglide.
- Oksigen kontinu, O₂ Tank, Swim Fins, Rebreather, dan refill hanya di permukaan atau interior habitat berdaya.
- Empat kategori Fabricator, Lifepod, Multipurpose Room, Solar Panel, Wall Locker, Beacon, save manual dan backup JSON.
- Enam bioma, 30 fauna, resource nodes, supply cache, wreck, cerita, radio, dan cutscene.
- Auto Save, checkpoint kasur, armor/chestplate, helmet terpisah, damage tekanan/suhu, oxygen station luar habitat, dan layanan online tetap dihapus.

## Pemeriksaan

`npm test` dan pemeriksaan sintaks modul berhasil dijalankan pada source. Build APK dan uji perangkat Android belum diverifikasi di lingkungan ini.
