# Changelog The Abyssal 1.5.1

Rilis pemeliharaan untuk memperbaiki jalur CI Android dan kesalahan yang terlewat pada packaging sebelumnya. Sistem gameplay dan save schema v11 tidak diubah.

## Perbaikan

- Menambahkan `scripts/configure-backend.mjs` sebagai kompatibilitas untuk workflow lama yang masih menjalankan perintah tersebut. Karena game ini single-player offline, skrip dengan sengaja tidak membaca secret, tidak menghubungi backend, dan tidak mengubah file konfigurasi.
- Workflow Android sekarang menjalankan skrip kompatibilitas tersebut setelah menemukan root proyek, baik dari source repository maupun ZIP yang diunggah.
- Deteksi root ZIP mensyaratkan keberadaan skrip build, verifikasi, dan kompatibilitas; ZIP yang salah tidak akan dipilih diam-diam.
- Kunci signing debug dipindahkan ke `native/abyssal-debug-signing.bin` agar tidak terbuang oleh aturan ignore `*.keystore` ketika source di-commit. Patcher menyalinnya ke direktori Android saat build.
- Workflow memvalidasi keystore sebelum Gradle, memeriksa integritas ZIP APK, dan memverifikasi application ID `com.abyssal.game` sebelum mengunggah artifact.
- Memperbaiki pesan log patcher yang sebelumnya menyebut OAuth deep link meskipun deep link tersebut sudah dihapus.
- Menyamakan versi pada package, pemeriksaan pembaruan, service worker cache, dan antarmuka menjadi 1.5.1.

## Kompatibilitas

- Save schema tetap v11; file save tidak perlu dimigrasikan ulang.
- Application ID tetap `com.abyssal.game`.
- Signing key debug dipertahankan untuk jalur update debug pada repository yang menggunakan file key ini.

## Batas verifikasi

`npm test` dan pemeriksaan sintaks dapat dijalankan secara lokal. Build APK penuh tetap harus dikonfirmasi oleh GitHub Actions karena instalasi dependensi npm di lingkungan pembuatan ZIP mengalami timeout.
