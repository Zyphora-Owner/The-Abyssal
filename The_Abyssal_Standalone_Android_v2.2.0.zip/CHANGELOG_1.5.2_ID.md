# Changelog The Abyssal 1.5.2

Rilis perbaikan startup dan build untuk menyelesaikan kegagalan rendering yang terlihat pada layar pembuka.

## Perbaikan utama

- **Memperbaiki `ReferenceError: WORLD_SEED is not defined`.** `hash2()` sebelumnya membaca `WORLD_SEED` yang tidak pernah dideklarasikan. Saat `createWorld()` membangun chunk pertama, pemanggilan `heightAt()` dan `hash2()` menghentikan proses boot sebelum menu utama muncul.
- Memindahkan seed, hash koordinat, dan value-noise ke `world-generation.mjs`, lalu mengimpor `hash2` dan `valueNoise` secara eksplisit dari `game.js`.
- Seed dunia sekarang deterministik. Terrain, node mineral, pulau, serta posisi procedural tetap konsisten ketika game dimuat ulang dan save lama tetap menggunakan koordinat dunianya.
- Menambahkan regression test untuk rentang hash, noise, determinisme, serta resolusi modul generator.
- Menambahkan pemeriksaan sintaks otomatis untuk seluruh skrip runtime/build ke `npm test`.
- Layar boot menampilkan tahap pemuatan dengan pesan yang lebih jelas. Ketika startup tetap gagal, aplikasi menampilkan sebab error dan tombol **COBA LAGI**.
- Pesan kegagalan WebGL dibuat lebih informatif untuk perangkat/WebView yang tidak menyediakan konteks grafis.

## Build Android

- Workflow sekarang memilih `npm run android:sync` bila folder Android telah tersedia dan `npm run android:add` bila belum ada. Ini mencegah perintah `cap add` gagal pada repository yang sudah memiliki proyek Android.
- Upload artifact memakai `actions/upload-artifact@v7`.
- Versi aplikasi, update checker, service-worker cache, label UI, dan nama artifact diselaraskan ke 1.5.2.
- Contoh update manifest tidak lagi mengiklankan versi lama 1.3.0.

## Kompatibilitas

- Save schema tetap **v11**; tidak ada reset atau migrasi save untuk pembaruan ini.
- Application ID tetap `com.abyssal.game`.
- Signing key debug dan struktur gameplay 1.5.x dipertahankan.
- Inventory 48 sel, 5 Quick Slots, PDA, Fabricator, Habitat Builder, Lifepod, Repair Tool, Seaglide, fauna, bioma, misi, dan save manual tidak dihapus.

## Batas verifikasi

`npm test`, pemeriksaan sintaks, regression test generator, dan validasi signing key berhasil. Instalasi dependensi npm tidak dapat diselesaikan di lingkungan pengerjaan karena DNS ke npm registry tidak tersedia. Karena itu Vite/Capacitor/Gradle belum dijalankan dan APK 1.5.2 belum diklaim berhasil dikompilasi atau diuji di perangkat Android.
