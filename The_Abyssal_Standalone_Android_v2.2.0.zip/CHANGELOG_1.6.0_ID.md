# Changelog — The Abyssal 1.6.0

## Online account dan co-op
- Menambahkan autentikasi email/password melalui Supabase Auth.
- Menambahkan UI Register, Login, status sesi, dan Logout.
- Menambahkan ruang privat 2–4 pemain dengan kode undangan enam karakter.
- Menambahkan Presence, daftar penyelam aktif, sinkronisasi posisi/arah via Broadcast sekitar 5 Hz, dan radio chat teks.
- Menambahkan reconnect handling, heartbeat ke database, penanganan status channel, serta pengecekan hasil `track()` dan `send()`.
- Memperbaiki normalisasi kode undangan pada SQL agar kode huruf kecil tidak terhapus sebelum konversi uppercase.
- Menambahkan migrasi SQL untuk tabel rooms/members, RPC room lifecycle, RLS tabel, dan izin Broadcast/Presence berbasis anggota.
- Memakai `realtime.topic()` pada kebijakan kanal privat dan fail-closed untuk format topic yang tidak valid.
- Menambahkan validasi pesan, nama tampilan, koordinat pemain, dan kode ruang.

## Build dan konfigurasi
- Menambahkan `@supabase/supabase-js`.
- Menyediakan `.env.example` dan panduan `SUPABASE_SETUP_ID.md`.
- GitHub Actions meneruskan Actions Secrets `SUPABASE_URL` dan `SUPABASE_PUBLISHABLE_KEY` ke Vite.
- Validasi konfigurasi dijalankan pada build lokal dan CI; secret/service_role ditolak.
- Jika konfigurasi online kosong, build tetap bisa untuk single-player offline dan kontrol akun dinonaktifkan dengan status yang jelas.
- Nama artifact APK menjadi `the-abyssal-android-apk-1.6.0`.

## Multiplayer scope
- Co-op saat ini menyinkronkan pemain, presence, dan teks chat.
- Inventory, resource, fauna, misi, bangunan, kendaraan, serta save belum disinkronkan. Mode ini belum server-authoritative dan belum merupakan shared-world co-op penuh.

## Kompatibilitas
- Application ID `com.abyssal.game` dipertahankan.
- Save schema tetap v11; tidak ada migrasi save lokal yang diperlukan untuk fitur jaringan ini.
- Single-player offline tetap tersedia bila backend belum dipasang atau jaringan terputus.
