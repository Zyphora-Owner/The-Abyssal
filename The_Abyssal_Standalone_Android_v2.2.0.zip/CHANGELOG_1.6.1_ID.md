# The Abyssal 1.6.1

## Akun dan konfigurasi backend
- Menambahkan konfigurasi Supabase langsung di dalam panel Account / Multiplayer.
- Pemain dapat memasukkan Project URL dan Publishable Key di perangkat, lalu menyimpan dan menghubungkan backend tanpa membangun APK ulang.
- Konfigurasi publik disimpan lokal pada perangkat dan dipulihkan saat aplikasi dibuka kembali.
- Validasi URL HTTPS serta format publishable/legacy anon key dilakukan sebelum membuat client.
- Kunci secret/service_role ditolak. Pengelola dapat mengubah URL/key melalui panel yang sama.
- Tombol Login/Register baru diaktifkan setelah backend terhubung.
- Pesan status menjelaskan langkah setup jika backend belum dikonfigurasi.

## Multiplayer
- Mempertahankan registrasi email/password, login/logout, pemulihan sesi, ruang privat, kode undangan enam karakter, daftar pemain, avatar/posisi realtime, dan chat.
- Koneksi, reconnect, Presence, dan Broadcast tetap menggunakan channel privat dan RLS.
- Ketika backend diganti, channel lama dibersihkan dan daftar peserta lokal dikosongkan.
- Save schema v11 dan sistem survival/gameplay yang ada tidak diubah.

## Build dan pemeriksaan
- Versi paket, cache service worker, label Android, workflow artifact, dan pemeriksaan source dinaikkan ke 1.6.1.
- Pengujian ditambah untuk validasi backend URL/key dan elemen konfigurasi di dalam game.
