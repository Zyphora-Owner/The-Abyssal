# Changelog — The Abyssal 1.6.2

## Perbaikan aplikasi
- Menambahkan penanganan tombol Back Android: panel ditutup sesuai urutan, sesi dijeda saat bermain, dan keluar dari menu utama meminta konfirmasi.
- Menangani perubahan status aplikasi Android. Saat aplikasi masuk background, joystick/keyboard input dibersihkan dan permainan dijeda untuk mencegah karakter terus bergerak.
- Memperbaiki pemulihan room co-op ketika anggota dihapus oleh pembersihan heartbeat setelah perangkat terlalu lama offline.
- Memperbaiki pergantian owner room jika owner lama tidak lagi tercatat sebagai anggota aktif.
- Menambahkan pemeriksaan koneksi Auth Supabase melalui `GET /auth/v1/settings` dengan header `apikey`.
- Menampilkan status koneksi berbeda untuk server terjangkau, jaringan tidak tersedia, pendaftaran dimatikan, dan provider Email tidak aktif.
- Menyimpan dukungan konfigurasi Supabase lokal serta mempertahankan autentikasi email/password.

## Visual dan launcher
- Mengganti ikon aplikasi menjadi ilustrasi leviathan laut dalam dengan mata bercahaya dan gigi tajam.
- Mengganti ikon PWA 192/512 dan maskable.
- Menambahkan ikon Android raster pada seluruh density dan adaptive icon Android 8+.
- Memastikan `AndroidManifest.xml` memakai `@mipmap/ic_launcher` dan `@mipmap/ic_launcher_round`.

## Kompatibilitas
- Application ID tetap `com.abyssal.game`.
- Save schema tetap v11; tidak ada reset slot atau perubahan format save.
- Backpack, Quick Slots, PDA, survival, bioma, fauna, Lifepod, Fabricator, habitat, Seaglide, dan mode offline dipertahankan.
- Migrasi backend tambahan: `202611060002_room_recovery.sql`. Untuk database versi 1.6.1 yang sudah menjalankan migrasi 0001, jalankan hanya migrasi 0002.

## Pengujian
- `node scripts/verify.mjs` lulus.
- Pemeriksaan sintaks Node untuk game, multiplayer, dan patcher lulus.
- Patcher Android diuji pada fixture Android minimal dan dijalankan dua kali untuk memeriksa idempotensi.
- Pemeriksaan dimensi dan signature PNG launcher icons lulus.
- Instalasi dependency npm mengalami timeout; Vite/Gradle APK build dan pengujian perangkat Android belum terverifikasi.
