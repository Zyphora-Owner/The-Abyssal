# Changelog The Abyssal 1.7.0

## Fokus rilis
Perbaikan gerak kamera, batas fisik Lifepod, akses hatch atap, visibilitas alat di tangan, tombol aksi Survival Knife dan senter, serta kontrol HUD Android.

## Perbaikan gameplay
- Mengoreksi transformasi yaw kamera: geser kanan memutar pandangan ke kanan, geser kiri ke kiri.
- Menambahkan unit mekanik murni yang teruji untuk look touch, transformasi world/local Lifepod, tabrakan hull, swept collision, ray bidik hatch, dan konsumsi oksigen.
- Memperbaiki inverse rotasi koordinat lokal Lifepod agar akurat untuk kapsul yang diputar; sebelumnya transformasi untuk collision dan hatch tidak konsisten dengan rotasi Three.js.
- Memperketat tabrakan 3D Lifepod di sisi, atap, dan bagian bawah serta memeriksa lintasan antar-frame agar pemain tidak menembus kapsul saat bergerak cepat.
- Mengubah shell luar Lifepod menjadi material opaque dengan depth-write aktif; permukaan interior hanya ditampilkan ketika pemain berada di dalam.
- Menambahkan hatch atas yang terlihat dan interaksi masuk hanya ketika reticle diarahkan ke bidang hatch dari atas. Keluar mengembalikan pemain di atas hatch.
- Menambahkan struktur detail interior, ring hatch, penutup, liner, tulang penguat, dan pijakan tangga.
- Mengatur model tangan dan alat pada first-person render layer agar tidak tertutup geometri dunia.
- Menambahkan serangan terarah Survival Knife dengan cooldown, jangkauan, damage fauna, animasi, efek, dan hasil gameplay.
- Menambahkan toggle senter yang mengaktifkan/menonaktifkan Spotlight sungguhan.
- Mempertahankan Scanner, Repair Tool, Habitat Builder, Seaglide, PDA, inventory, crafting, fauna, bioma, misi, cutscene, dan co-op yang sudah tersedia.

## Survival dan HUD
- Oksigen sekarang dihitung satu kali setiap 2 detik: 2–4 poin di kedalaman normal; mulai 4 poin dan meningkat seiring kedalaman pada zona dalam.
- Rebreather mengurangi konsumsi oksigen di kedalaman; timer tunggal menghindari pengurangan ganda akibat frame/timer bertumpuk.
- Menambah pengaturan sensitivitas kamera (50–200%) dan ukuran HUD (80–130%) yang disimpan di pengaturan lokal.
- Memperbesar dan menata ulang elemen HUD/action Android tanpa mengganti kontrol menjadi tombol dekoratif.

## Akun dan jaringan
- Publishable Key yang diberikan pemilik proyek diprefill sebagai key publik. Project URL sengaja tetap kosong karena harus diambil dari Supabase Dashboard; aplikasi tidak mengarang endpoint.
- Tidak ada Secret Key atau service_role key yang ditambahkan.
- Login/Register dan room multiplayer tetap memerlukan URL proyek Supabase valid, migrasi SQL, pengaturan Auth dan koneksi jaringan nyata.

## Kompatibilitas
- Package/app version: 1.7.0.
- Android Application ID dipertahankan: `com.abyssal.game`.
- Save schema tetap v11; penambahan camera sensitivity dan HUD scale hanya memperluas settings, bukan mengubah format slot save.
- Cache service worker dan nama artifact GitHub Actions dinaikkan ke 1.7.0.
