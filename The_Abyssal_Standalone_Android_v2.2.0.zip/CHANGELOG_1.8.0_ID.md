# Changelog — The Abyssal 1.8.0

Rilis pemeliharaan gameplay dan co-op yang dibangun di atas source 1.7.0. Tidak mengubah Android Application ID atau save schema.

## Perbaikan collision Lifepod

- Menemukan bug lanjutan yang lolos dari pemeriksaan sebelumnya: setelah collision hull mendeteksi tabrakan, floor clamp masih memakai `nextY` yang belum dikoreksi. Akibatnya, gerak vertikal dapat menembus atap atau bagian bawah Lifepod walaupun tes lintasan menyatakan tabrakan.
- Gerak sekarang memakai swept collision 3-sumbu X/Z/Y terhadap hull Lifepod yang telah ditransformasikan ke koordinat lokal.
- Jika salah satu sumbu tertahan hull, komponen kecepatan pada sumbu itu dihentikan.
- Floor clamp sekarang memakai koordinat Y hasil resolusi collision, tidak mengembalikan nilai gerak yang diblokir.
- Menambah uji regresi untuk gerak vertikal ke atap, ke bawah, ke samping, termasuk Lifepod yang diputar.

## Event dunia bersama untuk co-op

- Menambah log event persisten per room di Supabase untuk resource yang dipungut, supply cache yang dibuka, struktur yang ditempatkan, fauna yang dipindai, biome yang ditemukan, dan misi yang diselesaikan.
- Menambah RPC push/read dengan validasi tipe event dan payload di server, normalisasi payload menjadi hanya field yang diizinkan, batas laju per anggota, idempotency key yang tahan race condition, indeks untuk lookup/poll, dan RLS agar hanya anggota room dapat membaca event.
- Klien memiliki antrean lokal untuk perubahan yang menunggu jaringan, kemudian mencoba mengirim ulang saat room online.
- Menambah replay log event saat game dimuat sehingga perubahan room yang terjadi sebelum sesi game dibuka dapat diterapkan.
- Memperbaiki race condition antrean: event yang ditambahkan ketika RPC sedang berjalan tidak lagi tertimpa oleh penulisan antrean lama.
- Menghindari penguncian ganda poll/push ketika berpindah room sementara request sebelumnya masih berjalan.

## Batas sinkronisasi

Ini belum shared-world penuh. Event saat ini menyelaraskan status node/cache/struktur/penemuan/misi. Reward dan inventory tetap milik pemain yang mengumpulkan; fauna AI dan keadaan hidup, HP/O₂/Food/Water, kendaraan, status daya/kerusakan struktur, dan save masih lokal. Jangan menyebutnya server-authoritative world simulation.

## Kompatibilitas

- Android Application ID tetap `com.abyssal.game`.
- Save schema tetap v11; tidak ada reset save atau migrasi data pemain.
- Kontrol kamera, split touch, hatch, tools, survival, HUD, fauna, bioma, PDA, crafting, Lifepod, dan ikon launcher dari versi sebelumnya dipertahankan.
- Database mendapat migrasi tambahan `supabase/migrations/202611070001_shared_world_events.sql`.

## Pengujian source

- `npm test` menjalankan `scripts/verify.mjs` dan lulus pada source release ini.
- Suite memeriksa sintaks JS/MJS, ID dan referensi DOM, aset lokal, migrasi save v11, fungsi collision murni, arah kamera, sanitasi event, keberadaan RPC/RLS, serta konfigurasi Android statis.
- Build Vite, kompilasi Gradle/APK, integrasi Supabase nyata, WebGL WebView, dan uji dua perangkat belum dapat diklaim lulus; lihat laporan audit.
