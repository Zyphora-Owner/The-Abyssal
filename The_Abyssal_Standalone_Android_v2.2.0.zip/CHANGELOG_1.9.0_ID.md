# Changelog — The Abyssal 1.9.0

## Fokus rilis
Memperdalam loop eksplorasi, membuat daerah laut dalam yang benar-benar dapat dijelajahi, dan memperbaiki konsistensi fauna serta koordinat co-op. Semua perubahan mempertahankan Application ID `com.abyssal.game` dan save schema v11.

## Dunia dan eksplorasi
- Menambahkan palung laut jauh dari area awal dengan lantai laut prosedural hingga sekitar 290 m; terrain lama di sekitar Lifepod dan basis tersimpan tidak dipindahkan.
- Menambahkan biome Twilight Trench (sekitar 62–180 m) dan Hadal Reach (lebih dalam), dengan kabut, warna terrain, sumber daya, dan atmosfer cahaya yang berbeda.
- Mengubah pemilihan biome per-chunk agar memakai tinggi dasar laut sebenarnya, bukan kedalaman tetap 20 m.
- Menambahkan petunjuk jarak anomali palung saat pemain mendekati area baru.
- Menaikkan batas selam runtime dan normalisasi save menjadi 300 m tanpa reset atau kenaikan schema.

## Survival dan visual
- Tetap memakai tick oksigen tunggal setiap 2 detik: normal 2–4 poin; di bawah 20 m minimal 4, bertambah bertahap seiring kedalaman.
- Kurva kebutuhan oksigen dalam dibuat lebih terukur agar palung dapat dieksplorasi dengan tangki/rebreather tanpa menghilangkan ancaman kehabisan oksigen.
- Pencahayaan matahari dan god-rays kini melemah bertahap seiring kedalaman; fog meningkat sesuai biome dan kedalaman.

## Fauna
- Memperluas rentang kedalaman spesies laut dalam dan menambahkan Abyssal Stalker serta Trench Leviathan dengan model procedural yang sudah digunakan oleh fauna runtime.
- Membatasi fauna tetap berada di antara dasar laut dan batas kedalaman spesiesnya.
- Memperbaiki penangkapan ikan agar memakai ID individu yang tepat, bukan hanya ID spesies; ini menghindari ikan lain dari spesies sama yang tertangkap ketika reticle mengarah ke individu berbeda.

## Co-op dan kompatibilitas
- Sanitizer posisi pemain serta event bangunan mengizinkan koordinat vertikal palung.
- Menambahkan migrasi SQL `202611070002_deep_world_coordinates.sql` untuk memperbarui batas koordinat RPC world-event.
- Save schema v11 dan Application ID `com.abyssal.game` dipertahankan.

## Catatan
- Geometri/tekstur fauna tetap dibuat secara procedural; rilis ini tidak mengklaim menambah paket model atau audio rekaman eksternal.
- Vite build, Gradle APK, Supabase nyata, dan pengujian perangkat Android memerlukan dependency/runtime/server/perangkat yang tidak tersedia pada pemeriksaan lokal. Laporan audit memisahkan pengujian source dari verifikasi tersebut.
