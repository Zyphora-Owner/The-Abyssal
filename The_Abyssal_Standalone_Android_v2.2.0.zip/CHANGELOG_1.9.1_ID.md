# Changelog — The Abyssal 1.9.1

Fokus rilis ini adalah keterjangkauan dan konsistensi gameplay ekspedisi laut dalam, bukan menambah tombol dekoratif.

## Perbaikan
- Kapasitas tangki menggunakan satu fungsi bersama antara gameplay dan save normalizer. Tangki awal tetap 45 O₂; empat upgrade memberi kapasitas maksimum 345 O₂.
- Peningkatan tank memberi tambahan 75 O₂ dan batas upgrade/indikator Fabricator sama-sama berhenti pada tier maksimum.
- Save schema tetap v11; `tankLevel` 0–3 dari save lama dipertahankan, dan tier baru 4 diterima tanpa reset. Nilai O₂ lama tidak dipotong oleh batas kapasitas lama ketika data dinormalisasi.
- Menambahkan pengujian konservatif perjalanan turun-naik sampai 296 m dengan Rebreather dan tangki maksimum, menggunakan konsumsi oksigen tertinggi pada tiap tick simulasi.
- Fauna kini dijaga dalam rentang kedalaman spesies saat berenang, sekaligus tetap berada di atas dasar laut dan di bawah permukaan. Jika rentang habitat bertabrakan dengan terrain dangkal, sistem memprioritaskan volume air yang valid.
- Memperbarui versi aplikasi, cache service worker, nama artifact GitHub Actions, panduan build, dan dokumentasi.

## Kompatibilitas
- Android Application ID tetap `com.abyssal.game`.
- Save schema tetap v11; slot dan struktur save tidak direset.
- Fitur sebelumnya, migrasi Supabase, ikon launcher, Lifepod, inventory, PDA, Fabricator, tools, fauna, dan bioma tetap disertakan.

## Verifikasi
- `npm test` menguji syntax, ID dan referensi DOM, aset lokal, migrasi save, kapasitas tangki, simulasi budget O₂ ekspedisi, biome generator, collision, kamera, dan pemeriksaan source integration.
- Build Vite/APK dan pengujian perangkat fisik harus dilaporkan terpisah; tidak diklaim lulus tanpa dijalankan.
