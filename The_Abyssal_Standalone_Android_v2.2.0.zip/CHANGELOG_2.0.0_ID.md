# Changelog — The Abyssal 2.0.0

Rilis ini memusatkan pekerjaan pada peningkatan visual dunia, permukaan air, model kura-kura, Lifepod, dan cutscene pembuka tanpa mengganti fondasi gameplay atau format save.

## Perubahan yang diterapkan
- Lifepod diperbesar seragam 1,24×. Seluruh transformasi koordinat, collider, sweep collision, hatch aim, titik interior, dan posisi keluar/masuk mengikuti faktor skala yang sama.
- Menambah detail eksterior Lifepod: pressure ribs, panel servis, status strip, fastener, hatch, dan detail interior seperti liner, ladder, braces, Fabricator, serta oxygen outlet.
- Menambah gelombang permukaan air multi-frekuensi deterministik yang bergerak menurut world clock dan dibatasi amplitudonya.
- Menambahkan sky dome permukaan, sprite matahari/bulan, daylight cycle ringan, transisi fog/pencahayaan, water tint, efek waterline, dan SFX splash/dive.
- Oksigen di permukaan dipulihkan berdasarkan posisi kepala/eye point yang benar-benar melewati waterline, bukan hanya posisi tengah tubuh. Pengisian di habitat tetap hanya berlaku saat berada di dalam habitat yang valid.
- Meningkatkan resolusi mesh terrain berdasarkan preset grafis (Low 18, Balanced 28, High 36 segmen per sisi) dan membuat geometri batu lebih organik dengan deformasi vertex deterministik.
- Memperkuat pewarnaan sisi curam untuk membantu tebing dan ridge terbaca secara visual.
- Kura-kura laut kini mempunyai texture tempurung scute heksagonal, bump texture, rim, plastron, kepala, paruh, mata, flipper, dan detail anatomi.
- Kapsul pada cutscene pembuka memperoleh geometri lebih halus, ring struktur, porthole rim, hatch, engine ring, dan thruster.
- Tampilan lima slot tetap dipertahankan sebagai Quick Slots; label aksesibilitas tidak lagi menyebut “Hotbar 1/2”. Tidak ada slot yang dihapus.
- Menghindari alokasi objek `THREE.Color` baru setiap frame pada transisi waterline dengan memakai tint bersama.

## Kompatibilitas
- Android Application ID tetap `com.abyssal.game`.
- Save schema tetap v11; tidak ada reset save atau migrasi baru.
- Five Quick Slots, inventory 48-cell, PDA, equipment, tools, survival, Fabricator, crafting, habitat, fauna, biome, misi, save/load, akun, room, chat, dan event multiplayer lama tetap ada.
- Supabase migrations yang telah tersedia tidak diubah oleh rilis ini.

## Batas ruang lingkup
Rilis ini tidak menambahkan kendaraan baru, siklus cuaca penuh, atau shared-world authoritative untuk seluruh simulasi. Model/tekstur procedural yang sudah ada ditingkatkan; ini bukan paket aset sinematik AAA dan belum boleh dianggap setara kualitas produksi penuh.
