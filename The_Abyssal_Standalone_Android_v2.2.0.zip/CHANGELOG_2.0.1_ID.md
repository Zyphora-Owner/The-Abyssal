# Changelog — The Abyssal 2.0.1

Rilis pemeliharaan fungsional di atas 2.0.0. Fokus pada temuan bug yang dapat diperbaiki langsung pada source tanpa mengubah save schema atau database.

## Perbaikan
- Memperbaiki efek roll kamera agar tidak terakumulasi tiap frame. Orientasi dasar kini dihaluskan dengan quaternion tersendiri dan roll kecil dikomposisikan setiap frame.
- Memperbaiki kontrol naik/turun Split Touch dengan Set pointer terpisah untuk tombol ascend dan descend. Pembatalan satu pointer tidak memutus pointer lain; blur/background membersihkan seluruh pointer.
- Menambahkan first-person viewmodel prosedural untuk resource dan supply yang dapat dipilih pada lima Quick Slots (mineral, sampel, fish meat, medkit, ration, water, baterai, komponen elektronik, dan material olahan). Model hanya tampil jika item benar-benar dimiliki.
- Menampilkan tombol Attack hanya jika Survival Knife aktif dan target fauna berada pada arah bidikan serta jarak serang. Fungsi prediksi target dan serangan memakai aturan aim/range yang sama.
- Mengganti umpan balik UI lama 'Hotbar' menjadi 'Slot Cepat' tanpa menghapus atau mengubah lima slot.
- Membersihkan populasi fauna lama saat New Game atau Load Slot, lalu mengisi populasi kembali berdasarkan biome dan posisi pemain pada slot yang dipilih. Data penemuan fauna tetap disimpan.
- Memeriksa ulang posisi pemain setelah soft collision fauna agar dorongan fauna tidak dapat menempatkan pemain di dalam struktur atau terrain.

## Kompatibilitas
- Save schema tetap v11; tidak ada migrasi atau reset save.
- Application ID tetap `com.abyssal.game`.
- Signing resource, Supabase migrations, dan fitur lama tetap dipertahankan.
- Tidak ada SQL Supabase baru pada rilis ini.

## Batasan
Model first-person untuk item non-tool dibuat secara prosedural dari geometri/material Three.js lokal; aset eksternal GLB khusus untuk setiap resource belum ditambahkan. Build APK dan pengujian GPU fisik tetap harus diverifikasi melalui GitHub Actions dan perangkat Android.
