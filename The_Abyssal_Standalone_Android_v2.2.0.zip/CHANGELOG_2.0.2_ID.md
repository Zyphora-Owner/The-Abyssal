# Changelog — The Abyssal 2.0.2

## Fokus: HD ocean, vegetasi bergerak, dan animasi berenang

- Mengganti permukaan air sederhana dengan material fisik berbasis tekstur warna HD seamless dan normal map resolusi sesuai kualitas grafis: 512 (Low), 1024 (Balanced), 2048 (High).
- Menambahkan detail multi-skala pada pola permukaan air, normal ripples, anisotropic filtering, mipmap, clearcoat, dan gelombang dunia yang lebih terbaca.
- Meningkatkan subdivisi mesh air per kualitas grafis dan mengatur cadence pembaruan vertex agar beban CPU terkendali.
- Menambahkan pola caustics transparan yang bergerak sebagai emissive projection halus pada terrain dangkal, reef, dan kelp forest.
- Mengganti batang kelp silindris menjadi satu tuft berisi 11 helai rumput laut berbentuk pita, bertaper, berwarna gradasi, dan memiliki vertex sway di GPU.
- Menambahkan fase goyangan berbeda per instance berdasarkan posisi sehingga hamparan rumput tidak bergerak serempak.
- Menambah kepadatan rumput laut berdasarkan kualitas grafis tanpa mengubah biome/resource yang sudah ada.
- Memperhalus animasi first-person saat berenang: kayuhan lengan kiri/kanan bergantian, gerak pergelangan, bob badan, dan peredaman animasi saat Seaglide digunakan atau alat sedang dipegang.
- Menambahkan bubble pool ringan yang memunculkan gelembung dari penyelam ketika berenang di bawah air; partikel dibatasi dan digunakan ulang agar tidak terus membuat objek baru.
- Memperbarui versi aplikasi, cache service worker, label Android, dan nama artifact menjadi 2.0.2.

## Kompatibilitas

- Android Application ID tetap `com.abyssal.game`.
- Save schema tetap v11; tidak ada reset atau migrasi save.
- Inventory, lima Quick Slots, PDA, Fabricator, Lifepod, habitat, fauna, biome, misi, Seaglide, akun, Supabase, dan multiplayer dipertahankan.
- Tidak ada asset pihak ketiga atau aset proprietary Subnautica yang disalin. Tekstur permukaan air dibuat secara prosedural secara lokal.

## Audit lanjutan sebelum packaging
- Memperbaiki sampling penempatan rumput laut untuk preset Balanced/High. Kepadatan 25/34 tuft sebelumnya masih mengulang indeks sampling setelah 20 sehingga sebagian posisi dapat berulang; kini jumlah sampel deterministik mengikuti jumlah percobaan dan offset lookup.
- Mengembalikan indeks sampling batu ke rentang 20 yang lama agar penambahan variasi kelp tidak mengubah pola batu yang sudah ada.
- Menambahkan pendekatan koreksi normal vertex agar pencahayaan rumput laut mengikuti arah tekukan, bukan tetap tampak seperti helai kaku.
- Menambah regression check yang secara khusus memastikan loop kelp tidak lagi memakai modulo 20.
