# Changelog — The Abyssal 2.0.4

## Fokus rilis: graphics tiers yang benar-benar diterapkan

- Preset **Low** menargetkan tekstur air dan terrain utama 1024×1024 (di atas 512×512).
- Preset **Medium** menargetkan tekstur air dan terrain utama 2048×2048 (di atas 1024×1024).
- Preset **High** menargetkan tekstur air dan terrain utama 4096×4096 (di atas 2048×2048) pada perangkat yang memenuhi batas GPU dan memori.
- Pada High, texture pendukung seperti detail material, bump, caustics, dan tekstur fauna tetap berada di 2048×2048 untuk mengendalikan penggunaan memori GPU. Label Settings menunjukkan resolusi air, terrain utama, detail pendukung, batas GPU, dan alasan fallback.
- High 4K hanya diaktifkan jika GPU melaporkan batas tekstur minimal 4096 dan `navigator.deviceMemory` melaporkan kelas memori minimal 8 GB. Jika informasi tidak tersedia atau perangkat terbatas, game memakai 2K atau resolusi maksimum yang didukung dan menampilkan alasannya.
- Menambah fallback bertingkat saat pembuatan CanvasTexture gagal: High dapat turun ke Medium, Medium/High dapat turun ke Low. Tekstur sementara dibuang saat alokasi parsial gagal; tekstur aktif sebelumnya dipertahankan jika semua tingkat gagal.
- Mengubah preset saat runtime membangun ulang tekstur, melakukan rebind material pada objek scene, membuang tekstur lama setelah rebind, lalu memperbarui anisotropic filtering, mipmap, bayangan, pixel ratio, water mesh, fog, fauna, dan chunk.
- Menambahkan detail mikro pada tekstur fauna dan tempurung kura-kura sesuai resolusi preset.
- Memperbaiki pemilihan tier performa efektif ketika perangkat perlu fallback, sehingga densitas fauna, kompleksitas chunk, tessellation air, dan bayangan ikut turun; preset yang dipilih pengguna tetap tersimpan.
- Kecepatan berenang tidak lagi berubah karena pengaturan kualitas grafik.

## Kompatibilitas

- Android Application ID tetap `com.abyssal.game`.
- Save schema tetap v11. Tidak ada reset atau migrasi save.
- Nilai internal `balanced` tetap dipakai sebagai preset Medium agar konfigurasi lama terbaca.
- Inventory, Quick Slots, PDA, Lifepod, Fabricator, crafting, tools, fauna, biome, misi, akun, multiplayer, signing key, dan sistem update dipertahankan.
- Versi package, app, service worker, update example, serta nama artifact GitHub Actions diselaraskan ke 2.0.4.
