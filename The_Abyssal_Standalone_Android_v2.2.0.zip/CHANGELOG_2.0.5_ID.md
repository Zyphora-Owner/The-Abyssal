# Changelog — The Abyssal 2.0.5

## Visual, cutscene, interaction, Lifepod, and depth progression

- Lifepod dipindahkan agar mengapung di garis air: bagian atas dan hatch berada di atas permukaan, sementara hull bawah tetap terendam. Ukuran 1.32× dipertahankan.
- Collision hull kini mencocokkan radius badan luar (1.56 m ditambah radius pemain), sweep collision meneruskan radius pemain yang sebenarnya, dan titik keluar diselaraskan dengan roof hatch. Interior/exterior visibility diperbarui saat kapsul dibuat, dimasuki, dan ditinggalkan.
- Menambahkan service panels, rel luar, flood lamps, beacon mast, dan light beacon untuk membuat siluet Lifepod terbaca dari jauh.
- Kamera awal diarahkan ke roof hatch sehingga jalur masuk Lifepod lebih mudah ditemukan.
- Rating tekanan/kedalaman tangki: Mk I 50 m, Mk II 100 m, Mk III 200 m, Mk IV 300 m, Mk V 500 m. Kapasitas O₂ lama dipertahankan dan tetap terpisah dari rating tekanan. Melampaui rating menampilkan warning dan memberikan pressure stress bertingkat setiap dua detik; berada di habitat aman tidak terkena stress.
- Palung Hadal diperluas sampai sekitar 500 m, dan rentang habitat fauna trench/abyssal diperbarui agar kedalaman akhir memiliki fauna yang sesuai.
- Model leviathan cutscene dibuat lebih mudah terlihat: siluet tubuh lebih terang, rahang dan gigi, mata serta marking bioluminesen, sirip dan ekor animatif. Kamera cinematic mengikuti creature untuk menjaga framing.
- Subtitle cutscene dipindah ke tengah atas dengan ukuran ringkas, panel gelap kontras, dan ukuran responsif pada layar ponsel.
- Habitat Builder kini menampilkan hologram 3D untuk modul yang akan ditempatkan. Warna hijau/merah menunjukkan validitas lokasi; BUILD mengonfirmasi hanya jika material, kemiringan, jarak, dan collision valid. Esc membatalkan preview.
- Mining Ore dan pemotongan Creepvine menggunakan animasi ayunan, getaran/pengecilan deposit, fase retak, debris, dan suara hit/break sebelum resource dikeluarkan.
- Flashlight menggunakan SpotLight dunia yang lebih kuat, near-field point light, lensa emissive, dan cone beam visual. Tombol ON/OFF mengendalikan seluruh komponen cahaya.
- Tekstur prosedural mendapat detail 2K sumber pada tier 4K dan detail mikro lebih padat: retakan batu, pori karang, grain pasir, scratch logam, dan serat vegetasi. Model Ore mendapat facet dan aksen kristal.
- Video menu lokal 1280×720 H.264 berdurasi 8 detik dimainkan loop tanpa audio, dengan poster fallback; video dijeda saat layar selain menu dibuka.

## Kompatibilitas

- Save schema tetap v11; tidak ada reset atau migrasi save.
- Android Application ID tetap `com.abyssal.game`.
- Kapasitas inventory, lima Quick Slots, PDA, Fabricator, crafting, fauna, biome, tools, akun, Supabase, dan multiplayer tetap dipertahankan.
- Rating kedalaman diturunkan dari equipment tank level yang sudah tersimpan; tidak menambah field save baru.

## Verifikasi

- `npm test` — lulus, termasuk tes rating 50/100/200/300/500 m, damage pressure, palung 500 m, video menu lokal, hologram Builder, mining animation, flashlight, dan framing cutscene.
- `node --check` pada `game.js`, `fauna.js`, `multiplayer.js`, modul `.mjs`, dan skrip — lulus.
- Video menu diverifikasi sebagai H.264 1280×720, 24 fps, 8 detik.
- Build Vite/APK belum dapat diverifikasi: instalasi dependency npm mengalami timeout. Rendering GPU, suara, collision dan interaksi tetap perlu uji langsung di Android.
