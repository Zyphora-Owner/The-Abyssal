# The Abyssal 2.0.6 — Changelog

## Fokus rilis
Perbaikan akses Lifepod, collision, lompatan darat, cutscene ekspedisi Bumi–8142C, serta pengayaan gua dan ekosistem bawah laut. Fitur lama dipertahankan; save schema tidak diubah.

## Perbaikan utama

- **Akses Lifepod:** jarak deteksi interaksi hatch diperluas sampai 16 m; prompt memberi petunjuk ketika pemain dekat tetapi belum membidik hatch. Tombol Interact tetap hanya aktif ketika ray aim mengenai bukaan hatch di atap.
- **Hatch dan collision:** hatch tertutup memblokir jalur; jalur vertikal baru terbuka setelah interaksi membuka hatch. Ditambahkan shaft dan aperture visual agar bukaan yang terlihat selaras dengan koridor collision. Pengujian swept collision mencakup kondisi tertutup/terbuka dan Lifepod yang diputar maupun diskalakan.
- **Keluar/masuk kapsul:** posisi masuk ditempatkan di dalam envelope interior; posisi keluar diarahkan ke atas hatch. Interior dan eksterior berganti sesuai status pemain.
- **Lompatan:** tombol Lompat hanya muncul ketika pemain berada di daratan kering dan grounded. Tombol/Space di air tetap berfungsi sebagai gerakan naik, bukan lompatan. Clamp vertikal darat mempertahankan lintasan lompatan.
- **Cutscene:** kapsul mengikuti kapal transfer dari orbit Bumi, dilepas tanpa perpindahan posisi mendadak, memasuki atmosfer 8142C, lalu turun ke lokasi Lifepod yang sama dengan gameplay. Ditambahkan efek percikan saat mendarat dan kamera lebih dekat untuk menampilkan Leviathan.
- **Ekosistem:** gua/lorong visual, ventilasi termal/lahar, tanaman penghasil oksigen yang dapat mengisi ulang O₂ dengan biaya muatan dan waktu isi ulang, serta ikan penjaga sarang sulfur dengan node sulfur yang dapat dipanen.
- **Quick Slots:** label/toast lama “Slot Cepat 1/2/3...” tidak ditampilkan saat item dipegang; lima Quick Slots tetap tersedia.
- **Audio:** efek suara splash, hatch, lompatan, tumbukan dan interaksi yang relevan tetap menggunakan Web Audio API lokal.

## Kompatibilitas
- Android Application ID: `com.abyssal.game` (dipertahankan).
- Save schema: `v11` (dipertahankan; tidak ada migrasi/reset pada rilis ini).
- Inventori, PDA, lima Quick Slots, Fabricator, crafting, tools, fauna, biome, misi, Lifepod, habitat, Seaglide, akun, dan multiplayer tetap ada.
- Tidak ada migrasi SQL baru pada rilis ini.
