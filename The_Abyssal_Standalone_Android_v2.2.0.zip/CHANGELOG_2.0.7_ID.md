# The Abyssal 2.0.7 — Changelog

## Fokus rilis
Pembaruan first-person equipment: item yang dipilih sekarang menggunakan model 3D lokal yang lebih detail, posisi pegangan diselaraskan dengan telapak tangan, dan tangan memiliki overlay grip yang mengikuti transform model.

## Perubahan
- Mengganti model alat first-person yang terlalu sederhana dengan geometri 3D lokal yang lebih rinci untuk Scanner, Survival Knife, Flashlight, Habitat Builder, Repair Tool, dan Seaglide.
- Menambahkan pegangan, grip ribs, guard, lensa/emitter, layar, panel, ring, tombol, nozzle, dan detail material sesuai jenis alat.
- Menyempurnakan model 3D resource/supply dalam Quick Slots: mineral kristal, logam, sulfur, coral, kelp, glowcap, fish meat, medkit, ration, bottle, battery, power cell, wiring kit, chip, glass, dan bahan cair.
- Memperbaiki tangan first-person: lengan, cuff, telapak, jari bersegmen, thumb, dan glove grip overlay.
- Grip overlay mengikuti posisi, rotasi, dan skala item terpilih; jari grip dirender di atas model agar item terlihat benar-benar digenggam, bukan melayang di depan tangan.
- Membuat render layer first-person terpisah: lengan (1000), model item (1001), dan jari grip (1002). Material viewmodel tetap dirender di atas dunia agar tidak hilang tertutup terrain.
- Seaglide kini memakai pegangan kiri dan kanan; posisi lengan dan overlay grip kedua tangan diselaraskan ke handle.
- Animasi equip dan penggunaan tetap terhubung dengan aksi gameplay. Ring Scanner, emitter Habitat Builder, coil Repair Tool, propeller Seaglide, dan item resource memiliki gerakan tambahan yang ringan.
- Model item hanya tampil ketika item tersebut benar-benar dipilih dan dimiliki/tersedia pada Quick Slot. Memilih slot kosong tidak menampilkan model alat.
- Lima Quick Slots, item ID, inventory, resep crafting, PDA, fauna, biome, habitat, misi, save, akun, dan multiplayer dipertahankan.

## Kompatibilitas
- Versi aplikasi: `2.0.7`.
- Android Application ID: `com.abyssal.game` (tidak berubah).
- Save schema: `v11` (tidak berubah; tidak ada migrasi atau reset save).
- Tidak ada migrasi SQL baru.
- Signing key debug, workflow Android, Supabase, dan sistem update dipertahankan.

## Batasan aset
Model first-person pada rilis ini dibuat dari geometri Three.js prosedural yang dibundel di source. Rilis ini tidak menambahkan file model GLB/GLTF eksternal atau animasi skeletal berbasis rig impor. Model dan gerakan yang disebutkan berasal dari geometri serta animasi runtime lokal.
