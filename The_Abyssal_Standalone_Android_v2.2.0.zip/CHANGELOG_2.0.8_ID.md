# Changelog — The Abyssal 2.0.8

## Fokus: armada kendaraan bawah laut

- Menambahkan **Pelagic Skimmer**, kendaraan selam satu penyelam untuk eksplorasi cepat; **Pelagic Carrier**, kapal selam ekspedisi besar dengan fungsi basis bergerak dan ruang kargo; serta **Nautilus Exosuit**, rangka mekanis untuk eksplorasi dekat dasar dan penambangan.
- Ketiga kendaraan mempunyai model 3D prosedural original dengan material logam/kaca, lampu, thruster/propeller, detail panel, dan animasi di dunia.
- Menambahkan **Vehicle Fabrication Bay** yang dapat dibuat menggunakan Habitat Builder. Kendaraan hanya dapat dibuat, diluncurkan, di-upgrade, diperbaiki, diisi ulang, dan dikelola melalui alur Vehicle Bay.
- Upgrade per kendaraan: modul kedalaman bertingkat, penguatan hull/chassis, cargo/storage, sonar, efisiensi, thermal recharge Carrier, serta Mining Drill Arm dan Grappling Arm Exosuit.
- Menambahkan batas kedalaman, health/hull, power, cargo, konsumsi daya, kerusakan tekanan, repair, recharge, transfer material, dan pengecekan lokasi peluncuran.
- Kendaraan dapat dikemudikan menggunakan kontrol gerak, kamera, dan tombol naik/turun. Kamera mengikuti kendaraan; HUD menampilkan nama, kondisi hull, dan daya.
- Skimmer dan Carrier dapat menggunakan sonar setelah modul terpasang. Exosuit dapat menambang deposit dengan Drill Arm atau menarik rangka dengan Grappling Arm.
- **Carrier Command Deck** memungkinkan transfer cargo dari dalam Carrier bila Cargo Compartment terpasang. Fabrikasi, upgrade, repair, dan recharge tetap memerlukan Vehicle Bay permanen.
- Posisi, arah, ownership, upgrade, daya, health, dan cargo kendaraan disimpan pada save lokal. Active vehicle dipulihkan hanya jika kendaraan dimiliki dan deployed.
- Menambahkan swept collision per-sumbu, footprint terrain sampling, pemeriksaan tabrakan dengan struktur, Lifepod, wreck, supply cache, dan kendaraan lain. Hatch Lifepod tetap menjadi penghalang kendaraan meskipun terbuka untuk penyelam.
- Memperbaiki temporal-dead-zone pada interaction prompt, posisi exit kendaraan yang tidak aman, validasi launch, health save yang melebihi kapasitas hull, batas recharge Carrier 250 power, dan cargo panel Carrier.
- Save schema tetap **v11**. Fleet ditambahkan secara kompatibel: save lama memperoleh armada kosong tanpa menghapus data lama.

## Desain dan batas fitur

Model dan nama kendaraan adalah desain original The Abyssal yang terinspirasi arketipe umum sub kecil, kapal selam basis bergerak, dan exosuit laut dalam. Aset proprietary Subnautica tidak disalin. Armada 2.0.8 tersimpan lokal dan belum disinkronkan sebagai shared-world entity.

## Verifikasi

- Pemeriksaan sintaks modul JavaScript lulus.
- `npm test` lulus setelah fixture pengujian hull diperbaiki agar secara eksplisit menandai Reinforced Hull terpasang.
- `npm run build` belum berhasil karena dependency Vite tidak tersedia; upaya instalasi dependency timeout. APK belum dikompilasi atau diuji langsung pada Android. Lihat laporan audit untuk rincian.
