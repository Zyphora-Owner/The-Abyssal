# Changelog — The Abyssal 2.0.9

## Fokus: Lifepod egress, panel Android, dan cutscene

- Memperbaiki bug keluar Lifepod yang dapat membuat penyelam berhenti/stuck di area hatch. Sebelumnya posisi keluar tetap berada di dalam channel collision atap, sementara controller air membatasi ketinggian pemain pada waterline; setelah hatch menutup, hull memblokir gerakan berikutnya.
- Menambahkan helper koordinat `lifepodLocalToWorld()` dan `getLifepodExitWorldPosition()` agar posisi keluar dihitung berdasarkan yaw, skala, posisi kapsul, permukaan air, dan radius pemain.
- Saat keluar, runtime mencoba sisi kiri/kanan kapsul, lalu posisi clearance lebih lebar jika perlu. Kandidat harus berada di luar interior, di luar hatch channel, di luar hull, tidak menabrak struktur, dan memiliki clearance dari terrain.
- Jika tidak ada jalur aman, pemain tetap di dalam kapsul dan menerima pesan yang jelas; posisi tidak dipindahkan ke lokasi yang berpotensi menjebak.
- Pemeriksaan akhir setelah perpindahan keluar kini juga melakukan rollback posisi, kecepatan, yaw, dan pitch jika volume interior masih mendeteksi pemain di dalam kapsul.
- Pemeriksaan entry yang gagal mengembalikan checkpoint sebelumnya, sehingga percobaan masuk yang tidak valid tidak mengubah titik respawn.
- Memvalidasi koordinat entry sebelum memindahkan pemain. Jika pemeriksaan interior setelah snap tidak lulus, posisi, arah, dan pitch dipulihkan ke keadaan sebelumnya.
- Memperbaiki scroll Inventory dan Fabricator pada Android. `touch-action:none` pada root sebelumnya menonaktifkan gesture scroll panel. Root sekarang mengizinkan pan vertikal, sementara canvas/touch controls tetap memakai kontrol sentuh khusus.
- Menjaga Backpack 8×6, panel dengan max-height sesuai viewport dan safe-area, kategori Fabricator yang sticky, serta daftar resep yang dapat di-scroll.
- Menambahkan umpan balik audio untuk membuka/menutup Inventory, membuka Fabricator, berpindah kategori, dan masuk/keluar habitat.
- Mempercepat reveal Leviathan pada cutscene, memperkuat lampu bioluminesen, serta memperpanjang framing kamera pada monster agar tidak hanya terlihat sekilas pada akhir cutscene.
- Memperbarui versi aplikasi, cache Service Worker, label build, update check, dan artifact GitHub Actions menjadi 2.0.9.

## Kompatibilitas

- Application ID tetap `com.abyssal.game`.
- Save schema tetap `v11`; tidak ada migrasi atau reset save baru.
- Inventory, lima Quick Slots, PDA, Fabricator, seluruh tools, kendaraan 2.0.8, fauna, biome, misi, Supabase, dan fitur multiplayer sebelumnya dipertahankan.
- Tidak ada migrasi SQL baru.

## Batas verifikasi

Pengujian helper koordinat/collision, source checks, DOM/assets, dan test suite otomatis dijalankan. Build Vite/produksi, kompilasi APK, rendering GPU, serta sesi uji perangkat Android fisik tetap harus diverifikasi melalui workflow dan perangkat sebenarnya.
