# The Abyssal 2.1.0 — Changelog

## Fokus rilis

Pembaruan inkremental berbasis source 2.0.9. Fokus rilis ini adalah ketahanan lifecycle aplikasi, pemulihan rendering, dan preset grafis adaptif. Sistem gameplay dan data lama tidak diganti.

## Perubahan

- Menambahkan pengelolaan siklus aplikasi: ketika tab/aplikasi masuk background, input sentuh dilepas, ekspedisi dijeda, video menu dihentikan, audio ambient disuspensi, dan animation loop dihentikan. Saat aplikasi kembali aktif, ukuran viewport dan loop diperiksa kembali.
- Menambahkan penanganan kehilangan/pemulihan WebGL context. Ekspedisi dijeda saat context hilang; setelah context pulih, renderer dan pengaturan grafis disegarkan. Pemain tetap harus menekan Resume untuk melanjutkan sesi.
- Menambahkan pengaman frame runtime. Kesalahan saat update/render ditangkap, input dilepas, dan game dijeda agar satu exception tidak diam-diam menghentikan loop atau terus mengurangi kebutuhan survival.
- Memastikan tombol Resume juga mencoba mengaktifkan kembali AudioContext yang sebelumnya disuspensi.
- Menambahkan preset grafis Ultra yang hanya memakai target tekstur utama 4096 px bila GPU melaporkan batas minimal 4096 dan perangkat melaporkan memori minimal 12 GB. Secondary maps tetap dibatasi 2048 px.
- Fallback Ultra: perangkat 8 GB dengan GPU 4K turun ke profil High; memori tidak diketahui atau GPU tidak mendukung 4K turun ke profil aman Medium. Label UI mengikuti profil aktual.
- Menyelaraskan flag kemampuan 4K dengan ukuran tekstur yang benar-benar dialokasikan, termasuk preset Ultra.
- Menyesuaikan densitas fauna, detail terrain/air, bayangan, anisotropy, dan pixel ratio untuk Ultra tanpa mengubah balancing gameplay.
- Memperbarui versi aplikasi, workflow artifact, pemeriksaan rilis, update manifest contoh, dan nama cache Service Worker menjadi 2.1.0 agar aset lama tidak terus dipakai setelah pembaruan.

## Dipertahankan

- Application ID Android `com.abyssal.game`.
- Save schema v11 dan lima slot penyimpanan lokal.
- Kebijakan penyimpanan manual: progres tetap dikomit ketika pemain memilih Save; tidak ditambahkan autosave diam-diam.
- Inventory 8×6, lima Quick Slots, PDA, tools, Fabricator, survival, dunia/biome, fauna, misi, Lifepod/hatch, habitat/building, kendaraan, upgrade, autentikasi, room/co-op, event dunia bersama, Supabase SQL/RLS, offline mode, serta signing key dan alur update yang sudah ada.
- Tidak ada migrasi database Supabase baru pada rilis ini.

## Batasan

Rilis ini adalah hardening dan penambahan preset grafis, bukan remaster seluruh model/tekstur/audio atau pengganti pengujian gameplay langsung. Build Vite/produksi dan APK belum berhasil dibuktikan pada lingkungan penyusunan paket; lihat `AUDIT_REPORT_2.1.0_ID.md`.
