# The Abyssal 2.2.0 — Changelog

## Fokus rilis

Pembaruan inkremental berbasis source `The_Abyssal_Standalone_Android_v2.1.0.zip`. Fokus pada director cutscene pembuka, pemulihan state cutscene, framing Leviathan, serta polish animasi dan audio First-Person. Tidak membangun ulang proyek.

## Perubahan aktual

- Menambahkan modul `cinematic-systems.mjs` dengan tujuh shot kamera yang terdefinisi: orbital/planet, transfer craft, kapsul terlepas, re-entry, impact laut, Leviathan reveal, dan establishing Lifepod/ancaman.
- Memisahkan timeline shot dan subtitle ke modul murni yang dapat diuji tanpa renderer; durasi intro dan timing subtitle tetap mengikuti alur cerita yang sudah ada.
- Kamera cutscene kini memakai target dinamis, easing posisi dan arah pandang, serta FOV sinematik per shot. FOV pemain dipulihkan pada akhir atau pembatalan cutscene.
- Memperbaiki jalur keluar cutscene ketika pemain kembali ke menu di tengah adegan: geometri/tekstur temporer dibersihkan, overlay ditutup, FOV dipulihkan, dan `introSeen`/story/save tidak diubah.
- Kamera tidak lagi drift seperti kamera menu ketika gameplay sedang dijeda atau panel dibuka.
- Animasi Leviathan diperluas dengan gerak sirip pektoral, gerak badan kecil, pulse mata, dan pulse cahaya bioluminesen. Model orisinal dan detail yang sudah ada tetap digunakan.
- Model resource/supply First-Person yang sudah dibuat secara lokal tetap tersedia untuk semua item `ITEM_DEFS`; ukuran dan posisi genggaman kini memiliki profil yang lebih sesuai per item, sehingga objek kecil/besar tidak memakai satu skala seragam.
- Animasi tindakan juga memberi respons kecil pada pose lengan kanan/kiri, bukan hanya memutar model alat.
- Lapisan suara sintetis offline ditambah profil noise yang berbeda untuk impact, re-entry, roar, launch, warp, splash, repair, dan beberapa interaksi. Tidak membutuhkan file audio remote.
- Memperbarui versi aplikasi, label Android, workflow artifact, update manifest contoh, serta cache Service Worker ke `2.2.0`.

## Dipertahankan

- Semua fitur 2.1.0 dan sebelumnya: dunia, biome, flora/fauna, misi, cutscene dan cerita dasar, Lifepod/hatch, inventory 8×6, lima Quick Slots, PDA, tools, Fabricator, survival, habitat/building, kendaraan dan upgrade, akun, Supabase, room/co-op, save lokal, offline mode, serta preset grafis.
- Application ID `com.abyssal.game`, save schema v11, konfigurasi signing, dan kompatibilitas data lama.
- Nama, cerita, identitas, dan aset orisinal The Abyssal. Tidak menyalin aset proprietary Subnautica.

## Batasan

- Rilis ini adalah peningkatan kode dan aset prosedural yang sudah ada, bukan penggantian penuh seluruh aset proyek dengan paket model GLB/tekstur PBR resolusi tinggi atau rekaman audio studio baru.
- Viewmodel yang ada tetap berupa geometri Three.js prosedural dengan material/tekstur proyek. Tidak ada aset model/audio eksternal baru yang diklaim telah dibuat.
- Build Vite/produksi dan APK belum berhasil diverifikasi pada lingkungan ini karena paket `vite` tidak terpasang dan `node_modules` tidak tersedia.
- Gameplay visual nyata pada browser/WebGL dan perangkat Android fisik masih BELUM TERVERIFIKASI.
