# Prompt implementasi — THE ABYSSAL 1.0.2 Audit & Integrity

Lanjutkan proyek existing THE ABYSSAL secara non-destructive. Jangan menghapus atau mengganti fitur yang telah ada tanpa alasan kompatibilitas yang teruji. Prioritas pertama adalah memperbaiki bug yang dapat dibuktikan, bukan menambah fitur baru.

## Audit wajib

- Periksa seluruh import modul agar tidak ada file runtime yang hilang.
- Periksa HTML IDs unik dan semua referensi DOM dari JavaScript.
- Normalisasi save lokal, Cloud Save, backup import, dan setting sebelum digunakan.
- Jangan pernah menghapus/menimpa slot yang valid hanya karena slot lain rusak atau data backup tidak lengkap.
- Backup hanya dapat dipulihkan setelah validasi format dan lima slot selesai; larang restore saat sesi permainan/multiplayer aktif.
- Simpan snapshot slot aktif sebelum ekspor backup.
- Validasi koordinat, jumlah resource, equipment, fauna discovery, bioma, bangunan, dan world drops.
- Periksa lifecycle renderer, chunk, fauna, item, debris, cinematic, remote player, dan resource disposal.
- Periksa tombol Back Android, pause/resume, keyboard viewport, landscape, fullscreen dan fokus form.
- Multiplayer room connection gagal wajib membersihkan channel/role/room state; hanya Host yang bisa menulis shared save.
- Jangan menyebut multiplayer world authoritative selama fauna, AI, drop, collision, dan survival belum direplikasi server-side.
- Jangan menyebut OTA/auto-update aktif jika URL manifest belum dikonfigurasi dan proses pemasangan APK tetap butuh persetujuan Android.

## Pengujian

Buat tes perilaku untuk sanitasi Save Schema dan backup. Tambahkan pemeriksaan duplicate HTML IDs, dangling DOM references, dan wiring screen/callback yang penting. Jalankan `node --check` untuk semua JS/MJS dan `npm test`. Jangan menyamakan tes source dengan build Android atau device test. Catat dengan jelas jika Vite/Gradle, GPU Android, OAuth, Cloud Save, atau multiplayer dua perangkat belum dapat diuji.

## Aturan distribusi

Pertahankan Capacitor app ID `com.abyssal.game`, storage key lokal, keystore debug tetap, dan workflow ZIP-extractor milik repository pengguna. Jangan meminta pengguna menghapus aplikasi atau slot lama. Pengguna hanya mengunggah ZIP proyek versi baru ke root repository, mengganti ZIP lama saja, lalu menjalankan GitHub Actions yang telah ada.
