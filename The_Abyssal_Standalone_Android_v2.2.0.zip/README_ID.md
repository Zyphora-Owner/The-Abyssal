# The Abyssal 2.2.0

## Rilis 2.2.0 — Cutscene Director, Cinematic Recovery & First-Person Gameplay Polish

Rilis ini berbasis 2.1.0 dengan perubahan inkremental pada cutscene dan pengalaman first-person: director kamera tujuh shot, timeline subtitle teruji, pemulihan FOV, pembatalan cutscene yang aman, animasi Leviathan yang lebih hidup, pose lengan saat penggunaan item, dan kamera yang tetap diam ketika gameplay dijeda. Seluruh sistem 2.1.0 dan fitur sebelumnya dipertahankan.

## Rilis 2.1.0 — Lifecycle Recovery, Runtime Safety & Ultra Graphics

Rilis ini mempertahankan seluruh sistem 2.0.9 dan menambahkan penanganan suspend/resume, pemulihan konteks WebGL, pengamanan runtime frame, serta preset grafis Ultra adaptif.

## Rilis sebelumnya: 2.0.9 — Lifepod Egress, UI Scrolling & Cinematic Reliability

- Memperbaiki kasus keluar Lifepod yang terjebak: posisi akhir kini dihitung di luar hull pada waterline, di luar radius hatch, dan diubah dari koordinat lokal ke world memakai transformasi yaw/scale yang teruji.
- Runtime mencoba sisi kapsul kiri/kanan dan posisi clearance lebih lebar; exit dibatalkan dengan pesan yang jelas bila kedua sisi benar-benar terhalang.
- Validasi entry Lifepod sekarang memeriksa volume interior sebelum snap dan mengembalikan pose sebelumnya bila validasi akhir gagal.
- Membuat panel Inventory/Fabricator dapat di-scroll dengan sentuhan Android; memperbaiki `touch-action` global yang sebelumnya memblokir gesture scroll pada panel, menjaga backpack 8×6, dan menata ulang panel agar aman untuk viewport pendek/notch.
- Menambahkan umpan balik audio saat panel Inventory/Fabricator dibuka/ditutup dan saat kategori Fabricator diganti.
- Mempercepat pengenalan Leviathan pada cutscene, memperkuat glow, dan memperpanjang framing kamera agar monster terlihat lebih jelas sebelum akhir sequence.
- Save schema v11, Application ID `com.abyssal.game`, signing key, backend, seluruh kendaraan/fitur lama, dan progres pemain tetap dipertahankan.

## Rilis 2.0.8 — Underwater Vehicle Fleet & Vehicle Bay

- Menambahkan tiga kendaraan original: Pelagic Skimmer (sub eksplorasi), Pelagic Carrier (kapal selam ekspedisi/basis bergerak), dan Nautilus Exosuit (rangka mekanis laut dalam).
- Vehicle Fabrication Bay, crafting kendaraan, peluncuran, pilot, exit aman, repair, recharge, cargo, sonar, drill/grapple, dan upgrade terintegrasi dengan material serta save lokal.
- Upgrade depth bertingkat, hull/chassis, storage, sonar, efisiensi, thermal reactor, Mining Drill Arm, dan Grappling Arm memiliki efek gameplay.
- Kendaraan memakai swept collision per-sumbu, footprint terrain sampling, collision struktur/Lifepod/wreck/kendaraan, HUD hull/power, dan validasi area launch.
- Carrier Command Deck menyediakan transfer cargo saat Carrier dikemudikan jika Cargo Compartment terpasang; bengkel dan upgrade tetap memerlukan Vehicle Bay.
- Memperbaiki interaction prompt saat pilot, hatch Lifepod untuk hull kendaraan, posisi exit, validasi active vehicle pada save, dan batas recharge Carrier.
- Save schema v11, Application ID `com.abyssal.game`, inventory, lima Quick Slots, PDA, Fabricator, tools, dunia, fauna, misi, backend, dan fitur lama dipertahankan. Autentikasi, room, presence, chat, dan co-op sebelumnya tetap memakai Supabase.

**Batas:** armada, upgrade, posisi, dan cargo kendaraan tersimpan lokal. Data kendaraan belum menjadi shared-world multiplayer. Akun, room, dan co-op sebelumnya tetap dipertahankan.

## Rilis 2.0.7 — Full 3D First-Person Equipment & Hand Grip

- Tool dan item Quick Slot menggunakan viewmodel 3D lokal; tangan penyelam memiliki jari bersegmen dan grip mengikuti alat terpilih; Seaglide memakai pose dua tangan.
- Layer render first-person dipisahkan agar alat dan tangan tidak tertutup geometri dunia.

Kendaraan memakai desain original The Abyssal. Tidak ada model, tekstur, musik, suara, atau kode proprietary Subnautica yang disalin. Riwayat rilis sebelumnya tersedia pada changelog tiap versi.

Fitur **event dunia bersama** yang sudah ada tetap dipertahankan melalui Supabase. Kendaraan versi 2.0.8 belum ikut tersinkron, jadi ini **bukan simulasi shared-world penuh** untuk seluruh armada dan state kendaraan.
