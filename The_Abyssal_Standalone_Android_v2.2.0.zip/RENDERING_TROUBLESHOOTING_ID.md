# Diagnostik Rendering The Abyssal 1.5.2

## Error `WORLD_SEED is not defined`

Sudah diperbaiki pada 1.5.2. Generator dunia sekarang berada di `world-generation.mjs` dan diimpor langsung oleh `game.js`. Regression test memastikan seed, hash, dan noise tetap tersedia.

## Jika layar boot masih gagal

1. Pastikan file ZIP 1.5.2 yang dipakai; jangan campur source dari versi lama dengan folder `www` hasil build lama.
2. Jalankan `npm test` pada folder proyek. Tes ini memeriksa import generator dan semua skrip JavaScript.
3. Build ulang melalui GitHub Actions dan unduh artifact `the-abyssal-android-apk-1.5.2` dari run yang sama.
4. Pastikan hasil build merupakan APK baru, bukan APK yang tersimpan dari run sebelumnya.
5. Bila muncul pesan WebGL, periksa versi Android System WebView dan apakah akselerasi grafis perangkat tersedia.
6. Catat teks error penuh pada layar boot dan ambil screenshot baru. Pesan 1.5.2 sekarang mempertahankan penyebab awal agar tidak tertutup pesan generik.

## Batas verifikasi

Pengujian source tidak sama dengan uji render pada GPU Android. APK tetap harus berhasil dibuat melalui Actions dan dijalankan pada perangkat untuk memastikan seluruh pipeline grafis benar-benar berjalan.
