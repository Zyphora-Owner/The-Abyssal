# Supabase The Abyssal 2.0.6

Rilis 2.0.6 tidak menambahkan migrasi database baru. Konfigurasi Supabase dari versi sebelumnya tetap digunakan.

1. Buka Supabase Dashboard dan pilih proyek yang sama dengan konfigurasi akun/multiplayer.
2. Ambil **Project URL** dari Project Settings → API (atau menu Connect). Jangan menebak URL.
3. Gunakan Publishable Key sebagai kunci publik aplikasi. Jangan memakai `sb_secret`, `service_role`, password database, atau access token di frontend.
4. Masukkan Project URL dan Publishable Key di panel Account/Multiplayer The Abyssal, lalu simpan dan tes koneksi.
5. Email provider dan sign-up harus aktif; bila konfirmasi email aktif, verifikasi email sebelum Login.

Jangan jalankan ulang migrasi lama pada database yang sudah menerapkannya. Database baru harus menerapkan migration SQL yang ada secara berurutan sesuai nama file. Rilis 2.0.6 tidak memerlukan SQL tambahan.

Mode offline tetap tersedia jika backend tidak dapat dijangkau. Login/Register dan multiplayer live tetap membutuhkan Project URL yang benar dan konfigurasi Supabase yang valid.
