# Supabase — The Abyssal 2.0.7

Rilis 2.0.7 hanya memperbarui first-person viewmodel dan animasi tangan/peralatan. **Tidak ada migrasi database baru.** Konfigurasi Supabase, Auth, RLS, room, dan migrasi SQL dari versi sebelumnya tetap digunakan.

Project URL tetap harus diambil dari Supabase Dashboard → Project Settings → API. Gunakan Publishable Key sebagai key publik klien. Jangan memasukkan `sb_secret`, `service_role`, password database, atau token akun ke frontend maupun repository.

Login/Register dan Multiplayer tetap membutuhkan Project URL yang valid, provider Email aktif, migrasi SQL sebelumnya, RLS, serta jaringan. Pengujian live belum dilakukan pada rilis ini.
