# Supabase — The Abyssal 2.0.8

Tidak ada migrasi SQL baru yang diperlukan untuk Vehicle Bay/armada pada versi 2.0.8. Data kendaraan disimpan di save lokal v11.

Backend Auth/Room/Presence/Chat dan event dunia bersama yang sudah ada tetap menggunakan konfigurasi Supabase dari versi sebelumnya. Jangan menjalankan ulang migrasi lama jika database sudah menerapkannya.

Untuk menghubungkan aplikasi, masukkan Project URL yang benar dari Supabase Dashboard → Project Settings → API, bersama Publishable Key publik yang telah dikonfigurasi. Jangan masukkan Secret Key atau Service Role Key ke aplikasi.

**Batas penting:** kendaraan, upgrade, cargo, dan posisi kendaraan di 2.0.8 belum disinkronkan sebagai shared-world entity. Multiplayer lama tetap tersedia, tetapi setiap pemain memiliki fleet lokal pada save masing-masing.
