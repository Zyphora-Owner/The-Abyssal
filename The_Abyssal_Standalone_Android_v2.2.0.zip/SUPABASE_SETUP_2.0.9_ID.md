# Supabase — The Abyssal 2.0.9

Tidak ada migrasi SQL baru pada rilis 2.0.9. Pembaruan ini berfokus pada Lifepod, UI panel, dan cutscene; backend Supabase dari versi sebelumnya tetap dipakai.

- Jika database sudah menjalankan migrasi room recovery dan shared-world event sebelumnya, jangan jalankan ulang migrasi tersebut.
- Jika menyiapkan proyek Supabase baru, ikuti urutan migrasi yang dicantumkan pada file setup versi 2.0.8 dan pastikan tiap migrasi berhasil.
- Project URL harus disalin dari Supabase Dashboard → Project Settings → API → Project URL.
- Gunakan Publishable Key publik saja pada aplikasi klien.
- Jangan menaruh Secret Key, Service Role Key, password database, atau access token di frontend atau repository publik.

Autentikasi dan multiplayer tidak diuji terhadap server nyata pada rilis ini. Setelah Project URL valid dimasukkan, lakukan Register/Login dengan dua akun, Create Room/Join Room pada dua perangkat, lalu uji reconnect. Event dunia bersama dan kendaraan tetap mengikuti batas sinkronisasi yang dijelaskan di dokumentasi 2.0.8; kendaraan lokal belum otomatis menjadi shared-world entity.
