# Supabase — The Abyssal 2.1.0

Tidak ada migrasi SQL baru pada rilis 2.1.0. Backend Supabase, autentikasi, room recovery, event dunia bersama, dan batas sinkronisasi dari versi sebelumnya tetap dipakai.

## Ambil konfigurasi project

1. Buka Supabase Dashboard dan pilih project milik pemilik game.
2. Buka **Project Settings → API** atau panel **Connect**.
3. Salin **Project URL**. Jangan menebak URL dari Publishable Key.
4. Gunakan Publishable Key publik untuk client. Jangan masukkan `sb_secret`, `service_role`, password database, atau access token ke source/frontend.

## Database migration

Untuk project Supabase baru, jalankan SQL berikut satu per satu dan sesuai urutan:

1. `supabase/migrations/202611060001_multiplayer.sql`
2. `supabase/migrations/202611060002_room_recovery.sql`
3. `supabase/migrations/202611070001_shared_world_events.sql`
4. `supabase/migrations/202611070002_deep_world_coordinates.sql`

Jika project sudah menjalankan keempat migration ini, **tidak ada SQL baru yang perlu dijalankan untuk 2.1.0**. Jangan menjalankan ulang migration lama tanpa alasan yang jelas.

## Authentication

1. Buka **Authentication → Providers → Email**.
2. Pastikan Email aktif dan kebijakan sign-up sesuai kebutuhan.
3. Jika konfirmasi email aktif, selesaikan verifikasi sebelum login.
4. Atur redirect URL ke domain aplikasi yang benar-benar digunakan.

## Hubungkan aplikasi

1. Jalankan The Abyssal dan buka konfigurasi backend dari Account/Multiplayer.
2. Masukkan Project URL. Publishable Key publik dapat dimasukkan pada field yang tersedia.
3. Simpan konfigurasi dan hubungkan.
4. Register dengan email aktif, verifikasi jika diminta, kemudian Login.
5. Uji Create Room/Join Room dengan dua akun dan dua perangkat yang berbeda; periksa chat, posisi, reconnect, dan event dunia bersama.

## Batas sinkronisasi yang harus dipahami

Room, presence, posisi diver, chat, serta event dunia bersama yang diimplementasikan tersedia dalam arsitektur saat ini. Namun inventory, kebutuhan survival, fauna AI, kendaraan, dan keseluruhan simulasi dunia belum menjadi shared-world authoritative sepenuhnya. Keberhasilan test source tidak membuktikan backend live atau dua perangkat berhasil tersambung.

## Keamanan

- Jangan commit secret/service role key ke repository.
- Pastikan RLS aktif sesuai migration.
- Jangan menonaktifkan verifikasi/authorization hanya untuk membuat pengujian terlihat berhasil.
- Project URL dan kredensial harus berasal dari project yang benar-benar dimiliki dan dikonfigurasi.
