# Supabase — The Abyssal 2.0.2

Rilis 2.0.2 tidak menambah migrasi Supabase. Backend dan event co-op yang sudah ada tetap dipakai. Project URL masih harus berasal dari project Supabase milikmu sendiri.

## Ambil Project URL
1. Buka Supabase Dashboard dan pilih project.
2. Buka **Project Settings → API** (atau panel **Connect**).
3. Salin **Project URL**. Jangan menebaknya dari Publishable Key.
4. Publishable Key publik yang sebelumnya diberikan sudah tersedia sebagai nilai klien. Jangan gunakan `sb_secret`, `service_role`, password database, atau access token pada aplikasi.

## Database migration
Untuk project Supabase baru, jalankan file SQL satu per satu dan sesuai urutan: 
1. `202611060001_multiplayer.sql`
2. `202611060002_room_recovery.sql`
3. `202611070001_shared_world_events.sql`
4. `202611070002_deep_world_coordinates.sql`

Jika project yang sama sudah menjalankan keempat migration tersebut, **tidak ada SQL baru yang perlu dijalankan untuk 2.0.2**. Jangan menjalankan ulang migration lama kecuali SQL memang dirancang idempotent dan ada kebutuhan yang jelas.

## Authentication
1. Buka **Authentication → Providers → Email**.
2. Pastikan Email aktif dan sign-up diizinkan.
3. Jika email confirmation aktif, buka email verifikasi setelah Register sebelum Login.
4. Atur URL redirect sesuai domain aplikasi yang benar-benar sudah dipublikasikan.

## Sambungkan aplikasi
1. Buka The Abyssal → Account/Multiplayer → backend configuration.
2. Masukkan Project URL. Publishable Key publik sudah diprefill; jika field kosong, salin Publishable Key dari project yang sama.
3. Tekan **Simpan & Hubungkan**.
4. Register dengan email aktif, verifikasi jika diminta, lalu Login.
5. Untuk mencoba room, gunakan dua akun dan dua perangkat: perangkat pertama Create Room, perangkat kedua Join Room memakai kode undangan.

## Batas multiplayer
Fitur room, Presence, avatar/posisi, chat, reconnect, dan sebagian event dunia tersedia di source. Namun inventory, fauna AI, health/oxygen, kendaraan, dan seluruh simulasi dunia belum menjadi shared-world authoritative sepenuhnya. Keberhasilan source checks tidak membuktikan backend live atau dua perangkat berhasil tersambung.
