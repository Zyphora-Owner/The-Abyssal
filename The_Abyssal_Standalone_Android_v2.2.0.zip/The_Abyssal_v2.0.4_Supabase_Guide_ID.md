# Supabase — The Abyssal 2.0.4

Rilis 2.0.4 berfokus pada grafik dan tidak menambah migrasi Supabase. Backend/auth/multiplayer dari versi sebelumnya tetap dipakai.

## Project URL
1. Buka Supabase Dashboard dan pilih project.
2. Buka **Project Settings → API** atau panel **Connect**.
3. Salin **Project URL** dari project tersebut. Jangan menebaknya dari Publishable Key.
4. Gunakan Publishable Key publik pada aplikasi; jangan masukkan `sb_secret`, `service_role`, password database, atau access token.

## Migrasi database
Tidak ada SQL migration baru untuk 2.0.4. Jangan jalankan ulang SQL lama jika keempat migration sebelumnya sudah diterapkan:
- `202611060001_multiplayer.sql`
- `202611060002_room_recovery.sql`
- `202611070001_shared_world_events.sql`
- `202611070002_deep_world_coordinates.sql`

Untuk konfigurasi awal atau troubleshooting auth/room, ikuti `SUPABASE_SETUP_ID.md` yang sudah ada di repository.

## Batas verifikasi
Fitur backend tidak berubah pada rilis grafik ini. Login/Register, room, dan shared-world tetap memerlukan Project URL valid, konfigurasi Auth, RLS, serta koneksi Supabase. Rilis ini tidak mengklaim pengujian backend live.
