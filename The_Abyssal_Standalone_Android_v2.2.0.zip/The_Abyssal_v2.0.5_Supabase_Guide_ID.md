# Supabase — The Abyssal 2.0.5

Rilis 2.0.5 tidak mengubah skema backend, autentikasi, room, ataupun tabel shared-world. Tidak ada SQL migration baru.

## Project URL
1. Buka Supabase Dashboard dan pilih project.
2. Buka **Project Settings → API** atau dialog **Connect**.
3. Salin Project URL dari project yang sama dengan Publishable Key aplikasi.
4. Jangan pernah memasukkan `sb_secret`, `service_role`, password database, atau access token ke frontend.

## Migrasi
Tidak ada migrasi tambahan pada versi ini. Jika database 2.0.4 sudah menjalankan empat migrasi sebelumnya, jangan jalankan ulang migrasi lama.

## Batas verifikasi
Login/Register dan multiplayer tidak diubah pada rilis visual/gameplay ini. Pengujian live tetap memerlukan Project URL valid, Auth provider Email, RLS, Realtime dan koneksi jaringan.
