// Optional HTTPS manifest endpoint. Leave empty until you publish a trusted update manifest.
// The app can notify and open a release APK URL; Android still requires the user to approve installation.
window.ABYSSAL_UPDATE_MANIFEST_URL = '';
