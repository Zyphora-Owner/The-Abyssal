@echo off
setlocal
npm install
if not exist android\gradlew.bat (
  call npm run android:add
) else (
  call npm run android:sync
)
cd android
call gradlew.bat assembleDebug
if errorlevel 1 exit /b 1
echo APK: android\app\build\outputs\apk\debug\app-debug.apk
endlocal
