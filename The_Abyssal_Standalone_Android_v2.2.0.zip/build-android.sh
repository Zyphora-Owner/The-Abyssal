#!/usr/bin/env bash
set -euo pipefail
npm install
if [ ! -d android ]; then npm run android:add; else npm run android:sync; fi
(cd android && ./gradlew assembleDebug)
echo "APK: android/app/build/outputs/apk/debug/app-debug.apk"
