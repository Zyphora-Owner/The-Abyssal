/**
 * Deterministic intro-cutscene camera and subtitle timeline for The Abyssal.
 * The runtime resolves each shot against live Three.js object transforms.
 */
export const INTRO_CINEMATIC_DURATION = 32.8;
export const INTRO_CINEMATIC_LINES_AT = Object.freeze([0, 5.2, 10.1, 15.4, 21.2, 27.2]);

const shot = (id, start, end, focus, cameraOffset, targetOffset, fov, follow = 1.35) => Object.freeze({
  id, start, end, focus,
  cameraOffset: Object.freeze(cameraOffset),
  targetOffset: Object.freeze(targetOffset),
  fov, follow
});

export const INTRO_CAMERA_SHOTS = Object.freeze([
  shot('orbital-establishing', 0, 5.2, 'earth', [24, 10, 42], [0, 0, 0], 54, 0.92),
  shot('transfer-craft', 5.2, 9.3, 'transport', [-17, 8, 22], [0, 0, 0], 50, 1.45),
  shot('capsule-separation', 9.3, 12.5, 'pod', [12, 7, 19], [0, 0, 0], 52, 1.55),
  shot('atmospheric-reentry', 12.5, 18.1, 'pod', [10, 4, 15], [0, -0.25, -0.35], 56, 1.7),
  shot('ocean-impact', 18.1, 20.7, 'pod', [18, 9, 20], [0, -0.35, 0], 54, 1.45),
  shot('leviathan-reveal', 20.7, 27.2, 'attacker', [25, 9, -21], [0, 0, -7.5], 50, 1.2),
  shot('lifepod-threat-establish', 27.2, INTRO_CINEMATIC_DURATION, 'attacker', [22, 8, 15], [-4, -1, -4.5], 55, 1.0)
]);

export function getIntroCameraShot(elapsedSeconds = 0) {
  const time = Number.isFinite(Number(elapsedSeconds)) ? Math.max(0, Number(elapsedSeconds)) : 0;
  const selected = INTRO_CAMERA_SHOTS.find(item => time >= item.start && time < item.end)
    || INTRO_CAMERA_SHOTS[INTRO_CAMERA_SHOTS.length - 1];
  const duration = Math.max(0.001, selected.end - selected.start);
  const progress = Math.min(1, Math.max(0, (time - selected.start) / duration));
  return { ...selected, progress };
}

export function getIntroSubtitleIndex(elapsedSeconds = 0) {
  const time = Number.isFinite(Number(elapsedSeconds)) ? Math.max(0, Number(elapsedSeconds)) : 0;
  for (let index = INTRO_CINEMATIC_LINES_AT.length - 1; index >= 0; index--) {
    if (time >= INTRO_CINEMATIC_LINES_AT[index]) return index;
  }
  return 0;
}
