import * as THREE from 'three';
import { clampFaunaDepth } from './player-mechanics.mjs';

// Stylized low-poly marine life. Shared geometry/materials keep draw calls and memory modest on Android.
const SPECIES = [
  { id:'clownfish', name:'Clownfish', kind:'fish', color:0xf28a38, belly:0xffe6c4, scale:0.52, speed:3.1, depth:[-5,-20], weight:10 },
  { id:'blue_tang', name:'Blue Tang', kind:'fish', color:0x2377d8, belly:0xe8d8a8, scale:0.62, speed:3.8, depth:[-4,-22], weight:9 },
  { id:'butterflyfish', name:'Butterflyfish', kind:'fish', color:0xf5d34d, belly:0xfff1c7, scale:0.55, speed:2.7, depth:[-4,-18], weight:8 },
  { id:'angelfish', name:'Angelfish', kind:'fish', color:0x7a8bd8, belly:0xf2d9a0, scale:0.65, speed:2.6, depth:[-8,-28], weight:7 },
  { id:'parrotfish', name:'Parrotfish', kind:'fish', color:0x36ae9a, belly:0xbfe8d1, scale:0.72, speed:2.2, depth:[-7,-25], weight:7 },
  { id:'lionfish', name:'Lionfish', kind:'fish', color:0xd66b48, belly:0xf3d7c8, scale:0.72, speed:1.9, depth:[-10,-32], weight:5 },
  { id:'yellowfin_tuna', name:'Yellowfin Tuna', kind:'fish', color:0xb9c8d1, belly:0xf4e8ca, scale:0.9, speed:5.3, depth:[-8,-32], weight:5 },
  { id:'barracuda', name:'Barracuda', kind:'predator', color:0x8399a0, belly:0xd6e1d9, scale:1.0, speed:4.7, depth:[-12,-35], weight:4, hostile:true, damage:7, aggro:22 },
  { id:'seahorse', name:'Seahorse', kind:'seahorse', color:0xe7b45e, belly:0xffe1a0, scale:0.48, speed:1.15, depth:[-6,-25], weight:4 },
  { id:'pufferfish', name:'Pufferfish', kind:'fish', color:0xdba94c, belly:0xf6df9a, scale:0.62, speed:1.35, depth:[-5,-24], weight:5 },
  { id:'moorish_idol', name:'Moorish Idol', kind:'fish', color:0xe8d8a0, belly:0xf4eee0, scale:0.66, speed:3.0, depth:[-5,-22], weight:4 },
  { id:'triggerfish', name:'Titan Triggerfish', kind:'fish', color:0x3a9b8a, belly:0xc9e2ba, scale:0.78, speed:2.1, depth:[-7,-26], weight:3 },
  { id:'moray_eel', name:'Moray Eel', kind:'fish', color:0x778e51, belly:0xb9c28f, scale:0.86, speed:1.75, depth:[-12,-34], weight:3 },
  { id:'bioluminescent_angler', name:'Bioluminescent Anglerfish', kind:'angler', color:0x344d5c, belly:0x82999a, scale:0.92, speed:1.45, depth:[-70,-235], weight:1.2 },
  { id:'jellyfish', name:'Jellyfish', kind:'jelly', color:0x9f8bea, belly:0xd9d0ff, scale:0.8, speed:0.8, depth:[-10,-155], weight:5 },
  { id:'sea_turtle', name:'Green Sea Turtle', kind:'turtle', color:0x528b68, belly:0xc1aa79, scale:1.0, speed:1.6, depth:[-4,-26], weight:4 },
  { id:'manta_ray', name:'Manta Ray', kind:'manta', color:0x344a61, belly:0x91b7bf, scale:1.55, speed:3.2, depth:[-8,-34], weight:3 },
  { id:'reef_shark', name:'Reef Shark', kind:'shark', color:0x657d8b, belly:0xcbd9d9, scale:1.45, speed:4.2, depth:[-12,-82], weight:3, hostile:true, damage:9, aggro:28 },
  { id:'hammerhead', name:'Hammerhead Shark', kind:'hammerhead', color:0x657b88, belly:0xd1dfda, scale:1.9, speed:4.7, depth:[-18,-112], weight:2, hostile:true, damage:12, aggro:32 },
  { id:'humpback_whale', name:'Humpback Whale', kind:'whale', color:0x425e6b, belly:0x9aafb0, scale:3.2, speed:1.8, depth:[-8,-30], weight:1.4 },
  { id:'sperm_whale', name:'Sperm Whale', kind:'whale', color:0x536b73, belly:0xaabbb7, scale:3.7, speed:1.55, depth:[-22,-168], weight:0.8 },
  { id:'blue_whale', name:'Blue Whale', kind:'whale', color:0x3e7180, belly:0xb2ccca, scale:4.8, speed:1.25, depth:[-12,-37], weight:0.45 },
  { id:'orca', name:'Orca', kind:'whale', color:0x182b37, belly:0xe5eeee, scale:3.25, speed:2.4, depth:[-7,-30], weight:0.7 },
  { id:'giant_squid', name:'Giant Squid', kind:'squid', color:0x966075, belly:0xd2a2a9, scale:2.4, speed:1.7, depth:[-35,-205], weight:0.65 },
  { id:'abyssal_leviathan', name:'Abyssal Leviathan', kind:'leviathan', color:0x172c3b, belly:0x45636c, scale:4.5, speed:3.0, depth:[-150,-420], weight:0.16, hostile:true, damage:22, aggro:58 },
  { id:'abyssal_stalker', name:'Abyssal Stalker', kind:'predator', color:0x26384d, belly:0x526a78, scale:1.85, speed:3.7, depth:[-68,-218], weight:1.1, hostile:true, damage:14, aggro:38 },
  { id:'trench_leviathan', name:'Trench Leviathan', kind:'leviathan', color:0x111f31, belly:0x34495f, scale:6.1, speed:2.35, depth:[-220,-475], weight:0.035, hostile:true, damage:26, aggro:64 },
  { id:'glass_shrimp', name:'Glass Shrimp', kind:'fish', color:0x7dbfc0, belly:0xd1f0e8, scale:0.34, speed:2.4, depth:[-4,-19], weight:5 },
  { id:'ribbon_eel', name:'Ribbon Eel', kind:'fish', color:0x7b9a4b, belly:0xb8c78a, scale:0.78, speed:1.85, depth:[-12,-31], weight:3 },
  { id:'reef_cuttlefish', name:'Reef Cuttlefish', kind:'squid', color:0xb46d83, belly:0xe3b5b8, scale:0.95, speed:2.0, depth:[-7,-26], weight:2.4 },
  { id:'vent_crab', name:'Ember Vent Crab', kind:'fish', color:0xc45e42, belly:0xf0a16a, scale:0.62, speed:1.05, depth:[-22,-38], weight:2 },
  { id:'sulfur_masonfish', name:'Sulfur Masonfish', kind:'fish', color:0xd5a52c, belly:0xf3df98, scale:0.64, speed:1.05, depth:[-24,-62], weight:2.2 },
  { id:'lantern_fish', name:'Lanternfish', kind:'angler', color:0x365b7a, belly:0x83cad2, scale:0.55, speed:2.1, depth:[-45,-470], weight:2.6 }
];

const BIOME_SPECIES = {
  reef:['clownfish','blue_tang','butterflyfish','angelfish','parrotfish','pufferfish','moorish_idol','triggerfish','sea_turtle','manta_ray','glass_shrimp','reef_cuttlefish'],
  kelp:['lionfish','seahorse','moray_eel','jellyfish','barracuda','ribbon_eel','reef_shark','glass_shrimp'],
  wreck:['barracuda','moray_eel','reef_shark','hammerhead','lionfish','ribbon_eel','giant_squid'],
  thermal:['bioluminescent_angler','vent_crab','sulfur_masonfish','lantern_fish','giant_squid','jellyfish'],
  deep:['bioluminescent_angler','sperm_whale','giant_squid','abyssal_stalker','lantern_fish','hammerhead'],
  abyss:['bioluminescent_angler','sperm_whale','giant_squid','abyssal_leviathan','trench_leviathan','lantern_fish'],
  open:['yellowfin_tuna','manta_ray','humpback_whale','blue_whale','orca','reef_shark','glass_shrimp','hammerhead']
};

const QUALITY_COUNTS = { low: 12, balanced: 20, high: 28, ultra: 32 };
const SULFUR_NEST_SITES = Object.freeze([{x:296,z:-217,y:-42},{x:-272,z:246,y:-46},{x:448,z:365,y:-44}]);
const rand = (a,b) => a + Math.random() * (b-a);
const choose = (items) => items[Math.floor(Math.random() * items.length)];
const clamp = (v,a,b) => Math.max(a,Math.min(b,v));

function makeTaperedBodyGeometry(radialSegments=16, rings=14) {
  const positions=[], uvs=[], indices=[];
  const profile=[[-1,0.08],[-0.82,0.24],[-0.52,0.39],[-0.18,0.48],[0.22,0.44],[0.58,0.34],[0.86,0.21],[1,0.07]];
  for(let r=0;r<rings;r++){
    const t=r/(rings-1), p=t*(profile.length-1), i=Math.min(profile.length-2,Math.floor(p)), f=p-i;
    const z=THREE.MathUtils.lerp(profile[i][0],profile[i+1][0],f);
    const radius=THREE.MathUtils.lerp(profile[i][1],profile[i+1][1],f);
    for(let j=0;j<=radialSegments;j++){
      const a=j/radialSegments*Math.PI*2;
      positions.push(Math.cos(a)*radius,Math.sin(a)*radius,z);
      uvs.push(j/radialSegments,t);
    }
  }
  for(let r=0;r<rings-1;r++) for(let j=0;j<radialSegments;j++){
    const a=r*(radialSegments+1)+j,b=a+1,c=a+radialSegments+1,d=c+1;
    indices.push(a,b,c,b,d,c);
  }
  const geo=new THREE.BufferGeometry(); geo.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
  geo.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2)); geo.setIndex(indices); geo.computeVertexNormals(); return geo;
}

function makeTailFinGeometry() {
  const shape=new THREE.Shape();
  shape.moveTo(0,0); shape.quadraticCurveTo(-0.28,0.38,-0.62,0.66);
  shape.quadraticCurveTo(-0.52,0.27,-0.18,0.16); shape.quadraticCurveTo(0,0.28,0.18,0.16);
  shape.quadraticCurveTo(0.52,0.27,0.62,0.66); shape.quadraticCurveTo(0.28,0.38,0,0);
  return new THREE.ExtrudeGeometry(shape,{depth:0.075,bevelEnabled:true,bevelSegments:1,steps:1,bevelSize:0.025,bevelThickness:0.025});
}

export class FaunaDirector {
  constructor(scene, onAttack = () => {}, terrainHeight = () => -300, textureSize = 1024) {
    this.scene = scene;
    this.onAttack = onAttack;
    this.terrainHeight = terrainHeight;
    this.animals = [];
    this.spawnSerial = 0;
    this.discovered = new Set();
    this.quality = 'balanced';
    this.currentBiome = 'open';
    this.lastReplenish = 0;
    this.shared = {
      sphere: new THREE.SphereGeometry(1, 8, 6),
      cone: new THREE.ConeGeometry(0.45, 0.85, 4),
      fin: new THREE.ConeGeometry(0.42, 0.9, 3),
      smallSphere: new THREE.SphereGeometry(0.12, 6, 5),
      tentacle: new THREE.CylinderGeometry(0.035, 0.018, 1, 7, 2),
      taperedBody: makeTaperedBodyGeometry(18,16),
      tailFin: makeTailFinGeometry(),
      pectoralFin: new THREE.ConeGeometry(0.18,0.68,5,1)
    };
    this.materials = new Map();
    this.textureSize = Math.max(512, Number(textureSize) || 1024);
    this.scaleTexture = this.createScaleTexture(this.textureSize);
    this.scaleBumpTexture = this.createScaleBumpTexture(this.textureSize);
    this.turtleShellTexture = this.createTurtleShellTexture(false, this.textureSize);
    this.turtleShellBumpTexture = this.createTurtleShellTexture(true, this.textureSize);
    this.turtleShellMaterial = new THREE.MeshStandardMaterial({ color:0x528b68, map:this.turtleShellTexture, bumpMap:this.turtleShellBumpTexture, bumpScale:0.095, roughness:0.76, metalness:0.025 });
    this.shared.turtleShell = new THREE.SphereGeometry(0.82, 32, 18, 0, Math.PI * 2, 0, Math.PI / 2);
    this.shared.turtleRim = new THREE.TorusGeometry(0.76, 0.075, 8, 36);
  }

  createScaleTexture(size = 512) {
    const canvas = document.createElement('canvas');
    canvas.width = size; canvas.height = size;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Canvas 2D tidak tersedia untuk tekstur fauna');
    ctx.scale(size / 128, size / 128);
    const gradient = ctx.createLinearGradient(0, 0, 0, 128);
    gradient.addColorStop(0, '#ffffff'); gradient.addColorStop(1, '#b9d5d7');
    ctx.fillStyle = gradient; ctx.fillRect(0, 0, 128, 128);
    ctx.strokeStyle = 'rgba(24,58,72,.20)'; ctx.lineWidth = 1;
    for (let row = 0; row < 9; row++) {
      const y = row * 16;
      for (let col = -1; col < 9; col++) {
        const x = col * 16 + (row % 2) * 8;
        ctx.beginPath(); ctx.arc(x, y, 9, 0.12, Math.PI - 0.12); ctx.stroke();
        ctx.beginPath(); ctx.arc(x, y + 2, 6.8, 0.18, Math.PI - 0.18);
        ctx.strokeStyle = 'rgba(255,255,255,.25)'; ctx.stroke();
        ctx.strokeStyle = 'rgba(24,58,72,.20)';
      }
    }
    // Add unique high-frequency scale flecks at the real output resolution so
    // a 2K/4K map contains more detail rather than only being an enlarged 128px tile.
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    const microCount = Math.min(14000, Math.floor(size * size / 1150));
    for (let i = 0; i < microCount; i++) {
      const x = ((i * 16807) % 2147483647) / 2147483647 * size;
      const y = ((i * 48271 + 7919) % 2147483647) / 2147483647 * size;
      const r = Math.max(0.45, size / 2048) * (0.45 + (i % 7) * 0.12);
      ctx.fillStyle = i % 3 === 0 ? 'rgba(255,255,255,.12)' : 'rgba(25,58,72,.075)';
      ctx.beginPath(); ctx.ellipse(x, y, r * 1.8, r, (i % 13) * 0.19, 0, Math.PI * 2); ctx.fill();
    }
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(1.6, 1.2);
    texture.minFilter = THREE.LinearMipmapLinearFilter;
    texture.magFilter = THREE.LinearFilter;
    return texture;
  }

  createTurtleShellTexture(bump = false, size = 512) {
    const canvas=document.createElement('canvas'); canvas.width=canvas.height=size;
    const ctx=canvas.getContext('2d');
    if (!ctx) throw new Error('Canvas 2D tidak tersedia untuk tekstur tempurung kura-kura');
    ctx.scale(size / 512, size / 512);
    const base=ctx.createLinearGradient(0,0,512,512);
    if (bump) {
      base.addColorStop(0,'#a8a8a8'); base.addColorStop(1,'#646464');
    } else {
      base.addColorStop(0,'#9eaa67'); base.addColorStop(.48,'#657c4c'); base.addColorStop(1,'#3c5e43');
    }
    ctx.fillStyle=base; ctx.fillRect(0,0,512,512);
    // Hexagonal scutes with inset growth borders and mottled centres.
    const rows=7, cols=7, cellW=74, cellH=65;
    for(let row=0;row<rows;row++) for(let col=0;col<cols;col++) {
      const cx=col*cellW+(row%2)*cellW*.5+18, cy=row*cellH+24;
      const radius=30 + ((row*17+col*11)%7);
      const points=[];
      for(let k=0;k<6;k++){const a=Math.PI/3*k-Math.PI/6;points.push([cx+Math.cos(a)*radius,cy+Math.sin(a)*radius]);}
      ctx.beginPath(); points.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.closePath();
      if(bump){ctx.fillStyle='#858585';ctx.fill();ctx.strokeStyle='#d7d7d7';ctx.lineWidth=5;ctx.stroke();ctx.strokeStyle='#4c4c4c';ctx.lineWidth=2;ctx.stroke();}
      else {
        const hue=(row*13+col*19)%22;
        ctx.fillStyle=`hsl(${76+hue},${23+(row+col)%15}%,${29+(row*3+col*5)%17}%)`;ctx.fill();
        ctx.strokeStyle='rgba(18,35,23,.72)';ctx.lineWidth=5;ctx.stroke();
        ctx.strokeStyle='rgba(207,194,125,.52)';ctx.lineWidth=2;ctx.stroke();
        ctx.save();ctx.beginPath();ctx.arc(cx,cy,radius*.55,0,Math.PI*2);ctx.strokeStyle='rgba(220,213,157,.16)';ctx.lineWidth=2;ctx.stroke();ctx.restore();
      }
    }
    // Fine scratches and shell mottling break up the repeated scute pattern.
    for(let i=0;i<260;i++){
      const x=(i*137.5)%512,y=(i*83.7)%512,r=1+(i%4);
      ctx.fillStyle=bump?`rgba(220,220,220,${.08+(i%5)*.025})`:`rgba(${i%2?18:205},${i%2?39:190},${i%2?27:114},${.05+(i%5)*.025})`;
      ctx.beginPath();ctx.ellipse(x,y,r*1.7,r,((i%9)-4)*.12,0,Math.PI*2);ctx.fill();
    }
    // Fine shell pits and growth streaks scale with the selected texture preset.
    ctx.setTransform(1,0,0,1,0,0);
    const microCount=Math.min(18000,Math.floor(size*size/950));
    for(let i=0;i<microCount;i++){
      const x=((i*1103515245+12345)>>>0)/4294967296*size;
      const y=((i*2654435761+1013904223)>>>0)/4294967296*size;
      const r=Math.max(.45,size/4096)*(0.35+(i%6)*.16);
      ctx.fillStyle=bump?`rgba(${i%2?224:78},${i%2?224:78},${i%2?224:78},${.045+(i%4)*.018})`:`rgba(${i%2?218:20},${i%2?202:42},${i%2?143:26},${.045+(i%5)*.018})`;
      ctx.beginPath();ctx.ellipse(x,y,r*2.1,r,(i%11)*.21,0,Math.PI*2);ctx.fill();
    }
    const texture=new THREE.CanvasTexture(canvas);
    if(!bump) texture.colorSpace=THREE.SRGBColorSpace;
    texture.wrapS=texture.wrapT=THREE.RepeatWrapping;
    texture.minFilter=THREE.LinearMipmapLinearFilter;texture.magFilter=THREE.LinearFilter;
    texture.generateMipmaps=true;
    return texture;
  }

  createScaleBumpTexture(size = 512) {
    const canvas=document.createElement('canvas'); canvas.width=canvas.height=size;
    const ctx=canvas.getContext('2d');
    if (!ctx) throw new Error('Canvas 2D tidak tersedia untuk bump texture fauna');
    ctx.scale(size / 128, size / 128);
    ctx.fillStyle='#777'; ctx.fillRect(0,0,128,128);
    ctx.strokeStyle='#d0d0d0'; ctx.lineWidth=1.6;
    for(let row=0;row<9;row++) for(let col=-1;col<9;col++) {
      const x=col*16+(row%2)*8, y=row*14;
      ctx.beginPath(); ctx.arc(x,y,8,0.12,Math.PI-0.12); ctx.stroke();
    }
    ctx.setTransform(1,0,0,1,0,0);
    const microCount=Math.min(14000,Math.floor(size*size/1150));
    for(let i=0;i<microCount;i++){
      const x=((i*48271+7919)>>>0)/4294967296*size;
      const y=((i*69621+1237)>>>0)/4294967296*size;
      const v=112+(i%9)*4;
      ctx.fillStyle=`rgba(${v},${v},${v},.16)`;
      ctx.fillRect(x,y,Math.max(.6,size/2048),Math.max(.6,size/2048));
    }
    const tex=new THREE.CanvasTexture(canvas);
    tex.wrapS=tex.wrapT=THREE.RepeatWrapping; tex.repeat.set(1.6,1.2);
    tex.minFilter=THREE.LinearMipmapLinearFilter; tex.magFilter=THREE.LinearFilter;
    return tex;
  }

  setDiscoveries(ids = []) {
    this.discovered = new Set(Array.isArray(ids) ? ids.filter(id => SPECIES.some(s => s.id === id)) : []);
  }
  getDiscoveries() { return [...this.discovered]; }
  getDiscoveryRecords() { return SPECIES.filter(s => this.discovered.has(s.id)).map(s => ({ id:s.id, name:s.name, kind:s.kind, depth:s.depth })); }
  setBiome(id) { this.currentBiome = BIOME_SPECIES[id] ? id : 'open'; }
  getSpeciesCount() { return this.discovered.size; }
  setQuality(value, textureSize = null) {
    this.quality = value in QUALITY_COUNTS ? value : 'balanced';
    const fallbackSize = this.quality === 'low' ? 1024 : 2048;
    const nextSize = Math.max(512, Number(textureSize) || fallbackSize);
    if (nextSize === this.textureSize) return;
    const oldTextures = [this.scaleTexture,this.scaleBumpTexture,this.turtleShellTexture,this.turtleShellBumpTexture];
    this.textureSize = nextSize;
    this.scaleTexture = this.createScaleTexture(nextSize);
    this.scaleBumpTexture = this.createScaleBumpTexture(nextSize);
    this.turtleShellTexture = this.createTurtleShellTexture(false, nextSize);
    this.turtleShellBumpTexture = this.createTurtleShellTexture(true, nextSize);
    for (const material of this.materials.values()) {
      material.map = this.scaleTexture;
      material.bumpMap = this.scaleBumpTexture;
      material.needsUpdate = true;
    }
    this.turtleShellMaterial.map = this.turtleShellTexture;
    this.turtleShellMaterial.bumpMap = this.turtleShellBumpTexture;
    this.turtleShellMaterial.needsUpdate = true;
    for (const texture of new Set(oldTextures)) texture?.dispose();
  }

  /** Remove stale actors when loading or starting another save, then repopulate around that diver. */
  resetPopulation(playerPosition = null) {
    for (const animal of this.animals) this.scene.remove(animal.group);
    this.animals.length=0;
    this.lastReplenish=0;
    if (playerPosition) this.ensurePopulation(playerPosition);
  }

  material(color, options = {}) {
    const key = `${color}-${options.emissive || 0}-${options.roughness ?? 0.82}`;
    if (!this.materials.has(key)) this.materials.set(key, new THREE.MeshStandardMaterial({ color, map: this.scaleTexture, bumpMap:this.scaleBumpTexture, bumpScale:0.045, roughness: options.roughness ?? 0.82, metalness: 0.02, emissive: options.emissive || 0, emissiveIntensity: options.emissive ? 0.8 : 0 }));
    return this.materials.get(key);
  }
  mesh(geometry, material, group, scale, position) {
    const m = new THREE.Mesh(geometry, material);
    if (scale) m.scale.set(...scale);
    if (position) m.position.set(...position);
    group.add(m);
    return m;
  }

  createModel(species) {
    const root = new THREE.Group();
    const main = this.material(species.color);
    const belly = this.material(species.belly || 0xbad0d0);
    const dark = this.material(0x071a25, { roughness:0.45 });
    const glow = this.material(0x6ce6e4, { emissive:0x1b8f9b, roughness:0.38 });
    let tail = null, wings = [];

    if (species.kind === 'jelly') {
      this.mesh(this.shared.sphere, main, root, [0.62,0.48,0.62], [0,0,0]);
      const dome = new THREE.Mesh(this.shared.sphere, glow); dome.scale.set(0.38,0.22,0.38); dome.position.y=0.22; root.add(dome);
      for (let i=0;i<6;i++) {
        const strand = this.mesh(this.shared.tentacle, belly, root, [1,rand(1.2,2.2),1], [Math.cos(i*Math.PI/3)*0.34,-0.95,Math.sin(i*Math.PI/3)*0.34]);
        strand.rotation.z = Math.cos(i*Math.PI/3)*0.14;
        strand.rotation.x = Math.sin(i*Math.PI/3)*0.14;
      }
    } else if (species.kind === 'squid') {
      this.mesh(this.shared.sphere, main, root, [0.62,0.72,1.35], [0,0,0.42]);
      this.mesh(this.shared.sphere, belly, root, [0.5,0.52,0.68], [0,-0.18,-0.5]);
      for (const side of [-1,1]) this.mesh(this.shared.smallSphere, glow, root, [1.6,1.6,1.6], [side*0.38,0.1,-0.9]);
      for (let i=0;i<8;i++) {
        const angle=(i/8)*Math.PI*2;
        const arm=this.mesh(this.shared.tentacle, main, root, [1,rand(2.1,3.5),1], [Math.cos(angle)*0.38,-0.62,Math.sin(angle)*0.38-0.55]);
        arm.rotation.z=Math.cos(angle)*0.48; arm.rotation.x=Math.sin(angle)*0.42; wings.push(arm);
      }
      tail=this.mesh(this.shared.cone, main, root, [0.72,1.3,0.72], [0,0,1.55]); tail.rotation.x=-Math.PI/2;
    } else if (species.kind === 'turtle') {
      const shell = new THREE.Mesh(this.shared.turtleShell, this.turtleShellMaterial);
      shell.material.color.setHex(species.color);
      shell.scale.set(0.98,0.74,1.22); shell.position.set(0,0.10,0.03); root.add(shell);
      const rim = new THREE.Mesh(this.shared.turtleRim, this.material(0x485a3d,{roughness:0.92}));
      rim.rotation.x=Math.PI/2; rim.scale.set(1.0,1.22,1); rim.position.set(0,0.08,0.03); root.add(rim);
      const plastron = this.mesh(this.shared.sphere, belly, root, [0.66,0.16,0.91], [0,-0.16,0.04]);
      const neck = this.mesh(this.shared.sphere, main, root, [0.25,0.22,0.42], [0,-0.02,-0.83]);
      neck.rotation.x=-0.08;
      const head = this.mesh(this.shared.sphere, main, root, [0.31,0.27,0.40], [0,0.02,-1.12]);
      head.rotation.x=-0.10;
      const beak=this.mesh(this.shared.cone,belly,root,[0.11,0.18,0.10],[0,-0.08,-1.43]);beak.rotation.x=Math.PI/2;
      for (const side of [-1,1]) {
        const eye=this.mesh(this.shared.smallSphere,dark,root,[0.62,0.62,0.62],[side*0.235,0.12,-1.30]);
        const glint=this.mesh(this.shared.smallSphere,this.material(0xeaf5d8),root,[0.18,0.18,0.18],[side*0.26,0.15,-1.335]);
        for (const front of [-1,1]) {
          const flipper=this.mesh(this.shared.sphere, main, root, [0.24,0.12,0.62], [side*0.72,-0.015,front<0?-0.62:0.67]);
          flipper.rotation.y=side*0.42; flipper.rotation.x=front*0.18; wings.push(flipper);
          // Fine scaly ridges on the flippers create visible anatomy at close range.
          for(let ridge=0;ridge<3;ridge++){
            const line=this.mesh(this.shared.smallSphere,belly,root,[0.08,0.07,0.34],[side*(0.73+ridge*0.025),-0.035,front<0?-0.79+ridge*0.13:0.50+ridge*0.13]);
            line.rotation.y=side*0.42;
          }
        }
      }
      tail=this.mesh(this.shared.cone, main, root, [0.13,0.34,0.13], [0,-0.06,1.02]); tail.rotation.x=Math.PI/2;
    } else if (species.kind === 'manta') {
      this.mesh(this.shared.sphere, main, root, [0.72,0.17,1.2], [0,0,0]);
      this.mesh(this.shared.sphere, belly, root, [0.5,0.09,0.65], [0,-0.12,-0.05]);
      for (const side of [-1,1]) {
        const wing=this.mesh(this.shared.sphere, main, root, [1.35,0.075,0.74], [side*1.05,0,0.03]);
        wing.rotation.z=side*0.1; wings.push(wing);
      }
      tail=this.mesh(this.shared.cone, main, root, [0.12,1.2,0.12], [0,0,1.35]); tail.rotation.x=Math.PI/2;
    } else if (species.kind === 'whale') {
      this.mesh(this.shared.sphere, main, root, [1.12,0.88,2.2], [0,0,0]);
      this.mesh(this.shared.sphere, belly, root, [0.87,0.25,1.55], [0,-0.61,-0.05]);
      const head = this.mesh(this.shared.sphere, main, root, [1.05,0.72,0.95], [0,0.12,-1.45]);
      head.rotation.x=0.05;
      for (const side of [-1,1]) {
        const flipper=this.mesh(this.shared.sphere, main, root, [0.28,0.13,1.0], [side*0.92,-0.25,-0.1]);
        flipper.rotation.y=side*0.42; flipper.rotation.z=side*0.12; wings.push(flipper);
      }
      const tailFork = new THREE.Group(); tailFork.position.z=2.05; root.add(tailFork);
      for (const side of [-1,1]) {
        const l=this.mesh(this.shared.sphere, main, tailFork, [0.62,0.12,0.55], [side*0.48,0,0.2]);
        l.rotation.y=side*0.4; wings.push(l);
      }
      tail=tailFork;
    } else if (species.kind === 'leviathan') {
      this.mesh(this.shared.sphere, main, root, [1.0,0.88,2.75], [0,0,0]);
      this.mesh(this.shared.sphere, belly, root, [0.83,0.3,1.85], [0,-0.59,-0.1]);
      const jaw=this.mesh(this.shared.sphere, belly, root, [0.62,0.2,0.95], [0,-0.52,-1.95]); jaw.rotation.x=-0.15;
      for (const side of [-1,1]) {
        this.mesh(this.shared.smallSphere, glow, root, [1.35,1.35,1.35], [side*0.58,0.28,-2.15]);
        this.mesh(this.shared.sphere, dark, root, [0.12,0.1,0.16], [side*0.67,0.28,-2.28]);
        const fin=this.mesh(this.shared.sphere, main, root, [0.22,0.13,1.3], [side*0.83,-0.2,-0.15]); fin.rotation.y=side*0.45; wings.push(fin);
      }
      for (let i=0;i<8;i++) {
        const spine=this.mesh(this.shared.cone, glow, root, [0.16,rand(0.65,1.0),0.16], [0,0.78,0.95-i*0.42]);
        spine.rotation.x=-Math.PI/7;
      }
      tail=this.mesh(this.shared.cone, main, root, [0.6,1.35,0.5], [0,0.06,2.65]); tail.rotation.x=Math.PI/2;
    } else if (species.kind === 'seahorse') {
      this.mesh(this.shared.sphere, main, root, [0.35,0.7,0.3], [0,0.05,0]);
      const head=this.mesh(this.shared.sphere, main, root, [0.33,0.34,0.42], [0,0.62,-0.1]); head.rotation.x=-0.2;
      const snout=this.mesh(this.shared.cone, main, root, [0.13,0.5,0.13], [0.02,0.55,-0.5]); snout.rotation.x=Math.PI/2;
      const curl=this.mesh(this.shared.cone, main, root, [0.18,0.65,0.18], [0,-0.62,0.2]); curl.rotation.x=-Math.PI/2;
      tail=curl;
    } else {
      const elongated = species.kind === 'shark' || species.kind === 'hammerhead' || species.kind === 'predator';
      const bodyLen = elongated ? 1.75 : 1.25;
      this.mesh(this.shared.taperedBody, main, root, [elongated?1.12:1.18,elongated?0.88:1.08,bodyLen], [0,0,0]);
      this.mesh(this.shared.sphere, belly, root, [elongated?0.34:0.39,0.15,bodyLen*0.70], [0,-0.25,0.03]);
      // Layered gill covers add a recognizable anatomical break behind the head.
      for(const side of [-1,1]) for(let g=0;g<3;g++) {
        const slit=this.mesh(this.shared.sphere,dark,root,[0.022,0.105,0.022],[side*(elongated?0.36:0.39),-0.02,-0.42+g*0.13]);
      }
      if (species.kind === 'hammerhead') {
        const head=this.mesh(this.shared.sphere, main, root, [1.0,0.18,0.35], [0,0.03,-1.25]);
        for (const side of [-1,1]) this.mesh(this.shared.smallSphere, dark, root, [0.75,0.75,0.75], [side*0.87,0.11,-1.22]);
      } else {
        for (const side of [-1,1]) this.mesh(this.shared.smallSphere, dark, root, [0.75,0.75,0.75], [side*0.34,0.12,-0.78]);
      }
      const dorsal=this.mesh(this.shared.cone, main, root, [0.24,0.66,0.22], [0,0.46,-0.02]); dorsal.rotation.x=Math.PI/2;
      if (species.id === 'sulfur_masonfish') {
        // Warm sulphur-gold lateral bands and a darker dorsal saddle make this
        // cave-dwelling species readable even on Low graphics settings.
        const stripeMat=this.material(0x473a24,{roughness:0.78,metalness:0.04});
        const goldMat=this.material(0xffd75c,{roughness:0.56,emissive:0x634514,emissiveIntensity:0.26});
        for(let band=0;band<3;band++){
          const stripe=this.mesh(this.shared.sphere,stripeMat,root,[0.035,0.50,0.19],[0,0.02,-0.48+band*0.43]);
          stripe.rotation.x=-0.22;
        }
        for(const side of [-1,1]){
          this.mesh(this.shared.smallSphere,goldMat,root,[0.72,0.72,0.72],[side*0.29,0.14,-0.79]);
          const barb=this.mesh(this.shared.cone,goldMat,root,[0.08,0.30,0.08],[side*0.30,0.35,0.30]);barb.rotation.x=Math.PI/2;
        }
      }
      const anal=this.mesh(this.shared.cone,main,root,[0.18,0.38,0.16],[0,-0.34,0.62]); anal.rotation.x=-Math.PI/2;
      for(const side of [-1,1]) {
        const fin=this.mesh(this.shared.pectoralFin,main,root,[0.62,0.72,0.30],[side*0.34,-0.1,-0.06]);
        fin.rotation.z=side*0.72; fin.rotation.x=Math.PI/2; fin.userData.baseZ=fin.rotation.z; wings.push(fin);
      }
      if (species.kind==='angler') {
        const stalk=this.mesh(this.shared.tentacle, main, root, [1,0.72,1], [0,0.75,-0.62]); stalk.rotation.x=-0.45;
        this.mesh(this.shared.smallSphere, glow, root, [2.2,2.2,2.2], [0,1.08,-0.88]);
      }
      tail=new THREE.Group(); tail.position.z=bodyLen*0.82; root.add(tail);
      const peduncle=this.mesh(this.shared.sphere,main,tail,[0.16,0.17,0.38],[0,0,0.22]);
      const caudal=new THREE.Mesh(this.shared.tailFin,main); caudal.position.set(0,0,0.42); tail.add(caudal);
      for (const side of [-1,1]) {
        const fin=this.mesh(this.shared.cone, main, root, [0.16,0.55,0.14], [side*0.42,-0.1,-0.15]); fin.rotation.z=side*0.95; fin.rotation.x=Math.PI/2; wings.push(fin);
      }
    }
    root.scale.setScalar(species.scale);
    return { group:root, tail, wings, species };
  }

  chooseSpecies(depth, biomeId = this.currentBiome) {
    const habitatIds = BIOME_SPECIES[biomeId] || BIOME_SPECIES.open;
    const candidates = SPECIES.filter(s => depth <= s.depth[0] && depth >= s.depth[1] && habitatIds.includes(s.id));
    let pool = candidates.length ? candidates : SPECIES.filter(s => depth <= s.depth[0] && depth >= s.depth[1]);
    // Surface-edge or unusually deep spawn positions can fall outside every species band.
    // Fall back to the closest valid depth band so population spawning never dereferences undefined.
    if (!pool.length) {
      const nearestDistance = Math.min(...SPECIES.map(s => Math.min(Math.abs(depth - s.depth[0]), Math.abs(depth - s.depth[1]), depth < s.depth[1] ? s.depth[1] - depth : depth > s.depth[0] ? depth - s.depth[0] : 0)));
      pool = SPECIES.filter(s => Math.min(Math.abs(depth - s.depth[0]), Math.abs(depth - s.depth[1]), depth < s.depth[1] ? s.depth[1] - depth : depth > s.depth[0] ? depth - s.depth[0] : 0) <= nearestDistance + 0.001);
    }
    if (!pool.length) pool = SPECIES.filter(s => habitatIds.includes(s.id));
    if (!pool.length) pool = SPECIES;
    const total = pool.reduce((sum, s) => sum + s.weight, 0) || pool.length;
    let pick = Math.random() * total;
    for (const species of pool) { pick -= species.weight || 1; if (pick <= 0) return species; }
    return pool[pool.length - 1];
  }

  spawnOne(playerPosition, forceRare = false) {
    const angle=rand(0,Math.PI*2), distance=rand(26,118);
    const x=playerPosition.x+Math.cos(angle)*distance;
    const z=playerPosition.z+Math.sin(angle)*distance;
    let depth=clamp(playerPosition.y-rand(-3,22),-290,-4);
    // Spawn above the real local seabed; never create fauna inside the trench floor
    // or on the far side of a sloping shelf.
    const spawnFloor=this.terrainHeight(x,z);
    depth=clamp(depth, Math.min(-4,spawnFloor+1.4), -4);
    let species;
    if (forceRare && depth < -190 && Math.random()<0.012) species=SPECIES.find(s=>s.id==='trench_leviathan');
    else if (forceRare && depth < -135 && Math.random()<0.022) species=SPECIES.find(s=>s.id==='abyssal_leviathan');
    else species=this.chooseSpecies(depth, this.currentBiome);
    let nestPosition = null;
    if (species?.id === 'sulfur_masonfish') {
      const nest = SULFUR_NEST_SITES.reduce((best, site) => {
        const d = Math.hypot(site.x-playerPosition.x, site.z-playerPosition.z);
        return !best || d < best.distance ? {site,distance:d} : best;
      }, null)?.site;
      if (nest) {
        nestPosition = {x:nest.x,y:nest.y,z:nest.z};
        const nestAngle = rand(0,Math.PI*2), nestRadius = rand(3.5,10.5);
        const nx = nest.x + Math.cos(nestAngle)*nestRadius;
        const nz = nest.z + Math.sin(nestAngle)*nestRadius;
        const floor = this.terrainHeight(nx,nz);
        depth = clamp(nest.y + rand(-3,3), Math.min(-4,floor+2), -4);
        const model=this.createModel(species);
        model.group.position.set(nx,depth,nz);
        this.scene.add(model.group);
        this.animals.push({ ...model, instanceId:`${species.id}:${++this.spawnSerial}`, species, nestPosition, velocity:rand(0.55,0.9), direction:nestAngle+Math.PI, phase:rand(0,Math.PI*2), attackCooldown:rand(1,3), roamTimer:rand(1,4) });
        return;
      }
    }
    // Keep giant life at a readable distance so it appears as a discovery, not a surprise collision.
    if (species.kind==='leviathan' || species.kind==='whale') {
      const farAngle=rand(0,Math.PI*2), far=rand(85,150);
      const model=this.createModel(species);
      const farX=playerPosition.x+Math.cos(farAngle)*far;
      const farZ=playerPosition.z+Math.sin(farAngle)*far;
      const farFloor=this.terrainHeight(farX,farZ);
      const farDepth=clamp(depth,Math.min(-4,farFloor+species.scale*0.55+1),-4);
      model.group.position.set(farX,farDepth,farZ);
      this.scene.add(model.group);
      this.animals.push({ ...model, instanceId:`${species.id}:${++this.spawnSerial}`, species, velocity:rand(0.65,1.25), direction:farAngle+Math.PI, phase:rand(0,Math.PI*2), attackCooldown:rand(1,4), roamTimer:rand(2,8) });
      return;
    }
    const model=this.createModel(species);
    model.group.position.set(x,depth,z);
    this.scene.add(model.group);
    this.animals.push({ ...model, instanceId:`${species.id}:${++this.spawnSerial}`, species, velocity:rand(0.72,1.3), direction:angle+Math.PI, phase:rand(0,Math.PI*2), attackCooldown:rand(1,3), roamTimer:rand(1,5) });
  }

  ensurePopulation(playerPosition) {
    const radius=this.quality==='low'?165:this.quality==='high'?235:200;
    for (let i=this.animals.length-1;i>=0;i--) {
      const animal=this.animals[i];
      const distance=animal.group.position.distanceTo(playerPosition);
      if (distance>radius+45) {
        this.scene.remove(animal.group);
        this.animals.splice(i,1);
      }
    }
    const target=QUALITY_COUNTS[this.quality] || 20;
    while (this.animals.length>target) {
      const removed=this.animals.pop();
      this.scene.remove(removed.group);
    }
    while (this.animals.length<target) this.spawnOne(playerPosition,true);
  }

  update(dt, playerPosition, biomeId = this.currentBiome) {
    this.setBiome(biomeId);
    this.lastReplenish-=dt;
    if (this.lastReplenish<=0) { this.lastReplenish=1.8; this.ensurePopulation(playerPosition); }
    let nearest=null, nearestDistance=Infinity;
    for (const animal of this.animals) {
      const species=animal.species;
      const pos=animal.group.position;
      const dx=playerPosition.x-pos.x, dy=playerPosition.y-pos.y, dz=playerPosition.z-pos.z;
      const dist=Math.hypot(dx,dy,dz);
      if (dist<nearestDistance) { nearestDistance=dist; nearest={ species, distance:dist }; }
      animal.roamTimer-=dt;
      const aggro=species.aggro||0;
      if (species.hostile && dist<aggro && dist>4.5) {
        const desired=Math.atan2(-dx,-dz);
        let diff=desired-animal.group.rotation.y;
        while(diff>Math.PI)diff-=Math.PI*2; while(diff<-Math.PI)diff+=Math.PI*2;
        animal.group.rotation.y+=diff*Math.min(1,dt*1.6);
        animal.direction=animal.group.rotation.y;
        const speed=(species.kind==='leviathan')?species.speed:species.speed*0.78;
        pos.x+=Math.sin(animal.direction)*speed*dt;
        pos.z-=Math.cos(animal.direction)*speed*dt;
        pos.y+=clamp(dy,-4,4)*0.22*dt;
      } else {
        if (animal.nestPosition) {
          const homeDX=animal.nestPosition.x-pos.x, homeDZ=animal.nestPosition.z-pos.z;
          const homeDistance=Math.hypot(homeDX,homeDZ);
          if(homeDistance>8){ animal.direction=Math.atan2(homeDX,-homeDZ); animal.roamTimer=0.9; }
          else if (animal.roamTimer<=0) { animal.direction+=rand(-0.45,0.45); animal.roamTimer=rand(2.0,3.8); }
          // Sulfur Masonfish repeatedly circles its nest and nudges its mineral bed.
          animal.nestActivity=(animal.nestActivity||0)+dt;
          animal.nestPulse=0.5+0.5*Math.sin(animal.nestActivity*1.4);
        } else if (animal.roamTimer<=0) { animal.direction+=rand(-0.85,0.85); animal.roamTimer=rand(2.5,7); }
        const targetYaw=animal.direction;
        animal.group.rotation.y+=((targetYaw-animal.group.rotation.y+Math.PI*3)%(Math.PI*2)-Math.PI)*Math.min(1,dt*1.2);
        const speed=species.speed*animal.velocity;
        pos.x+=Math.sin(animal.direction)*speed*dt;
        pos.z-=Math.cos(animal.direction)*speed*dt;
        if(animal.nestPosition){
          const homeDistance=Math.hypot(animal.nestPosition.x-pos.x,animal.nestPosition.z-pos.z);
          if(homeDistance>9){pos.x+=(animal.nestPosition.x-pos.x)*Math.min(1,dt*1.15);pos.z+=(animal.nestPosition.z-pos.z)*Math.min(1,dt*1.15);}
        }
        if (species.kind==='jelly' || species.kind==='whale' || species.kind==='leviathan') pos.y+=Math.sin((animal.phase+=dt)*0.7)*dt*(species.kind==='jelly'?1.2:0.35);
        else pos.y+=Math.sin((animal.phase+=dt)*1.15)*dt*0.22;
      }
      const wave=Math.sin((animal.phase+=dt*2.2))*0.19;
      if (animal.tail && animal.tail.rotation) {
        animal.tail.rotation.y=wave*1.55;
        if(species.kind==='whale') animal.tail.rotation.x=Math.sin(animal.phase*0.65)*0.13;
      }
      if (species.kind==='manta' && animal.wings.length) {
        animal.wings[0].rotation.z=Math.sin(animal.phase)*0.25+0.1;
        animal.wings[1].rotation.z=-Math.sin(animal.phase)*0.25-0.1;
      } else if(species.kind==='whale') {
        for(let i=0;i<Math.min(2,animal.wings.length);i++) animal.wings[i].rotation.x=Math.sin(animal.phase*0.75+i)*0.08;
      } else if(species.kind==='turtle') {
        animal.wings.forEach((fin,i)=>{ fin.rotation.x=Math.sin(animal.phase*1.8+i)*0.22; fin.rotation.z=Math.sin(animal.phase*1.2+i)*0.12; });
      } else if(species.kind==='squid') {
        animal.wings.forEach((arm,i)=>{ arm.rotation.x=Math.sin(animal.phase*1.35+i*0.8)*0.12; arm.rotation.z=Math.cos(animal.phase*1.15+i*0.7)*0.15; });
      } else if(species.kind==='jelly') {
        const pulse=1+Math.sin(animal.phase*1.8)*0.09;
        animal.group.scale.setScalar(species.scale*pulse);
      } else if(animal.wings.length) {
        animal.wings.forEach((fin,i)=>{ fin.rotation.z=(fin.userData.baseZ||0)+Math.sin(animal.phase*1.25+i*0.9)*0.075*(i%2?1:-1); });
      }
      // Keep marine life inside its species depth band and the local water column.
      const seabed=this.terrainHeight(pos.x,pos.z);
      const clearance=Math.max(1.0,species.scale*0.52);
      pos.y=clampFaunaDepth(pos.y,seabed,clearance,species.depth);
      if (species.hostile && dist<5.4 && animal.attackCooldown<=0) {
        animal.attackCooldown=species.id==='abyssal_leviathan'?3.8:2.7;
        this.onAttack(species.damage||8,species.name);
      } else animal.attackCooldown-=dt;
    }
    return { count:this.animals.length, nearest:nearest&&nearestDistance<95?nearest:null, threat:this.animals.filter(a=>a.species.hostile).reduce((best,a)=>{const d=a.group.position.distanceTo(playerPosition);return d<(best?.distance??Infinity)?{name:a.species.name,distance:d}:best;},null) };
  }

  resolvePlayerCollision(position) {
    // Large fauna have a soft body boundary; small fish remain non-blocking to preserve flow.
    for (const animal of this.animals) {
      const species=animal.species;
      if (species.scale < 1.35 && species.kind !== 'leviathan') continue;
      const dx=position.x-animal.group.position.x;
      const dz=position.z-animal.group.position.z;
      const distance=Math.hypot(dx,dz) || 0.001;
      const radius=Math.max(1.05,species.scale*0.48+0.7);
      if (distance < radius && Math.abs(position.y-animal.group.position.y) < species.scale*0.72+1.2) {
        const push=(radius-distance)*0.72;
        position.x += dx/distance*push;
        position.z += dz/distance*push;
      }
    }
  }

  /** Non-mutating counterpart used by the HUD to show Attack only for a valid aimed target. */
  getAttackTarget(playerPosition, origin, direction, range = 3.4) {
    let best = null;
    let bestScore = -Infinity;
    for (const animal of this.animals) {
      const offset = animal.group.position.clone().sub(origin);
      const distance = offset.length();
      if (distance < 0.45 || distance > range + animal.species.scale * 0.32) continue;
      const alignment = direction.dot(offset.normalize());
      if (alignment < 0.76) continue;
      const score = alignment - distance * 0.035;
      if (score > bestScore) { best = animal; bestScore = score; }
    }
    if (!best) return null;
    return { instanceId:best.instanceId, id:best.species.id, name:best.species.name, distance:best.group.position.distanceTo(origin), position:best.group.position.clone(), hostile:Boolean(best.species.hostile), speciesKind:best.species.kind };
  }

  /** Directional close-range knife attack. Small fauna can be dispatched; larger life is injured and flees. */
  attackTarget(playerPosition, origin, direction, range = 3.4, damage = 24) {
    const target=this.getAttackTarget(playerPosition,origin,direction,range);
    if (!target) return null;
    const best=this.animals.find(animal=>animal.instanceId===target.instanceId);
    if (!best) return null;

    const species = best.species;
    const position = best.group.position.clone();
    const healthMax = Math.max(24, Math.round(species.scale * (species.hostile ? 42 : 30)));
    best.health = Number.isFinite(best.health) ? best.health : healthMax;
    best.health = Math.max(0, best.health - damage);
    const away = best.group.position.clone().sub(playerPosition);
    best.direction = Math.atan2(away.x, -away.z);
    best.group.rotation.y = best.direction;
    best.velocity = Math.max(best.velocity || 1, 1.35);
    best.roamTimer = Math.max(best.roamTimer || 0, 3.2);
    best.attackCooldown = Math.max(best.attackCooldown || 0, 2.4);

    const result = {
      id: species.id,
      name: species.name,
      position,
      health: best.health,
      healthMax,
      killed: best.health <= 0,
      hostile: Boolean(species.hostile),
      speciesKind: species.kind
    };
    if (result.killed) {
      this.scene.remove(best.group);
      const index = this.animals.indexOf(best);
      if (index >= 0) this.animals.splice(index, 1);
    }
    return result;
  }

  getHarvestTarget(playerPosition, range=6.5, aim=null) {
    let best=null, bestDistance=range, bestScore=-Infinity;
    for(const animal of this.animals){
      const species=animal.species;
      // Only small, non-hostile fish can be caught in this early survival build.
      // Large fauna, protected wildlife and predators remain scan-only.
      if(species.kind!=='fish' || species.hostile || species.scale>0.85) continue;
      const position=animal.group.position;
      const distance=position.distanceTo(playerPosition);
      if(distance>=bestDistance)continue;
      let alignment=1;
      if(aim?.origin&&aim?.direction){
        const direction=position.clone().sub(aim.origin);
        if(direction.length()>range)continue;
        alignment=aim.direction.dot(direction.normalize());
        if(alignment<(aim.minAlignment??0.945))continue;
      }
      const score=alignment-distance*0.001;
      if(score>bestScore){bestDistance=distance;bestScore=score;best={id:animal.instanceId || species.id,speciesId:species.id,name:species.name,distance,position:position.clone()};}
    }
    return best;
  }

  harvestNearest(playerPosition, range=6.5, targetId=null) {
    // Prefer the exact instance aimed at. A species-only fallback is retained
    // for older callers, but always selects the nearest individual of that species.
    let index=-1;
    if (targetId) {
      index=this.animals.findIndex(animal=>animal.instanceId===targetId && animal.group.position.distanceTo(playerPosition)<=range);
      if(index<0) {
        let nearest=Infinity;
        this.animals.forEach((animal,i)=>{
          const distance=animal.group.position.distanceTo(playerPosition);
          if(animal.species.id===targetId && distance<=range && distance<nearest){nearest=distance;index=i;}
        });
      }
    } else {
      const target=this.getHarvestTarget(playerPosition,range);
      if(target) index=this.animals.findIndex(animal=>animal.instanceId===target.id);
    }
    if(index<0)return null;
    const animal=this.animals[index];
    const position=animal.group.position.clone();
    this.scene.remove(animal.group);
    this.animals.splice(index,1);
    return {id:animal.species.id,instanceId:animal.instanceId,name:animal.species.name,position};
  }

  getScanTarget(playerPosition, range=58, aim=null) {
    let best=null, bestDistance=range, bestScore=-Infinity;
    for (const animal of this.animals) {
      const position=animal.group.position;
      const distance=position.distanceTo(playerPosition);
      if (distance>=bestDistance) continue;
      let alignment=1;
      if (aim?.origin && aim?.direction) {
        const direction=position.clone().sub(aim.origin);
        if (direction.length()>range) continue;
        alignment=aim.direction.dot(direction.normalize());
        if (alignment<(aim.minAlignment??0.94545)) continue;
      }
      const score=alignment-distance*0.001;
      if (score>bestScore) { bestDistance=distance; bestScore=score; best={id:animal.species.id,name:animal.species.name,kind:animal.species.kind,distance,position:position.clone()}; }
    }
    return best;
  }

  scan(playerPosition, range=58, aim=null) {
    const target=this.getScanTarget(playerPosition,range,aim);
    if (!target) return null;
    const isNew=!this.discovered.has(target.id);
    this.discovered.add(target.id);
    return { ...target, distance:Math.round(target.distance), isNew, total:this.discovered.size, maximum:SPECIES.length };
  }

  dispose() {
    for (const animal of this.animals) this.scene.remove(animal.group);
    this.animals.length=0;
    for (const geometry of Object.values(this.shared)) geometry.dispose();
    for (const material of this.materials.values()) material.dispose();
    this.materials.clear();
    this.scaleTexture.dispose(); this.scaleBumpTexture.dispose();
    this.turtleShellMaterial.dispose();
    this.turtleShellTexture.dispose(); this.turtleShellBumpTexture.dispose();
  }
}

export const FAUNA_SPECIES_COUNT = SPECIES.length;
