const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

export function normalizeRoomCode(value) {
  return String(value ?? '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
}

export function sanitizeChatText(value) {
  return String(value ?? '')
    .replace(/[\r\n\t]+/g, ' ')
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '')
    .trim()
    .replace(/\s+/g, ' ')
    .slice(0, 180);
}

export function sanitizeDisplayName(value, fallback = 'Diver') {
  const name = String(value ?? '').replace(/[\u0000-\u001f\u007f<>]/g, '').trim().replace(/\s+/g, ' ').slice(0, 24);
  return name || fallback;
}

export function sanitizePlayerState(value) {
  if (!value || typeof value !== 'object') return null;
  const userId = String(value.userId ?? '').slice(0, 80);
  const number = input => Number.isFinite(Number(input)) ? Number(input) : null;
  const x = number(value.x), y = number(value.y), z = number(value.z);
  const yaw = number(value.yaw), pitch = number(value.pitch);
  if (!userId || x === null || y === null || z === null || yaw === null || pitch === null) return null;
  if (Math.abs(x) > 250000 || Math.abs(z) > 250000 || y < -320 || y > 100) return null;
  return {
    userId,
    displayName: sanitizeDisplayName(value.displayName),
    x: clamp(x, -250000, 250000),
    y: clamp(y, -320, 100),
    z: clamp(z, -250000, 250000),
    yaw: clamp(yaw, -Math.PI * 100, Math.PI * 100),
    pitch: clamp(pitch, -1.3, 1.3),
    depth: clamp(number(value.depth) ?? Math.max(0, -y), 0, 10000),
    biome: String(value.biome ?? 'open').replace(/[^a-z0-9_-]/gi, '').slice(0, 24),
    tool: String(value.tool ?? '').replace(/[^a-z0-9_-]/gi, '').slice(0, 32),
    sentAt: clamp(number(value.sentAt) ?? Date.now(), 0, Date.now() + 60000)
  };
}

export function flattenPresence(presenceState) {
  if (!presenceState || typeof presenceState !== 'object') return [];
  const found = new Map();
  for (const [key, entries] of Object.entries(presenceState)) {
    const values = Array.isArray(entries) ? entries : [entries];
    for (const entry of values) {
      if (!entry || typeof entry !== 'object') continue;
      const userId = String(entry.user_id ?? entry.userId ?? key).slice(0, 80);
      if (!userId) continue;
      found.set(userId, {
        userId,
        displayName: sanitizeDisplayName(entry.display_name ?? entry.displayName)
      });
    }
  }
  return [...found.values()];
}


const WORLD_EVENT_TYPES = new Set([
  'resource_collected', 'structure_placed', 'cache_collected',
  'fauna_scanned', 'biome_discovered', 'mission_completed'
]);
const STRUCTURE_TYPES = new Set(['compartment', 'foundation', 'storage_locker', 'solar_array', 'beacon']);

/** Strict allow-list for persistent co-op world events. */
export function sanitizeWorldEventInput(eventType, entityId, rawPayload = {}) {
  const type = String(eventType || '');
  const id = String(entityId || '').replace(/[^A-Za-z0-9:_-]/g, '').slice(0, 120);
  if (!WORLD_EVENT_TYPES.has(type) || !id) return null;
  const payload = rawPayload && typeof rawPayload === 'object' && !Array.isArray(rawPayload) ? rawPayload : {};
  const safeNumber = (key, min, max) => {
    const raw = payload[key];
    if (typeof raw !== 'number' && typeof raw !== 'string') return null;
    if (typeof raw === 'string' && raw.trim() === '') return null;
    const value = Number(raw);
    return Number.isFinite(value) && value >= min && value <= max ? value : null;
  };
  let clean = {};
  if (type === 'resource_collected') {
    if (typeof payload.type !== 'string') return null;
    const resourceType = payload.type.replace(/[^a-z0-9_-]/gi, '').slice(0, 32);
    if (!resourceType) return null;
    clean = { type: resourceType };
  } else if (type === 'structure_placed') {
    const structureType = typeof payload.type === 'string' ? payload.type : '';
    const x = safeNumber('x', -250000, 250000), y = safeNumber('y', -320, 100), z = safeNumber('z', -250000, 250000), yaw = safeNumber('yaw', -100, 100);
    if (!STRUCTURE_TYPES.has(structureType) || [x,y,z,yaw].some(value => value === null)) return null;
    clean = { type: structureType, x, y, z, yaw };
  } else if (type === 'cache_collected') {
    const cacheId = String(payload.cacheId || id).replace(/[^a-z0-9_-]/gi, '').slice(0, 80);
    if (!cacheId) return null;
    clean = { cacheId };
  } else if (type === 'fauna_scanned') {
    const speciesId = String(payload.speciesId || id).replace(/[^a-z0-9_-]/gi, '').slice(0, 64);
    if (!speciesId) return null;
    clean = { speciesId };
  } else if (type === 'biome_discovered') {
    const biomeId = String(payload.biomeId || id).replace(/[^a-z0-9_-]/gi, '').slice(0, 32);
    if (!biomeId) return null;
    clean = { biomeId };
  } else if (type === 'mission_completed') {
    const missionId = String(payload.missionId || id).replace(/[^a-z0-9_-]/gi, '').slice(0, 64);
    if (!missionId) return null;
    clean = { missionId };
  }
  if (JSON.stringify(clean).length > 4096) return null;
  return { eventType: type, entityId: id, payload: clean };
}

export function normalizeWorldEvent(row) {
  if (!row || typeof row !== 'object') return null;
  const clean = sanitizeWorldEventInput(row.event_type ?? row.eventType, row.entity_id ?? row.entityId, row.payload);
  const eventId = Number(row.event_id ?? row.eventId);
  const actorId = String(row.actor_id ?? row.actorId ?? '').slice(0, 80);
  if (!clean || !Number.isSafeInteger(eventId) || eventId < 1 || !actorId) return null;
  const date = new Date(row.created_at ?? row.createdAt ?? Date.now());
  return { ...clean, eventId, actorId, createdAt: Number.isNaN(date.getTime()) ? new Date().toISOString() : date.toISOString() };
}

export function validatePublicBackendConfig(rawUrl, rawKey) {
  const url = String(rawUrl ?? '').trim().replace(/\/$/, '');
  const key = String(rawKey ?? '').trim();
  if (!url || !key) throw new Error('Project URL dan Publishable Key harus diisi.');
  let parsed;
  try { parsed = new URL(url); } catch { throw new Error('Project URL tidak valid.'); }
  if (parsed.protocol !== 'https:' || parsed.username || parsed.password || parsed.search || parsed.hash || (parsed.pathname && parsed.pathname !== '/')) {
    throw new Error('Project URL harus berupa URL HTTPS tanpa path, query, atau kredensial.');
  }
  if (/^sb_secret_/i.test(key) || /service_role/i.test(key)) {
    throw new Error('Kunci secret/service_role tidak boleh digunakan di aplikasi. Gunakan Publishable Key.');
  }
  let isPublic = key.startsWith('sb_publishable_') && key.length > 20;
  const parts = key.split('.');
  if (parts.length === 3) {
    try {
      const segment = parts[1].replace(/-/g, '+').replace(/_/g, '/');
      const padded = segment.padEnd(Math.ceil(segment.length / 4) * 4, '=');
      const decoded = typeof atob === 'function'
        ? atob(padded)
        : (typeof Buffer !== 'undefined' ? Buffer.from(padded, 'base64').toString('utf8') : '');
      const payload = JSON.parse(decoded);
      if (payload.role === 'service_role') throw new Error('Kunci service_role terdeteksi.');
      isPublic = payload.role === 'anon';
    } catch (error) {
      if (String(error?.message || '').includes('service_role')) throw error;
      isPublic = false;
    }
  }
  if (!isPublic) throw new Error('Key tidak dikenali. Gunakan Supabase Publishable Key (sb_publishable_...) atau legacy anon key.');
  return { url: parsed.origin, publishableKey: key };
}
