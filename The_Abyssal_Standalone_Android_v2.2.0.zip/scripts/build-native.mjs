import { cp, mkdir, readFile, rm } from 'node:fs/promises';
import { resolve } from 'node:path';
import { build } from 'vite';
import './configure-backend.mjs';

const root = resolve(process.cwd());
const publicDir = resolve(root, 'public');
const outputDir = resolve(root, 'www');

// Copy browser-only static files into Vite's public directory. Android does not
// rely on these files for offline gameplay; its executable modules are bundled.
await rm(publicDir, { recursive: true, force: true });
await mkdir(resolve(publicDir, 'icons'), { recursive: true });
await cp(resolve(root, 'manifest.webmanifest'), resolve(publicDir, 'manifest.webmanifest'));
await cp(resolve(root, 'sw.js'), resolve(publicDir, 'sw.js'));
await cp(resolve(root, 'icons'), resolve(publicDir, 'icons'), { recursive: true });

await build({ configFile: resolve(root, 'vite.config.js') });

const html = await readFile(resolve(outputDir, 'index.html'), 'utf8');
if (html.includes('importmap') || /cdn\.jsdelivr\.net|unpkg\.com/.test(html)) {
  throw new Error('Build audit failed: HTML still contains a remote module import map.');
}
if (!html.includes('./assets/') && !html.includes('/assets/')) {
  throw new Error('Build audit failed: Vite did not generate local bundled assets.');
}
console.log('Standalone bundle ready: game modules and runtime dependencies are packaged locally in www/.');
console.log('No Netlify deployment or runtime CDN is required by the Android APK.');
