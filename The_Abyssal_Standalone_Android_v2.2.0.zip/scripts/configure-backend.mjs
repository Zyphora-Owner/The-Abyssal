/**
 * Validate optional Supabase runtime settings before a web or Android build.
 * Only HTTPS project URLs and public publishable/legacy anon keys are allowed.
 * Never bundle a Supabase secret or service_role key into a client application.
 */
const url = String(process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL || '').trim().replace(/\/$/, '');
const key = String(
  process.env.VITE_SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_PUBLISHABLE_KEY ||
  process.env.VITE_SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KEY || ''
).trim();

if (url) {
  let parsed;
  try { parsed = new URL(url); } catch { throw new Error('VITE_SUPABASE_URL bukan URL yang valid.'); }
  if (parsed.protocol !== 'https:' || parsed.username || parsed.password || parsed.search || parsed.hash || parsed.pathname !== '/') {
    throw new Error('VITE_SUPABASE_URL harus berupa URL HTTPS project Supabase tanpa path, query, atau kredensial.');
  }
}
if ((url && !key) || (!url && key)) {
  throw new Error('Konfigurasi Supabase belum lengkap. Isi URL dan publishable key sekaligus, atau kosongkan keduanya untuk build offline.');
}
if (/^sb_secret_/i.test(key) || /service_role/i.test(key)) {
  throw new Error('Kunci Supabase secret/service_role tidak boleh dimasukkan ke aplikasi. Gunakan publishable key.');
}
if (key && /YOUR_PROJECT_REF|REPLACE_WITH_YOUR_KEY/i.test(`${url} ${key}`)) {
  throw new Error('Ganti nilai contoh pada .env.example dengan URL dan publishable key dari proyek Supabase milikmu.');
}
let isPublicKey = key.startsWith('sb_publishable_') && key.length > 20;
if (key.split('.').length === 3) {
  try {
    const payload = JSON.parse(Buffer.from(key.split('.')[1], 'base64url').toString('utf8'));
    if (payload.role === 'service_role') throw new Error('Kunci service_role terdeteksi. Jangan pernah membundelnya dalam APK.');
    isPublicKey = payload.role === 'anon';
  } catch (error) {
    if (String(error?.message || '').includes('service_role')) throw error;
    isPublicKey = false;
  }
}
if (key && !isPublicKey) {
  throw new Error('Key tidak dikenali sebagai Supabase publishable key atau legacy anon key. Salin key publik dari dashboard proyek Supabase.');
}
if (url && key) {
  console.log('[The Abyssal] Supabase project URL and public key detected. Multiplayer will be enabled in the build.');
} else {
  console.warn('[The Abyssal] Supabase credentials are not configured. This build remains single-player; login and multiplayer stay disabled until configured.');
}
