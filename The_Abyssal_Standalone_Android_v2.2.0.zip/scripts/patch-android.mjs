import { readFile, writeFile, readdir, copyFile, access, mkdir } from 'node:fs/promises';
import { join } from 'node:path';

const manifestPath = 'android/app/src/main/AndroidManifest.xml';
let manifest = await readFile(manifestPath, 'utf8');

for (const permission of ['android.permission.INTERNET', 'android.permission.ACCESS_NETWORK_STATE']) {
  const escaped = permission.replaceAll('.', '\\.');
  if (!new RegExp(`<uses-permission\\s+android:name="${escaped}"`).test(manifest)) {
    manifest = manifest.replace('<application', `    <uses-permission android:name="${permission}" />\n\n    <application`);
  }
}

const activityMatch = manifest.match(/<activity\b[^>]*android:name="[^"]*MainActivity"[^>]*>[\s\S]*?<\/activity>/);
if (!activityMatch) throw new Error('MainActivity tidak ditemukan di AndroidManifest.xml');
let activity = activityMatch[0];
const openEnd = activity.indexOf('>') + 1;
let activityOpen = activity.slice(0, openEnd);
if (!/android:screenOrientation=/.test(activityOpen)) {
  activityOpen = activityOpen.replace('<activity', '<activity android:screenOrientation="landscape"');
} else {
  activityOpen = activityOpen.replace(/android:screenOrientation="[^"]*"/, 'android:screenOrientation="landscape"');
}
if (!/android:launchMode=/.test(activityOpen)) {
  activityOpen = activityOpen.replace('<activity', '<activity android:launchMode="singleTask"');
}
if (!/android:exported=/.test(activityOpen)) {
  activityOpen = activityOpen.replace('<activity', '<activity android:exported="true"');
}
if (!/android:windowSoftInputMode=/.test(activityOpen)) {
  activityOpen = activityOpen.replace('<activity', '<activity android:windowSoftInputMode="adjustPan"');
} else {
  activityOpen = activityOpen.replace(/android:windowSoftInputMode="[^"]*"/, 'android:windowSoftInputMode="adjustPan"');
}
activity = activityOpen + activity.slice(openEnd);

// Remove any legacy authentication callback intent filter; this release is offline single-player.
activity = activity.replace(/\s*<intent-filter>[\s\S]*?<data android:scheme="theabyssal"[\s\S]*?<\/intent-filter>/g, '');
manifest = manifest.replace(activityMatch[0], activity);

// Install the branded launcher icon in the native Android resource tree.
// Capacitor does not turn the PWA manifest icons into Android launcher
// resources automatically, so this is applied after every cap add/sync.
const androidRes = 'android/app/src/main/res';
for (const density of ['mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi']) {
    const sourceDir = `native/android-icons/mipmap-${density}`;
    const targetDir = `${androidRes}/mipmap-${density}`;
    await mkdir(targetDir, { recursive: true });
    await copyFile(`${sourceDir}/ic_launcher.png`, `${targetDir}/ic_launcher.png`);
    await copyFile(`${sourceDir}/ic_launcher_round.png`, `${targetDir}/ic_launcher_round.png`);
}
const adaptiveDir = `${androidRes}/mipmap-anydpi-v26`;
await mkdir(adaptiveDir, { recursive: true });
await copyFile('native/android-icons/mipmap-anydpi-v26/ic_launcher.xml', `${adaptiveDir}/ic_launcher.xml`);
await copyFile('native/android-icons/mipmap-anydpi-v26/ic_launcher_round.xml', `${adaptiveDir}/ic_launcher_round.xml`);
const drawableDir = `${androidRes}/drawable-nodpi`;
await mkdir(drawableDir, { recursive: true });
await copyFile('native/android-icons/ic_launcher_foreground.png', `${drawableDir}/ic_launcher_foreground.png`);
const valuesDir = `${androidRes}/values`;
await mkdir(valuesDir, { recursive: true });
await copyFile('native/android-icons/abyssal_launcher_colors.xml', `${valuesDir}/abyssal_launcher_colors.xml`);

const applicationTag = manifest.match(/<application\b[^>]*>/);
if (!applicationTag) throw new Error('Tag <application> tidak ditemukan di AndroidManifest.xml');
let updatedApplicationTag = applicationTag[0];
if (/android:icon=/.test(updatedApplicationTag)) {
    updatedApplicationTag = updatedApplicationTag.replace(/android:icon="[^"]*"/, 'android:icon="@mipmap/ic_launcher"');
} else {
    updatedApplicationTag = updatedApplicationTag.replace('<application', '<application android:icon="@mipmap/ic_launcher"');
}
if (/android:roundIcon=/.test(updatedApplicationTag)) {
    updatedApplicationTag = updatedApplicationTag.replace(/android:roundIcon="[^"]*"/, 'android:roundIcon="@mipmap/ic_launcher_round"');
} else {
    updatedApplicationTag = updatedApplicationTag.replace('<application', '<application android:roundIcon="@mipmap/ic_launcher_round"');
}
manifest = manifest.replace(applicationTag[0], updatedApplicationTag);
console.log('Horror leviathan launcher icon installed for PWA and native Android (legacy + adaptive densities).');

await writeFile(manifestPath, manifest);

async function findMainActivity(dir) {
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const path = join(dir, entry.name);
    if (entry.isDirectory()) {
      const found = await findMainActivity(path);
      if (found) return found;
    } else if (entry.name === 'MainActivity.java' || entry.name === 'MainActivity.kt') return path;
  }
  return null;
}

const sourcePath = await findMainActivity('android/app/src/main/java');
if (!sourcePath) throw new Error('MainActivity.java / MainActivity.kt tidak ditemukan');
const original = await readFile(sourcePath, 'utf8');
const packageLine = original.match(/^package\s+[^;\n]+;?/m)?.[0]?.trim();
if (!packageLine) throw new Error('Package MainActivity tidak terbaca');

let source;
if (sourcePath.endsWith('.kt')) {
  const packageName = packageLine.replace(/^package\s+/, '').replace(/;$/, '');
  source = `package ${packageName}

import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN)
        applyImmersiveMode()
    }
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersiveMode()
    }
    private fun applyImmersiveMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            )
        }
    }
}
`;
} else {
  source = `${packageLine}

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        applyImmersiveMode();
    }
    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersiveMode();
    }
    private void applyImmersiveMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            );
        }
    }
}
`;
}
await writeFile(sourcePath, source);
console.log('Android native shell patched: landscape, immersive fullscreen, IME adjustPan, required permissions; legacy auth deep link removed.');


// Use a stable debug signing key for future APK updates from fresh GitHub runners.
// This key is development-only; never use it for Play Store or production release signing.
const packageJson = JSON.parse(await readFile('package.json', 'utf8'));
const version = String(packageJson.version || '0.7.0');
const parts = version.split('.').map(value => Number.parseInt(value, 10) || 0);
const versionCode = (parts[0] * 10000) + (parts[1] * 100) + parts[2];
const appGradleCandidates = ['android/app/build.gradle', 'android/app/build.gradle.kts'];
let appGradlePath = null;
for (const candidate of appGradleCandidates) {
    try { await access(candidate); appGradlePath = candidate; break; } catch { /* try next */ }
}
if (!appGradlePath) throw new Error('android/app/build.gradle(.kts) tidak ditemukan');
const stableKeystore = 'native/abyssal-debug-signing.bin';
await copyFile(stableKeystore, 'android/app/debug.keystore');
let appGradle = await readFile(appGradlePath, 'utf8');

function blockRange(source, opener) {
    const match = new RegExp(`\\b${opener}\\s*\\{`).exec(source);
    if (!match) return null;
    const start = match.index;
    const openBrace = start + match[0].lastIndexOf('{');
    let depth = 0;
    for (let i = openBrace; i < source.length; i++) {
        if (source[i] === '{') depth++;
        else if (source[i] === '}') {
            depth--;
            if (depth === 0) return { start, openBrace, closeBrace: i };
        }
    }
    return null;
}

if (appGradlePath.endsWith('.kts')) {
    const androidBlock = blockRange(appGradle, 'android');
    if (!androidBlock) throw new Error('Blok android { } tidak ditemukan pada Gradle Kotlin DSL');
    let signBlock = blockRange(appGradle.slice(androidBlock.openBrace + 1, androidBlock.closeBrace), 'signingConfigs');
    if (!signBlock) {
        const insert = `\n    signingConfigs {\n        getByName("debug") {\n            storeFile = file("debug.keystore")\n            storePassword = "android"\n            keyAlias = "androiddebugkey"\n            keyPassword = "android"\n        }\n    }\n`;
        appGradle = appGradle.slice(0, androidBlock.openBrace + 1) + insert + appGradle.slice(androidBlock.openBrace + 1);
    } else {
        const globalStart = androidBlock.openBrace + 1 + signBlock.openBrace;
        const globalEnd = androidBlock.openBrace + 1 + signBlock.closeBrace;
        const section = appGradle.slice(globalStart, globalEnd + 1);
        if (!section.includes('getByName("debug")') && !section.includes('create("debug")')) {
            appGradle = appGradle.slice(0, globalEnd) + `\n        getByName("debug") { storeFile = file("debug.keystore"); storePassword = "android"; keyAlias = "androiddebugkey"; keyPassword = "android" }\n` + appGradle.slice(globalEnd);
        }
    }
    appGradle = appGradle.replace(/versionCode\s*=\s*\d+/, `versionCode = ${versionCode}`);
    appGradle = appGradle.replace(/versionName\s*=\s*"[^"]*"/, `versionName = "${version}"`);
    if (!/signingConfig\s*=\s*signingConfigs\.getByName\("debug"\)/.test(appGradle)) {
        appGradle = appGradle.replace(/getByName\("debug"\)\s*\{/, `getByName("debug") { signingConfig = signingConfigs.getByName("debug");`);
    }
} else {
    const androidBlock = blockRange(appGradle, 'android');
    if (!androidBlock) throw new Error('Blok android { } tidak ditemukan pada Gradle');
    const inner = appGradle.slice(androidBlock.openBrace + 1, androidBlock.closeBrace);
    const signBlock = blockRange(inner, 'signingConfigs');
    const debugConfig = `\n        debug {\n            storeFile file("debug.keystore")\n            storePassword "android"\n            keyAlias "androiddebugkey"\n            keyPassword "android"\n        }\n`;
    if (!signBlock) {
        appGradle = appGradle.slice(0, androidBlock.openBrace + 1) + `\n    signingConfigs {${debugConfig}    }\n` + appGradle.slice(androidBlock.openBrace + 1);
    } else {
        const open = androidBlock.openBrace + 1 + signBlock.openBrace;
        const close = androidBlock.openBrace + 1 + signBlock.closeBrace;
        const section = appGradle.slice(open, close + 1);
        if (!/\bdebug\s*\{/.test(section)) appGradle = appGradle.slice(0, close) + debugConfig + appGradle.slice(close);
        else {
            const debugBlock = blockRange(section, 'debug');
            if (debugBlock) {
                const begin = open + debugBlock.openBrace + 1;
                const finish = open + debugBlock.closeBrace;
                const body = `\n            storeFile file("debug.keystore")\n            storePassword "android"\n            keyAlias "androiddebugkey"\n            keyPassword "android"\n        `;
                appGradle = appGradle.slice(0, begin) + body + appGradle.slice(finish);
            }
        }
    }
    appGradle = appGradle.replace(/versionCode\s+\d+/, `versionCode ${versionCode}`);
    appGradle = appGradle.replace(/versionName\s+["'][^"']*["']/, `versionName "${version}"`);
    const buildTypes = blockRange(appGradle, 'buildTypes');
    if (buildTypes) {
        const section = appGradle.slice(buildTypes.openBrace + 1, buildTypes.closeBrace);
        const debugBlock = blockRange(section, 'debug');
        if (!debugBlock) {
            appGradle = appGradle.slice(0, buildTypes.openBrace + 1) + `\n        debug { signingConfig signingConfigs.debug }\n` + appGradle.slice(buildTypes.openBrace + 1);
        } else if (!/signingConfig\s+signingConfigs\.debug/.test(section.slice(debugBlock.openBrace + 1, debugBlock.closeBrace))) {
            const insertAt = buildTypes.openBrace + 1 + debugBlock.openBrace + 1;
            appGradle = appGradle.slice(0, insertAt) + ` signingConfig signingConfigs.debug; ` + appGradle.slice(insertAt);
        }
    } else {
        const currentAndroid = blockRange(appGradle, 'android');
        appGradle = appGradle.slice(0, currentAndroid.closeBrace) + `\n    buildTypes { debug { signingConfig signingConfigs.debug } }\n` + appGradle.slice(currentAndroid.closeBrace);
    }
}
await writeFile(appGradlePath, appGradle);
console.log(`Stable debug signing configured; version ${version} (${versionCode}).`);
