import { readFile, access, readdir } from 'node:fs/promises';
import { resolve, join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { WORLD_SEED, hash2, valueNoise, MAX_DIVE_DEPTH, ABYSSAL_TRENCH, trenchInfluenceAt, seaFloorDepth } from '../world-generation.mjs';
import { applyTouchLook, canPlayerJump, getLifepodHatchAim, getLifepodExitWorldPosition, lifepodLocalToWorld, lifepodHatchChannelContains, lifepodHullBlocksLocal, lifepodHullBlocksWorld, lifepodInteriorContains, lifepodSegmentBlocked, oxygenUsePerTick, oxygenTankCapacity, oxygenTankDepthRating, depthStressDamage, OXYGEN_TANK_DEPTH_RATINGS, MAX_OXYGEN_TANK_LEVEL, clampFaunaDepth, resolveLifepodMovement, resolveVerticalInput, worldToLifepodLocal } from '../player-mechanics.mjs';
import { waterSurfaceHeightAt, computeSurfaceBlend, canBreatheAtSurface, computeDaylight, computeSeagrassSway, computeSwimPose, waterTextureResolution, resolveGraphicsTextureProfile, GRAPHICS_TEXTURE_TARGETS } from '../environment-simulation.mjs';
import { VEHICLE_IDS, VEHICLE_DEFS, VEHICLE_UPGRADES, createVehicleState, normalizeVehicleFleet, getVehicleDepthRating, getVehicleMaxHealth, getVehicleCargoCapacity, getVehicleCargoUsed, getVehicleSpeed, vehiclePowerDrainPerSecond, vehicleDepthDamage, canInstallVehicleUpgrade, addVehicleCargo, removeVehicleCargo, integrateVehicleMotion, resolveVehicleSweep } from '../vehicle-systems.mjs';
import { INTRO_CINEMATIC_DURATION, INTRO_CINEMATIC_LINES_AT, INTRO_CAMERA_SHOTS, getIntroCameraShot, getIntroSubtitleIndex } from '../cinematic-systems.mjs';
import { normalizeRoomCode, sanitizeChatText, sanitizeDisplayName, sanitizePlayerState, sanitizeWorldEventInput, normalizeWorldEvent, flattenPresence, validatePublicBackendConfig } from '../multiplayer-core.mjs';
import {
  normalizeGameSettings,
  normalizeSaveRecord,
  normalizeBackupPayload,
  SAVE_SCHEMA_VERSION,
  SLOT_COUNT
} from '../save-schema.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const read = path => readFile(join(root, path), 'utf8');
const [html, game, fauna, styles, schema, worldGeneration, playerMechanics, multiplayer, multiplayerCore, multiplayerSql, roomRecoverySql, sharedWorldSql, deepWorldSql, envExample, environmentSimulation, vehicleSystems, manifestText, capacitorText, packageText, workflow, serviceWorker, nativeBuilder, nativePatcher, readme, backendSetup, gitignore] = await Promise.all([
  read('index.html'), read('game.js'), read('fauna.js'), read('styles.css'), read('save-schema.mjs'), read('world-generation.mjs'), read('player-mechanics.mjs'),
  read('multiplayer.js'), read('multiplayer-core.mjs'), read('supabase/migrations/202611060001_multiplayer.sql'),
  read('supabase/migrations/202611060002_room_recovery.sql'), read('supabase/migrations/202611070001_shared_world_events.sql'), read('supabase/migrations/202611070002_deep_world_coordinates.sql'), read('.env.example'), read('environment-simulation.mjs'), read('vehicle-systems.mjs'),
  read('manifest.webmanifest'), read('capacitor.config.json'), read('package.json'),
  read('.github/workflows/android-apk.yml'), read('sw.js'), read('scripts/build-native.mjs'), read('scripts/patch-android.mjs'), read('README_ID.md'), read('scripts/configure-backend.mjs'), read('.gitignore')
]);
const manifest = JSON.parse(manifestText);
const capacitor = JSON.parse(capacitorText);
const pkg = JSON.parse(packageText);
const setupGuide = await read('SUPABASE_SETUP_ID.md');

// Parse every runtime/build script with the same Node major used by CI. This
// catches syntax regressions before Vite or Gradle starts a longer build.
const scriptFiles = (await readdir(join(root, 'scripts'))).filter(file => file.endsWith('.mjs')).map(file => `scripts/${file}`);
const syntaxFiles = ['game.js', 'fauna.js', 'multiplayer.js', 'multiplayer-core.mjs', 'vite.config.js', 'app-update-config.js', 'sw.js', 'save-schema.mjs', 'world-generation.mjs', 'player-mechanics.mjs', 'environment-simulation.mjs', 'vehicle-systems.mjs', 'cinematic-systems.mjs', ...scriptFiles];
for (const file of syntaxFiles) {
  const result = spawnSync(process.execPath, ['--check', file], { cwd: root, encoding: 'utf8' });
  assert.equal(result.status, 0, `JavaScript syntax check failed for ${file}: ${result.stderr || result.stdout || result.error || 'unknown error'}`);
}

// DOM IDs must be unique, and every static game.js lookup must point to an element.
const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map(match => match[1]);
const idSet = new Set(ids);
const duplicates = [...new Set(ids.filter((id, index) => ids.indexOf(id) !== index))];
assert.deepEqual(duplicates, [], `Duplicate DOM IDs: ${duplicates.join(', ')}`);
const staticRefs = [...game.matchAll(/\$\(['"]([^'"]+)['"]\)/g)].map(match => match[1]);
const missing = [...new Set(staticRefs.filter(id => !idSet.has(id)))];
assert.deepEqual(missing, [], `Missing DOM nodes: ${missing.join(', ')}`);

// Local assets and module imports must resolve from the archive itself.
for (const match of html.matchAll(/(?:src|href)="\.\/([^?#"]+)/g)) {
  const target = match[1];
  if (!target.startsWith('data:')) await access(join(root, target));
}
for (const sourceFile of ['game.js', 'fauna.js', 'save-schema.mjs', 'world-generation.mjs', 'player-mechanics.mjs', 'environment-simulation.mjs', 'vehicle-systems.mjs', 'cinematic-systems.mjs', 'multiplayer.js', 'multiplayer-core.mjs']) {
  const source = await read(sourceFile);
  for (const match of source.matchAll(/(?:from\s*|import\s*\()(['"])(\.\/[^"]+?)\1/g)) {
    await access(join(root, dirname(sourceFile), match[2]));
  }
}
for (const match of game.matchAll(/icon:'([a-z0-9_-]+)'/gi)) {
  await access(join(root, 'icons', 'items', `${match[1]}.png`));
}
for (const match of html.matchAll(/\.\/icons\/([^"']+\.png)/g)) {
  await access(join(root, 'icons', match[1]));
}
for (const match of styles.matchAll(/url\(\s*['\"]?\.\/([^'\")]+)['\"]?\s*\)/g)) {
  await access(join(root, match[1]));
}

// Save migration: old custom bed checkpoints and PDA hotbar assignments are retired.
assert.equal(SLOT_COUNT, 5);
assert.equal(SAVE_SCHEMA_VERSION, 11);
assert.equal(normalizeGameSettings({graphics:'ultra'}).graphics, 'ultra', 'Ultra graphics preference must persist without changing save schema');
assert.deepEqual(normalizeGameSettings({ graphics: 'cinematic', renderDistance: 99, volume: -5, fov: 140, language: 'xx', autoSave: true }), {
  graphics: 'balanced', renderDistance: 3, volume: 0, fov: 90, cameraSensitivity: 1, hudScale: 100, language: 'id'
});
const legacy = normalizeSaveRecord({
  version: 8,
  savedAt: 'bad-date',
  position: { x: 15, y: -12, z: -9 },
  respawnPoint: { x: 750, y: -24, z: -360 },
  yaw: 'NaN', pitch: 99,
  survival: { hp: -20, oxygen: 110, food: 'bad', water: 51, medkits: 999, rations: -3 },
  inventory: { titanium: -9, copper: '4.7', quartz: 10000, invalid: 12 },
  equipment: { tankLevel: 2, fins: 1, rebreather: true, reinforcedSuitOwned: true, helmetOwned: true },
  ownedTools: ['explorer_pda', 'scanner', 'knife', 'flashlight'],
  hotbar: ['explorer_pda', 'scanner', 'knife', 'flashlight', null],
  discoveries: ['clownfish', 'not-a-species', 'abyssal_leviathan'],
  knownBiomes: ['reef', 'bogus', 'abyss'],
  collectedCaches: ['verdant_cache', 'bogus'],
  collectedResources: ['1:2:ore:3', 'bad-key'],
  placedStructures: [
    { id: 'build-1', type: 'beacon', x: 4, y: -8, z: 9, yaw: 2 },
    { id: 'bad', type: 'teleporter', x: 0, y: 0, z: 0 }
  ],
  droppedItems: [
    { id: 'drop-1', type: 'glowcap', position: { x: 2, y: -9, z: 3 } },
    { id: 'bad', type: 'explosive', position: { x: 0, y: 0, z: 0 } }
  ],
  story: { introSeen: true, missionIndex: 999, counters: { materials: 99 }, completed: ['lifepod', 'evil'] }
});
assert.ok(legacy);
assert.equal(legacy.version, 11);
assert.deepEqual(legacy.respawnPoint, { x: 0, y: -7, z: 0 }, 'Legacy bed/checkpoint positions must not survive migration');
assert.equal(legacy.survival.hp, 0);
assert.equal(legacy.survival.oxygen, 110, 'Save v11 oxygen must not be clipped when tank capacity expands');
assert.equal(legacy.survival.medkits, 20);
assert.equal(legacy.inventory.titanium, 0);
assert.equal(legacy.inventory.copper, 5);
assert.equal(legacy.inventory.quartz, 999);
assert.equal(legacy.equipment.tankLevel, 2);
assert.equal(oxygenTankCapacity(0), 45, 'Starter O₂ remains exactly 45');
assert.equal(oxygenTankCapacity(3), 270, 'Existing tank tiers retain their level and gain consistent capacity');
assert.equal(oxygenTankCapacity(4), 345, 'Final tank tier supports a deep expedition');
assert.equal(MAX_OXYGEN_TANK_LEVEL, 4);
const maxTankSave = normalizeSaveRecord({ version:11, position:{x:760,y:-275,z:-620}, survival:{oxygen:345}, inventory:{}, equipment:{tankLevel:4} });
assert.equal(maxTankSave.equipment.tankLevel, 4, 'Save v11 must preserve the new final tank tier');
assert.equal(maxTankSave.survival.oxygen, 345, 'Save normalization must preserve upgraded tank capacity');
let deepRoundTripOxygen = 0;
const deepDiveTicks = [];
for (let depth=14; depth<296; depth+=14) deepDiveTicks.push(depth);
deepDiveTicks.push(296);
for (const depth of [...deepDiveTicks, ...[...deepDiveTicks].reverse()]) deepRoundTripOxygen += oxygenUsePerTick(depth, true, () => 0.999);
assert.ok(deepRoundTripOxygen < oxygenTankCapacity(4), 'Max tank plus Rebreather must support a conservative 296 m return profile');
assert.equal('reinforcedSuitOwned' in legacy.equipment, false);
assert.equal('helmetOwned' in legacy.equipment, false);
assert.equal(legacy.equipment.seaglideCharge, 0, 'No legacy Seaglide should start charged unless it was owned');
assert.deepEqual(legacy.hotbar, [null, 'scanner', 'knife', 'flashlight', null]);
assert.deepEqual(legacy.discoveries, ['clownfish', 'abyssal_leviathan']);
assert.deepEqual(legacy.knownBiomes, ['reef', 'abyss']);
assert.deepEqual(legacy.collectedCaches, ['verdant_cache']);
assert.deepEqual(legacy.collectedResources, ['1:2:ore:3']);
assert.equal(legacy.placedStructures.length, 1);
assert.equal(legacy.droppedItems.length, 1);
assert.equal(legacy.story.missionIndex, 7);
assert.equal(normalizeSaveRecord({ totally: 'invalid' }), null);
const modern = normalizeSaveRecord({ version: 11, position: { x: 5, y: -9, z: 8 }, respawnPoint: { x: 20, y: -8, z: -10 }, survival: {}, inventory: {}, ownedTools:['seaglide'], equipment:{seaglideCharge:72} });
assert.deepEqual(modern.respawnPoint, { x: 20, y: -8, z: -10 });
assert.equal(modern.equipment.seaglideCharge, 72);
const migratedSeaglide = normalizeSaveRecord({ version: 10, position:{x:0,y:-7,z:0}, survival:{}, inventory:{}, ownedTools:['seaglide'] });
assert.equal(migratedSeaglide.equipment.seaglideCharge, 100, 'Legacy Seaglide owners should receive a full battery on migration');
const deepSave = normalizeSaveRecord({ version:11, position:{x:760,y:-275,z:-620}, respawnPoint:{x:760,y:-260,z:-620}, knownBiomes:['deep','abyss'], survival:{}, inventory:{} });
assert.equal(deepSave.position.y, -275, 'Save normalization must preserve legitimate trench depth');
assert.equal(deepSave.respawnPoint.y, -260, 'Deep habitat respawn position must remain valid');
assert.deepEqual(deepSave.knownBiomes, ['deep','abyss'], 'Deep biomes must persist in the existing save schema');
const backup = normalizeBackupPayload({ format: 'the-abyssal-save-backup', schemaVersion: 1, slots: [legacy, null, null, null, null], settings: { volume: 120 } });
assert.equal(backup.slots.length, 5);
assert.equal(backup.settings.volume, 100);
assert.throws(() => normalizeBackupPayload({ format: 'wrong', slots: [] }), /Format backup/);
assert.throws(() => normalizeBackupPayload({ format: 'the-abyssal-save-backup', slots: [null] }), /tepat lima slot/);

// Subnautica-style core loop: backpack dimensions, quick slots, tool gating, survival and habitat systems.
assert.equal(pkg.version, '2.2.0');
assert.match(game, /from '\.\/world-generation\.mjs'/);
assert.match(game, /from '\.\/multiplayer\.js'/);
assert.match(worldGeneration, /export const WORLD_SEED = 0x0ab155a1/);
assert.ok(Number.isInteger(WORLD_SEED) && WORLD_SEED > 0);
assert.equal(hash2(0, 0), hash2(0, 0), 'World seed output must be deterministic');
assert.notEqual(hash2(0, 0), hash2(1, 0), 'Adjacent world coordinates should produce varied terrain');
for (const [x, z] of [[0, 0], [1.25, -4.5], [-180, 92], [10000, -10000]]) {
  const value = hash2(x, z);
  const noise = valueNoise(x, z);
  assert.ok(Number.isFinite(value) && value >= 0 && value < 1, 'World hash must be a finite unit interval value');
  assert.ok(Number.isFinite(noise) && noise >= -1 && noise <= 1, 'Terrain noise must be finite and bounded');
}
assert.equal(MAX_DIVE_DEPTH, 500, 'World dive limit must support the final 500 m pressure tier');
assert.deepEqual([...OXYGEN_TANK_DEPTH_RATINGS],[50,100,200,300,500]);
assert.deepEqual([0,1,2,3,4].map(oxygenTankDepthRating),[50,100,200,300,500]);
assert.equal(depthStressDamage(50,0),0,'Starter tank is safe through 50 m');
assert.equal(depthStressDamage(75,0),2,'Starter tank pressure stress escalates after its 50 m rating');
assert.equal(depthStressDamage(100,1),0,'Tank Mk II is safe through 100 m');
assert.equal(depthStressDamage(125,1),2,'Tank Mk II pressure stress begins beyond 100 m');
assert.equal(depthStressDamage(500,4),0,'Tank Mk V is safe through 500 m');
assert.equal(trenchInfluenceAt(ABYSSAL_TRENCH.x, ABYSSAL_TRENCH.z), 1, 'Trench basin center must have full influence');
assert.equal(trenchInfluenceAt(ABYSSAL_TRENCH.x + 2000, ABYSSAL_TRENCH.z), 0, 'Trench must not modify the existing starter region');
assert.ok(seaFloorDepth(0, 0) > -55, 'Existing spawn-region sea floor must remain unchanged');
assert.ok(seaFloorDepth(ABYSSAL_TRENCH.x, ABYSSAL_TRENCH.z) < -480, 'Remote trench must provide a genuine hadal basin for the 500 m tank tier');
assert.ok(seaFloorDepth(ABYSSAL_TRENCH.x, ABYSSAL_TRENCH.z) > -496, 'Trench floor must remain above the hard dive limit with capsule clearance');
for (let ox=-200; ox<=200; ox+=50) for (let oz=-200; oz<=200; oz+=50) assert.ok(seaFloorDepth(ABYSSAL_TRENCH.x+ox,ABYSSAL_TRENCH.z+oz) >= -496, 'No trench sample may fall below the safe floor limit');
assert.ok(oxygenUsePerTick(490,false,()=>0.999) > oxygenUsePerTick(44,false,()=>0.999), 'Oxygen demand must increase at the deepest playable depth');
assert.match(game, /import \{ hash2, valueNoise, seaFloorDepth, trenchInfluenceAt, ABYSSAL_TRENCH, MAX_DIVE_DEPTH \} from '\.\/world-generation\.mjs'/);
assert.doesNotMatch(game, /WORLD_SEED is not defined/);
assert.ok(idSet.has('boot-retry-btn'), 'Boot recovery button is required');
assert.match(game, /boot-retry-btn/);
assert.match(game, /Dunia 3D gagal dimuat/);
assert.match(game, /const SURVIVAL_DEFAULTS = \{ hp: 100, oxygen: 45/);
assert.match(game, /const columns = 8, rows = 6/);
assert.match(game, /for \(let index=0; index<48; index\+\+\)/);
assert.match(html, /48 CELLS USED/);
assert.match(html, /aria-label="5 Quick Slots"/);
assert.match(game, /let hotbarSlots = \['scanner','knife','flashlight',null,null\]/);
assert.match(game, /if \(itemId === 'explorer_pda'\)/);
assert.match(game, /explorer_pda:\{name:'PDA'/);
assert.match(game, /size:6,kind:'tool',width:2,height:3/);
assert.match(game, /function getMaxOxygen\(\) \{ return oxygenTankCapacity\(equipment\.tankLevel \|\| 0\); \}/);
assert.match(game, /oxygenTickTimer >= 2/);
assert.match(game, /oxygenUsePerTick\(depth,Boolean\(equipment\.rebreather\)\)/);
assert.match(game, /seaFloorDepth\(x, z\)/);
assert.match(game, /MAX_DIVE_DEPTH/);
assert.match(game, /Twilight Trench/);
assert.match(game, /TRENCH ANOMALY/);
assert.match(game, /depthNow \/ MAX_DIVE_DEPTH/);
assert.match(game, /root\.position\.set\(LIFEPOD_POSITION\.x,LIFEPOD_POSITION\.y,LIFEPOD_POSITION\.z\)/, 'Lifepod must use the authored waterline transform');
assert.match(game, /player\.yaw=0; player\.pitch=0\.34/, 'New game camera must initially face toward the Lifepod');
assert.match(game, /getLifepodExitWorldPosition\(/, 'Lifepod exit must calculate a safe world position beyond the shell');
assert.match(game, /function updateBuildPreview\(/, 'Habitat Builder must show a world-space placement hologram');
assert.match(game, /function updateResourceBreakActions\(/, 'Ore destruction must have a timed impact animation');
assert.match(game, /playSfx\(node\.type==='kelp'\?'knife':'oreHit'\)/, 'Mining hit must have an audio event');
assert.match(game, /playSfx\('oreBreak'\)/, 'Ore break must have an audio event');
assert.match(game, /const flashlightBeam = new THREE\.SpotLight\(0xc8fbff, 46, 58/, 'Flashlight must use a real world SpotLight');
assert.match(game, /introSequence\.attacker\.userData\.tail/, 'Intro leviathan must animate its tail');
assert.match(game, /getIntroCameraShot\(t\)/, 'Cutscene camera must use the cinematic shot director');
assert.match(html, /id="menu-background-video"[^>]*autoplay muted loop playsinline/, 'Main menu must use a local looping cinematic video');
await access(join(root,'assets/menu-underwater-loop.mp4'));
await access(join(root,'assets/menu-underwater-frame.png'));
assert.match(game, /SAFE DEPTH/);
assert.match(game, /depthStressDamage\(depth,equipment\.tankLevel\)/);
assert.match(fauna, /depth:\[-220,-475\]/, 'Trench Leviathan must inhabit the extended 500 m trench');
assert.match(styles, /\.cinematic-caption\{position:absolute;top:/, 'Cutscene subtitle must sit in the upper centre area');
assert.match(fauna, /trench_leviathan/);
assert.match(fauna, /abyssal_stalker/);
assert.match(fauna, /instanceId/);
assert.match(fauna, /animal\.instanceId===targetId/);
assert.match(fauna, /clampFaunaDepth\(pos\.y,seabed,clearance,species\.depth\)/);
assert.equal(clampFaunaDepth(-42, -296, 2.5, [-178,-292]), -178, 'Trench fauna cannot float above its authored deep habitat');
assert.equal(clampFaunaDepth(-295, -296, 2.5, [-178,-292]), -292, 'Trench fauna cannot pass below its authored depth range');
assert.equal(clampFaunaDepth(-170, -40, 1.5, [-178,-292]), -38.5, 'Fauna must stay above shallow terrain when no depth-band overlap exists');
assert.match(playerMechanics, /Math\.sqrt\(Math\.max\(0, depth - 20\) \/ 8\)/);
assert.match(game, /survival\.oxygen=clamp\(survival\.oxygen-oxygenCost,0,getMaxOxygen\(\)\)/);
assert.doesNotMatch(game, /oxygenRate \* dt/);
assert.equal(oxygenUsePerTick(5, false, () => 0), 2, 'Normal-depth minimum oxygen use is 2 per tick');
assert.equal(oxygenUsePerTick(5, false, () => 0.999), 4, 'Normal-depth maximum oxygen use is 4 per tick');
assert.equal(oxygenUsePerTick(20, false, () => 0), 4, 'Deep-water oxygen use starts at 4 per tick');
assert.equal(oxygenUsePerTick(44, false, () => 0.999), 7, 'Deep-water demand rises smoothly with depth');
assert.ok(oxygenUsePerTick(44, true, () => 0.999) < oxygenUsePerTick(44, false, () => 0.999), 'Rebreather must reduce deep-water oxygen demand');
assert.match(game, /if \(indoorHabitat && isHabitatPowered\(indoorHabitat\)\)/);
assert.match(game, /else if \(atSurface\)/);
assert.match(game, /function isHabitatPowered\(/);
assert.match(game, /function openFabricator\(\)/);
assert.match(game, /function craftFabricatorRecipe\(id\)/);
assert.match(game, /sustenance:\{title:'Sustenance'/);
assert.match(game, /personal:\{title:'Personal'/);
assert.match(game, /resources:\{title:'Resources'/);
assert.match(game, /electronics:\{title:'Electronics'/);
assert.match(game, /function openBuildMenu\(\)[\s\S]*?getSelectedHotbarItem\(\) !== 'habitat_builder'/);
assert.match(game, /function interactNearby\(\)/);
assert.match(game, /function gatherNearbyResource\(\)/);
assert.match(game, /function scanNearestFauna\(\)/);
assert.match(game, /minAlignment:0\.945/);
assert.match(game, /function makeFirstPersonViewModel\(\)/);
assert.match(game, /makeWaterColorTexture/);
assert.match(game, /makeWaterNormalTexture/);
assert.match(game, /function applyWaterQualitySettings\(profile =/);
assert.match(game, /oldGeometry\.dispose\(\)/);
assert.match(game, /causticTexture\.offset\.x/);
assert.match(game, /makeSeagrassTuftGeometry/);
assert.match(game, /const randomCount = Math\.max\(20, kelpAttempts \+ 12\)/, 'Kelp density must have enough independent deterministic placement samples');
const kelpLoopStart = game.indexOf('for (let i = 0; i < kelpAttempts; i++) {');
const kelpLoopEnd = game.indexOf('\n  kelp.count', kelpLoopStart);
assert.ok(kelpLoopStart >= 0 && kelpLoopEnd > kelpLoopStart, 'Kelp placement loop must be present');
const kelpPlacementLoop = game.slice(kelpLoopStart, kelpLoopEnd);
assert.doesNotMatch(kelpPlacementLoop[1], /%\s*20/, 'High-density kelp placement must not wrap after 20 samples');
assert.match(game, /updateSwimBubbles\(dt\)/);
assert.match(game, /computeSwimPose\(player\.swimPhase/);
assert.match(game, /new THREE\.MeshPhysicalMaterial\(\{/);
assert.match(game, /const visualQuality = getActiveGraphicsQuality\(\);[\s\S]*?const waterSegments = visualQuality === 'low' \? 72 : \(visualQuality === 'high' \|\| visualQuality === 'ultra'\) \?/);
assert.match(game, /viewModel\.userData\.seaglide\.visible=selectedTool==='seaglide'/);
assert.match(game, /equipment\.seaglideCharge-0\.30\*dt/);
assert.match(game, /Ganti baterai Seaglide/);
assert.match(game, /function activateLifepod\([\s\S]*?getSelectedHotbarItem/);
assert.match(game, /ownedTools\.includes\('repair_tool'\)\|\|getSelectedHotbarItem\(\)!=='repair_tool'/);
assert.match(game, /CONTROL CONSOLE · FABRICATE REPAIR TOOL/);
assert.match(game, /consoleMaterial\.emissive\.setHex\(0x18c9b8\)/);
assert.match(game, /const speed=.*seaglideEquipped\?1\.75/);
assert.match(game, /function enterHabitat\(target\)/);
assert.match(game, /getAimedLifepodHatchTarget/);
assert.match(game, /ENTER THROUGH TOP HATCH/);
assert.match(game, /transparent:false, opacity:1, depthWrite:true/);
assert.match(game, /lifepodHullBlocksWorld/);
assert.match(game, /resolveLifepodMovement/);
assert.match(game, /function updateLifepodInteriorVisibility\(\)/);
assert.match(game, /function openLifepodHatch\(/);
assert.match(game, /function updateLifepodHatchAnimation\(/);
assert.match(game, /lostpointercapture', stopLook/);
assert.match(game, /if \(joyPointer !== null\) return/);
assert.match(game, /if \(look\.active\) return/);
assert.match(game, /releaseTouchControls = \(\) =>/);
assert.match(game, /visibilitychange', \(\) => \{/);
assert.match(game, /function startAnimationLoop\(\)/);
assert.match(game, /function stopAnimationLoop\(\)/);
assert.match(game, /function suspendApplication\(\)/);
assert.match(game, /function resumeApplication\(\)/);
assert.match(game, /ambientContext\?\.state === 'suspended'\) ambientContext\.resume/);
assert.match(game, /settings\.graphics === 'ultra' \? 1\.6/);
assert.match(game, /webglcontextlost/);
assert.match(game, /webglcontextrestored/);
assert.match(game, /Runtime frame paused safely/);
assert.match(game, /applicationSuspended \|\| webglContextLost/);
assert.match(game, /applyTouchLook/);
assert.match(game, /function attackWithKnife\(\)/);
assert.match(fauna, /attackTarget\(playerPosition, origin, direction/);
assert.match(game, /flashlightEnabled/);
assert.match(game, /const setLayer = \(root, layer\) => root\.traverse\(object =>/,'First-person meshes must use explicit render layers for arm, held model, and grip');
assert.ok(idSet.has('attack-btn'), 'Knife action button must exist');
assert.ok(idSet.has('camera-sensitivity-range') && idSet.has('hud-scale-range'), 'Touch sensitivity and HUD scale controls must exist');
assert.ok(idSet.has('replay-intro-btn'), 'Intro cinematic replay control must exist');
assert.match(game, /startIntroCinematic\(\{replayOnly:true\}\)/);
assert.match(game, /if\(replayOnly\)\{/);
assert.match(game, /settings\.cameraSensitivity/);
assert.match(game, /settings\.hudScale/);
assert.equal(normalizeGameSettings({cameraSensitivity:99,hudScale:999}).cameraSensitivity,2);
assert.equal(normalizeGameSettings({cameraSensitivity:-1,hudScale:1}).cameraSensitivity,0.5);
assert.equal(normalizeGameSettings({cameraSensitivity:1,hudScale:999}).hudScale,130);
assert.equal(normalizeGameSettings({cameraSensitivity:1,hudScale:1}).hudScale,80);
assert.match(html, /icons\/hud\/attack\.png/);
assert.equal(applyTouchLook(0, 0, 20, 0).yaw > 0, true, 'A rightward swipe must turn the camera right');
assert.equal(applyTouchLook(0, 0, -20, 0).yaw < 0, true, 'A leftward swipe must turn the camera left');
assert.equal(applyTouchLook(0, 0, 0, 1000).pitch, 0.98, 'Camera pitch must be clamped');
assert.equal(resolveVerticalInput(1,0),1,'An active ascend pointer must move upward');
assert.equal(resolveVerticalInput(0,1),-1,'An active descend pointer must move downward');
assert.equal(resolveVerticalInput(1,1),0,'Opposing vertical controls must cancel safely');
assert.equal(resolveVerticalInput(2,1),0,'Releasing one pointer must not leave a stale vertical direction');
assert.equal(resolveVerticalInput(0,0),0,'No active vertical pointer must be neutral');
assert.equal(canPlayerJump(8,8,0,0),true,'Jump is allowed when grounded on exposed dry terrain');
assert.equal(canPlayerJump(-1.9,-1.9,0,0),false,'Jump is unavailable while swimming');
assert.equal(canPlayerJump(8.8,8,0,0),false,'Jump is unavailable while airborne outside the ground tolerance');
assert.equal(canPlayerJump(8,8,0,2),false,'Jump cannot be retriggered while moving upward');
assert.match(game,/const verticalPointers = \{ ascend:new Set\(\), descend:new Set\(\) \}/);
assert.match(game,/pointerSet\.delete\(event\.pointerId\); updateVerticalInput\(\)/);
assert.match(game,/cameraBaseQuaternion\.slerp\(cameraTargetQuaternion,cameraBlend\)/);
assert.match(game,/camera\.quaternion\.copy\(cameraBaseQuaternion\)\.multiply\(cameraRollQuaternion\)/);
assert.doesNotMatch(game,/camera\.rotateZ\(/,'Camera roll must be composed from a clean base quaternion and never accumulated frame-to-frame');
assert.match(game,/function hasQuickSlotItem\(itemId\)/);
assert.match(game,/viewModel\.userData\.heldItems\s*=\s*heldItems/);
assert.match(game,/const makeGripOverlay = \(parent, name = 'RightToolGrip'\)/,'The first-person rig must create a physical glove grip overlay');
assert.match(game,/RightGloveGrip/,'Right hand grip overlay must be present');
assert.match(game,/LeftSeaglideGrip/,'Seaglide must have a second hand grip');
assert.match(game,/scanner\.name = 'ScannerViewModel'/,'Scanner must have a dedicated 3D viewmodel');
assert.match(game,/knife\.name = 'SurvivalKnifeViewModel'/,'Knife must have a dedicated 3D viewmodel');
assert.match(game,/flashlight\.name = 'FlashlightViewModel'/,'Flashlight must have a dedicated 3D viewmodel');
assert.match(game,/builder\.name = 'HabitatBuilderViewModel'/,'Habitat Builder must have a dedicated 3D viewmodel');
assert.match(game,/repairTool\.name = 'RepairToolViewModel'/,'Repair Tool must have a dedicated 3D viewmodel');
assert.match(game,/seaglide\.name = 'SeaglideViewModel'/,'Seaglide must have a dedicated 3D viewmodel');
assert.match(game,/viewModel\.userData\.toolModels = \{ scanner, knife, flashlight, habitat_builder: builder, repair_tool: repairTool, seaglide \}/,'Every primary tool must be registered in the viewmodel map');
assert.match(game,/rightGrip\.position\.copy\(selectedModel\.position\)\.add\(offset\)/,'Glove grip must follow the selected 3D item transform');
assert.match(game,/rightGrip\.scale\.copy\(selectedModel\.scale\)/,'Grip scale must follow the held model scale');
assert.match(game,/usingSeaglideView/,'Seaglide must use a two-handed first-person pose');
assert.match(game,/setLayer\(rightGrip, 1002\); setLayer\(leftGrip, 1002\)/,'Grip fingers must render above the held object');
assert.match(game,/setLayer\(model, 1001\)/,'3D tool models must render above the arm layer');
assert.match(game,/heldModel\.userData\.basePosition\?\.y/,'Generic held items must preserve their authored hand position during use');
assert.match(game,/for \(const id of Object\.keys\(ITEM_DEFS\)\) makeHeldItem\(id\)/);
assert.match(game,/const hasSelectedItem=hasQuickSlotItem\(selectedTool\)/);
assert.match(game,/const heldPresentation=/,'All holdable resource/supply models must use authored hand-fit presentation profiles');
assert.match(game,/heldModel\.userData\.basePosition/,'Held item use animation must preserve per-item base placement');
assert.match(game,/const noiseProfiles=\{/,'Cinematic and interaction sounds must have distinct layered offline noise profiles');
assert.match(game,/roar:\{type:'lowpass',frequency:145/,'Leviathan roar must use its own low-frequency sound layer');
assert.match(game,/reentry:\{type:'bandpass',frequency:820/,'Atmospheric re-entry must have a distinct filtered sound layer');
assert.match(game,/function makeCaveEntrance\(/,'Cave entrance generation must exist');
assert.match(game,/function makeOxygenPlant\(/,'Oxygen-producing flora must exist');
assert.match(game,/function makeSulfurNest\(/,'Sulfur-producing fauna must have authored nests');
assert.match(game,/LIFEPOD NEARBY · SWIM ABOVE IT AND AIM AT THE TOP HATCH/,'Players near the Lifepod receive entry guidance when they are not aimed at the hatch');
assert.match(game,/findNearbyHabitat\(16\)/,'Lifepod interaction detection must cover a practical approach range');
assert.match(game,/const hatchShaft=/,'The roof hatch must have a visible shaft aligned with its collision passage');
assert.match(fauna,/sulfur_masonfish/,'Sulfur nest fish species must exist');
assert.match(fauna,/nestActivity/,'Sulfur nest fish must perform nest activity');
assert.match(game,/function updateCinematic\(/);
assert.match(game,/8142C/,'Intro story must target planet 8142C');
assert.match(game,/pod\.position\.copy\(craftPosition\)\.add\(attachOffset\)/,'The escape capsule must remain attached to the transfer craft before release');
assert.match(game,/introSequence\.podReleasePosition=introSequence\.pod\.position\.clone\(\)/,'Capsule release must preserve its current position and avoid a cinematic teleport');
assert.match(game,/LIFEPOD_POSITION\.x,3,LIFEPOD_POSITION\.z/,'Cinematic landing and gameplay Lifepod must share the same destination');
assert.match(game,/splashRing/,'The capsule ocean landing must render a water impact effect');
assert.match(game,/getIntroCameraShot\(t\)/,'The final cinematic camera must use a dedicated shot director to frame the leviathan and landing scene');
assert.match(game,/canPlayerJump\(/);
assert.match(html,/id="jump-btn"/);
assert.match(game,/floorClearance\+2\.25/,'Dry-ground jump arc must not be clamped to the floor');
assert.match(game,/const current = '2\.2\.0'/);
assert.match(game,/function cancelIntroCinematic\(\)/,'Returning to the main menu during a cutscene must release temporary scene resources');
assert.match(game,/if \(introSequence\.active\) cancelIntroCinematic\(\)/,'Main-menu navigation must safely abort an active intro');
assert.match(game,/else if \(!gameActive && rendererReady\)/,'Paused in-game camera must not drift like the main-menu camera');
assert.match(game,/camera\.fov=54;camera\.updateProjectionMatrix\(\)/,'Intro camera must use a dedicated cinematic FOV');
assert.match(game,/pectoralFins/,'Leviathan pectoral fins must have an animation channel');
assert.equal(INTRO_CINEMATIC_DURATION,32.8);
assert.deepEqual(INTRO_CINEMATIC_LINES_AT,[0,5.2,10.1,15.4,21.2,27.2]);
assert.equal(INTRO_CAMERA_SHOTS.length,7,'Intro must have a distinct camera shot for each major story beat');
assert.equal(getIntroCameraShot(0).id,'orbital-establishing');
assert.equal(getIntroCameraShot(8).id,'transfer-craft');
assert.equal(getIntroCameraShot(11).id,'capsule-separation');
assert.equal(getIntroCameraShot(16).id,'atmospheric-reentry');
assert.equal(getIntroCameraShot(19).id,'ocean-impact');
assert.equal(getIntroCameraShot(24).id,'leviathan-reveal');
assert.equal(getIntroCameraShot(30).id,'lifepod-threat-establish');
assert.equal(getIntroSubtitleIndex(22),4);
assert.equal(getIntroSubtitleIndex(28),5);
assert.ok(INTRO_CAMERA_SHOTS.every(item => item.end>item.start && item.fov>=45 && item.fov<=70));
assert.doesNotMatch(game,/Slot Cepat \${selectedHotbarIndex \+ 1}/,'Selecting a held item must not show the old Quick Slot 1/2/3 toast');
assert.doesNotMatch(game,/Hotbar \${selectedHotbarIndex/,'Player-facing Quick Slot feedback must not show legacy Hotbar labels');
assert.match(game,/faunaDirector\?\.resetPopulation\(player\.position\)/);
assert.match(fauna,/resetPopulation\(playerPosition = null\)/);
assert.match(fauna,/getAttackTarget\(playerPosition, origin, direction/);
assert.match(game,/getAttackTarget\(player\.position,origin,direction,3\.4\)/);
assert.match(game,/attackButton\?\.classList\.toggle\('hidden',!attackAim\)/);
assert.equal(lifepodInteriorContains(0, 0, 0), true);
assert.equal(lifepodHullBlocksLocal(0, 0, 0), false, 'The hatch-entered interior remains traversable');
assert.equal(lifepodHullBlocksLocal(1.3, 0, 0), true, 'The Lifepod side wall blocks the player capsule');
assert.equal(lifepodHullBlocksLocal(0, 1.6, 1.05), true, 'The Lifepod roof blocks movement outside the dedicated hatch');
assert.equal(lifepodHatchChannelContains(0, 1.55, 0.15), true, 'The hatch channel must allow a diver through the roof opening');
assert.equal(lifepodHatchChannelContains(0.92, 1.55, 0.15), false, 'The hatch channel must not turn the surrounding roof into a pass-through');
const surfaceHatchAim=getLifepodHatchAim({x:0,y:.13,z:-7.5},{x:0,y:-Math.sin(.98),z:-Math.cos(.98)},{x:0,y:-2.4,z:-7.5},0,16,1.32);
assert.ok(surfaceHatchAim,'A diver at the reachable waterline must be able to aim at the Lifepod hatch');
assert.equal(getLifepodHatchAim({x:1.25,y:.13,z:-7.5},{x:0,y:-Math.sin(.98),z:-Math.cos(.98)},{x:0,y:-2.4,z:-7.5},0,16,1.32),null,'Aiming beside the hatch must not allow entry');
assert.equal(lifepodHullBlocksLocal(0, 1.6, 0.15), true, 'A closed roof hatch must block entry');
assert.equal(lifepodHullBlocksLocal(0, 1.6, 0.15, 0.38, true), false, 'The aimed and opened roof hatch must provide a passage');
assert.equal(lifepodHullBlocksLocal(0, -1.6, 0), true, 'The Lifepod underside blocks tunnelling');
assert.equal(lifepodHullBlocksLocal(4, 0, 0), false, 'Collision volume must not extend indefinitely');
const rotatedPod = { x: 12, y: -8, z: -4 };
const rotatedYaw = 0.42;
// Exit placement regression: the old runtime exit stayed in the open hatch
// channel at the waterline and became trapped as soon as the lid closed.
for (const [position,yaw,scale,surface] of [
  [{x:0,y:-2.4,z:-7.5},0.18,1.32,0],
  [{x:12,y:-8,z:-4},0.42,1,0],
  [{x:44,y:-8,z:-31},0.73,1.24,0]
]) {
  const exit=getLifepodExitWorldPosition(position,yaw,scale,surface,1,0.38);
  const local=worldToLifepodLocal(exit.x,exit.y,exit.z,position,yaw,scale);
  assert.ok(!lifepodInteriorContains(local.x,local.y,local.z),'Lifepod exit position must be outside the cabin volume');
  assert.equal(lifepodHullBlocksLocal(local.x,local.y,local.z,0.38,false),false,'Lifepod exit must remain clear after the hatch closes');
  assert.equal(lifepodHatchChannelContains(local.x,local.y,local.z),false,'Lifepod exit must be fully clear of the hatch channel');
  const roundTrip=lifepodLocalToWorld(local,position,yaw,scale);
  assert.ok(Math.abs(roundTrip.x-exit.x)<1e-8&&Math.abs(roundTrip.y-exit.y)<1e-8&&Math.abs(roundTrip.z-exit.z)<1e-8,'Entry/exit transform must be invertible');
}
const podCenter={...rotatedPod};
const roofOutsideHatch={x:podCenter.x+Math.sin(rotatedYaw),y:podCenter.y,z:podCenter.z+Math.cos(rotatedYaw)};
const verticalEscape=resolveLifepodMovement(roofOutsideHatch,{x:roofOutsideHatch.x,y:roofOutsideHatch.y+3.2,z:roofOutsideHatch.z},rotatedPod,rotatedYaw,0.38,1,false);
assert.equal(verticalEscape.blocked.y,true,'Lifepod roof must block vertical movement, not only horizontal movement');
assert.ok(verticalEscape.position.y < roofOutsideHatch.y+1.1,'The diver must remain below the Lifepod roof after a vertical collision');
const hatchStartLocal={x:0,y:2.45,z:0.15};
const hatchEndLocal={x:0,y:0.22,z:0.15};
const toWorld=(p,scale=1)=>({x:rotatedPod.x+scale*(p.x*Math.cos(rotatedYaw)+p.z*Math.sin(rotatedYaw)),y:rotatedPod.y+scale*p.y,z:rotatedPod.z+scale*(-p.x*Math.sin(rotatedYaw)+p.z*Math.cos(rotatedYaw))});
const openedPassage=resolveLifepodMovement(toWorld(hatchStartLocal),toWorld(hatchEndLocal),rotatedPod,rotatedYaw,0.38,1,true);
assert.equal(openedPassage.blocked.y,false,'An opened hatch must allow vertical passage into the Lifepod');
assert.equal(lifepodInteriorContains(...Object.values(worldToLifepodLocal(openedPassage.position.x,openedPassage.position.y,openedPassage.position.z,rotatedPod,rotatedYaw))),true,'Opened hatch passage must end inside the cabin');
const closedPassage=resolveLifepodMovement(toWorld(hatchStartLocal),toWorld(hatchEndLocal),rotatedPod,rotatedYaw,0.38,1,false);
assert.equal(closedPassage.blocked.y,true,'A closed hatch must prevent vertical entry');
const undersideEscape=resolveLifepodMovement(podCenter,{x:podCenter.x,y:podCenter.y-3.2,z:podCenter.z},rotatedPod,rotatedYaw);
assert.equal(undersideEscape.blocked.y,true,'Lifepod underside must block downward movement');
const sideEscape=resolveLifepodMovement(podCenter,{x:podCenter.x+3.2,y:podCenter.y,z:podCenter.z},rotatedPod,rotatedYaw);
assert.equal(sideEscape.blocked.x,true,'Lifepod side wall must block horizontal movement');
assert.ok(sideEscape.position.x < podCenter.x+1.1,'The diver must remain inside the hull after a side collision');
const localCenter = { x: 0, y: 0, z: 0 };
const rotatedWorldCenter = { x: rotatedPod.x + localCenter.x*Math.cos(rotatedYaw) + localCenter.z*Math.sin(rotatedYaw), y: rotatedPod.y, z: rotatedPod.z - localCenter.x*Math.sin(rotatedYaw) + localCenter.z*Math.cos(rotatedYaw) };
assert.deepEqual(worldToLifepodLocal(rotatedWorldCenter.x, rotatedWorldCenter.y, rotatedWorldCenter.z, rotatedPod, rotatedYaw), { x: 0, y: 0, z: 0 }, 'World/local transform must invert Three.js yaw rotation');
assert.equal(lifepodInteriorContains(...Object.values(worldToLifepodLocal(rotatedWorldCenter.x, rotatedWorldCenter.y, rotatedWorldCenter.z, rotatedPod, rotatedYaw))), true);
assert.equal(lifepodSegmentBlocked({x:10,y:-8,z:-4},{x:14,y:-8,z:-4},rotatedPod,rotatedYaw), true, 'Swept collision must stop movement through the hull');
const hatchOrigin = { x: rotatedPod.x + 0.15*Math.sin(rotatedYaw), y: rotatedPod.y + 4, z: rotatedPod.z + 0.15*Math.cos(rotatedYaw) };
const hatchDirection = { x: -Math.sin(rotatedYaw)*0, y: -1, z: 0 };
assert.ok(getLifepodHatchAim(hatchOrigin, hatchDirection, rotatedPod, rotatedYaw, 7), 'Top hatch should be aimable from above');
assert.equal(getLifepodHatchAim(hatchOrigin, {x:1,y:0,z:0}, rotatedPod, rotatedYaw, 7), null, 'Sideways aim cannot trigger hatch entry');
assert.match(game, /function exitHabitat\(\)/);
assert.match(game, /getLifepodExitWorldPosition\(/, 'Lifepod exit must use a tested, shell-clear egress coordinate');
assert.match(game, /!lifepodInteriorContains\(local\.x,local\.y,local\.z\)/, 'Exit candidates must be outside the interior volume');
assert.match(game, /!lifepodHatchChannelContains\(local\.x,local\.y,local\.z\)/, 'Exit candidates must clear the hatch channel');
assert.match(game, /player\.position\.copy\(previousPosition\);player\.velocity\.copy\(previousVelocity\)/, 'A failed final exit validation must roll back the diver pose and velocity');
assert.match(game, /respawnPoint\.copy\(previousRespawnPoint\)/, 'Failed entry validation must restore the prior checkpoint');
assert.match(game, /getInsideHabitat\(\)\?\.type!==\s*'lifepod'/, 'Lifepod entry must validate its final interior state');
assert.match(game, /playSfx\('panelOpen'\)/, 'Inventory panel opening should provide UI audio feedback');
assert.match(game, /playSfx\('fabricatorOpen'\)/, 'Fabricator opening should provide UI audio feedback');
assert.match(styles, /html,body\{[^}]*touch-action:pan-y/, 'Scrollable panels must not inherit a global touch-action:none');
assert.match(styles, /\.panel-screen\{[^}]*touch-action:pan-y/, 'Panel overlay must allow vertical touch scrolling');
assert.match(styles, /grid-template-columns:repeat\(8,minmax\(0,1fr\)\);grid-template-rows:repeat\(6/, 'Backpack must keep its 8×6 grid layout');
assert.match(game, /function saveCurrentSlot\(\)/);
assert.match(game, /No background saving: progress is committed only when the player selects Save/);

// Explicitly retired custom features are absent from runtime, schema, and interface.
for (const [label, source] of [['game.js', game], ['save-schema.mjs', schema], ['index.html', html], ['styles.css', styles]]) {
  assert.doesNotMatch(source, /autoSave|autosave-toggle|autosave-setting/i, `${label} still exposes autosave`);
  assert.doesNotMatch(source, /bed-btn|bed checkpoint|checkpoint kasur|isNearHabitatBed/i, `${label} still exposes bed checkpoints`);
  assert.doesNotMatch(source, /chestplate|helmetOwned|reinforcedSuitOwned|oxygen_station/i, `${label} still exposes retired armor/oxygen-station gear`);
}
assert.doesNotMatch(game, /Math\.random\(\) \* 3|oxygenDrainTimer/, 'Random/timed oxygen drain must be removed');
assert.doesNotMatch(game, /pressureDamageTimer|thermalDamageTimer|temperatureC/, 'Custom pressure/temperature damage must be removed');
assert.ok(!idSet.has('supply-btn'), 'Separate supply button should be replaced by contextual Interact');
assert.ok(!idSet.has('autosave-toggle') && !idSet.has('bed-btn'));

// Android/offline packaging must not depend on an external backend.
assert.equal(manifest.orientation, 'landscape');
assert.equal(capacitor.appId, 'com.abyssal.game');
assert.equal(capacitor.webDir, 'www');
assert.ok(pkg.dependencies['@capacitor/app'], 'Native Android back/lifecycle plugin must be installed');
assert.match(serviceWorker, /the-abyssal-2-2-0-cinematic-gameplay-overhaul/);
assert.match(game, /const current = '2\.2\.0'/);
assert.match(backendSetup, /VITE_SUPABASE_URL/);
assert.match(workflow, /node scripts\/configure-backend\.mjs/);
assert.match(workflow, /native\/abyssal-debug-signing\.bin/);
assert.match(nativePatcher, /native\/abyssal-debug-signing\.bin/);
assert.doesNotMatch(gitignore, /abyssal-debug-signing\.bin/);
await access(join(root, 'native/abyssal-debug-signing.bin'));
assert.match(workflow, /dump badging/);
assert.match(workflow, /com\.abyssal\.game/);
assert.match(workflow, /VITE_SUPABASE_URL/);
assert.match(workflow, /VITE_SUPABASE_PUBLISHABLE_KEY/);
assert.doesNotMatch(nativePatcher, /auth\/callback|deepLinkFilter/);
assert.match(nativeBuilder, /await build\(/);
assert.match(workflow, /npm test/);
assert.match(workflow, /assembleDebug/);
assert.match(workflow, /if \[ -d android \]/);
assert.match(workflow, /npm run android:sync/);
assert.match(workflow, /npm run android:add/);
assert.match(workflow, /actions\/upload-artifact@v7/);
assert.doesNotMatch(workflow, /actions\/upload-artifact@v4/);
assert.match(readme, /multiplayer/i);
assert.match(readme, /Supabase/i);
assert.match(multiplayer, /signUp/);
assert.match(multiplayer, /get authReady\(\)/);
assert.match(multiplayer, /signInWithPassword/);
assert.match(multiplayer, /abyssal_create_room/);
assert.match(multiplayer, /abyssal_join_room/);
assert.match(multiplayer, /player_state/);
assert.match(multiplayer, /room_chat/);
assert.match(multiplayer, /trackStatus !== 'ok'/);
assert.match(multiplayer, /status !== 'ok'/);
assert.match(multiplayer, /status === 'SUBSCRIBED'/);
assert.match(game, /diver\.initialized/);
assert.match(game, /ROOM RECONNECTING/);
assert.match(game, /KONFIGURASI TERSIMPAN/);
assert.match(workflow, /VITE_SUPABASE_URL: \$\{\{ secrets\.SUPABASE_URL \}\}/);
assert.match(workflow, /VITE_SUPABASE_PUBLISHABLE_KEY: \$\{\{ secrets\.SUPABASE_PUBLISHABLE_KEY \}\}/);
assert.match(workflow, /the-abyssal-android-apk-2\.2\.0/);
assert.match(nativeBuilder, /configure-backend\.mjs/);
assert.match(multiplayerSql, /enable row level security/i);
assert.match(multiplayerSql, /abyssal_is_room_member/);
assert.match(multiplayerSql, /realtime\.messages/);
assert.match(multiplayerSql, /realtime\.topic\(\)/i);
assert.match(sharedWorldSql,/abyssal_room_world_events/);
assert.match(sharedWorldSql,/enable row level security/i);
assert.match(sharedWorldSql,/abyssal_is_room_member/);
assert.match(sharedWorldSql,/abyssal_push_world_event/);
assert.match(sharedWorldSql,/abyssal_read_world_events/);
assert.match(sharedWorldSql,/unique \(room_id, actor_id, client_event_id\)/i);
assert.match(sharedWorldSql,/on conflict \(room_id, actor_id, client_event_id\) do nothing/i,'World event RPC must tolerate an idempotent retry race');
assert.match(sharedWorldSql,/jsonb_build_object\('type', v_payload->>'type'\)/,'Server stores only a canonical event payload');
assert.match(multiplayer,/abyssal_push_world_event/);
assert.match(multiplayer,/abyssal_read_world_events/);
assert.match(multiplayer,/worldOutboxKey/);
assert.match(multiplayer,/refreshWorldEvents/);
assert.match(multiplayer,/const latestQueue = this\.readWorldOutbox\(roomId\)/,'Outbox flush must merge acknowledgements with concurrently appended events');
assert.match(multiplayer,/Do not clear in-flight locks here/,'Room changes must not unlock still-pending world sync requests');
assert.match(game,/applySharedWorldEvent/);
assert.match(game,/publishSharedWorldEvent\('resource_collected'/);
assert.match(game,/publishSharedWorldEvent\('structure_placed'/);
assert.match(game,/publishSharedWorldEvent\('cache_collected'/);
assert.match(game,/resolveLifepodMovement\(from,requested/,'Runtime movement must use the swept 3-axis collision resolver');
assert.match(game,/player\.position\.y=clamp\(player\.position\.y,floorClearance,upperBound\)/,'Floor clamp must preserve collision-resolved Y, never restore the blocked target');
assert.doesNotMatch(game,/player\.position\.y=clamp\(nextY,floorClearance,upperBound\)/);
assert.match(multiplayerSql, /abyssal_is_realtime_room_member/i);
assert.match(multiplayerSql, /\[\^A-Za-z0-9\]/, 'Server room-code sanitizer must accept lowercase codes before uppercase normalization');
assert.match(envExample, /VITE_SUPABASE_URL/);
assert.match(envExample, /VITE_SUPABASE_PUBLISHABLE_KEY/);
assert.doesNotMatch(envExample, /VITE_[A-Z0-9_]+=(?:sb_secret_|[^\n]*service_role)/i, 'The environment template must never contain a secret key value');
assert.match(workflow, /secrets\.SUPABASE_URL/);
assert.match(workflow, /secrets\.SUPABASE_PUBLISHABLE_KEY/);
assert.match(game, /MULTIPLAYER ROOM/);
assert.match(html, /id="online-login-form"/);
assert.match(html, /id="online-register-form"/);
assert.match(html, /id="create-room-btn"/);
assert.match(html, /id="join-room-btn"/);
assert.match(html, /id="online-chat-form"/);
assert.match(html, /id="backend-config-form"/);
assert.match(html, /id="backend-project-url"/);
assert.match(html, /id="backend-publishable-key"/);
assert.match(multiplayer, /configureBackend/);
assert.match(multiplayer, /the-abyssal-supabase-config-v1/);
assert.match(game, /online\.configureBackend/);
assert.match(game, /!online\.authReady/);
assert.match(game, /explainOnlineError/);
assert.match(game, /Email belum diverifikasi/);
assert.deepEqual(validatePublicBackendConfig('https://abyssal-demo.supabase.co', 'sb_publishable_example_public_key'), { url:'https://abyssal-demo.supabase.co', publishableKey:'sb_publishable_example_public_key' });
assert.throws(() => validatePublicBackendConfig('http://abyssal-demo.supabase.co', 'sb_publishable_example_public_key'), /HTTPS/);
assert.throws(() => validatePublicBackendConfig('https://abyssal-demo.supabase.co', 'sb_secret_do_not_use'), /secret/);
assert.throws(() => validatePublicBackendConfig('https://abyssal-demo.supabase.co', 'not-a-key'), /Key tidak dikenali/);
assert.equal(normalizeRoomCode(' ab-12cd '), 'AB12CD');
assert.equal(normalizeRoomCode('A!B?'), 'AB');
assert.equal(sanitizeChatText('  hi\nthere\u0000  '), 'hi there');
assert.equal(sanitizeDisplayName('  <Diver>  '), 'Diver');
assert.equal(sanitizePlayerState({ userId:'u1', x:1, y:-7, z:2, yaw:0.5, pitch:0.2 }).depth, 7);
assert.equal(sanitizePlayerState({ userId:'u1', x:760, y:-275, z:-620, yaw:0.5, pitch:0.2 })?.y, -275, 'Deep-diver player state must pass multiplayer sanitizer');
assert.equal(sanitizeWorldEventInput('structure_placed','trench-build',{type:'compartment',x:760,y:-270,z:-620,yaw:0.5})?.payload.y, -270, 'Deep habitat build event must pass client sanitizer');
assert.equal(sanitizePlayerState({ userId:'u1', x:Infinity, y:-7, z:2, yaw:0, pitch:0 }), null);
assert.deepEqual(flattenPresence({u1:[{user_id:'u1',display_name:'Diver 1'}],u2:[{user_id:'u2',display_name:'Diver 2'}]}).map(member=>member.userId), ['u1','u2']);
assert.deepEqual(sanitizeWorldEventInput('resource_collected','12:8:ore:2',{type:'copper'}), {eventType:'resource_collected',entityId:'12:8:ore:2',payload:{type:'copper'}});
assert.equal(sanitizeWorldEventInput('structure_placed','build-1',{type:'compartment',x:12,y:-8,z:4,yaw:0.5})?.payload.type,'compartment');
assert.equal(sanitizeWorldEventInput('structure_placed','build-1',{type:'teleporter',x:0,y:0,z:0,yaw:0}),null);
assert.equal(sanitizeWorldEventInput('resource_collected','x'.repeat(150),{type:'copper'}).entityId.length,120);
assert.equal(sanitizeWorldEventInput('structure_placed','build-blank',{type:'compartment',x:'',y:0,z:0,yaw:0}),null,'Blank coordinates must not be coerced to zero');
assert.equal(sanitizeWorldEventInput('structure_placed','build-bool',{type:'compartment',x:true,y:0,z:0,yaw:0}),null,'Boolean coordinates must not be coerced to numbers');
assert.equal(normalizeWorldEvent({event_id:'7',actor_id:'user-2',event_type:'biome_discovered',entity_id:'reef',payload:{biomeId:'reef'},created_at:'2026-11-07T00:00:00Z'}).eventId,7);
assert.equal(normalizeWorldEvent({event_id:'bad',actor_id:'user-2',event_type:'biome_discovered',entity_id:'reef',payload:{biomeId:'reef'}}),null);
assert.ok(styles.includes('.oxygen-gauge') && styles.includes('.depth-indicator') && styles.includes('.hotbar-slot'));
assert.ok(styles.includes('.inventory-slot-grid') && styles.includes('.fabricator-recipes') && styles.includes('.action-controls'));


const configureScript = join(root, 'scripts/configure-backend.mjs');
const cleanEnv = { ...process.env };
for (const key of ['VITE_SUPABASE_URL','SUPABASE_URL','VITE_SUPABASE_PUBLISHABLE_KEY','SUPABASE_PUBLISHABLE_KEY','VITE_SUPABASE_ANON_KEY','SUPABASE_ANON_KEY']) delete cleanEnv[key];
const offlineConfig = spawnSync(process.execPath, [configureScript], { cwd: root, env: cleanEnv, encoding: 'utf8' });
assert.equal(offlineConfig.status, 0, `Offline config should remain buildable: ${offlineConfig.stderr}`);
const configuredEnv = { ...cleanEnv, VITE_SUPABASE_URL:'https://abyssal-demo.supabase.co', VITE_SUPABASE_PUBLISHABLE_KEY:'sb_publishable_example_public_key' };
const validConfig = spawnSync(process.execPath, [configureScript], { cwd: root, env: configuredEnv, encoding: 'utf8' });
assert.equal(validConfig.status, 0, `Public Supabase configuration should validate: ${validConfig.stderr}`);
const partialConfig = spawnSync(process.execPath, [configureScript], { cwd: root, env: { ...cleanEnv, VITE_SUPABASE_URL:'https://abyssal-demo.supabase.co' }, encoding: 'utf8' });
assert.notEqual(partialConfig.status, 0, 'Partial Supabase config must fail closed');
const secretConfig = spawnSync(process.execPath, [configureScript], { cwd: root, env: { ...cleanEnv, VITE_SUPABASE_URL:'https://abyssal-demo.supabase.co', VITE_SUPABASE_PUBLISHABLE_KEY:'sb_secret_never_bundle' }, encoding: 'utf8' });
assert.notEqual(secretConfig.status, 0, 'Supabase secret keys must never be bundled');
const unknownKeyConfig = spawnSync(process.execPath, [configureScript], { cwd: root, env: { ...cleanEnv, VITE_SUPABASE_URL:'https://abyssal-demo.supabase.co', VITE_SUPABASE_PUBLISHABLE_KEY:'not-a-supabase-key' }, encoding: 'utf8' });
assert.notEqual(unknownKeyConfig.status, 0, 'Unknown key formats must fail closed');

// 2.0.0 deep-expedition, waterline, scaled Lifepod, and fauna habitat constraints: verify Auth endpoint wiring/config validation,
// app lifecycle source, stale room-membership recovery source, and actual native launcher icon assets.
assert.match(multiplayer, /\/auth\/v1\/settings/);
assert.match(multiplayer, /headers:\s*\{\s*apikey:\s*this\.publishableKey/);
assert.match(multiplayer, /data === false/);
assert.match(multiplayer, /abyssal_join_room/);
assert.match(multiplayer, /heartbeatInFlight/);
assert.match(game, /bindNativeLifecycle/);
assert.match(game, /addListener\('backButton'/);
assert.match(game, /addListener\('appStateChange'/);
assert.match(game, /Keluar dari The Abyssal/);
assert.match(roomRecoverySql, /create or replace function public\.abyssal_join_room/);
assert.match(roomRecoverySql, /Promote the oldest[\s\S]*active member/);
assert.match(roomRecoverySql, /grant execute on function public\.abyssal_join_room\(text\) to authenticated/);
assert.match(nativePatcher, /native\/android-icons\/mipmap-\$\{density\}/);
assert.match(nativePatcher, /android:roundIcon="@mipmap\/ic_launcher_round"/);
assert.ok(nativePatcher.includes('manifest.match(/<application\\b'), 'Android manifest application tag must use a word-boundary regex');
for (const relative of [
  'icons/icon-192.png', 'icons/icon-512.png', 'icons/icon-maskable-512.png',
  'native/android-icons/ic_launcher_foreground.png',
  'native/android-icons/mipmap-anydpi-v26/ic_launcher.xml',
  'native/android-icons/mipmap-anydpi-v26/ic_launcher_round.xml',
  'native/android-icons/abyssal_launcher_colors.xml',
  'native/android-icons/mipmap-mdpi/ic_launcher.png',
  'native/android-icons/mipmap-hdpi/ic_launcher.png',
  'native/android-icons/mipmap-xhdpi/ic_launcher.png',
  'native/android-icons/mipmap-xxhdpi/ic_launcher.png',
  'native/android-icons/mipmap-xxxhdpi/ic_launcher.png'
]) await access(join(root, relative));
for (const [relative, expectedSize] of [
  ['icons/icon-192.png', 192],
  ['icons/icon-512.png', 512],
  ['icons/icon-maskable-512.png', 512],
  ['native/android-icons/ic_launcher_foreground.png', 432],
  ['native/android-icons/mipmap-mdpi/ic_launcher.png', 48],
  ['native/android-icons/mipmap-hdpi/ic_launcher.png', 72],
  ['native/android-icons/mipmap-xhdpi/ic_launcher.png', 96],
  ['native/android-icons/mipmap-xxhdpi/ic_launcher.png', 144],
  ['native/android-icons/mipmap-xxxhdpi/ic_launcher.png', 192]
]) {
  const png = await readFile(join(root, relative));
  assert.equal(png.subarray(0, 8).toString('hex'), '89504e470d0a1a0a', `${relative} must be a PNG`);
  assert.equal(png.readUInt32BE(16), expectedSize, `${relative} width is incorrect`);
  assert.equal(png.readUInt32BE(20), expectedSize, `${relative} height is incorrect`);
}

// 2.0.0 environment, Lifepod scale, and texture regression tests.
assert.match(game, /const LIFEPOD_SCALE = 1\.32/);
assert.match(game, /root\.scale\.setScalar\(LIFEPOD_SCALE\)/);
assert.match(game, /waterSurfaceHeightAt\(player\.position\.x,player\.position\.z,clockState\.elapsed\)/);
assert.match(game, /updateSurfacePresentation\(eyeY,localWaterHeight,biome\)/);
assert.match(game, /updateWaterSurface\(dt\)/);
assert.match(game, /PlaneGeometry\(1900, 1900, waterSegments, waterSegments\)/);
assert.match(game, /surfaceSky\.userData\.dome\.material\.opacity=surfaceBlend/);
assert.match(game, /surfaceWaterTint/);
assert.match(fauna, /createTurtleShellTexture\(bump = false, size = 512\)/);
assert.match(fauna, /Hexagonal scutes/);
assert.match(fauna, /turtleShellBumpTexture/);
assert.match(fauna, /new THREE\.TorusGeometry\(0\.76, 0\.075, 8, 36\)/);
assert.match(styles, /surface-transition::after/);
assert.match(html, /aria-label="Quick Slot 1"/);
assert.match(html, /ANDROID BUILD 2\.2\.0/);
assert.match(html, /Low · 1024×1024/);
assert.match(html, /Medium · 2048×2048/);
assert.match(html, /High · 4096×4096/);
assert.match(html, /Ultra · 4K/);
assert.match(html, /id="graphics-detail"/);
assert.match(environmentSimulation, /export function waterSurfaceHeightAt/);
assert.match(environmentSimulation, /export function canBreatheAtSurface/);
assert.match(environmentSimulation, /export function computeDaylight/);
assert.match(environmentSimulation, /export function computeSeagrassSway/);
assert.match(environmentSimulation, /export function computeSwimPose/);
assert.match(environmentSimulation, /export function waterTextureResolution/);
const waterA = waterSurfaceHeightAt(12.5, -7.25, 18);
const waterB = waterSurfaceHeightAt(12.5, -7.25, 18);
const waterLater = waterSurfaceHeightAt(12.5, -7.25, 19);
assert.equal(waterA, waterB, 'Water waves must be deterministic at the same world coordinate and time');
assert.ok(Number.isFinite(waterA) && Math.abs(waterA) < 0.25, 'Water wave displacement must remain bounded');
assert.notEqual(waterA, waterLater, 'Water surface must animate over time');
assert.deepEqual(GRAPHICS_TEXTURE_TARGETS, { low: 1024, balanced: 2048, high: 4096, ultra: 4096 });
assert.equal(waterTextureResolution('low'), 1024);
assert.equal(waterTextureResolution('balanced'), 2048);
assert.equal(waterTextureResolution('high'), 4096);
assert.equal(waterTextureResolution('ultra'), 4096);
const lowTextureProfile = resolveGraphicsTextureProfile('low', 8192, 8);
assert.equal(lowTextureProfile.primaryTextureSize, 1024, 'Low preset must render main textures above 512px');
assert.equal(lowTextureProfile.waterTextureSize, 1024, 'Low preset water texture must be above 512px');
assert.equal(lowTextureProfile.effectivePreset, 'low');
const mediumTextureProfile = resolveGraphicsTextureProfile('balanced', 8192, 8);
assert.equal(mediumTextureProfile.primaryTextureSize, 2048, 'Medium preset must render main textures above 1024px');
assert.equal(mediumTextureProfile.waterTextureSize, 2048, 'Medium preset water texture must be above 1024px');
assert.equal(mediumTextureProfile.effectivePreset, 'balanced');
const ultraTextureProfile = resolveGraphicsTextureProfile('ultra', 8192, 12);
assert.equal(ultraTextureProfile.primaryTextureSize, 4096, 'Ultra preset must use 4K main textures on a 12 GB-class device');
assert.equal(ultraTextureProfile.supportingTextureSize, 2048, 'Ultra secondary maps remain at a controlled 2K memory budget');
assert.equal(ultraTextureProfile.effectivePreset, 'ultra');
assert.equal(ultraTextureProfile.is4K, true, 'Ultra 4K capability flag must match its allocated primary textures');
const lowMemoryUltraProfile = resolveGraphicsTextureProfile('ultra', 8192, 8);
assert.equal(lowMemoryUltraProfile.effectivePreset, 'high', 'Ultra must gracefully fall back to High when 4K is supported but the Ultra memory budget is not');
assert.ok(lowMemoryUltraProfile.fallbackReason.includes('Ultra'));
const unknownMemoryUltraProfile = resolveGraphicsTextureProfile('ultra', 8192, 0);
assert.equal(unknownMemoryUltraProfile.effectivePreset, 'balanced', 'Unknown device memory must use the safe Medium tier for Ultra');
const highTextureProfile = resolveGraphicsTextureProfile('high', 8192, 8);
assert.equal(highTextureProfile.primaryTextureSize, 4096, 'High preset must activate 4K main textures on capable devices');
assert.equal(highTextureProfile.waterTextureSize, 4096, 'High preset must activate 4K water textures on capable devices');
assert.equal(highTextureProfile.supportingTextureSize, 2048, 'High preset keeps secondary maps at a memory-safe 2K tier');
assert.equal(highTextureProfile.effectivePreset, 'high');
const midMemoryHighProfile = resolveGraphicsTextureProfile('high', 8192, 6);
assert.equal(midMemoryHighProfile.primaryTextureSize, 2048, 'High preset must avoid 4K allocations on 6GB-class mobile devices');
assert.ok(midMemoryHighProfile.fallbackReason.includes('Memori'));
assert.equal(midMemoryHighProfile.effectivePreset, 'balanced');
const unknownMemoryHighProfile = resolveGraphicsTextureProfile('high', 8192, 0);
assert.equal(unknownMemoryHighProfile.waterTextureSize, 2048, 'Unknown device memory must use a safe 2K fallback');
assert.equal(resolveGraphicsTextureProfile('low', 8192, 4).primaryTextureSize, 1024);
assert.equal(resolveGraphicsTextureProfile('balanced', 8192, 4).waterTextureSize, 2048);
assert.equal(resolveGraphicsTextureProfile('low', 512, 4).waterTextureSize, 512, 'A GPU below the requested tier must report its hardware-limited texture size');
assert.equal(resolveGraphicsTextureProfile('balanced', Number.POSITIVE_INFINITY, 4).waterTextureSize, 2048, 'Non-finite GPU reports must not produce infinite texture dimensions');
const gpuFallbackProfile = resolveGraphicsTextureProfile('high', 2048, 8);
assert.equal(gpuFallbackProfile.primaryTextureSize, 2048, 'High preset must fall back to GPU maximum when 4K is unsupported');
assert.ok(gpuFallbackProfile.fallbackReason.includes('GPU'));
assert.equal(gpuFallbackProfile.effectivePreset, 'balanced');
const memoryFallbackProfile = resolveGraphicsTextureProfile('high', 8192, 4);
assert.equal(memoryFallbackProfile.waterTextureSize, 2048, 'High preset must avoid 4K allocations on low-memory devices');
assert.ok(memoryFallbackProfile.fallbackReason.includes('Memori'));
assert.match(game, /function makeGraphicsTextureSet\(profile\)/);
assert.match(game, /function makeGraphicsTextureSetWithFallback\(requestedProfile\)/);
assert.match(game, /Semua tingkat tekstur gagal dibuat/);
assert.match(game, /activeGraphicsTextureSetKey|activeGraphicsProfileKey/);
assert.match(game, /texture\.anisotropy = anisotropy/);
assert.match(game, /function applyGraphicsTextureSet\(set, disposePrevious = true\)/);
assert.match(game, /applyGraphicsTextureSet\(built\.textureSet\)/);
assert.match(game, /updateGraphicsResolutionLabel\(profile\)/);
assert.match(game, /applyWaterQualitySettings\(profile, visualQuality\)/);
assert.match(game, /renderer\.shadowMap\.enabled = visualQuality !== 'low'/);
assert.match(game, /sunLight\.castShadow = isHighQuality/);
assert.match(game, /faunaDirector\?\.setQuality\(visualQuality, profile\.faunaTextureSize\)/);
assert.doesNotMatch(game, /const speed=\(settings\.graphics/, 'Graphics presets must not change swimming gameplay speed');
assert.match(environmentSimulation, /memory >= 8/);
assert.match(fauna, /createTurtleShellTexture\(bump = false, size = 512\)/);
assert.match(fauna, /setQuality\(value, textureSize = null\)/);
for (const [x,z,t] of [[0,0,0],[100,-80,42],[-250,310,120]]) {
  const h=waterSurfaceHeightAt(x,z,t);
  assert.ok(Number.isFinite(h) && Math.abs(h) < 0.25, 'Water wave height must stay bounded and finite');
  const sway=computeSeagrassSway(x,z,t,0.9);
  assert.ok(Number.isFinite(sway.x) && Number.isFinite(sway.z) && Math.abs(sway.x)<0.3 && Math.abs(sway.z)<0.2);
}
const stillPose=computeSwimPose(0.7,0,false,false);
const swimPose=computeSwimPose(0.7,0.8,false,false);
const glidePose=computeSwimPose(0.7,0.8,true,true);
assert.equal(stillPose.blend,0);
assert.ok(Math.abs(swimPose.leftArmX)>Math.abs(stillPose.leftArmX));
assert.ok(Math.abs(glidePose.rightArmX-0.08)<Math.abs(swimPose.rightArmX-0.08), 'Seaglide pose should damp free-swim strokes');
assert.equal(canBreatheAtSurface(0.2, 0, 0.045), true, 'Breathing requires the diver eye to be clearly above the surface');
assert.equal(canBreatheAtSurface(-0.2, 0, 0.045), false, 'A diver below the waterline cannot breathe');
assert.ok(computeSurfaceBlend(0.2, 0) > computeSurfaceBlend(-0.2, 0), 'Waterline transition must blend continuously across the surface');
assert.ok(Math.abs(computeDaylight(35, 900).daylight - computeDaylight(935, 900).daylight) < 1e-12, 'Day/night cycle must repeat for the same world-clock phase');
assert.ok(Number.isFinite(computeDaylight(Number.NaN).daylight), 'Invalid world time must not poison daylight math');

// World-to-local and collision must remain correct after uniform Lifepod scaling and yaw.
const podPosition = { x: 44, y: -8, z: -31 };
const podYaw = 0.73;
const podScale = 1.24;
const localPoint = { x: 0.22, y: 0.15, z: -0.31 };
const cosYaw = Math.cos(podYaw), sinYaw = Math.sin(podYaw);
const worldPoint = {
  x: podPosition.x + podScale * (localPoint.x * cosYaw + localPoint.z * sinYaw),
  y: podPosition.y + podScale * localPoint.y,
  z: podPosition.z + podScale * (-localPoint.x * sinYaw + localPoint.z * cosYaw)
};
const recoveredLocal = worldToLifepodLocal(worldPoint.x, worldPoint.y, worldPoint.z, podPosition, podYaw, podScale);
assert.ok(Math.abs(recoveredLocal.x - localPoint.x) < 1e-9);
assert.ok(Math.abs(recoveredLocal.y - localPoint.y) < 1e-9);
assert.ok(Math.abs(recoveredLocal.z - localPoint.z) < 1e-9);
const wallLocal = { x: 1.55, y: 0, z: 0 };
const wallWorld = {
  x: podPosition.x + podScale * (wallLocal.x * cosYaw + wallLocal.z * sinYaw),
  y: podPosition.y,
  z: podPosition.z + podScale * (-wallLocal.x * sinYaw + wallLocal.z * cosYaw)
};
assert.equal(lifepodHullBlocksWorld(wallWorld.x, wallWorld.y, wallWorld.z, podPosition, podYaw, 0.38, podScale), true, 'Scaled Lifepod side shell must remain solid');
const hatchOriginLocal = { x: 0, y: 3, z: 0.15 };
const scaledHatchOrigin = { x: podPosition.x + podScale * hatchOriginLocal.z * sinYaw, y: podPosition.y + podScale * hatchOriginLocal.y, z: podPosition.z + podScale * hatchOriginLocal.z * cosYaw };
const hatchAim = getLifepodHatchAim(scaledHatchOrigin, { x: 0, y: -1, z: 0 }, podPosition, podYaw, 7, podScale);
assert.ok(hatchAim, 'Scaled Lifepod roof hatch must remain aimable');
const scaledHatchLocal={x:0,y:1.6,z:0.15};
const scaledHatchCenter={x:podPosition.x+podScale*(scaledHatchLocal.x*cosYaw+scaledHatchLocal.z*sinYaw),y:podPosition.y+podScale*scaledHatchLocal.y,z:podPosition.z+podScale*(-scaledHatchLocal.x*sinYaw+scaledHatchLocal.z*cosYaw)};
assert.equal(lifepodHullBlocksWorld(scaledHatchCenter.x,scaledHatchCenter.y,scaledHatchCenter.z,podPosition,podYaw,0.38,podScale,false),true,'Scaled closed hatch must block entry');
assert.equal(lifepodHullBlocksWorld(scaledHatchCenter.x,scaledHatchCenter.y,scaledHatchCenter.z,podPosition,podYaw,0.38,podScale,true),false,'Scaled opened hatch must be passable');
assert.ok(Math.abs(hatchAim.localZ - 0.15) < 1e-6);
const roofOutsideLocal = {x:0,y:0,z:1.05};
const moveFrom = {x:podPosition.x+podScale*(roofOutsideLocal.x*cosYaw+roofOutsideLocal.z*sinYaw),y:podPosition.y,z:podPosition.z+podScale*(-roofOutsideLocal.x*sinYaw+roofOutsideLocal.z*cosYaw)};
const moveTo = { x: moveFrom.x, y: podPosition.y + 2.6 * podScale, z: moveFrom.z };
const resolvedRoof = resolveLifepodMovement(moveFrom, moveTo, podPosition, podYaw, 0.38, podScale);
const resolvedRoofLocal = worldToLifepodLocal(resolvedRoof.position.x, resolvedRoof.position.y, resolvedRoof.position.z, podPosition, podYaw, podScale);
assert.equal(resolvedRoof.blocked.y, true, 'Vertical swept collision must stop movement through the scaled roof');
assert.ok(resolvedRoofLocal.y < 1.2, 'Player must remain inside the collision boundary when moving into the roof');
const moveToFloor = { x: podPosition.x, y: podPosition.y - 2.6 * podScale, z: podPosition.z };
const resolvedFloor = resolveLifepodMovement(moveFrom, moveToFloor, podPosition, podYaw, 0.38, podScale);
const resolvedFloorLocal = worldToLifepodLocal(resolvedFloor.position.x, resolvedFloor.position.y, resolvedFloor.position.z, podPosition, podYaw, podScale);
assert.equal(resolvedFloor.blocked.y, true, 'Vertical swept collision must stop movement through the scaled floor/bottom hull');
assert.ok(resolvedFloorLocal.y > -1.2, 'Player must remain inside the collision boundary when moving into the floor');

// Original underwater vehicle fleet: save compatibility, upgrades, cargo, motion and collision.
assert.deepEqual(VEHICLE_IDS, ['skimmer','carrier','exosuit']);
for (const id of VEHICLE_IDS) {
  const def=VEHICLE_DEFS[id];
  assert.ok(def && def.dimensions && def.craftCost, `${id} must have a complete definition`);
  const state=createVehicleState(id);
  assert.equal(state.owned,false);
  assert.equal(state.deployed,false);
  assert.equal(getVehicleDepthRating(id,state),def.baseDepth);
  state.owned=true;
  assert.equal(canInstallVehicleUpgrade(id,state,'depth1'),true);
  assert.equal(canInstallVehicleUpgrade(id,state,'depth2'),false,'Depth module II must require module I first');
  state.upgrades.depth=1;
  assert.equal(canInstallVehicleUpgrade(id,state,'depth2'),true);
  state.upgrades.depth=2;
  assert.equal(getVehicleDepthRating(id,state),500,`${id} final depth rating should be 500 m`);
  assert.ok(getVehicleDepthRating(id,state)>=def.baseDepth);
  assert.equal(canInstallVehicleUpgrade(id,state,'hull'),true);
  state.upgrades.hull=true;
  assert.equal(getVehicleMaxHealth(id,state),def.maxHealth*1.5);
  const baseSpeed=getVehicleSpeed(id,state);
  state.upgrades.efficiency=true;
  assert.ok(getVehicleSpeed(id,state)>baseSpeed);
  assert.ok(vehiclePowerDrainPerSecond(id,state,true,false)>0);
  assert.equal(vehiclePowerDrainPerSecond(id,state,false,false),0);
  assert.ok(vehicleDepthDamage(id,{upgrades:{depth:2}},550)>=1);
  assert.equal(vehicleDepthDamage(id,{upgrades:{depth:2}},500),0);
}
const skimmer=createVehicleState('skimmer');
skimmer.owned=true;
assert.equal(getVehicleCargoCapacity('skimmer',skimmer),VEHICLE_DEFS.skimmer.baseCargo);
skimmer.upgrades.storage=true;
assert.ok(getVehicleCargoCapacity('skimmer',skimmer)>VEHICLE_DEFS.skimmer.baseCargo);
assert.equal(addVehicleCargo(skimmer,'titanium',999),getVehicleCargoCapacity('skimmer',skimmer));
assert.equal(getVehicleCargoUsed(skimmer),getVehicleCargoCapacity('skimmer',skimmer));
assert.equal(addVehicleCargo(skimmer,'titanium',4),0,'Vehicle cargo must not exceed its capacity');
assert.equal(removeVehicleCargo(skimmer,'titanium',3),3);
assert.equal(getVehicleCargoUsed(skimmer),getVehicleCargoCapacity('skimmer',skimmer)-3);
assert.equal(addVehicleCargo(skimmer,'secret_key',1),0,'Unsupported or secret data must not enter vehicle cargo');
const fleet=normalizeVehicleFleet({
  skimmer:{owned:true,deployed:true,position:{x:18,y:-45,z:-29},yaw:1.2,health:999,power:88,upgrades:{depth:2,storage:true,hull:true},cargo:{titanium:4}},
  carrier:{owned:false,deployed:true,position:{x:0,y:-900,z:0},cargo:{titanium:2000}},
  unknown:{owned:true,deployed:true}
});
assert.equal(fleet.skimmer.deployed,true);
assert.equal(fleet.skimmer.health,VEHICLE_DEFS.skimmer.maxHealth*1.5);
assert.equal(fleet.skimmer.power,88);
assert.equal(fleet.skimmer.position.y,-45);
assert.equal(fleet.skimmer.cargo.titanium,4);
assert.equal(fleet.carrier.deployed,false,'An unowned vehicle must never restore as deployed');
assert.equal(normalizeVehicleFleet({skimmer:{owned:true,health:999}}).skimmer.health,VEHICLE_DEFS.skimmer.maxHealth,'Unreinforced hull health must be clamped to its actual capacity');
assert.equal(fleet.carrier.position.y,-500,'Persisted vehicle coordinates must be clamped to valid world bounds');
assert.equal(fleet.unknown,undefined,'Unknown vehicle IDs must be discarded');
const vehicleSave=normalizeSaveRecord({version:11,position:{x:18,y:-45,z:-29},survival:{},inventory:{},vehicles:{skimmer:{owned:true,deployed:true,position:{x:18,y:-45,z:-29},upgrades:{depth:1}}},activeVehicleId:'skimmer'});
assert.equal(vehicleSave.version,11,'Vehicle persistence must remain additive to the existing v11 schema');
assert.equal(vehicleSave.vehicles.skimmer.deployed,true);
assert.equal(vehicleSave.activeVehicleId,'skimmer','A saved pilot state must restore only for a valid deployed owned vehicle');
const invalidActiveVehicleSave=normalizeSaveRecord({version:11,position:{},survival:{},inventory:{},vehicles:{skimmer:{owned:false,deployed:true}},activeVehicleId:'skimmer'});
assert.equal(invalidActiveVehicleSave.activeVehicleId,null,'Invalid deployed vehicle references must not survive save normalization');
const motion=integrateVehicleMotion({id:'skimmer',state:{power:100,upgrades:{}},position:{x:0,y:-20,z:0},velocity:{x:0,y:0,z:0},yaw:0,pitch:0,forward:1,dt:.05});
assert.ok(motion.position.z<0 && motion.position.y===-20,'Forward vehicle input must move ahead without accidental vertical drift');
assert.ok(Number.isFinite(motion.velocity.z));
const stalled=integrateVehicleMotion({id:'skimmer',state:{power:0,upgrades:{}},position:{x:0,y:-20,z:0},velocity:{x:0,y:0,z:0},yaw:0,pitch:0,forward:1,dt:.05});
assert.ok(Math.abs(stalled.velocity.z)<Math.abs(motion.velocity.z),'Empty power must reduce vehicle thrust');
const sweptVehicle=resolveVehicleSweep({x:0,y:-20,z:0},{x:6,y:-20,z:4},probe=>probe.x>=2,.25);
assert.equal(sweptVehicle.blocked.x,true,'Vehicle swept collision must detect a thin obstacle between frames');
assert.equal(sweptVehicle.position.x,0,'Blocked vehicle axis must not tunnel through the obstacle');
assert.equal(sweptVehicle.position.z,4,'A blocked axis should preserve lateral sliding');
assert.deepEqual(resolveVehicleSweep({x:0,y:-20,z:0},{x:1,y:-19,z:2},()=>false).position,{x:1,y:-19,z:2});
assert.match(game,/function sampleVehicleFloor\(/,'Vehicle floor sampling must cover its footprint, not only the player center');
assert.match(game,/function vehicleBlocksPosition\(/,'Vehicle hulls must collide with structures and the Lifepod');
assert.match(game,/resolveVehicleSweep\(/,'Vehicle movement must use swept collision resolution');
assert.match(game,/function exitActiveVehicle\(/,'Vehicle dismount must have a dedicated safe-exit path');
assert.match(game,/Tidak ada ruang aman untuk keluar/,'Dismount must fail safely if no clear exit position exists');
assert.match(game,/attackButton=\$\('attack-btn'\);[\s\S]*?useButton=\$\('use-item-btn'\);[\s\S]*?if\(activeVehicleId\)/,'Vehicle interaction prompt must initialize its buttons before the vehicle branch');
assert.match(html,/PELAGIC VEHICLE SYSTEMS/i);
assert.match(vehicleSystems,/Pelagic Skimmer/);
assert.match(vehicleSystems,/Pelagic Carrier/);
assert.match(vehicleSystems,/Nautilus Exosuit/);
assert.match(html,/id="vehicle-screen"/);
assert.match(html,/id="vehicle-special-btn"/);
assert.match(html,/id="vehicle-cargo-btn"/);
assert.match(html,/id="vehicle-hud-panel"/);
assert.match(game,/function hasVehicleServiceAccess\(/,'The mobile carrier must provide onboard cargo access');
assert.match(game,/vehicle-cargo-btn/,'The large carrier needs an onboard cargo action');
assert.match(game,/activeVehicleId==='carrier'\?'CARRIER COMMAND DECK/,'Carrier cargo must be available from its mobile command deck');
assert.match(game,/vehicle-bay-title/,'Vehicle panel title must distinguish the fixed bay from the mobile deck');
assert.match(game,/state\.power>=def\.maxPower/,'Recharge must respect each vehicle’s actual power capacity');
assert.match(html,/Vehicle Fabrication Bay/);

assert.match(setupGuide, /202611060002_room_recovery\.sql/);
assert.match(setupGuide, /202611070001_shared_world_events\.sql/);
assert.match(deepWorldSql, /abyssal_push_world_event/);
assert.match(deepWorldSql, /numeric < -320 or \(v_payload->>'y'\)::numeric > 100/);
assert.match(deepWorldSql, /grant execute on function public\.abyssal_push_world_event/);
assert.match(setupGuide, /202611070002_deep_world_coordinates\.sql/);
assert.match(workflow, /the-abyssal-android-apk-2\.2\.0/);
assert.match(serviceWorker, /the-abyssal-2-2-0-cinematic-gameplay-overhaul/);
assert.match(readme, /event dunia bersama/i);
assert.match(readme, /bukan simulasi shared-world penuh/i);
assert.match(readme, /The Abyssal 2\.2\.0/i);
console.log(`The Abyssal 2.2.0 verification passed: ${ids.length} unique DOM IDs, ${staticRefs.length} valid DOM references, local asset paths, deterministic terrain, v11 save migration and vehicle fleet/upgrades/cargo/swept collision, waterline/daylight helpers, scaled Lifepod transforms/collision/hatch regression, dry-ground jump gating, cave/oxygen-plant/sulfur-nest systems, 8142C cinematic source checks, 7-shot cutscene director/timeline and cancellation recovery checks, animated Leviathan fin/eye/light checks, held-item hand-fit profiles and layered cinematic audio checks, turtle shell texture source checks, survival/inventory/camera/tool checks, Supabase/Auth and SQL/RLS source checks, Android lifecycle/icon/signing/workflow checks.`);
