-- The Abyssal 1.7.0: email/password auth + private co-op rooms + realtime player sync.
-- Run once in Supabase SQL Editor. Never place a service_role/secret key in the app.

create table if not exists public.abyssal_rooms (
  id uuid primary key default gen_random_uuid(),
  code text not null unique check (code ~ '^[A-Z0-9]{6}$'),
  name text not null check (char_length(name) between 1 and 32),
  owner_id uuid not null references auth.users(id) on delete cascade,
  max_players smallint not null default 4 check (max_players between 2 and 4),
  created_at timestamptz not null default now()
);

create table if not exists public.abyssal_room_members (
  room_id uuid not null references public.abyssal_rooms(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  display_name text not null default 'Diver',
  joined_at timestamptz not null default now(),
  last_seen timestamptz not null default now(),
  primary key (room_id, user_id)
);

create index if not exists abyssal_room_members_active_idx
  on public.abyssal_room_members(room_id, last_seen desc);

alter table public.abyssal_rooms enable row level security;
alter table public.abyssal_room_members enable row level security;

grant select on public.abyssal_rooms to authenticated;
grant select on public.abyssal_room_members to authenticated;

create or replace function public.abyssal_is_room_member(p_room_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public, auth, pg_temp
as $$
  select exists (
    select 1 from public.abyssal_room_members m
    where m.room_id = p_room_id and m.user_id = (select auth.uid())
  );
$$;
revoke all on function public.abyssal_is_room_member(uuid) from public;
grant execute on function public.abyssal_is_room_member(uuid) to authenticated;

drop policy if exists "room members can read their rooms" on public.abyssal_rooms;
create policy "room members can read their rooms"
  on public.abyssal_rooms for select to authenticated
  using (public.abyssal_is_room_member(id));

drop policy if exists "room members can see fellow members" on public.abyssal_room_members;
create policy "room members can see fellow members"
  on public.abyssal_room_members for select to authenticated
  using (public.abyssal_is_room_member(room_id));

create or replace function public.abyssal_create_room(p_name text default 'Deep Expedition', p_max_players integer default 4)
returns table(room_id uuid, room_code text, room_name text, max_players integer, member_count integer)
language plpgsql
security definer
set search_path = public, auth, pg_temp
as $$
declare
  v_user_id uuid := auth.uid();
  v_code text;
  v_name text;
  v_room public.abyssal_rooms%rowtype;
  v_display text;
begin
  if v_user_id is null then raise exception 'AUTH_REQUIRED'; end if;
  v_name := left(regexp_replace(coalesce(nullif(trim(p_name), ''), 'Deep Expedition'), '[[:cntrl:]<>]', '', 'g'), 32);
  if v_name = '' then v_name := 'Deep Expedition'; end if;
  v_display := left(regexp_replace(coalesce((select raw_user_meta_data->>'display_name' from auth.users where id = v_user_id), 'Diver'), '[[:cntrl:]<>]', '', 'g'), 24);
  if p_max_players is null or p_max_players < 2 or p_max_players > 4 then raise exception 'INVALID_PLAYER_LIMIT'; end if;
  loop
    v_code := upper(substr(md5(random()::text || clock_timestamp()::text || v_user_id::text), 1, 6));
    exit when not exists (select 1 from public.abyssal_rooms r where r.code = v_code);
  end loop;
  insert into public.abyssal_rooms(code, name, owner_id, max_players)
    values (v_code, v_name, v_user_id, p_max_players)
    returning * into v_room;
  insert into public.abyssal_room_members(room_id, user_id, display_name)
    values (v_room.id, v_user_id, coalesce(nullif(v_display, ''), 'Diver'));
  return query select v_room.id, v_room.code, v_room.name, v_room.max_players::integer, 1;
end;
$$;

create or replace function public.abyssal_join_room(p_room_code text)
returns table(room_id uuid, room_code text, room_name text, max_players integer, member_count integer)
language plpgsql
security definer
set search_path = public, auth, pg_temp
as $$
declare
  v_user_id uuid := auth.uid();
  v_room public.abyssal_rooms%rowtype;
  v_count integer;
  v_display text;
  -- Normalize to uppercase before filtering so lowercase invite codes remain valid.
  v_code text := upper(regexp_replace(coalesce(p_room_code, ''), '[^A-Za-z0-9]', '', 'g'));
begin
  if v_user_id is null then raise exception 'AUTH_REQUIRED'; end if;
  if char_length(v_code) <> 6 then raise exception 'INVALID_ROOM_CODE'; end if;
  select * into v_room from public.abyssal_rooms r where r.code = v_code for update;
  if not found then raise exception 'ROOM_NOT_FOUND'; end if;
  -- A crashed app cannot hold a slot forever. Active clients refresh last_seen every 20 seconds.
  delete from public.abyssal_room_members m
    where m.room_id = v_room.id and m.last_seen < now() - interval '90 seconds';
  select count(*)::integer into v_count from public.abyssal_room_members m where m.room_id = v_room.id;
  if not exists (select 1 from public.abyssal_room_members m where m.room_id = v_room.id and m.user_id = v_user_id)
     and v_count >= v_room.max_players then
    raise exception 'ROOM_FULL';
  end if;
  v_display := left(regexp_replace(coalesce((select raw_user_meta_data->>'display_name' from auth.users where id = v_user_id), 'Diver'), '[[:cntrl:]<>]', '', 'g'), 24);
  insert into public.abyssal_room_members(room_id, user_id, display_name, last_seen)
    values (v_room.id, v_user_id, coalesce(nullif(v_display, ''), 'Diver'), now())
    on conflict (room_id, user_id) do update
      set display_name = excluded.display_name, last_seen = now();
  select count(*)::integer into v_count from public.abyssal_room_members m where m.room_id = v_room.id;
  return query select v_room.id, v_room.code, v_room.name, v_room.max_players::integer, v_count;
end;
$$;

create or replace function public.abyssal_touch_room(p_room_id uuid)
returns boolean
language plpgsql
security definer
set search_path = public, auth, pg_temp
as $$
declare v_user_id uuid := auth.uid(); v_updated integer;
begin
  if v_user_id is null then return false; end if;
  update public.abyssal_room_members
    set last_seen = now()
    where room_id = p_room_id and user_id = v_user_id;
  get diagnostics v_updated = row_count;
  return v_updated = 1;
end;
$$;

create or replace function public.abyssal_leave_room(p_room_id uuid)
returns boolean
language plpgsql
security definer
set search_path = public, auth, pg_temp
as $$
declare
  v_user_id uuid := auth.uid();
  v_owner uuid;
  v_next_owner uuid;
begin
  if v_user_id is null then return false; end if;
  select owner_id into v_owner from public.abyssal_rooms where id = p_room_id for update;
  if not found then return true; end if;
  delete from public.abyssal_room_members where room_id = p_room_id and user_id = v_user_id;
  if v_owner = v_user_id then
    select user_id into v_next_owner from public.abyssal_room_members
      where room_id = p_room_id order by joined_at asc limit 1;
    if v_next_owner is null then
      delete from public.abyssal_rooms where id = p_room_id;
    else
      update public.abyssal_rooms set owner_id = v_next_owner where id = p_room_id;
    end if;
  elsif not exists (select 1 from public.abyssal_room_members where room_id = p_room_id) then
    delete from public.abyssal_rooms where id = p_room_id;
  end if;
  return true;
end;
$$;

revoke all on function public.abyssal_create_room(text, integer) from public;
revoke all on function public.abyssal_join_room(text) from public;
revoke all on function public.abyssal_touch_room(uuid) from public;
revoke all on function public.abyssal_leave_room(uuid) from public;
grant execute on function public.abyssal_create_room(text, integer) to authenticated;
grant execute on function public.abyssal_join_room(text) to authenticated;
grant execute on function public.abyssal_touch_room(uuid) to authenticated;
grant execute on function public.abyssal_leave_room(uuid) to authenticated;

-- Private Realtime topics are tied to membership. Topic format: abyssal-room:<room UUID>.
-- Use realtime.topic() directly; this avoids a room-table subquery in Realtime's
-- authorization path and fails closed for malformed topics.
create or replace function public.abyssal_is_realtime_room_member(p_topic text)
returns boolean
language sql
stable
security definer
set search_path = public, auth, pg_temp
as $$
  select case
    when p_topic ~ '^abyssal-room:[0-9a-fA-F-]{36}$' then exists (
      select 1
      from public.abyssal_room_members m
      where m.room_id::text = split_part(p_topic, ':', 2)
        and m.user_id = (select auth.uid())
    )
    else false
  end;
$$;
revoke all on function public.abyssal_is_realtime_room_member(text) from public;
grant execute on function public.abyssal_is_realtime_room_member(text) to authenticated;

drop policy if exists "Abyssal members can receive private room events" on realtime.messages;
create policy "Abyssal members can receive private room events"
  on realtime.messages for select to authenticated
  using (
    extension in ('broadcast', 'presence')
    and public.abyssal_is_realtime_room_member((select realtime.topic()))
  );

drop policy if exists "Abyssal members can send private room events" on realtime.messages;
create policy "Abyssal members can send private room events"
  on realtime.messages for insert to authenticated
  with check (
    extension in ('broadcast', 'presence')
    and public.abyssal_is_realtime_room_member((select realtime.topic()))
  );
