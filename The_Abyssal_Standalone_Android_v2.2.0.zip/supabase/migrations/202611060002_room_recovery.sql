-- The Abyssal 1.7.0 follow-up migration.
-- Run this AFTER 202611060001_multiplayer.sql. It repairs stale-room ownership
-- when sleeping/offline members are pruned and another diver rejoins.

create or replace function public.abyssal_join_room(p_room_code text)
returns table(room_id uuid, room_code text, room_name text, max_players integer, member_count integer)
language plpgsql
security definer
set search_path = public, auth, pg_temp
as $$
declare
  v_user_id uuid := auth.uid();
  v_room public.abyssal_rooms%rowtype;
  v_count integer;
  v_display text;
  v_next_owner uuid;
  v_code text := upper(regexp_replace(coalesce(p_room_code, ''), '[^A-Za-z0-9]', '', 'g'));
begin
  if v_user_id is null then raise exception 'AUTH_REQUIRED'; end if;
  if char_length(v_code) <> 6 then raise exception 'INVALID_ROOM_CODE'; end if;

  select * into v_room from public.abyssal_rooms r where r.code = v_code for update;
  if not found then raise exception 'ROOM_NOT_FOUND'; end if;

  -- Remove room memberships left behind by a client that has been offline
  -- longer than the server heartbeat window.
  delete from public.abyssal_room_members m
    where m.room_id = v_room.id and m.last_seen < now() - interval '90 seconds';

  select count(*)::integer into v_count
    from public.abyssal_room_members m where m.room_id = v_room.id;

  if not exists (
      select 1 from public.abyssal_room_members m
      where m.room_id = v_room.id and m.user_id = v_user_id
    ) and v_count >= v_room.max_players then
    raise exception 'ROOM_FULL';
  end if;

  v_display := left(regexp_replace(
    coalesce((select raw_user_meta_data->>'display_name' from auth.users where id = v_user_id), 'Diver'),
    '[[:cntrl:]<>]', '', 'g'
  ), 24);

  insert into public.abyssal_room_members(room_id, user_id, display_name, last_seen)
    values (v_room.id, v_user_id, coalesce(nullif(v_display, ''), 'Diver'), now())
    on conflict (room_id, user_id) do update
      set display_name = excluded.display_name, last_seen = now();

  -- A previous owner may have been removed as stale. Promote the oldest
  -- active member so the room does not retain an owner who is no longer in it.
  if not exists (
      select 1 from public.abyssal_room_members m
      where m.room_id = v_room.id and m.user_id = v_room.owner_id
    ) then
    select m.user_id into v_next_owner
      from public.abyssal_room_members m
      where m.room_id = v_room.id
      order by m.joined_at asc, m.user_id asc
      limit 1;
    if v_next_owner is not null then
      update public.abyssal_rooms set owner_id = v_next_owner where id = v_room.id;
    end if;
  end if;

  select count(*)::integer into v_count
    from public.abyssal_room_members m where m.room_id = v_room.id;

  return query select v_room.id, v_room.code, v_room.name, v_room.max_players::integer, v_count;
end;
$$;

revoke all on function public.abyssal_join_room(text) from public;
grant execute on function public.abyssal_join_room(text) to authenticated;
