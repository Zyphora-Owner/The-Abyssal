-- The Abyssal 1.8.0: persistent, member-scoped co-op world event log.
-- Apply after 202611060001_multiplayer.sql and 202611060002_room_recovery.sql.
-- This stores shared discoveries, collected world nodes/caches, and built structures.
-- Player inventory, fauna simulation, vehicles, survival values, and local saves
-- are intentionally not server-authoritative in this release.

create table if not exists public.abyssal_room_world_events (
  event_id bigint generated always as identity primary key,
  room_id uuid not null references public.abyssal_rooms(id) on delete cascade,
  actor_id uuid not null references auth.users(id) on delete cascade,
  client_event_id uuid not null,
  event_type text not null check (event_type in (
    'resource_collected', 'structure_placed', 'cache_collected',
    'fauna_scanned', 'biome_discovered', 'mission_completed'
  )),
  entity_id text not null check (char_length(entity_id) between 1 and 120),
  payload jsonb not null default '{}'::jsonb check (jsonb_typeof(payload) = 'object' and pg_column_size(payload) <= 4096),
  created_at timestamptz not null default now(),
  unique (room_id, actor_id, client_event_id)
);

create index if not exists abyssal_room_world_events_cursor_idx
  on public.abyssal_room_world_events(room_id, event_id asc);

create index if not exists abyssal_room_world_events_rate_idx
  on public.abyssal_room_world_events(room_id, actor_id, created_at desc);

alter table public.abyssal_room_world_events enable row level security;
grant select on public.abyssal_room_world_events to authenticated;
revoke insert, update, delete on public.abyssal_room_world_events from anon, authenticated;

drop policy if exists "Room members can read shared world events" on public.abyssal_room_world_events;
create policy "Room members can read shared world events"
  on public.abyssal_room_world_events for select to authenticated
  using (public.abyssal_is_room_member(room_id));

create or replace function public.abyssal_push_world_event(
  p_room_id uuid,
  p_event_type text,
  p_entity_id text,
  p_payload jsonb default '{}'::jsonb,
  p_client_event_id uuid default gen_random_uuid()
)
returns table(event_id bigint, actor_id uuid, event_type text, entity_id text, payload jsonb, created_at timestamptz)
language plpgsql
security definer
set search_path = public, auth, pg_temp
as $$
declare
  v_user uuid := auth.uid();
  v_entity text := left(regexp_replace(coalesce(p_entity_id, ''), '[^A-Za-z0-9:_-]', '', 'g'), 120);
  v_payload jsonb := coalesce(p_payload, '{}'::jsonb);
  v_existing public.abyssal_room_world_events%rowtype;
  v_count integer;
  v_row public.abyssal_room_world_events%rowtype;
begin
  if v_user is null then raise exception 'AUTH_REQUIRED'; end if;
  if not public.abyssal_is_room_member(p_room_id) then raise exception 'ROOM_MEMBERSHIP_REQUIRED'; end if;
  if p_event_type not in ('resource_collected','structure_placed','cache_collected','fauna_scanned','biome_discovered','mission_completed') then
    raise exception 'INVALID_WORLD_EVENT_TYPE';
  end if;
  if p_client_event_id is null or v_entity = '' or jsonb_typeof(v_payload) <> 'object' or pg_column_size(v_payload) > 4096 then
    raise exception 'INVALID_WORLD_EVENT_PAYLOAD';
  end if;

  -- Validate each event type server-side; never trust a modified client payload.
  if p_event_type = 'resource_collected' and coalesce(v_payload->>'type','') not in
    ('titanium','copper','quartz','kelp','coral','lithium','sulfur','magnetite','salt','glowcap','silver') then
    raise exception 'INVALID_RESOURCE_TYPE';
  elsif p_event_type = 'structure_placed' then
    if coalesce(v_payload->>'type','') not in ('compartment','foundation','storage_locker','solar_array','beacon')
      or coalesce(v_payload->>'x','') !~ '^-?[0-9]+(\.[0-9]+)?([eE][+-]?[0-9]{1,3})?$'
      or coalesce(v_payload->>'y','') !~ '^-?[0-9]+(\.[0-9]+)?([eE][+-]?[0-9]{1,3})?$'
      or coalesce(v_payload->>'z','') !~ '^-?[0-9]+(\.[0-9]+)?([eE][+-]?[0-9]{1,3})?$'
      or coalesce(v_payload->>'yaw','') !~ '^-?[0-9]+(\.[0-9]+)?([eE][+-]?[0-9]{1,3})?$'
      or abs((v_payload->>'x')::numeric) > 250000
      or abs((v_payload->>'z')::numeric) > 250000
      or abs((v_payload->>'y')::numeric) > 100
      or abs((v_payload->>'yaw')::numeric) > 100 then
      raise exception 'INVALID_STRUCTURE_EVENT';
    end if;
  elsif p_event_type = 'cache_collected' and coalesce(v_payload->>'cacheId','') !~ '^[A-Za-z0-9_-]{1,80}$' then
    raise exception 'INVALID_CACHE_EVENT';
  elsif p_event_type = 'fauna_scanned' and coalesce(v_payload->>'speciesId','') !~ '^[A-Za-z0-9_-]{1,64}$' then
    raise exception 'INVALID_FAUNA_EVENT';
  elsif p_event_type = 'biome_discovered' and coalesce(v_payload->>'biomeId','') !~ '^[A-Za-z0-9_-]{1,32}$' then
    raise exception 'INVALID_BIOME_EVENT';
  elsif p_event_type = 'mission_completed' and coalesce(v_payload->>'missionId','') !~ '^[A-Za-z0-9_-]{1,64}$' then
    raise exception 'INVALID_MISSION_EVENT';
  end if;

  if p_event_type = 'resource_collected' then
    v_payload := jsonb_build_object('type', v_payload->>'type');
  elsif p_event_type = 'structure_placed' then
    v_payload := jsonb_build_object(
      'type', v_payload->>'type',
      'x', (v_payload->>'x')::numeric,
      'y', (v_payload->>'y')::numeric,
      'z', (v_payload->>'z')::numeric,
      'yaw', (v_payload->>'yaw')::numeric
    );
  elsif p_event_type = 'cache_collected' then
    v_payload := jsonb_build_object('cacheId', v_payload->>'cacheId');
  elsif p_event_type = 'fauna_scanned' then
    v_payload := jsonb_build_object('speciesId', v_payload->>'speciesId');
  elsif p_event_type = 'biome_discovered' then
    v_payload := jsonb_build_object('biomeId', v_payload->>'biomeId');
  elsif p_event_type = 'mission_completed' then
    v_payload := jsonb_build_object('missionId', v_payload->>'missionId');
  end if;

  -- Idempotency makes offline queue retries safe if the server committed but the
  -- client lost the response before persisting its acknowledgement.
  select * into v_existing from public.abyssal_room_world_events e
    where e.room_id = p_room_id and e.actor_id = v_user and e.client_event_id = p_client_event_id;
  if found then
    return query select v_existing.event_id, v_existing.actor_id, v_existing.event_type,
      v_existing.entity_id, v_existing.payload, v_existing.created_at;
    return;
  end if;

  select count(*)::integer into v_count from public.abyssal_room_world_events e
    where e.room_id = p_room_id and e.actor_id = v_user and e.created_at > now() - interval '10 seconds';
  if v_count >= 24 then raise exception 'WORLD_EVENT_RATE_LIMIT'; end if;

  insert into public.abyssal_room_world_events(room_id, actor_id, client_event_id, event_type, entity_id, payload)
    values (p_room_id, v_user, p_client_event_id, p_event_type, v_entity, v_payload)
    on conflict (room_id, actor_id, client_event_id) do nothing
    returning * into v_row;
  if not found then
    select * into v_row from public.abyssal_room_world_events e
      where e.room_id = p_room_id and e.actor_id = v_user and e.client_event_id = p_client_event_id;
  end if;
  return query select v_row.event_id, v_row.actor_id, v_row.event_type,
    v_row.entity_id, v_row.payload, v_row.created_at;
end;
$$;

create or replace function public.abyssal_read_world_events(
  p_room_id uuid,
  p_after_event_id bigint default 0,
  p_limit integer default 100
)
returns table(event_id bigint, actor_id uuid, event_type text, entity_id text, payload jsonb, created_at timestamptz)
language plpgsql
security definer
set search_path = public, auth, pg_temp
as $$
declare v_limit integer := least(greatest(coalesce(p_limit,100),1),100);
begin
  if auth.uid() is null then raise exception 'AUTH_REQUIRED'; end if;
  if not public.abyssal_is_room_member(p_room_id) then raise exception 'ROOM_MEMBERSHIP_REQUIRED'; end if;
  return query select e.event_id, e.actor_id, e.event_type, e.entity_id, e.payload, e.created_at
    from public.abyssal_room_world_events e
    where e.room_id = p_room_id and e.event_id > greatest(coalesce(p_after_event_id,0),0)
    order by e.event_id asc limit v_limit;
end;
$$;

revoke all on function public.abyssal_push_world_event(uuid,text,text,jsonb,uuid) from public;
revoke all on function public.abyssal_read_world_events(uuid,bigint,integer) from public;
grant execute on function public.abyssal_push_world_event(uuid,text,text,jsonb,uuid) to authenticated;
grant execute on function public.abyssal_read_world_events(uuid,bigint,integer) to authenticated;
