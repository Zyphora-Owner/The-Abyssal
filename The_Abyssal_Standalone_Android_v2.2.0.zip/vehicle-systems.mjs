/**
 * Original underwater vehicle progression for The Abyssal.
 * Pure state helpers are kept outside the renderer so upgrades, depth limits,
 * power, cargo and save migrations can be tested without a GPU.
 */
export const VEHICLE_IDS = Object.freeze(['skimmer', 'carrier', 'exosuit']);

export const VEHICLE_DEFS = Object.freeze({
  skimmer: Object.freeze({
    id: 'skimmer', name: 'Pelagic Skimmer', role: 'Kendaraan selam satu penyelam',
    description: 'Kendaraan cepat untuk eksplorasi terumbu, bangkai kapal, dan gua menengah.',
    baseDepth: 200, depthSteps: Object.freeze([0, 150, 300]), speed: 14.5, verticalSpeed: 8.5,
    acceleration: 5.2, maxHealth: 150, maxPower: 100, baseCargo: 8,
    craftCost: Object.freeze({ titanium: 8, glass: 2, power_cell: 1, lubricant: 1, computer_chip: 1 }),
    dimensions: Object.freeze({ length: 4.4, width: 2.45, height: 2.15, camera: 7.2, clearance: 1.45 })
  }),
  carrier: Object.freeze({
    id: 'carrier', name: 'Pelagic Carrier', role: 'Kapal selam ekspedisi / basis bergerak',
    description: 'Kapal selam besar untuk ekspedisi jauh, penyimpanan, sonar, dan tempat berlindung bergerak.',
    baseDepth: 300, depthSteps: Object.freeze([0, 100, 200]), speed: 6.8, verticalSpeed: 4.2,
    acceleration: 2.4, maxHealth: 420, maxPower: 250, baseCargo: 30,
    craftCost: Object.freeze({ titanium: 30, glass: 8, power_cell: 3, lubricant: 4, computer_chip: 3, lithium: 4 }),
    dimensions: Object.freeze({ length: 15.5, width: 5.2, height: 5.0, camera: 19, clearance: 3.6 })
  }),
  exosuit: Object.freeze({
    id: 'exosuit', name: 'Nautilus Exosuit', role: 'Rangka mekanis penyelam laut dalam',
    description: 'Rangka mekanis untuk penjelajahan dekat dasar laut, penambangan, dan mobilitas vertikal.',
    baseDepth: 400, depthSteps: Object.freeze([0, 50, 100]), speed: 5.8, verticalSpeed: 5.2,
    acceleration: 3.8, maxHealth: 280, maxPower: 120, baseCargo: 12,
    craftCost: Object.freeze({ titanium: 20, lithium: 3, power_cell: 2, computer_chip: 2, lubricant: 2, glass: 2 }),
    dimensions: Object.freeze({ length: 2.5, width: 2.4, height: 4.6, camera: 8.8, clearance: 2.5 })
  })
});

export const VEHICLE_UPGRADES = Object.freeze({
  skimmer: Object.freeze({
    depth1: Object.freeze({ id: 'depth1', label: 'Depth Module I', cost: Object.freeze({ titanium: 4, lithium: 1, computer_chip: 1 }), depthLevel: 1 }),
    depth2: Object.freeze({ id: 'depth2', label: 'Depth Module II', cost: Object.freeze({ titanium: 6, lithium: 2, computer_chip: 1 }), depthLevel: 2 }),
    hull: Object.freeze({ id: 'hull', label: 'Reinforced Hull', cost: Object.freeze({ titanium: 5, lithium: 2 }), flag: 'hull' }),
    storage: Object.freeze({ id: 'storage', label: 'Expanded Storage', cost: Object.freeze({ titanium: 4, glass: 1, computer_chip: 1 }), flag: 'storage' }),
    sonar: Object.freeze({ id: 'sonar', label: 'Active Sonar', cost: Object.freeze({ magnetite: 2, computer_chip: 1, battery: 1 }), flag: 'sonar' }),
    efficiency: Object.freeze({ id: 'efficiency', label: 'Efficient Thrusters', cost: Object.freeze({ copper: 2, lubricant: 1, computer_chip: 1 }), flag: 'efficiency' })
  }),
  carrier: Object.freeze({
    depth1: Object.freeze({ id: 'depth1', label: 'Pressure Hull I', cost: Object.freeze({ titanium: 10, lithium: 3, computer_chip: 2 }), depthLevel: 1 }),
    depth2: Object.freeze({ id: 'depth2', label: 'Pressure Hull II', cost: Object.freeze({ titanium: 12, lithium: 4, computer_chip: 2 }), depthLevel: 2 }),
    hull: Object.freeze({ id: 'hull', label: 'Heavy Reinforcement', cost: Object.freeze({ titanium: 12, lithium: 3 }), flag: 'hull' }),
    storage: Object.freeze({ id: 'storage', label: 'Cargo Compartment', cost: Object.freeze({ titanium: 8, glass: 2, computer_chip: 1 }), flag: 'storage' }),
    sonar: Object.freeze({ id: 'sonar', label: 'Long-Range Sonar', cost: Object.freeze({ magnetite: 4, computer_chip: 2, battery: 2 }), flag: 'sonar' }),
    reactor: Object.freeze({ id: 'reactor', label: 'Thermal Recharge Core', cost: Object.freeze({ lithium: 4, magnetite: 3, power_cell: 1 }), flag: 'reactor' })
  }),
  exosuit: Object.freeze({
    depth1: Object.freeze({ id: 'depth1', label: 'Depth Module I', cost: Object.freeze({ titanium: 6, lithium: 2, computer_chip: 1 }), depthLevel: 1 }),
    depth2: Object.freeze({ id: 'depth2', label: 'Depth Module II', cost: Object.freeze({ titanium: 8, lithium: 3, computer_chip: 2 }), depthLevel: 2 }),
    hull: Object.freeze({ id: 'hull', label: 'Reinforced Chassis', cost: Object.freeze({ titanium: 8, lithium: 2 }), flag: 'hull' }),
    storage: Object.freeze({ id: 'storage', label: 'Cargo Mount', cost: Object.freeze({ titanium: 5, computer_chip: 1 }), flag: 'storage' }),
    drill: Object.freeze({ id: 'drill', label: 'Mining Drill Arm', cost: Object.freeze({ titanium: 6, lithium: 1, computer_chip: 1 }), flag: 'drill' }),
    grapple: Object.freeze({ id: 'grapple', label: 'Grappling Arm', cost: Object.freeze({ titanium: 5, wiring_kit: 2, lubricant: 1 }), flag: 'grapple' })
  })
});

const CARGO_KEYS = Object.freeze(['titanium','copper','quartz','kelp','coral','lithium','sulfur','magnetite','salt','glowcap','fish_meat','glass','silicone','fiber_mesh','battery','wiring_kit','computer_chip','silver','power_cell','lubricant','bleach']);
const finite = (value, fallback, min, max) => {
  const number = Number(value);
  return Number.isFinite(number) ? Math.min(max, Math.max(min, number)) : fallback;
};
const int = (value, fallback, min, max) => Math.round(finite(value, fallback, min, max));
const isObject = value => value !== null && typeof value === 'object' && !Array.isArray(value);

export function createVehicleState(id) {
  const definition = VEHICLE_DEFS[id];
  if (!definition) return null;
  return {
    id, owned: false, deployed: false,
    position: { x: 0, y: -12, z: 0 }, yaw: 0,
    health: definition.maxHealth, power: definition.maxPower,
    upgrades: { depth: 0, hull: false, storage: false, sonar: false, efficiency: false, reactor: false, drill: false, grapple: false },
    cargo: Object.fromEntries(CARGO_KEYS.map(key => [key, 0]))
  };
}

export function normalizeVehicleFleet(value) {
  const source = isObject(value) ? value : {};
  const fleet = {};
  for (const id of VEHICLE_IDS) {
    const definition = VEHICLE_DEFS[id];
    const input = isObject(source[id]) ? source[id] : {};
    const fallback = createVehicleState(id);
    const pos = isObject(input.position) ? input.position : {};
    const upgrades = isObject(input.upgrades) ? input.upgrades : {};
    const cargo = isObject(input.cargo) ? input.cargo : {};
    fleet[id] = {
      id,
      owned: input.owned === true,
      deployed: input.deployed === true && input.owned === true,
      position: {
        x: finite(pos.x, fallback.position.x, -1_000_000, 1_000_000),
        y: finite(pos.y, fallback.position.y, -500, 28),
        z: finite(pos.z, fallback.position.z, -1_000_000, 1_000_000)
      },
      yaw: finite(input.yaw, 0, -Math.PI * 8, Math.PI * 8),
      health: finite(input.health, definition.maxHealth, 0, definition.maxHealth * (upgrades.hull === true ? 1.5 : 1)),
      power: finite(input.power, definition.maxPower, 0, definition.maxPower),
      upgrades: {
        depth: int(upgrades.depth, 0, 0, 2),
        hull: upgrades.hull === true,
        storage: upgrades.storage === true,
        sonar: upgrades.sonar === true,
        efficiency: upgrades.efficiency === true,
        reactor: upgrades.reactor === true,
        drill: upgrades.drill === true,
        grapple: upgrades.grapple === true
      },
      cargo: Object.fromEntries(CARGO_KEYS.map(key => [key, int(cargo[key], 0, 0, 999)]))
    };
  }
  return fleet;
}

export function getVehicleDepthRating(id, state = {}) {
  const definition = VEHICLE_DEFS[id];
  if (!definition) return 0;
  const level = int(state?.upgrades?.depth, 0, 0, 2);
  return definition.baseDepth + definition.depthSteps[level];
}

export function getVehicleMaxHealth(id, state = {}) {
  const definition = VEHICLE_DEFS[id];
  return definition ? definition.maxHealth * (state?.upgrades?.hull ? 1.5 : 1) : 0;
}

export function getVehicleCargoCapacity(id, state = {}) {
  const definition = VEHICLE_DEFS[id];
  return definition ? definition.baseCargo + (state?.upgrades?.storage ? Math.ceil(definition.baseCargo * 0.75) : 0) : 0;
}

export function getVehicleSpeed(id, state = {}) {
  const definition = VEHICLE_DEFS[id];
  if (!definition) return 0;
  const efficiency = state?.upgrades?.efficiency ? 1.18 : 1;
  return definition.speed * efficiency;
}

export function vehiclePowerDrainPerSecond(id, state = {}, moving = false, special = false) {
  if (!moving && !special) return 0;
  const base = id === 'carrier' ? 0.34 : id === 'exosuit' ? 0.42 : 0.30;
  const efficiency = state?.upgrades?.efficiency ? 0.72 : 1;
  return (base * (moving ? 1 : 0) + (special ? 0.04 : 0)) * efficiency;
}

export function vehicleDepthDamage(id, state, depth) {
  const excess = Math.max(0, Number(depth) - getVehicleDepthRating(id, state));
  if (!Number.isFinite(excess) || excess <= 0) return 0;
  const hullFactor = state?.upgrades?.hull ? 0.65 : 1;
  return Math.max(1, Math.ceil(excess / 45)) * hullFactor;
}

export function canInstallVehicleUpgrade(id, state, upgradeId) {
  const upgrade = VEHICLE_UPGRADES[id]?.[upgradeId];
  if (!upgrade || !state?.owned || !isObject(state.upgrades)) return false;
  if (upgrade.depthLevel) return int(state.upgrades.depth, 0, 0, 2) === upgrade.depthLevel - 1;
  return state.upgrades[upgrade.flag] !== true;
}

export function getVehicleCargoUsed(state) {
  if (!state?.cargo) return 0;
  return CARGO_KEYS.reduce((sum, key) => sum + Math.max(0, Number(state.cargo[key]) || 0), 0);
}

export function addVehicleCargo(state, type, amount = 1) {
  if (!CARGO_KEYS.includes(type) || !state?.owned || !isObject(state.cargo)) return 0;
  const capacity = getVehicleCargoCapacity(state.id, state);
  const free = Math.max(0, capacity - getVehicleCargoUsed(state));
  const accepted = Math.min(int(amount, 0, 0, 999), free, 999 - (state.cargo[type] || 0));
  state.cargo[type] = (state.cargo[type] || 0) + accepted;
  return accepted;
}

export function removeVehicleCargo(state, type, amount = 1) {
  if (!CARGO_KEYS.includes(type) || !state?.owned || !isObject(state.cargo)) return 0;
  const removed = Math.min(int(amount, 0, 0, 999), state.cargo[type] || 0);
  state.cargo[type] -= removed;
  return removed;
}

/** Integrate a buoyant vehicle with local axes and bounded acceleration. */
export function integrateVehicleMotion({ id, state, position, velocity, yaw, pitch, forward = 0, strafe = 0, vertical = 0, dt = 0.016 }) {
  const definition = VEHICLE_DEFS[id];
  if (!definition) return { position: { ...position }, velocity: { x: 0, y: 0, z: 0 }, yaw, pitch };
  const step = Math.min(0.05, Math.max(0, Number(dt) || 0));
  const powerFactor = state?.power > 0 ? 1 : 0.28;
  const speed = getVehicleSpeed(id, state) * powerFactor;
  const f = finite(forward, 0, -1, 1);
  const s = finite(strafe, 0, -1, 1);
  const v = finite(vertical, 0, -1, 1);
  const desiredX = (Math.sin(yaw) * f + Math.cos(yaw) * s) * speed;
  const desiredZ = (-Math.cos(yaw) * f + Math.sin(yaw) * s) * speed;
  const desiredY = v * definition.verticalSpeed * powerFactor;
  const blend = 1 - Math.exp(-step * definition.acceleration);
  const nextVelocity = {
    x: finite(velocity?.x, 0, -40, 40) + (desiredX - finite(velocity?.x, 0, -40, 40)) * blend,
    y: finite(velocity?.y, 0, -20, 20) + (desiredY - finite(velocity?.y, 0, -20, 20)) * blend,
    z: finite(velocity?.z, 0, -40, 40) + (desiredZ - finite(velocity?.z, 0, -40, 40)) * blend
  };
  const damping = Math.exp(-step * (Math.abs(f) + Math.abs(s) + Math.abs(v) > 0.01 ? 0.18 : 1.8));
  if (Math.abs(f) + Math.abs(s) + Math.abs(v) <= 0.01) {
    nextVelocity.x *= damping; nextVelocity.y *= damping; nextVelocity.z *= damping;
  }
  const turnRate = id === 'carrier' ? 0.42 : id === 'exosuit' ? 0.68 : 0.95;
  const nextYaw = yaw + s * turnRate * step;
  const nextPitch = Math.max(-0.55, Math.min(0.55, pitch - v * 0.10 * step));
  return {
    position: {
      x: finite(position.x + nextVelocity.x * step, position.x, -1_000_000, 1_000_000),
      y: finite(position.y + nextVelocity.y * step, position.y, -500, 28),
      z: finite(position.z + nextVelocity.z * step, position.z, -1_000_000, 1_000_000)
    },
    velocity: nextVelocity,
    yaw: nextYaw,
    pitch: nextPitch
  };
}

/**
 * Swept, axis-separated collision resolution for larger underwater vehicles.
 * A callback receives each probe position and returns true when occupied.
 * The resolver preserves wall sliding and prevents tunnelling on fast frames.
 */
export function resolveVehicleSweep(from, to, isBlocked, stepLength = 0.38) {
  const position = {
    x: finite(from?.x, 0, -1_000_000, 1_000_000),
    y: finite(from?.y, -12, -500, 28),
    z: finite(from?.z, 0, -1_000_000, 1_000_000)
  };
  const target = {
    x: finite(to?.x, position.x, -1_000_000, 1_000_000),
    y: finite(to?.y, position.y, -500, 28),
    z: finite(to?.z, position.z, -1_000_000, 1_000_000)
  };
  const blocked = { x: false, y: false, z: false };
  const safeStep = finite(stepLength, 0.38, 0.08, 2);
  for (const axis of ['x', 'z', 'y']) {
    const distance = target[axis] - position[axis];
    const steps = Math.max(1, Math.ceil(Math.abs(distance) / safeStep));
    let hit = false;
    for (let index = 1; index <= steps; index += 1) {
      const probe = { ...position, [axis]: position[axis] + distance * (index / steps) };
      if (typeof isBlocked === 'function' && isBlocked(probe, axis)) { hit = true; break; }
    }
    if (hit) blocked[axis] = true;
    else position[axis] = target[axis];
  }
  return { position, blocked };
}
