# Asset & Immersion Quality Matrix — The Abyssal 2.3.0

Matriks ini membedakan aset yang diimplementasikan dalam source dari kualitas runtime yang belum dapat diuji secara visual.

| Kategori | Implementasi source | Status verifikasi |
|---|---|---|
| Held item First-Person | Model Three.js prosedural untuk resource/supply dan profil per item | Source/test lulus; tampilan Android belum terverifikasi |
| Tool First-Person | Scanner, Knife, Flashlight, Habitat Builder, Repair Tool, Seaglide | Source/test lulus; uji visual fisik belum terverifikasi |
| Tangan/grip | Lengan, tangan, overlay grip kanan dan Seaglide dua tangan | Source/test lulus; clipping pada semua rasio layar belum terverifikasi |
| Tekstur lingkungan | Tekstur canvas/DataTexture terrain, rock, kelp, coral, wood, metal, water, caustics | Path/source ada; kualitas visual runtime belum terverifikasi |
| Mineral dan kristal held item | Material metal, transmissive crystal, emission sulfur/lithium/glowcap, shard geometry | Source/test lulus; hasil material pada GPU fisik belum terverifikasi |
| Fauna | Model/mesh dan animasi prosedural di `fauna.js` | Source tersedia; semua animasi real-time belum diuji satu per satu |
| Leviathan intro | Model prosedural, fins, tail, jaw, eyes, bioluminescent light | Source/test lulus; komposisi visual perangkat belum terverifikasi |
| Cutscene | 7 shot kamera dengan path, easing, FOV dan roll | Unit/source test lulus; playback visual lengkap belum terverifikasi |
| Audio | WebAudio synthesized SFX/ambient profiles | Source ada; suara speaker/headphone Android belum terverifikasi |
| Visual effects | Bubbles, splash, caustics, fog, god rays, scan/repair/hologram effects | Source ada; FPS/visual fidelity perangkat belum terverifikasi |
| Dunia/biome | Procedural terrain, biome fog/tint, day-night, waterline, particles | Unit/source test; eksplorasi sesi panjang belum diuji pada perangkat |

## Batasan

Status `source/test lulus` membuktikan kode/helper dan referensi yang diuji tersedia, bukan jaminan bahwa semua tampilan telah diperiksa mata secara langsung. Aset yang belum diuji pada GPU/perangkat tidak dinyatakan sempurna.
