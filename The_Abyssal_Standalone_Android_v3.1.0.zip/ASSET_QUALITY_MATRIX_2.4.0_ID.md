# Asset Quality Matrix — The Abyssal 2.4.0

Matriks ini menunjukkan apa yang diubah pada source dan apa yang belum diverifikasi secara visual. `Source/test lulus` tidak berarti semua tampilan telah diperiksa langsung pada Android.

| Kategori | Perubahan source 2.4.0 | Dampak pada proporsi/siluet | Status |
|---|---|---|---|
| Profil fauna | Profil badan `deep`, `oval`, `compressed`, `boxy`, `fusiform`, `predator`, `eel`, `puffer`, `angler`, serta profil fauna besar | Ukuran panjang/lebar/tinggi dipetakan ke geometri badan | Source/test lulus; visual runtime belum diverifikasi |
| Ikan karang | Bentuk compressed untuk butterflyfish, angelfish, Moorish idol; boxy untuk triggerfish | Bentuk badan lebih berbeda antarspesies | Source/test lulus; visual runtime belum diverifikasi |
| Hammerhead | Cephalofoil, lobe, sensor pores | Kepala melebar khas hammerhead | Source/test lulus; visual runtime belum diverifikasi |
| Moray/ribbon eel | Detail dorsal ridge dan sirip pektoral berpasangan | Siluet lebih memanjang dan khusus spesies | Source/test lulus; visual runtime belum diverifikasi |
| Ikan predator | Snout dan lower jaw | Profil kepala lebih runcing | Source/test lulus; visual runtime belum diverifikasi |
| Resource di dunia | Archetype ingot, nodule, crystal, crystal cluster, cubic cluster, mushroom, leaf bundle, branching organic | Siluet resource tidak hanya satu batu generik | Source/test lulus; penempatan visual runtime belum diverifikasi |
| Item Kelp First-Person | Mesh bilah daun dan midrib | Daun pipih/organik, bukan kapsul | Source/test lulus; genggaman Android belum diverifikasi |
| Item lainnya | Profil heldScale untuk mineral, kristal, baterai, power cell, komponen, supply, food, dan liquid | Ukuran relatif antaritem lebih konsisten | Source/test lulus; visual runtime belum diverifikasi |
| Multipurpose Compartment | 8 panel tekanan modular, upper/lower seams, bolt detail | Dinding bawah lebih silindris dan modular | Source/test lulus; collision/visual runtime belum diverifikasi |
| Airlock | Gasket karet tambahan | Detail sambungan/hatch lebih meyakinkan | Source/test lulus; runtime belum diverifikasi |
| Beacon/foundation/locker/solar/vehicle bay | Detail geometris dan metadata dimensi dipertahankan/ditingkatkan dari profil | Proporsi footprint visual terdokumentasi | Source/test lulus; runtime belum diverifikasi |
| Pelagic Skimmer | Longitudinal profiled hull geometry dan pressure bands | Lambung ramping dan hydrodynamic | Source/test lulus; collision/visual runtime belum diverifikasi |
| Pelagic Carrier | Lambung longitudinal berpenampang variatif dan pressure bands | Hull kapal selam lebih panjang dan bersegmen | Source/test lulus; collision/visual runtime belum diverifikasi |
| Nautilus Exosuit | Mempertahankan bentuk 3D dan dimensi existing | Tidak ada perubahan collision/dimensi gameplay | Source test; visual runtime belum diverifikasi |
| Lifepod | Bounding dimensions visual terukur | Metadata bounds visual; collision tetap | Source/test lulus; visual runtime belum diverifikasi |

## Batasan

- Tekstur PBR prosedural/lokal yang sudah ada tetap menjadi dasar; rilis ini tidak menyertakan paket eksternal model 3D atau texture scan baru.
- Tidak ada klaim bahwa seluruh ikan, struktur, dan item telah setara secara visual dengan Subnautica.
- Belum ada pemeriksaan visual langsung melalui emulator/GPU atau perangkat Android fisik.
- Model dan siluet tetap original untuk The Abyssal; Subnautica berfungsi sebagai acuan kualitas dan bahasa bentuk umum, bukan sumber aset yang disalin.
