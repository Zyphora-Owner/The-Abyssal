# Asset & Gameplay Quality Matrix — The Abyssal 2.6.0

| Kategori | Perubahan source 2.6.0 | Status |
|---|---|---|
| Seafloor palung | Formasi basalt/spire rendah-poly dibedakan palet dan profilnya per biome dalam | Source/test lulus; runtime belum diverifikasi |
| Hadal Garden | Formasi batuan pendek dan flora bioluminesen existing | Source/test lulus; runtime belum diverifikasi |
| Midnight Grotto / Blue Void | Formasi pilar dan urat mineral berwarna dingin | Source/test lulus; runtime belum diverifikasi |
| Hadal Rift | Spire lebih tinggi dan material seam bercahaya ungu | Source/test lulus; runtime belum diverifikasi |
| Fauna schooling | Clownfish, blue tang, butterflyfish, yellowfin tuna, glass shrimp, lanternfish dan abyssal skater dapat bergerak berkelompok | Source/test lulus; visual belum diverifikasi |
| Barracuda | Dart-bite, lunge pendek dan jaw animation | Source/test lulus; runtime belum diverifikasi |
| Reef Shark / Hammerhead | Surge-bite / hammer-ram, jaw serta kepala khusus spesies | Source/test lulus; runtime belum diverifikasi |
| Abyssal/Trench Stalker | Ambush-bite dengan lunge dan hit reaction | Source/test lulus; runtime belum diverifikasi |
| Void Dragonfish | Lure-bite dengan lower jaw dan detail gigi procedural | Source/test lulus; runtime belum diverifikasi |
| Hadal Squid | Tentacle-sweep dengan gerakan lengan/tentakel | Source/test lulus; runtime belum diverifikasi |
| Leviathan | Charge/hadal-crush, jaw/fins dan timing lebih besar | Source/test lulus; runtime belum diverifikasi |
| Pemain First-Person | Ayunan Knife menggerakkan pisau, lengan dan pergelangan | Automated source check lulus; Android belum diuji |
| Player hit reaction | Animasi recoil viewmodel/kamera tanpa movement lock | Source/test lulus; feel belum diverifikasi |
| Moving attack input | Tombol tetap terlihat saat knife terpilih; swing kosong jika tidak ada target | Source/test lulus; multi-touch fisik belum diverifikasi |

## Catatan

- Semua tambahan geometri menggunakan Three.js geometry dan material/tekstur lokal yang sudah ada. Tidak ada model/tekstur resmi Subnautica yang disalin.
- `source/test lulus` berarti implementasi dan pemeriksaan otomatis berjalan, bukan verifikasi visual di GPU Android.
- Tekstur PBR detail, rekaman audio profesional, rigging artist-authored penuh, dan playtest fauna belum seluruhnya tersedia/terverifikasi.
