# Asset & Gameplay Quality Matrix — The Abyssal 2.7.0

| Kategori | Implementasi 2.7.0 | Status |
|---|---|---|
| Ekologi reef | Profil kepadatan coral dan seagrass berdasarkan preset grafis | Source + automated test lulus; visual runtime belum diverifikasi |
| Kelp biome | Kepadatan seagrass lebih tinggi dan oxygen plant mengikuti budget biome | Source + automated test lulus; visual runtime belum diverifikasi |
| Deep/Abyss | Sponge clusters, luminous bloom, dan basalt formation diprofilkan per biome | Source + automated test lulus; visual runtime belum diverifikasi |
| Hadal Shelf/Grotto | Coral/fan coral terbatas dan sponge garden lebih padat | Source + automated test lulus; visual runtime belum diverifikasi |
| Blue Void/Hadal Rift | Palet sponge dan glow mengikuti identitas biome, formasi batu tetap di-stream per chunk | Source + automated test lulus; visual runtime belum diverifikasi |
| Hadal Garden | Anggaran sponge dan hadal bloom terbesar; batas instance dijaga | Source + automated test lulus; visual runtime belum diverifikasi |
| Siphonophore | Model koloni zooid, float, cord, tentakel dan animasi drift prosedural | Syntax/source + morphology profile lulus; visual runtime belum diverifikasi |
| Glasswing Ray | Menggunakan profil manta dan muncul pada biome shelf/grotto sesuai kedalaman | Roster/profile test lulus; animasi visual perlu playtest |
| Rift Angler | Menggunakan profil angler, menjadi predator lokal pada kedalaman rift/grotto | Roster/profile test lulus; AI feel perlu playtest |
| Pemilihan fauna | Biome lokal + rentang kedalaman; hindari reef fish dipaksakan ke hadal | Source test lulus; distribusi in-game perlu sampling runtime |
| Predator evasion | Fauna non-hostile menghindari predator terdekat | Source test lulus; perilaku real-time perlu playtest |
| Schooling | Cohesion/separation lama dipertahankan | Source test lulus; visual runtime belum diverifikasi |
| First-Person Knife | Hit frame diselaraskan dengan animasi, memperhitungkan gerak diver dan target | Unit/source test lulus; multi-touch Android belum diuji |
| Serangan predator | Profil serangan spesifik spesies dan reaksi tetap dipertahankan | Regression source test lulus; feel belum diverifikasi di perangkat |
| Audio/VFX | Memakai aset audio/efek yang sudah ada; tidak mengklaim rekaman baru | Tidak ada paket rekaman profesional baru di rilis ini |

## Catatan teknis
- Flora tambahan menggunakan geometri prosedural bersama + `InstancedMesh`, bukan satu mesh unik untuk setiap tanaman.
- Material memakai texture lokal yang telah ada. Tidak semua objek baru memiliki map PBR terpisah (albedo/normal/roughness/metallic/AO/emission) yang artist-authored.
- Geometri dan fauna baru mempertahankan identitas orisinal The Abyssal; tidak ada aset Subnautica resmi yang disalin.
- `Source + automated test lulus` berarti struktur dan aturan kode diverifikasi, bukan bukti bahwa hasil visual setara Subnautica di GPU Android.
