# Matriks Kualitas Aset — 2.8.0

| Aset / sistem | Kondisi 2.8.0 | Batasan dan verifikasi |
|---|---|---|
| Ikon PWA 192/512 | Lambang pari abyssal vektor original, raster high-quality | Dimensi PNG dan path manifest diuji otomatis |
| Ikon maskable | Artwork diskalakan dengan padding safe-zone | Tidak menggantikan screenshot uji launcher semua OEM |
| Android adaptive icon | Foreground transparan dan background terpisah; legacy density mdpi–xxxhdpi diperbarui | Android build dan home-screen fisik belum diuji |
| Relief pasir | Ripples dan grain multi-frekuensi tileable | Procedural, bukan scan fotogrametri |
| Relief batu/basalt | Strata dan fracture multi-frekuensi | Procedural, bukan PBR scan |
| Relief coral | Pore/ridge micro-detail | Procedural |
| Relief kelp | Urat longitudinal | Procedural |
| Relief kayu | Fiber/grain direction | Procedural |
| Relief metal | Fine scratch dan pit | Procedural |
| Warna permukaan | CanvasTexture historis per-material tetap dipakai | Belum semua mempunyai authored albedo/roughness/metalness PBR texture set |
| Fauna | Phase animasi konsisten per tick; model tetap procedural/profile-based | Rig artist-authored dan motion-capture belum tersedia |
| Menu/UI motion | Logo float + staggered menu entry; transform/opacity ringan dan reduced-motion aware | Belum diuji di semua refresh rate/OEM Android |
| Water | Water color + tangent-space wave normal + caustic historis dipertahankan | Refraction/reflection tetap dibatasi implementasi WebGL proyek |

**Catatan:** Peningkatan ini memperbaiki konsistensi relief dan identitas aplikasi; bukan klaim bahwa semua aset sudah setara game AAA.
