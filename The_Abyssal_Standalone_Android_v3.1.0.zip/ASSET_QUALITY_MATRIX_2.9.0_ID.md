# Matriks Kualitas Aset — 2.9.0

| Aset / sistem | Status pada 2.9.0 | Batas verifikasi |
|---|---|---|
| Ikon aplikasi dan identitas | Dipertahankan dari 2.8.0; PWA, maskable, adaptive Android | Validasi berkas dan metadata otomatis; tampilan launcher perlu uji perangkat |
| Tekstur permukaan | Tekstur prosedural dan bump map spesifik permukaan dari 2.8.0 | Bukan seluruhnya tekstur hasil pemindaian/PBR buatan artis |
| Laut dan arus | Medan arus deterministik 3D, profil per biome, batas kecepatan, dukungan diver/kendaraan/fauna/debris/flora | Perlu pengamatan visual dan tuning di perangkat untuk rasa kendali |
| Fauna | Model procedural low-poly, animasi sirip/ekor/tentakel, drift mengikuti massa air | Belum menggunakan rig/animasi skeletal profesional untuk semua spesies |
| Flora | Gerakan lokal dipengaruhi fase animasi dan arus | Tidak ada simulasi deformasi vertex penuh |
| Air dan atmosfer | Waterline, caustics, fog kedalaman, partikel, daylight, tekstur air | Refraction/reflection volumetrik penuh belum diimplementasikan |
| Kendaraan | Pelagic Skimmer, Pelagic Carrier, Nautilus Exosuit dengan drift arus lemah | Fisika dan kontrol perlu uji Android fisik |
| Gameplay | Lima Quick Slots, inventory, PDA, Fabricator, habitat, Lifepod, tools, survival, cutscene, save v11 | Integrasi end-to-end tetap perlu playtest |
| Multiplayer | Supabase Auth/room/presence/chat/event sesuai sistem lama | Live server tidak diuji pada audit lokal ini |

Kualitas visual real-time tidak dapat dinilai penuh hanya dari pemeriksaan statis.
