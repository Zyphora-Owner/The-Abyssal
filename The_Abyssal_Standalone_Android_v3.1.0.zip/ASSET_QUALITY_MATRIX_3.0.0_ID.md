# Matriks Visual, Grafik, Tekstur, Audio & Lingkungan — 3.0.0

| Area | Implementasi 3.0.0 | Pemeriksaan otomatis | Batas / yang belum terbukti |
|---|---|---|---|
| Terrain dan gua | Empat lorong/ruang gua tambahan, carving terrain deterministik, batu, bibir, stalaktit/stalagmit, kristal emissive, debu dan lampu | Cave profiles, carve lokal, ceiling clearance, side-wall helper | Belum inspeksi WebGL di browser/Android; bentuk gua procedural, bukan sculpted mesh artistik |
| Tekstur batu gua | Memakai rock albedo dan bump map existing dengan roughness tinggi | Referensi map/bump diverifikasi melalui source | Bukan photogrammetry; tidak semua material mempunyai full PBR texture set |
| Material dunia | Relief map khusus pasir, batu, coral, kelp, kayu, dan metal dari versi terdahulu | Asset/profile dan map references | Butuh visual inspection untuk skala texel, tiling, artifact, dan kualitas mipmap |
| Pencahayaan cave | Crystal emissive, dua point light per cave, pulse kecil, particle dust | Static integration checks | Bloom/volumetric shaft tidak diklaim; GPU behavior belum diukur |
| Air dan atmosfer | Waterline, depth fog, caustics, day/night, current particle/flora effects dari versi terdahulu | Regression suite source tests | Refraction/reflection volumetrik penuh belum tersedia; tidak ada GPU frame capture |
| Fauna | Fauna procedural, animasi species-specific, current drift, cave ceiling/lateral constraints untuk fauna kecil | Fauna source tests dan cave helper test | Belum semua fauna pakai skeletal rig profesional; perilaku perlu playtest |
| Collision | Lantai multi-sample, structure/Lifepod collision, vehicle sweep, cave roof dan side-wall constraint | Analytic helper and static integration checks | Belum rigid-body mesh collision untuk setiap batu/coral; perlu test navigasi nyata |
| Gravitasi dan buoyancy | 9,81 m/s² untuk ground; fluid helper dengan buoyancy density ratio, damping dan speed cap; debris/drops pakai model fluida | Numerical tests untuk float/sink, gravity, bounded integration | Diver swimming tetap kontrol game/trim, bukan simulator fisika scuba lengkap |
| Audio | Low-pass kedalaman, dry/wet SFX, convolver cave reverb dan feedback echo teredam, ambience biome | Audio profile tests dan source wiring checks | Audio synthesizer procedural; belum ada rekaman studio, pengukuran akustik, atau uji speaker/headphone |
| Cutscene | Camera impact shake/roll/FOV pulse; reveal light/emissive pulse; timeline lama dipertahankan | Time-profile bounds and integration checks | Belum direkam/diuji visual sebagai video render pada device |
| Android | PWA/native metadata, app ID dan signing asset lama dipertahankan | Static workflow/config tests | APK build dan perangkat fisik belum diverifikasi |

## Kesimpulan
Release ini memperluas struktur gua, collision ruang, fluida, akustik dan cutscene dengan kode yang dapat diuji secara deterministik. Klaim kualitas akhir visual, suara, performa, serta kesetaraan AAA/Subnautica tidak dibuat tanpa pengujian visual dan audio langsung.
