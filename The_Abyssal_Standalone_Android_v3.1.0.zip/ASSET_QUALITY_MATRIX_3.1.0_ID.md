# Matriks Kualitas Aset — The Abyssal 3.1.0

## Tekstur PBR baru

| Keluarga | Albedo | Normal | Roughness | Penggunaan |
|---|---:|---:|---:|---|
| Sand | 2048² | 1024² | 1024² | Terrain/pasir dasar |
| Basalt | 2048² | 1024² | 1024² | Batu, tebing, batuan gua |
| Coral | 2048² | 1024² | 1024² | Coral dan dekorasi laut |
| Kelp | 2048² | 1024² | 1024² | Kelp/flora berdaun |
| Wreck wood | 2048² | 1024² | 1024² | Kayu reruntuhan |
| Oxidized metal | 2048² | 1024² | 1024² | Logam, struktur/habitat |
| Fish scales | 2048² | 1024² | 1024² | Material kulit fauna bersisik |
| Bioluminescent tissue | 2048² | 1024² | 1024² | Fauna/organisme bioluminesen |

Total: 24 WebP, 8,326,692 byte. Resolusi sumber albedo 2048² dan detail normal/roughness 1024²; ukuran efektif pada perangkat dapat diturunkan sesuai preset grafis, memori perangkat, dan batas tekstur GPU.

## Audio OGG baru

| Kelompok | Aset | Penggunaan |
|---|---|---|
| Ambience | reef, kelp, wreck, hadal, cave | Lapisan ambience biome dan ruang gua |
| Interaksi | bubbles, sonar, hatch servo, pickup, scanner sweep, hull impact, mineral strike | Interaksi dunia, alat, kendaraan, resource |
| Fauna | fauna chirp, leviathan call, whale song, predator growl, crustacean click, jelly pulse, ray sweep | Panggilan fauna dengan profil kelompok spesies |

Total: 29 OGG, 1,449,675 byte, sekitar 98,46 detik materi suara. File dibuat dengan sintesis audio orisinal, bukan rekaman lapangan.

## Model dan animasi

| Elemen | Status pada 3.1.0 | Catatan |
|---|---|---|
| Fauna ikan dan organisme | Geometri procedural diperhalus + PBR skin maps | Belum seluruhnya memiliki rig/skeletal animation individual |
| Fan coral | Cabang tubular melengkung + sway | Digerakkan kanal animasi procedural |
| Anemone | 9 tentakel/cabang fleksibel | Gerak mengikuti fase dan arus lokal |
| Sea urchin | Badan dan 16 duri | Gerak/pulse sederhana |
| Starfish | Mesh ekstrusi berbentuk bintang | Gerak/pulse sederhana |
| Flora resource | Partikel/daun animasi dan glowcap pulse | Terikat pada registry chunk |
| Struktur | Lampu indikator pulse | Variasi masih sederhana |
| Inventory icons | Ikon UI 2D | Tidak diubah menjadi model 3D UI |

Mayoritas objek/struktur/alat/vehicle sudah memiliki geometri 3D di dunia dari versi terdahulu. 3.1.0 tidak mengklaim telah mengganti semua itu dengan aset high-poly artistik terpisah. Tekstur dan suara baru hanya dapat memperbaiki material/objek yang sudah terhubung pada kelompok material atau event yang dipetakan.

## Profil performa
Tekstur normal/roughness dibatasi hingga 1024². Albedo runtime mengikuti preset (low ≤512, balanced ≤1024, high ≤1536 jika perangkat terdeteksi memadai, ultra ≤2048 jika memori perangkat memadai) dan `MAX_TEXTURE_SIZE`. Uji frame rate aktual tetap diperlukan per perangkat.
