# Audit Report — The Abyssal 2.3.0

## Dasar pengerjaan

- Source: `The_Abyssal_Standalone_Android_v2.2.0.zip`.
- Versi rilis: `2.3.0`.
- Perubahan bersifat inkremental dan non-destruktif.
- Application ID tetap `com.abyssal.game`.
- Save schema tetap v11; tidak ada migrasi atau reset save.
- Inventory, lima Quick Slots, tools, PDA, Fabricator, Lifepod, dunia, fauna/flora, habitat, kendaraan, upgrade, Supabase, dan multiplayer lama dipertahankan.

## Perubahan source yang diaudit

### Kamera intro

- `cinematic-systems.mjs` kini menyediakan lintasan camera offset dan target awal-akhir untuk tujuh shot.
- Posisi kamera, target, dan FOV diinterpolasi dengan smooth easing.
- Roll sinematik kecil dikomposisikan menggunakan quaternion dasar yang disalin ulang setiap frame untuk mencegah akumulasi rotasi.
- Durasi intro dan timeline subtitle dipertahankan.

### First-Person

- Modul baru `immersive-systems.mjs` menyediakan profil per item yang dapat diuji tanpa WebGL.
- Profil mencakup skala, posisi, orientasi, grip offset, idle bob/roll/yaw, serta respons saat item dipakai.
- Animasi memakai base transform masing-masing model sehingga idle/action motion tidak menyebabkan transformasi kumulatif.
- Overlay grip disegarkan setelah item bergerak agar tetap mengikuti posisi genggaman.
- Semua model tool/resource yang tersedia tetap dibuat lokal melalui Three.js; tidak ada penggantian item menjadi ikon 2D.

### Material dan fog

- Material resource metallic (titanium, copper, magnetite, silver) dibedakan melalui metalness/roughness dan map metal.
- Quartz/lithium memperoleh material transmissive dengan clearcoat; sulfur/glowcap memperoleh emission terkontrol.
- Bentuk ore metal dan shard kristal dibuat lebih berkarakter.
- Fog scene memakai tint biome yang bergeser ke warna abyssal pada kedalaman tinggi dan kembali ke tint permukaan ketika pemain naik.
- Save dan balancing survival tidak diubah.

## Pengujian yang benar-benar dijalankan

Perintah:

- `node --check` untuk runtime JavaScript, modul `.mjs`, konfigurasi, service worker, dan skrip build/test.
- `npm test`.

Hasil `npm test`:

- **LULUS** — 176 ID HTML unik.
- **LULUS** — 258 referensi DOM statis valid.
- **LULUS** — path aset lokal dan import modul yang diperiksa.
- **LULUS** — syntax JavaScript/MJS.
- **LULUS** — pemeriksaan determinisme terrain, save schema v11, Lifepod/hatch/collision, inventory/tools, kendaraan/upgrade, Supabase/SQL/RLS, Android lifecycle/signing/workflow.
- **LULUS** — 7 shot sinematik, interpolasi kamera dalam shot, rentang FOV, roll finite, dan timeline subtitle.
- **LULUS** — semua 24 profil held resource/supply yang diuji memiliki transform valid dan motion finite.
- **LULUS** — profil fog kedalaman mengubah palet/retensi cahaya dengan transisi permukaan yang aman.

Output test:

`The Abyssal 2.3.0 verification passed: 176 unique DOM IDs, 258 valid DOM references, local asset paths, deterministic terrain, v11 save migration and vehicle fleet/upgrades/cargo/swept collision, waterline/daylight helpers, scaled Lifepod transforms/collision/hatch regression, dry-ground jump gating, cave/oxygen-plant/sulfur-nest systems, 8142C cinematic source checks, 7-shot cutscene director/timeline and cancellation recovery checks, animated Leviathan fin/eye/light checks, held-item hand-fit profiles and layered cinematic audio checks, turtle shell texture source checks, survival/inventory/camera/tool checks, Supabase/Auth and SQL/RLS source checks, Android lifecycle/icon/signing/workflow checks.`

## Build dan perangkat

- **Production build: GAGAL / BELUM TERVERIFIKASI.** `npm run build` berhenti sebelum Vite build karena dependency `vite` tidak terpasang di lingkungan (`ERR_MODULE_NOT_FOUND: Cannot find package 'vite'`).
- **APK compilation: BELUM TERVERIFIKASI.** Karena production build belum selesai, Gradle APK tidak dijalankan.
- **Physical Android test: BELUM TERVERIFIKASI.** Tidak ada perangkat Android fisik yang dijalankan dalam sesi ini.
- **Visual runtime test: BELUM TERVERIFIKASI.** Automated tests memeriksa source dan helper deterministik, bukan penilaian visual melalui browser/WebGL.
- **Audio device test: BELUM TERVERIFIKASI.** Suara speaker/headphone Android belum diuji.
- **Live Supabase/two-device multiplayer: BELUM TERVERIFIKASI.**

## Batasan kualitas

Versi 2.3.0 meningkatkan lintasan kamera, model First-Person prosedural, material beberapa item, dan fog atmosfer. Ini **bukan remaster total semua aset**: tidak ada paket model dunia GLB/FBX eksternal, seluruh tekstur PBR eksternal, rekaman audio studio, atau animasi capture baru yang ditambahkan. Kualitas akhir di GPU dan perangkat tetap perlu diuji sebelum dapat dinyatakan sempurna.
