# Audit Report — The Abyssal 2.4.0

## Basis perubahan

Source yang dipakai adalah proyek 2.3.0 yang tersedia. Pekerjaan difokuskan pada dimensi visual, bentuk, siluet, dan detail geometri untuk fauna, item, struktur, Lifepod, dan kendaraan. Tidak ada perubahan save schema atau migrasi database.

## Pemeriksaan source

| Pemeriksaan | Hasil |
|---|---|
| `node --check game.js` | LULUS |
| `node --check fauna.js` | LULUS |
| `node --check asset-proportions.mjs` | LULUS |
| `node --check scripts/verify.mjs` | LULUS |
| `npm test` | LULUS |
| Pemeriksaan unique DOM IDs | 176 unik |
| Pemeriksaan static DOM references | 258 valid |
| Pemeriksaan modul/path lokal | LULUS |
| Validasi profil fauna/resource/struktur/kendaraan | LULUS |
| Verifikasi geometri hull Skimmer/Carrier berbasis profil | Source assertion LULUS |
| Verifikasi model Kelp First-Person dan panel tekanan habitat | Source assertion LULUS |
| Save schema | v11 dipertahankan |
| Quick Slots | 5 dipertahankan |
| Android Application ID | `com.abyssal.game` dipertahankan |
| ZIP extraction/integrity | Akan dilaporkan setelah arsip final dibuat dan diuji |

## Build dan runtime

| Pemeriksaan | Status |
|---|---|
| `npm run build` | GAGAL di lingkungan saat ini: `ERR_MODULE_NOT_FOUND: Cannot find package 'vite'` |
| APK compilation | BELUM TERVERIFIKASI |
| Android fisik/emulator | BELUM TERVERIFIKASI |
| Visual fidelity semua model/fauna/struktur | BELUM TERVERIFIKASI |
| Collision/placement runtime sesudah perubahan geometri | Belum diuji langsung; data collision dan dimension gameplay tidak diubah |
| Supabase login/co-op live | BELUM TERVERIFIKASI |

## Perubahan yang diperiksa

1. `asset-proportions.mjs` ditambahkan sebagai pusat profil bentuk dan skala.
2. `fauna.js` menggunakan profil badan per morfologi dan bentuk spesifik hammerhead, eels, triggerfish, Moorish idol, serta predator.
3. `game.js` memakai profil resource, model daun Kelp untuk held viewmodel, panel tekanan dan gasket compartment, geometri lambung longitudinal Skimmer/Carrier, serta pengukuran bounding visual Lifepod.
4. `scripts/verify.mjs` mencakup syntax/module paths dan assertion baru untuk profil proporsi, fauna, resource, struktur, kendaraan, dan aset terkait.
5. Metadata rilis 2.4.0, cache Service Worker, workflow artifact, dan label build diperbarui.

## Risiko dan tindak lanjut

- Perubahan geometri harus diuji visual pada perangkat dengan resolusi dan kemampuan GPU berbeda.
- Siluet model prosedural masih bukan pengganti model 3D eksternal artist-authored dengan topology/UV/texture set lengkap.
- Collision dan placement sengaja tidak diubah untuk menjaga kompatibilitas; bila hasil visual menunjukkan mismatch, collision harus diperiksa terpisah melalui tes runtime.
- Build harus dijalankan di lingkungan yang telah memasang dependency proyek, termasuk Vite. Jangan menyimpulkan APK tersedia hanya dari lulusnya `npm test`.

## Kesimpulan

Source 2.4.0 melewati syntax check dan automated verification. Arsip final tetap harus diekstrak dan diperiksa. Production bundle, APK, gameplay runtime, dan visual perangkat fisik belum dapat dinyatakan lulus.
