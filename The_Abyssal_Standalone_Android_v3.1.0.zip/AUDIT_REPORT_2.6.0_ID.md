# Audit & Verification Report — The Abyssal 2.6.0

## Basis perubahan

- Source dasar: proyek The Abyssal 2.5.0 yang tersedia pada sesi ini.
- Versi hasil: 2.6.0.
- Strategi: perubahan inkremental dan non-destruktif; tidak ada penggantian proyek dari nol.

## Perubahan yang diaudit

| Area | Perubahan | Status source |
|---|---|---|
| Kedalaman dunia | Batas dive 1.500 m; pusat palung sekitar 1.494,5 m; hard floor dengan clearance | LULUS automated checks |
| Biome | Tujuh band biome dari 62 sampai 1.500 m | LULUS automated checks |
| Flora/geologi | Formasi basalt prosedural per biome dan chunk lifecycle cleanup | LULUS syntax/source checks |
| Fauna hadal | Habitat species diselaraskan; threshold spawn langka diperbaiki | LULUS syntax/source checks |
| Schooling | Kelompok fauna dengan cohesion/separation untuk spesies tertentu | LULUS syntax/source checks |
| Serangan fauna | Profil timing/jangkauan/lunge/cooldown spesifik spesies | LULUS automated checks |
| Damage fauna | Impact hanya sekali per animasi | LULUS automated checks |
| Reaksi fauna | Jaw/tail/fins/tentacles, hit reaction, flee dan defeat non-grafis | LULUS syntax/source checks |
| Serangan pemain | Tombol tetap tersedia saat knife dipilih; swing tidak menghentikan movement | LULUS automated checks |
| Interaksi saat bergerak | Sistem Interact tetap berjalan bersama joystick/look; tidak ada movement lock baru | Source check; perangkat belum diuji |
| Save | Schema v11 tetap; tidak ada reset/migrasi data save | LULUS source checks |
| Android identity | `com.abyssal.game` dipertahankan | LULUS source checks |

## Hasil pengujian aktual

| Pengujian | Hasil |
|---|---|
| `node --check` root JS/MJS dan scripts | LULUS |
| `npm test` | LULUS |
| 176 ID HTML unik | LULUS |
| 258 referensi DOM | LULUS |
| Validasi path aset lokal | LULUS |
| Terrain deterministik dan batas 1.500 m | LULUS |
| Pusat dasar palung lebih dalam dari 1.490 m | LULUS |
| Tujuh band biome hadal | LULUS |
| Profil animasi serangan fauna | LULUS source checks |
| Attack control saat knife dipilih | LULUS source checks |
| Schooling dan formasi basalt | LULUS source checks |
| Save v11 dan fitur inventory | LULUS source checks |
| ZIP integrity (`unzip -t`) | LULUS — tidak ada error kompresi/arsip |
| `npm test` setelah ekstraksi ZIP | LULUS — hasil sama dengan pengujian source |
| `npm run build` | GAGAL di lingkungan ini: Vite tidak terpasang (`ERR_MODULE_NOT_FOUND`) |
| APK compilation | BELUM TERVERIFIKASI |
| Pengujian visual Android fisik | BELUM TERVERIFIKASI |
| Multiplayer Supabase live | BELUM TERVERIFIKASI |

## Catatan akar masalah build

`npm run build` memanggil `scripts/build-native.mjs`, yang mengimpor `vite`. Dependency tersebut tercantum di `devDependencies`, tetapi paket tidak tersedia pada lingkungan pengerjaan. Build berhenti sebelum proses bundling dimulai. Ini bukan bukti bahwa source build rusak, tetapi production build tetap berstatus belum terverifikasi sampai dependensi terpasang dan build dijalankan ulang.

## Batasan visual / gameplay

- Pemeriksaan otomatis memvalidasi struktur kode, aturan, dan referensi; bukan pengganti playtest real-time.
- Deep flora/formasi dan fauna memakai geometri lokal/prosedural; belum semuanya memakai sculpted external assets atau texture scans.
- Combat memiliki state/animasi prosedural. Kualitas feel, hitbox, timing, dan respons touch harus dikonfirmasi pada perangkat Android.
- Attack UI mendukung swing saat bergerak; tidak ada uji multi-touch fisik untuk joystick + look + attack di lingkungan ini.

## Kesimpulan

Source 2.6.0 lulus `npm test` dan pemeriksaan syntax. ZIP hasil rilis lulus `unzip -t`, berisi 196 file, dan `npm test` kembali lulus setelah ekstraksi. Kedalaman, biome, schooling, dan attack flow memiliki implementasi source yang dapat diuji. APK, visual runtime, dan multiplayer live belum diverifikasi. Tidak ada klaim bahwa proyek sudah setara penuh secara artistik atau teknis dengan Subnautica.
