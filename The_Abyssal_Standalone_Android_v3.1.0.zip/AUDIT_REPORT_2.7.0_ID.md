# Audit & Verification Report — The Abyssal 2.7.0

## Basis perubahan
- Source dasar: `The_Abyssal_Standalone_Android_v2.6.0.zip` yang tersedia di Library.
- Versi hasil: 2.7.0.
- Pendekatan: patch inkremental; tidak membangun ulang proyek.
- Save schema: v11 (tidak berubah).
- Application ID: `com.abyssal.game` (tidak berubah).
- Database: tidak ada migration Supabase baru.

## Ringkasan perubahan yang diaudit

| Area | Implementasi | Status pemeriksaan |
|---|---|---|
| Ekologi dasar laut | Profil flora dan formasi per biome/preset grafis | LULUS automated source checks |
| Sponge garden | Instanced tube sponge, mouth rings, glow modules, shared geometry/material | LULUS syntax/source checks |
| Roster fauna | Duplikat key `BIOME_SPECIES` dibersihkan | LULUS syntax/source checks |
| Spawn fauna | Biome lokal di titik spawn + rentang depth valid | LULUS syntax/source checks |
| Fauna hadal | Glasswing Ray, Rift Angler, Siphonophore colony model | LULUS profile/source checks |
| Perilaku fauna | Non-hostile fauna menghindar dari predator dekat; schooling dipertahankan | LULUS syntax/source checks |
| Moving melee | Hit diselesaikan pada frame animasi; sweep memperhitungkan velocity pemain dan lead target | LULUS helper/source checks |
| Lifecycle combat | Pending melee dibatalkan ketika pause, masuk kendaraan, atau intro cutscene dimulai | LULUS source checks |
| Save | Schema v11 dan data lama tidak diubah | LULUS regression checks |
| Backend | Tidak ada perubahan Supabase | LULUS source checks |
| Release metadata | package version, cache, update sample, workflow artifact, dokumentasi ke 2.7.0 | LULUS source checks |

## Hasil pengujian aktual

| Pengujian | Hasil |
|---|---|
| `node --check game.js` | LULUS |
| `node --check fauna.js` | LULUS |
| `node --check asset-proportions.mjs` | LULUS |
| `node --check ocean-ecology.mjs` | LULUS |
| `node --check combat-mechanics.mjs` | LULUS |
| `node --check scripts/verify.mjs` | LULUS |
| Semua file JS/MJS dan scripts melalui `scripts/verify.mjs` | LULUS |
| `npm test` | LULUS |
| 176 ID HTML unik | LULUS |
| 258 referensi DOM statis | LULUS |
| Import/path aset lokal | LULUS |
| 12 profil ekologi biome dan kualitas Low–Ultra | LULUS |
| Tiga profil fauna tambahan | LULUS |
| Helper hit sweep/normalisasi arah/lead velocity | LULUS |
| Terrain 1.500 m dan tujuh biome hadal lama | LULUS regression checks |
| Save schema v11, lima Quick Slots dan inventory lama | LULUS regression checks |
| Production build (`npm run build`) | GAGAL di lingkungan ini sebelum bundling: `ERR_MODULE_NOT_FOUND: Cannot find package 'vite'` |
| APK compilation | BELUM TERVERIFIKASI |
| Pengujian visual pada Android fisik | BELUM TERVERIFIKASI |
| Uji combat multi-touch (joystick + look + attack) | BELUM TERVERIFIKASI |
| Supabase multiplayer live dengan dua perangkat | BELUM TERVERIFIKASI |

## Batasan dan risiko tersisa
- Automated tests memeriksa struktur kode, nilai profil, import, referensi DOM, dan source assertions. Pengujian tersebut bukan pengganti sesi bermain real-time.
- Bentuk fauna/flora tambahan masih prosedural. Belum ada penggantian massal dengan model sculpted/rigged artist-authored atau tekstur PBR scan high-end.
- Build berhenti sebelum bundling karena `vite` tidak tersedia di environment ini. APK tidak dihasilkan.
- Hit frame dan movement-aware sweep telah diuji sebagai helper/source logic, tetapi respons tombol multi-touch, collision feel, dan animasi pada layar Android memerlukan device playtest.
- Multiplayer dan server Supabase tidak dijalankan secara live selama audit.

## Kesimpulan
Source 2.7.0 lolos `npm test` dan syntax checks. Profil ekologi baru, fauna tambahan, pemilihan fauna lokal, predator evasion, dan moving melee timing tercakup dalam pemeriksaan otomatis. Production build, APK, perangkat Android fisik, dan multiplayer live tetap berstatus belum terverifikasi. Versi ini memperkaya ekologi dan combat, tetapi belum boleh diklaim setara penuh dengan Subnautica secara visual atau keseluruhan gameplay.
