# Audit & Verification Report — The Abyssal 2.8.0

## Basis perubahan
- Source input: ZIP 2.7.0 dari sesi pengerjaan sebelumnya.
- Upgrade: patch inkremental, tanpa membangun ulang proyek. Audit struktur: 203 file baseline menjadi 210 file rilis; 7 file baru (dokumen/vector icon), 0 file lama dihapus.
- Save schema v11; Application ID `com.abyssal.game`; Supabase migrations tidak berubah.

## Perubahan yang benar-benar dibuat
- Ikon PWA 192/512/maskable, ikon native adaptive foreground/background, dan launcher density mdpi sampai xxxhdpi diselaraskan ke lambang baru.
- `makeHeightTexture()` membuat relief berbeda untuk sand, stone, kelp, coral, wood, dan metal; enam bump map disimpan/di-dispose terpisah dengan cap 512px pada Low dan 1K pada preset lain.
- `applyGraphicsTextureSet()` memperbarui bump map material berdasarkan albedo map-nya sehingga material yang sudah hidup menerima relief yang sesuai saat kualitas grafis berubah.
- Jam animasi fauna hanya bertambah satu kali per tick, bukan pada beberapa cabang yang berbeda.
- Animasi menu menggunakan transform/opacity ringan, dibatasi ke layar menu, dan mematuhi `prefers-reduced-motion`.
- Cache SW dan release metadata dinaikkan ke 2.8.0.

## Hasil uji aktual
| Pengujian | Status |
|---|---|
| `npm test` (workspace dan hasil ekstraksi ZIP final) | LULUS — 176 ID unik, 258 referensi DOM valid, pemeriksaan jalur aset, regression suite, tekstur, animasi, dan ikon |
| `node --check` seluruh JS/MJS/scripts | dijalankan melalui test runner |
| PNG PWA 192×192 dan 512×512 | diverifikasi melalui test runner |
| `unzip -t` final ZIP | LULUS — tidak ada error data terkompresi |
| PNG Android launcher density | diverifikasi melalui test runner |
| Referensi icon di manifest | diverifikasi melalui test runner |
| Save schema v11 dan sistem lama | regression suite historis dijalankan |
| `npm install --no-audit --no-fund` | timeout pada lingkungan pengerjaan; dependency tidak berhasil dipasang |
| Vite production bundle (`npm run build`) | GAGAL sebelum bundling: `ERR_MODULE_NOT_FOUND` untuk package `vite` |
| APK compilation/signing | BELUM DIVERIFIKASI |
| Android fisik / launcher OEM | BELUM DIVERIFIKASI |
| Performa GPU / visual playtest | BELUM DIVERIFIKASI |
| Supabase multiplayer live | BELUM DIVERIFIKASI |

Automated source checks bukan pengganti playtest. Tekstur baru procedural bump/relief, bukan paket PBR scan; animasi fauna belum menggunakan rig artist-authored.
