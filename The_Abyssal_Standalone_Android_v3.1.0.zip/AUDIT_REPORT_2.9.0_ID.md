# Audit — The Abyssal 2.9.0

## Lingkup
Source 2.8.0 dipertahankan dan diperbarui secara inkremental. Fitur 2.9.0 menambahkan arus 3D deterministik pada gameplay dan ekologi.

## Hasil yang dijalankan
- `node --check` seluruh JS/MJS dan build scripts.
- `npm test` termasuk verifikasi ZIP yang telah diekstrak.
- `unzip -t` untuk integritas arsip.
- Unit test medan arus: semua biome, stabilitas pada input sama, variasi lokasi/waktu, finite output, batas speed, dan skala resistansi diver/kendaraan.
- Audit DOM ID/referensi, jalur asset, impor lokal, save schema v11, biome, fauna, kendaraan, Lifepod, cutscene, dan pemeriksaan regresi dari suite warisan.

## Batas yang belum diuji
- Build produksi Vite/Capacitor dan APK Android tidak dianggap berhasil sampai perintah build selesai di lingkungan dengan dependency terpasang.
- Belum dilakukan uji perangkat Android fisik, pengukuran FPS/GPU/memori, kontrol multi-touch, atau koneksi Supabase live.
- Kualitas visual dan rasa arus perlu playtest; unit test hanya memastikan logika/batas hasil.

## Data yang dipertahankan
- `SAVE_SCHEMA_VERSION = 11`
- Application ID: `com.abyssal.game`
- File penandatanganan historis dan konfigurasi backend tetap ada.
- Tidak ada file proyek lama yang sengaja dihapus; tidak ada migration database baru.
