# Audit Rilis The Abyssal 3.1.0

## Ringkasan artefak
- Basis: source ZIP The Abyssal 3.0.0.
- File sumber basis: 224.
- File lama dihapus: 0.
- File tambahan: 63 (24 PBR WebP, 29 OGG, dua generator, satu audio runtime module, dua manifest, dan lima dokumen rilis).
- Jumlah file proyek akhir: 287.
- 8 keluarga PBR; tiap keluarga 1 albedo 2048² + 1 normal 1024² + 1 roughness 1024².
- 29 file audio OGG lokal.
- PBR WebP total: 8,326,692 byte.
- OGG audio total: 1,449,675 byte.
- PBR + audio: 9,776,367 byte sebelum kompresi.

- Arsip final melewati `unzip -t` dan `zipfile.testzip()` tanpa error; ukuran final dicantumkan pada pesan rilis.
- Pemeriksaan dimensi memakai Pillow: seluruh 8 albedo 2048×2048, seluruh 8 normal 1024×1024, dan seluruh 8 roughness 1024×1024.
- Pemeriksaan dekode memakai `ffprobe`: seluruh 29 file OGG dapat dibaca; total durasi aset sekitar 98,46 detik (ambience loop dan SFX).

## Pemeriksaan yang dijalankan
- `node --check game.js`: LULUS.
- `node --check fauna.js`: LULUS.
- `node --check audio-assets.mjs`: LULUS.
- `node --check scripts/verify.mjs`: LULUS.
- `node --check sw.js`: LULUS.
- `npm test`: LULUS; verifier mencakup 176 unique HTML IDs, 259 referensi DOM, 8 keluarga PBR, keberadaan file 2K/1K map, batas texture GPU, disposal safety, 29 OGG, audio event/fauna mapping, audio listener/spatial flow, animasi dekorasi dan cleanup chunk, serta regresi sistem lama.

## Build dan perangkat
- `npm install --no-audit --no-fund --fetch-retries=0 --fetch-timeout=45000`: GAGAL karena DNS jaringan ke `registry.npmjs.org` menghasilkan `EAI_AGAIN` (dependency tidak dapat diunduh).
- `npm run build`: GAGAL sebelum bundling karena package `vite` tidak terpasang/tersedia (`ERR_MODULE_NOT_FOUND`).
- APK Android: TIDAK DIBUAT.
- WebGL live visual, GPU/frame pacing, hasil audio di speaker/headphone, dan kontrol multi-touch: BELUM TERVERIFIKASI pada browser/perangkat nyata.
- Supabase live multiplayer: TIDAK DIUJI pada rilis aset ini.

## Integritas dan kompatibilitas
- Tidak ada file basis yang hilang.
- Save schema tetap v11.
- Application ID tetap `com.abyssal.game`.
- Tidak ada migration Supabase baru.
- Peningkatan 3.1.0 tidak mengubah protokol multiplayer.

## Keterbatasan kualitas
Aset tekstur PBR adalah hasil generasi procedural dan audio OGG merupakan sintesis terprogram, bukan bahan hasil pemindaian/rekaman profesional. Fauna dan sebagian besar benda masih tersusun dari geometri procedural dan tidak semuanya memiliki skeletal rig individual. Uji statis tidak menjamin hasil render, audibilitas, collision/animasi pada semua skenario runtime, atau kesetaraan kualitas dengan Subnautica. Verifikasi visual/audio harus dilanjutkan dengan bundle yang berhasil dibangun dan uji pada perangkat nyata.
