# Build The Abyssal 2.3.0 dari ponsel

1. Ekstrak ZIP lengkap ke folder baru. Jangan menimpa folder proyek lama sebelum membuat backup.
2. Unggah seluruh isi repository ke GitHub sesuai struktur root ZIP. Pastikan `package.json`, `index.html`, `game.js`, `immersive-systems.mjs`, dan folder `.github` berada pada lokasi yang benar.
3. Buka GitHub Actions dan jalankan workflow Android APK yang sudah ada.
4. Pastikan workflow berhasil menjalankan instalasi dependency, Vite build, Capacitor sync, dan Gradle assembleDebug.
5. Unduh artifact APK hanya jika job berhasil. Instal/update melalui Android dengan persetujuan pengguna.

## Catatan keselamatan data

- Jangan menghapus aplikasi lama atau membersihkan data aplikasi untuk melakukan update.
- Jangan menghapus save slot. Versi 2.3.0 mempertahankan schema save v11.
- Simpan backup ZIP dan backup save sebelum mengganti aplikasi.
- Pertahankan Application ID `com.abyssal.game` dan signing key yang sesuai agar Android mengenali paket sebagai update aplikasi yang sama.

## Jika build gagal

Periksa log job secara lengkap. Bedakan kegagalan pengunduhan dependency, Vite, Capacitor, Gradle, Android SDK, dan signing. Jangan menghapus test atau mengubah konfigurasi signing untuk menutupi kegagalan.
