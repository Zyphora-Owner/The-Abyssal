# Panduan Build The Abyssal 2.4.0 dari Ponsel

Panduan ini tetap mengikuti workflow proyek. Build APK tidak dapat dihasilkan hanya dengan mengekstrak ZIP; dependency Node, Java, Android SDK, dan signing harus tersedia pada lingkungan build.

## Persiapan

1. Ekstrak `The_Abyssal_Standalone_Android_v2.4.0.zip`.
2. Pastikan folder proyek berisi `package.json`, `index.html`, `capacitor.config.json`, `game.js`, `fauna.js`, `asset-proportions.mjs`, `scripts/`, `native/`, dan `.github/`.
3. Buka folder tersebut di lingkungan terminal/build Android yang mendukung Node.js 22, Java 21, dan Android SDK.
4. Duplikasi/backup folder save pribadi sebelum melakukan instalasi/update aplikasi.

## Build

Jalankan dari root proyek:

```bash
npm install
npm test
npm run build
```

Jika `npm run build` berhasil membuat folder `www/`, lanjutkan:

```bash
npx cap add android
node scripts/patch-android.mjs
npx cap sync android
cd android
./gradlew --no-daemon assembleDebug
```

Jika folder `android/` sudah tersedia, gunakan:

```bash
npm run android:debug:existing
```

## Pemeriksaan sebelum instalasi

- Pastikan APK build memiliki Application ID `com.abyssal.game`.
- Pertahankan signing key yang dipakai rilis sebelumnya agar proses update tidak membuat Android menganggap aplikasi sebagai aplikasi berbeda.
- Jangan uninstall aplikasi lama sebelum memastikan backup save tersedia.
- Pastikan konfigurasi Supabase berasal dari project milik pengguna. Isi `VITE_SUPABASE_URL` dan `VITE_SUPABASE_PUBLISHABLE_KEY` melalui `.env` atau CI secrets; jangan memasukkan service-role key ke client.

## Catatan status rilis 2.4.0

`npm test` lulus pada lingkungan pengerjaan. `npm run build` belum berhasil di lingkungan tersebut karena dependency Vite tidak terpasang (`ERR_MODULE_NOT_FOUND`). Karena itu, belum ada klaim bahwa APK 2.4.0 berhasil dikompilasi atau diuji pada perangkat fisik dari lingkungan ini.
