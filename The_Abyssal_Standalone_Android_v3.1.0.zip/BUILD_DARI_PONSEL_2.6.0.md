# Panduan Build The Abyssal 2.6.0 dari Ponsel

Panduan ini mengikuti workflow proyek. ZIP source dapat dibuka di editor/terminal yang mendukung Node.js, tetapi kompilasi APK memerlukan Node, Java, Android SDK/Gradle, dependensi, dan signing key yang kompatibel dengan rilis sebelumnya.

## Persiapan

1. Ekstrak `The_Abyssal_Standalone_Android_v2.6.0.zip`.
2. Pastikan root memuat `package.json`, `index.html`, `capacitor.config.json`, `game.js`, `fauna.js`, `world-generation.mjs`, `vehicle-systems.mjs`, `scripts/`, `native/`, `supabase/`, dan `.github/`.
3. Backup save pemain dan signing key yang digunakan rilis terdahulu.
4. Gunakan Node.js 22 dan Java 21 sesuai toolchain proyek, serta Android SDK yang dibutuhkan.

## Pemeriksaan dan build

Jalankan dari root proyek:

```bash
npm install
npm test
npm run build
```

Jika build web selesai dan menghasilkan `www/`, siapkan Android project:

```bash
npx cap add android
node scripts/patch-android.mjs
npx cap sync android
cd android
./gradlew --no-daemon assembleDebug
```

Untuk project Android yang sudah ada:

```bash
npm run android:debug:existing
```

## Signing dan update

- Application ID harus tetap `com.abyssal.game`.
- Pertahankan signing key lama agar Android menerima APK sebagai pembaruan aplikasi yang sama.
- Jangan uninstall rilis lama sebelum backup save tervalidasi.
- Save schema v11 dipertahankan oleh source 2.6.0.

## Backend

Jika multiplayer digunakan, isi `VITE_SUPABASE_URL` dan `VITE_SUPABASE_PUBLISHABLE_KEY` dari Supabase project milikmu melalui `.env` atau CI secrets. Jangan memasukkan service-role key, secret, atau password database ke client. Migrasi Hadal `202611080001_hadal_depth_coordinates.sql` berasal dari rilis 2.5.0 dan bersifat append-only; jika belum diterapkan ke project Supabase yang sudah memakai migration lama, jalankan sekali setelah `202611070002_deep_world_coordinates.sql`. Rilis 2.6.0 tidak menambah migration database baru.

## Status verifikasi rilis

- `npm test`: LULUS.
- `node --check` untuk file JS/MJS utama dan scripts: LULUS.
- `npm run build`: belum berhasil di lingkungan pengerjaan karena paket Vite tidak tersedia (`ERR_MODULE_NOT_FOUND`).
- APK compilation dan pengujian Android fisik: BELUM TERVERIFIKASI.
