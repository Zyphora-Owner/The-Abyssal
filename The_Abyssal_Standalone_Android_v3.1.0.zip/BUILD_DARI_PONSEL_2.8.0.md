# Panduan Build The Abyssal 2.8.0 dari Ponsel

ZIP ini adalah **source project**, bukan APK siap instal. Build APK memerlukan Node.js, Java, Android SDK/Gradle, dependency yang berhasil dipasang, dan signing key yang sesuai dengan aplikasi versi sebelumnya.

## Persiapan
1. Ekstrak `The_Abyssal_Standalone_Android_v2.8.0.zip`.
2. Pastikan root berisi `package.json`, `index.html`, `game.js`, `fauna.js`, `ocean-ecology.mjs`, `combat-mechanics.mjs`, `capacitor.config.json`, `scripts/`, `native/`, `supabase/`, dan `.github/`.
3. Backup save dan signing key lama.
4. Gunakan Node.js 22 dan Java 21 sesuai workflow proyek, ditambah Android SDK yang kompatibel.

## Pemeriksaan dan build
Jalankan dari root proyek:

```bash
npm install
npm test
npm run build
```

Jika web bundle berhasil dan folder `www/` terbentuk:

```bash
npx cap add android
node scripts/patch-android.mjs
npx cap sync android
cd android
./gradlew --no-daemon assembleDebug
```

Jika direktori Android sudah ada, gunakan workflow `npm run android:debug:existing`.

## Identitas aplikasi dan data
- Application ID harus tetap `com.abyssal.game`.
- Pertahankan signing key lama agar APK dapat memperbarui aplikasi yang sama.
- Save schema v11 tetap dipakai; jangan menghapus data aplikasi untuk mengatasi masalah build.
- Lima Quick Slots, inventory, PDA, Fabricator, kendaraan, dan dunia hadal tetap menjadi bagian source.

## Backend
Rilis 2.8.0 tidak menambahkan migration Supabase. Konfigurasikan `VITE_SUPABASE_URL` dan `VITE_SUPABASE_PUBLISHABLE_KEY` sesuai project milikmu jika multiplayer digunakan. Jangan pernah menaruh `service_role` key/secret di client.

## Status verifikasi pada sesi pembuatan
- `npm test`: LULUS.
- Syntax JS/MJS dan pemeriksaan import/path: LULUS.
- `npm install --no-audit --no-fund`: percobaan pemasangan dependency melewati batas waktu lingkungan; `node_modules/vite` tetap tidak tersedia.
- `npm run build`: gagal sebelum bundling dengan `ERR_MODULE_NOT_FOUND: Cannot find package 'vite'`. APK tidak dibuat dalam sesi ini.
- APK compilation: BELUM TERVERIFIKASI.
- Pengujian Android fisik: BELUM TERVERIFIKASI.

## Ikon dan material 2.8.0
Ikon PWA serta Android sudah tersedia dalam ZIP. Relief pasir/basalt/coral/kelp/kayu/logam dibuat secara procedural dengan bump map terpisah. Tidak perlu mengunduh aset eksternal untuk menggunakan peningkatan ini.
