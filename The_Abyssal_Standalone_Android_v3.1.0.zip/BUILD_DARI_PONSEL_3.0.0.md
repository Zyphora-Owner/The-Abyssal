# Panduan Build The Abyssal 3.0.0 dari Ponsel

ZIP ini adalah **source project lengkap**, bukan APK siap instal. Build native memerlukan Node.js 22, Java 21, Android SDK/Gradle, dependency npm yang berhasil terpasang, dan signing key yang sama dengan aplikasi sebelumnya.

## Persiapan
1. Ekstrak `The_Abyssal_Standalone_Android_v3.0.0.zip`.
2. Pastikan root berisi `index.html`, `package.json`, `game.js`, `fauna.js`, `cave-systems.mjs`, `physics-systems.mjs`, `audio-design.mjs`, `capacitor.config.json`, `scripts/`, `native/`, `supabase/`, dan `.github/`.
3. Backup save penting dan signing key lama sebelum menguji update APK.
4. Gunakan Node.js 22 dan Java 21, sesuai workflow.

## Verifikasi dan build
Dari root proyek:

```bash
npm install
npm test
npm run build
```

Jika web bundle sukses dan folder `www/` terbentuk:

```bash
npx cap add android
node scripts/patch-android.mjs
npx cap sync android
cd android
./gradlew --no-daemon assembleDebug
```

Jika folder Android sudah ada, gunakan `npm run android:debug:existing` dari root. Jangan menghapus folder native/signing assets untuk mencoba memperbaiki build.

## Kompatibilitas
- Application ID tetap `com.abyssal.game`.
- Gunakan signing key historis agar update dipasang sebagai aplikasi yang sama.
- Save schema tetap v11; jangan hapus data aplikasi.
- Tidak ada Supabase migration baru pada 3.0.0.
- Jangan menyalin service-role key atau database secret ke client; gunakan Project URL dan publishable key.

## Status pada sesi pembuatan v3.0.0
- `npm test`: LULUS.
- Pemeriksaan sintaks JS/MJS dan import/path: LULUS.
- `npm run build`: GAGAL sebelum bundling karena package `vite` tidak tersedia (`ERR_MODULE_NOT_FOUND`).
- `npm install --no-audit --no-fund --ignore-scripts`: timeout pada lingkungan build ini.
- APK: TIDAK DIBUAT.
- Android fisik, WebGL visual, audio, GPU/FPS dan input multi-touch: BELUM TERVERIFIKASI.

Build pada perangkat/runner yang memiliki akses dependency dan Android SDK masih diperlukan untuk menghasilkan APK. ZIP source ini tidak boleh dianggap sebagai APK siap instal.
