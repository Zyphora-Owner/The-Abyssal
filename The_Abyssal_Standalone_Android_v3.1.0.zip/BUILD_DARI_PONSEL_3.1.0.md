# Panduan Build The Abyssal 3.1.0 dari Ponsel

ZIP ini adalah **source project lengkap**, bukan APK siap instal. Build native memerlukan Node.js 22, Java 21, Android SDK/Gradle, dependency npm yang berhasil terpasang, dan signing key historis.

## Persiapan
1. Ekstrak `The_Abyssal_Standalone_Android_v3.1.0.zip`.
2. Pastikan root berisi `index.html`, `package.json`, `game.js`, `fauna.js`, `audio-assets.mjs`, `assets/pbr/`, `assets/audio/`, `native/`, `supabase/`, dan `.github/`.
3. Backup save penting dan signing key sebelum menguji update APK.
4. Gunakan Node.js 22 dan Java 21 sesuai workflow proyek.

## Verifikasi dan build
```bash
npm install
npm test
npm run build
```

Jika bundle sukses dan `www/` terbentuk:
```bash
npx cap add android
node scripts/patch-android.mjs
npx cap sync android
cd android
./gradlew --no-daemon assembleDebug
```

Jika folder Android sudah ada, gunakan `npm run android:debug:existing` dari root. Jangan menghapus folder native/signing assets untuk memperbaiki build.

## Kompatibilitas
- Application ID tetap `com.abyssal.game`.
- Gunakan signing key historis agar update dipasang sebagai aplikasi yang sama.
- Save schema tetap v11.
- Tidak ada Supabase migration baru pada 3.1.0.
- Jangan menaruh service-role key atau database secret pada client.

## Status build pada sesi 3.1.0
- Pemeriksaan sintaks JS/MJS: LULUS.
- `npm test`: LULUS.
- `npm install`: GAGAL saat mengakses `registry.npmjs.org` karena DNS `EAI_AGAIN`; dependency tidak dapat diunduh.
- `npm run build`: GAGAL sebelum bundling karena dependency `vite` tidak tersedia (`ERR_MODULE_NOT_FOUND`).
- APK: TIDAK DIBUAT.
- Visual WebGL/audio/GPU dan Android fisik: BELUM TERVERIFIKASI.

ZIP source tidak boleh dianggap APK siap instal. Build dan uji pada perangkat/runner dengan dependency lengkap serta Android SDK masih diperlukan.
