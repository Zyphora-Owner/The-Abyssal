# The Abyssal 2.3.0 — Cinematic Motion, First-Person & Underwater Atmosphere

## Dasar rilis

Pembaruan inkremental di atas source proyek 2.2.0. Tidak membangun ulang dari nol, tidak mengubah save schema, dan tidak mengganti identitas atau nama orisinal The Abyssal.

## Perubahan yang diterapkan

### Kamera sinematik
- Setiap dari tujuh shot intro kini memiliki lintasan kamera awal-akhir, lintasan target, transisi FOV, dan roll sinematik kecil yang dibatasi.
- Interpolasi memakai easing deterministik sehingga kamera bergerak sepanjang shot, bukan hanya menahan satu posisi.
- Roll dikomposisikan dari quaternion dasar yang bersih, bukan diakumulasikan setiap frame.
- Timing cerita, timeline subtitle, Skip/Replay, dan durasi intro tetap dipertahankan.

### First-Person item presentation
- Menambahkan `immersive-systems.mjs` sebagai sumber profil presentasi per item yang dapat diuji tanpa renderer.
- Item resource dan supply yang dapat dipegang memiliki profil khusus untuk skala, posisi, rotasi, posisi grip, bob, idle motion, dan respons saat digunakan.
- Animasi item kini memakai transformasi dasar per model sehingga gerakan idle/pakai tidak menggeser posisi genggaman secara kumulatif.
- Overlay sarung tangan dihitung ulang setelah transformasi model agar mengikuti grip item.
- Profil tetap mempertahankan model 3D lokal dan tidak mengganti item dengan ikon 2D.

### Material dan aset item
- Titanium, copper, magnetite, dan silver memakai respons metalness/roughness serta tekstur metal yang lebih sesuai.
- Quartz dan lithium memakai material fisik transparan/transmissive dengan clearcoat; lithium mendapat emisi halus.
- Sulfur dan glowcap mendapat emisi kontekstual yang dibatasi.
- Ore metal mendapat bentuk polyhedron lebih bersegi dan aksen permukaan, sedangkan kristal memakai kumpulan shard berbeda.
- Tekstur lama dan sistem preset grafis tetap digunakan; tidak mengklaim semua aset proyek sudah menjadi paket PBR eksternal.

### Atmosfer bawah laut
- Warna fog kini mengikuti biome dan bergeser secara bertahap menuju palet abyssal berdasarkan kedalaman.
- Density fog memakai profil kualitas dan kedalaman yang teruji, serta bertransisi kembali saat pemain berada di atas permukaan.
- Tidak ada perubahan save schema atau nilai survival.

## Fitur yang dipertahankan

Seluruh fitur versi sebelumnya tetap dipertahankan, termasuk cutscene dan cerita 8142C, Leviathan, Lifepod/hatch, dunia dan biome, flora/fauna, inventory 8×6, lima Quick Slots, PDA, tools, Fabricator, survival, habitat/building, tiga kendaraan dan upgrade, Supabase/Auth, room/co-op, offline play, dan save schema v11.

Application ID tetap `com.abyssal.game`. Signing dan konfigurasi Android yang sudah ada tidak sengaja diubah.

## Batasan yang diketahui

- Peningkatan ini memperhalus sistem sinematik, model First-Person prosedural, beberapa material item, dan fog. Ini bukan penggantian penuh seluruh aset dengan model GLB/FBX PBR eksternal.
- Audio tetap memakai sistem audio sintetis offline yang sudah ada; tidak ada rekaman dialog, foley, atau soundtrack studio baru yang ditambahkan.
- Kualitas tampilan akhir masih memerlukan pemeriksaan langsung di browser/WebGL dan perangkat Android.
- Build produksi/APK hanya dinyatakan berhasil bila dependency Vite/Gradle tersedia dan build benar-benar selesai.
