# The Abyssal 2.4.0 — Proportion, Silhouette & Asset Geometry Overhaul

## Fokus rilis

Menyempurnakan bentuk, proporsi, siluet, dan detail struktural aset dunia The Abyssal dengan mempertahankan sistem gameplay, collision, save, dan identitas orisinal proyek.

## Perubahan

### 1. Profil proporsi terpusat
- Menambahkan `asset-proportions.mjs` sebagai sumber profil visual bersama untuk fauna, resource/item, struktur habitat, dan kendaraan.
- Memisahkan profil siluet dari collision dan footprint gameplay agar perubahan visual tidak diam-diam mengubah physics, placement, atau data save.
- Menambahkan validasi profil dimensi dan skala item.

### 2. Fauna dan ikan
- Geometri badan ikan sekarang menerapkan rasio lebar/tinggi sesuai referensi masing-masing bentuk tubuh, bukan satu rasio global.
- Menambahkan morfologi compressed-body untuk butterflyfish, angelfish, dan Moorish idol serta morfologi boxier untuk triggerfish.
- Menambahkan cephalofoil khas hammerhead, detail moncong/rahang untuk ikan predator, dan detail punggung/sirip berpasangan pada moray eel serta ribbon eel.
- Menambahkan detail streamer dorsal untuk Moorish idol dan detail bentuk khusus triggerfish.
- Menambahkan metadata dimensi visual pada model fauna tanpa mengubah nilai `species.scale`, kecepatan, depth band, damage, aggro, atau spawn behavior.

### 3. Item dan resource
- Memperluas profil skala untuk mineral, kristal, resource organik, baterai, komponen elektronik, supply, serta consumable.
- Mengubah model Kelp yang dipegang menjadi kumpulan bilah daun berbentuk lembaran dengan midrib, bukan kumpulan kapsul generik.
- Mempertahankan model First-Person dan sistem grip yang sudah ada untuk semua tool dan item yang dapat dipegang.
- Mempertahankan footprint inventory dan ukuran slot yang berlaku.

### 4. Struktur dan Lifepod
- Menambahkan panel tekanan modular melingkar pada Multipurpose Compartment agar bentuk habitat lebih terbaca sebagai struktur silinder bawah laut.
- Menambahkan gasket karet pada frame airlock.
- Mempertahankan ukuran visual nominal struktur dan seluruh collision/placement yang sudah ada.
- Lifepod kini menghitung dan menyimpan metadata bounding dimensions visual setelah transformasinya diterapkan; collision radius dan collision length tidak berubah.

### 5. Kendaraan
- Skimmer dan Carrier sekarang menggunakan geometri lambung longitudinal yang dibentuk dari profil panjang, lebar, tinggi, dan section lambung yang diarsipkan bersama.
- Menambahkan pressure bands mengikuti siluet hull.
- Mempertahankan data dimensi kendaraan, collision, depth rating, health, power, upgrades, cargo, serta save data.
- Nautilus Exosuit mempertahankan geometri dan dimensi gameplay yang berlaku.

### 6. Metadata rilis dan cache
- Versi proyek dinaikkan menjadi 2.4.0.
- Cache Service Worker dan label build diperbarui.
- Application ID tetap `com.abyssal.game`.
- Save schema tetap v11.

## Kompatibilitas dan fitur yang dipertahankan

Tidak ada migrasi save atau perubahan database. Seluruh fitur sebelumnya tetap berada dalam proyek: intro/cutscene 8142C, Leviathan, Lifepod/hatch, dunia dan biome, flora/fauna, inventory, lima Quick Slots, PDA, tools, Fabricator, survival, habitat, kendaraan, upgrade, Supabase, login/co-op, dan offline mode.

## Pengujian

- `node --check` untuk `game.js`, `fauna.js`, `asset-proportions.mjs`, dan `scripts/verify.mjs`: lulus.
- `npm test`: lulus.
- `npm run build`: belum berhasil karena paket `vite` tidak tersedia dalam lingkungan pengerjaan (`ERR_MODULE_NOT_FOUND`).
- APK dan pengujian visual pada perangkat Android fisik: belum terverifikasi.

## Batasan rilis

Perubahan ini merupakan penyempurnaan geometri prosedural dan profil proporsi, bukan penggantian total semua aset dengan model eksternal bertekstur PBR, rekaman audio profesional, atau animasi motion-captured. Kesesuaian visual runtime pada GPU/perangkat fisik tetap perlu diuji. Aset mengikuti bahasa desain survival bawah laut sebagai referensi, tetapi bentuk dan identitas The Abyssal tetap orisinal.
