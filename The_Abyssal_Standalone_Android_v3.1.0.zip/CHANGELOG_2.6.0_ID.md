# The Abyssal 2.6.0 — Moving Combat, Hadal Ecology & 1.500 m Ocean

Rilis inkremental berdasarkan source 2.5.0. Fokus rilis ini adalah combat yang tidak mengunci pergerakan, serangan fauna dengan animasi spesifik spesies, kehidupan laut berkelompok, serta detail seafloor palung terdalam.

## 1. Combat saat bergerak

- Tombol serang tetap tersedia ketika Survival Knife berada di Quick Slot dan item dimiliki, termasuk saat pemain sedang berenang.
- Ayunan pisau tetap menjalankan animasi First-Person ketika tidak ada target; jika ada fauna dalam bidikan dan jangkauan, serangan diterapkan.
- Serangan pemain tidak menghentikan joystick, momentum berenang, atau kamera.
- Animasi ayunan mempergerakkan pisau, lengan kanan, dan pergelangan secara tersinkron.
- Reaksi terkena serangan pada pemain menggerakkan viewmodel dan kamera secara singkat tanpa mengunci kontrol.

## 2. Serangan fauna dengan perilaku spesifik

- Fauna agresif memakai siklus telegraph/wind-up → lunge → contact check → recovery.
- Setiap serangan memiliki profil timing, jangkauan, jarak lunge, dan cooldown spesies; contohnya dart-bite, hammer-ram, ambush-bite, lure-bite, tentacle-sweep, leviathan-charge, dan hadal-crush.
- Jaw, tail, fins, tentacles, dan orientasi tubuh ikut beranimasi sesuai bentuk makhluk.
- Damage hanya diterapkan satu kali per animasi serangan melalui `hitApplied`.
- Pemain dapat menghindar dengan terus berenang; pemeriksaan kontak dilakukan pada fase impact terhadap posisi pemain saat itu.
- Fauna yang terkena pisau memperlihatkan hit reaction dan gerakan menjauh; fauna yang kalah menampilkan animasi non-grafis sebelum despawn.
- Spesies non-hostile tidak berubah menjadi predator; mereka merespons dengan gerakan menghindar/menjauh.

## 3. Laut lebih hidup

- Spesies schooling yang dipilih membentuk kelompok dengan cohesion dan separation sehingga tidak bergerak sebagai aktor acak yang sepenuhnya terpisah.
- Lanternfish juga dapat membentuk kelompok pada zona gelap.
- Ditambahkan formasi basalt prosedural di biome dalam: pilar, spire, batuan bertingkat, dan urat mineral bercahaya yang dibedakan per biome.
- Formasi baru di-stream per chunk dan dibersihkan ketika chunk dibongkar.
- Seluruh fauna/lingkungan lama tetap ada.

## 4. Palung mendekati 1.500 m

- Batas penyelaman, tanki, dan modul kendaraan tetap mendukung rating 1.500 m.
- Dasar pusat palung diperdalam dari sekitar 1.478 m menjadi sekitar 1.494,5 m; hard floor tetap menjaga clearance teknis agar pemain/kendaraan tidak menembus batas dunia.
- Tujuh lapisan biome palung dipertahankan:

| Kedalaman | Biome |
|---:|---|
| 62–180 m | Twilight Trench / Deep |
| 180–500 m | The Hadal Reach / Abyss |
| 500–720 m | Abyssal Shelf |
| 720–940 m | Midnight Grotto |
| 940–1.160 m | Blue Void |
| 1.160–1.360 m | Hadal Rift |
| 1.360–1.500 m | Hadal Garden |

- Kedalaman spawn Leviathan dan fauna langka diselaraskan dengan habitat masing-masing agar tidak muncul di atas rentang kedalamannya.
- Rating tanki dan kendaraan sampai 1.500 m dari rilis sebelumnya tetap berlaku; tier lama tidak diubah.

## 5. Kompatibilitas dan fitur lama

- Save schema v11, Application ID `com.abyssal.game`, signing, sistem offline, Supabase, dan konfigurasi room lama dipertahankan.
- Tidak ada reset save atau perubahan format save.
- Inventory 8×6, lima Quick Slots, PDA, Fabricator, Lifepod, hatch, habitat, kendaraan, upgrade, story/cutscene, serta biome dangkal tidak dihapus.
- Tidak ada aset Subnautica resmi yang disalin; desain dan nama The Abyssal tetap orisinal.

## 6. Batasan yang diketahui

- Model, flora, fauna, batuan, dan audio procedural/lokal masih menjadi basis; ini bukan penggantian seluruh aset dengan paket 3D artist-authored atau rekaman audio profesional.
- Automated source checks tidak membuktikan kualitas visual runtime. Pengujian Android fisik dan multiplayer Supabase live belum dilakukan.
- `npm run build` belum berhasil di lingkungan pengerjaan karena paket Vite tidak tersedia (`ERR_MODULE_NOT_FOUND`). APK belum dapat dinyatakan terkompilasi.
