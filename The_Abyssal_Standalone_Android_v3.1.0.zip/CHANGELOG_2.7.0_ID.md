# The Abyssal 2.7.0 — Hadal Ecology & Responsive Moving Combat

## Fokus rilis
Peningkatan inkremental ekologi laut, distribusi fauna berdasarkan biome/kedalaman, flora bentik instanced, variasi fauna hadal, serta hit timing Survival Knife saat pemain tetap bergerak.

## Perubahan
- Menambahkan `ocean-ecology.mjs` untuk anggaran flora/struktur dasar laut per-biome dan per-preset grafis. Profil mencakup seagrass, coral, fan coral, sponge clusters, oxygen plants, hadal blooms, dan basalt formations.
- Sponge garden dibangun sebagai `InstancedMesh` menggunakan geometri/material bersama agar jumlah organisme dasar laut bertambah tanpa satu draw call per tabung.
- Merapikan roster `BIOME_SPECIES` agar setiap biome hanya didefinisikan sekali.
- Spawn fauna sekarang membaca biome lokal pada koordinat spawn dan memilih spesies yang rentang kedalamannya sesuai; fallback hanya memakai spesies yang valid untuk kedalaman tersebut.
- Menambahkan Glasswing Ray, Rift Angler, dan Abyssal Siphonophore dengan silhouette khusus. Siphonophore memakai koloni zooid bercahaya dan tentakel beranimasi, bukan model ikan generik.
- Fauna non-hostile melarikan diri ketika predator berada dekat; sistem schooling lama tetap dipertahankan.
- Menambahkan `combat-mechanics.mjs` untuk profil serangan dan perhitungan sweep First-Person yang memperhitungkan velocity diver.
- Damage Knife kini diselesaikan pada active animation frame; target diprediksi sedikit berdasarkan gerakannya. Gerakan berenang tidak dikunci.
- Serangan tertunda dibatalkan aman saat pause, ketika masuk kendaraan, dan saat memulai cutscene agar hit tidak terjadi setelah state permainan berubah.
- Cache Service Worker, metadata versi, workflow artifact, dan dokumentasi diperbarui ke 2.7.0.

## Kompatibilitas dan fitur yang dipertahankan
- Save schema tetap v11; tidak ada migrasi save baru.
- Tidak ada migrasi Supabase atau perubahan tabel/database untuk 2.7.0.
- Application ID tetap `com.abyssal.game`.
- Signing key, lima Quick Slots, inventory 8×6, PDA, Fabricator, Lifepod, habitat, kendaraan Pelagic, upgrade, offline mode, Supabase Auth, room/multiplayer, serta dunia 1.500 m dengan tujuh biome hadal dipertahankan.
- Seluruh aset lama tetap ada; tambahan baru dibuat dari geometri dan material prosedural lokal.

## Batasan yang diketahui
- Model tambahan masih berbasis geometri prosedural low-poly dan tekstur lokal; ini bukan penggantian semua fauna/flora dengan sculpted asset atau tekstur PBR scan berkualitas tinggi.
- Uji hitbox, feel combat, dan multi-touch masih berupa automated/source verification; belum dilakukan pada perangkat Android fisik.
- Production build/APK belum dibuat pada lingkungan pengerjaan karena dependency `vite` tidak tersedia.
