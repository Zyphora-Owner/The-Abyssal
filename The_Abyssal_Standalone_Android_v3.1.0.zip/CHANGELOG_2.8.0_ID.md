# Changelog — The Abyssal 2.8.0

Rilis ini merupakan pembaruan inkremental dari 2.7.0. Struktur proyek, save lama, backend, dan fitur yang sudah ada dipertahankan.

## Peningkatan
- Identitas ikon aplikasi diperbarui dengan lambang pari abyssal bioluminesen original; ikon PWA, maskable, adaptive Android, dan seluruh density launcher diselaraskan.
- Tekstur relief sekarang memiliki detail khusus permukaan: pasir beriak, basalt retak/berlapis, kelp berurat, coral berpori, serat kayu, serta logam bercalar.
- Setiap jenis material memakai bump map masing-masing sehingga permukaan logam tidak lagi memakai relief batu yang sama dengan pasir/coral. Alokasi relief dibatasi 512px pada Low dan 1K pada preset lain untuk menjaga penggunaan memori GPU mobile.
- Jam animasi fauna maju sekali per tick. Gerakan sirip, ekor, tentakel, dan buoyancy tidak lagi mempercepat phase karena beberapa cabang memperbarui jam yang sama.
- Menu utama mendapat animasi masuk tombol dan gerakan apung logo yang ringan; semuanya dinonaktifkan saat sistem meminta reduced motion.
- Cache service worker dan seluruh metadata rilis dinaikkan ke 2.8.0.

## Dipertahankan
- Save schema v11, lima Quick Slots, inventory/PDA/Fabricator, Lifepod, habitat, kendaraan, dunia 1.500 m, tujuh biome hadal, Supabase/Auth/multiplayer, offline mode, Application ID `com.abyssal.game`, dan signing key debug historis.
- Tidak ada penghapusan fitur maupun migrasi database baru.

## Batas verifikasi
`npm test` dan pemeriksaan sintaks dapat memverifikasi struktur, regresi helper, aset, dan referensi statis. Kualitas visual real-time, performa perangkat Android fisik, APK release, serta multiplayer live tetap harus diuji pada perangkat/pipeline sebenarnya.
