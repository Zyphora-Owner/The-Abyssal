# Changelog — The Abyssal 2.9.0

Pembaruan inkremental dari 2.8.0. Tidak membangun ulang proyek dan tidak menghapus fitur lama.

## Simulasi arus laut
- Menambahkan `ocean-currents.mjs`, medan arus laut 3D deterministik yang kontinu dalam koordinat dunia dan waktu simulasi.
- Arus memiliki profil berbeda pada reef, kelp forest, wreck, thermal vents, open water, deep, abyss, midnight grotto, blue void, hadal rift, dan hadal garden.
- Penyelam mengalami drift saat melepas input; fins mengurangi drift dan Seaglide memberi resistansi yang lebih tinggi. Arus tidak memengaruhi gerak saat berada di tanah kering atau di dalam habitat.
- Kendaraan terkena arus sesuai bobot: Carrier paling tahan, Exosuit menengah, Skimmer lebih responsif. Gerak tetap melewati swept collision yang sudah ada.
- Fauna menerima drift yang berbeda menurut cara berenang: gelatinous fauna lebih terbawa arus, hewan besar dan predator lebih mampu melawannya.
- Debris dan resource drop yang belum menyentuh dasar ikut terbawa arus. Oxygen plants dan hadal flora menyesuaikan arah sway dengan arus lokal.
- Semua perhitungan dibatasi dan bebas random per-frame; tidak mengubah save schema.

## Dipertahankan
- Save schema v11, lima Quick Slots, semua menu/gameplay lama, ikon/tekstur dari 2.8.0, offline play, Supabase, Application ID `com.abyssal.game`, signing asset historis.
- Tidak ada migrasi database baru dan tidak ada dependency tambahan.

## Batas pengujian
- Pengujian otomatis memeriksa medan arus, batas kecepatan, variasi ruang/waktu, serta integrasi sumber.
- Tampilan visual, rasa kendali, performa GPU, APK, Android fisik, dan multiplayer live belum dapat dianggap terverifikasi oleh unit test.
