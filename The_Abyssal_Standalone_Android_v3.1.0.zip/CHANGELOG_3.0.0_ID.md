# The Abyssal 3.0.0 — Changelog

Pembaruan inkremental dari v2.9.0. Fokus rilis: gua bawah laut, collision ruang, gravitasi/buoyancy, akustik kedalaman, dan momen cutscene.

## 1. Dunia dan struktur gua
- Menambahkan `cave-systems.mjs` sebagai sumber data tunggal untuk carving terrain, profil atap, batas gerak samping, dan audio blend.
- Tiga cekungan termal lama dipertahankan pada koordinat dan kedalaman yang sama.
- Empat situs gua baru membentuk lorong dan ruang utama di abyss, Midnight Grotto, Hadal Rift, dan Hadal Garden.
- Setiap lorong memakai geometri TubeGeometry melengkung, ruang gua, bibir batu, dinding bertekstur, stalaktit/stalagmit, kristal emissive, lampu lokal, dan partikel debu sedimen.
- Debu dan pencahayaan gua beranimasi ringan; objek ikut lifecycle streaming chunk sehingga dibersihkan ketika chunk keluar dari radius render.

## 2. Collision gua dan fauna
- Profil gua yang sama dipakai untuk lantai terukir, ceiling/roof clamp, dan dinding samping.
- Penyelam, kendaraan, resource drop, debris, serta fauna kecil yang sedang berada di dalam lorong dibatasi terhadap dinding samping.
- Player/vehicle/fauna dibatasi dari menembus atap gua; vehicle sweep, tabrakan terrain, Lifepod, dan struktur lama tetap aktif.
- Mulut lorong dapat digunakan untuk masuk/keluar; collision lateral tidak menutup jalur keluar yang dirancang.
- Fauna terlalu besar tidak dipaksa masuk ke lorong sempit.

## 3. Fisika, gravitasi, dan buoyancy
- Menambahkan `physics-systems.mjs` dengan konstanta gravitasi standar, percepatan buoyancy dari rasio densitas, drag fluida eksponensial, integrasi semi-implicit, speed cap, dan capsule roof clamp.
- Gerakan jatuh di permukaan kering memakai 9,81 m/s².
- Resource drop dan debris bergerak dengan gravitasi efektif air, densitas item, drag, arus laut, lantai, struktur, dan atap gua.
- Penyelam tetap memakai kontrol renang berbasis input dan trim buoyancy ringan; ini bukan simulasi scuba ballast/pressure solver penuh.

## 4. Suara dan akustik
- Menambahkan `audio-design.mjs` untuk profil audio berdasarkan kedalaman, biome, serta tingkat keterkungkungan gua.
- SFX melalui filter low-pass, jalur dry, convolver reverb, dan delayed echo dengan feedback teredam yang dibatasi.
- Kedalaman dan gua mengubah frekuensi filter, porsi pantulan, waktu delay, dan ekor echo.
- Ambience dan SFX tetap dibuat lokal melalui Web Audio; tidak ada audio rekaman studio atau file musik baru yang ditambahkan.

## 5. Cutscene
- Menambahkan kurva efek deterministik untuk benturan kapsul: camera shake, impact roll, dan FOV punch dengan nilai maksimum terbatas.
- Momen reveal makhluk besar memiliki pulse cahaya tersinkron pada emissive material dan creature light.
- Timeline kamera, subtitle, Leviathan, splash, reentry, skip, dan pemulihan kontrol yang lama dipertahankan.

## 6. Kompatibilitas dan metadata
- Package version, footer aplikasi, update checker, Service Worker cache, contoh metadata update, dan nama artifact workflow diperbarui ke 3.0.0.
- `SAVE_SCHEMA_VERSION` tetap 11.
- Application ID tetap `com.abyssal.game`.
- Tidak ada migration Supabase baru.
- Semua 216 file proyek sumber v2.9.0 dipertahankan; tiga modul runtime baru ditambahkan. Dokumen rilis baru ditambahkan terpisah.

## 7. Batasan yang diketahui
- Gua dan struktur masih procedural, bukan sculpted/photogrammetry high-poly assets.
- Collision atap/samping merupakan collision analitik berbasis lorong, bukan mesh collider rigid-body kontinu untuk seluruh batuan.
- Fauna kecil dapat dibatasi oleh ruang gua; fauna raksasa tidak dapat masuk ke setiap lorong.
- Tekstur tetap procedural dengan map relief/bump yang sudah ada. Tidak semua material mempunyai full PBR set (albedo, normal, roughness, metallic, AO) berbasis hasil scan.
- Efek audio sintetis Web Audio; reverb/echo merupakan pendekatan ringan, bukan akustik ray-traced.
- Tes otomatis tidak dapat membuktikan tampilan renderer, kualitas suara yang didengar, frame pacing, atau rasa kontrol di perangkat nyata.
