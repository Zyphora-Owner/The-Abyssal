# Changelog The Abyssal 3.1.0

## Living Ocean Asset & Audio Upgrade

Pembaruan inkremental dari 3.0.0. Fokus utama adalah menghadirkan aset tekstur dan suara lokal yang benar-benar dikemas bersama proyek, lalu menghubungkannya ke material dan gameplay.

### Aset baru yang dikemas
- 24 tekstur WebP PBR dari delapan keluarga material: sand, basalt, coral, kelp, wreck wood, oxidized metal, fish scales, dan bioluminescent tissue.
- Setiap keluarga memiliki albedo 2048×2048, normal 1024×1024, dan roughness 1024×1024. Semua memiliki repeat/seamless metadata.
- 29 file OGG lokal: lima ambience area (reef, kelp, wreck, hadal, cave) serta 24 SFX/varian creature call, termasuk suara pisau, fabricator, build seal, repair tool, alarm oksigen, fin sweep, switch, bite, eating, dan engine start.
- Dua generator aset Python dan satu modul runtime `audio-assets.mjs`.

### Integrasi runtime
- PBR maps diterapkan ke terrain, batuan, kelp, coral, kayu wreck, logam, dan skin fauna.
- Ukuran tekstur runtime dibatasi oleh preset grafis, `deviceMemory` bila ada, dan kemampuan GPU; normal/roughness dibatasi maksimum 1024.
- PBR texture override dipertahankan ketika preset grafis berganti, agar tidak tertimpa atau dibuang ketika membuat ulang tekstur dasar.
- Audio lokal dimuat dan di-decode melalui Web Audio; ambience biome dan gua di-crossfade, master volume mengikuti setting game, serta SFX/fauna menggunakan posisi dunia dan HRTF jika tersedia.
- Fauna memiliki pemetaan jenis panggilan/call profile dan cooldown agar tidak berbunyi terus-menerus.
- Geometri fauna diperhalus; material fish-scale dan bioluminescent tissue digunakan menurut jenis spesies.
- Fan coral memakai cabang tubular melengkung; anemone, sea urchin, starfish, flora resource, dan lampu struktur mendapatkan kanal animasi. Registry dekorasi dibersihkan saat chunk di-unload.

### Dipertahankan
Semua file 3.0.0 tetap ada. Tidak ada file lama yang dihapus. Save schema v11, Android Application ID `com.abyssal.game`, Supabase schema/migrations, kendaraan, inventory, PDA, Fabricator, Lifepod, habitat, gua, fisika, cutscene, dan sistem lama dipertahankan.

### Batasan
Tekstur dibuat secara procedural (bukan fotogrametri), audio OGG disintesis (bukan rekaman lapangan/studio), dan mayoritas model fauna/objek masih procedural geometry, bukan model high-poly bespoke dengan skeletal rig. UI inventory tetap menggunakan ikon 2D. Pengujian otomatis tidak menggantikan pengujian visual/audio WebGL di browser maupun Android fisik.
