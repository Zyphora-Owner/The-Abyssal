# The Abyssal 3.1.0

## Rilis 3.1.0 — Living Ocean Asset & Audio Upgrade

Pembaruan inkremental dari **3.0.0**. Proyek tidak dibangun ulang dari nol. Sistem gameplay, save, backend, struktur Android, dan aset lama dipertahankan.

### Peningkatan aset dan presentasi dunia
- **PBR material lokal:** delapan keluarga material orisinal (`sand`, `basalt`, `coral`, `kelp`, `wreck_wood`, `oxidized_metal`, `fish_scales`, `biolum_tissue`). Setiap keluarga menyertakan albedo WebP 2048², normal 1024², dan roughness 1024². Tekstur dipakai oleh terrain/objek lingkungan/fauna melalui material map yang sesuai.
- **Skalabilitas GPU:** ukuran tekstur runtime disesuaikan menurut preset grafis, `deviceMemory` bila tersedia, dan `MAX_TEXTURE_SIZE`; map PBR dijaga tetap hidup ketika preset grafis diganti.
- **Audio OGG lokal:** 29 file ambience dan SFX orisinal yang disintesis untuk biome, gua, gelembung, sonar, fauna/leviathan, hatch, pickup, scanner, impact/resource, pisau, fabricator, build, repair, alarm oksigen, gerakan fin, switch, gigitan fauna, makan, dan engine start. Tidak memerlukan audio remote. Browser tetap perlu memulai AudioContext setelah gesture pengguna sesuai kebijakan autoplay.
- **Audio spasial:** listener mengikuti kamera, sumber suara fauna/interaksi memakai posisi dunia dan panning HRTF bila didukung, ambience biome/cave melakukan crossfade, dan profil panggilan fauna berbeda untuk beberapa kelompok spesies.
- **Objek laut lebih hidup:** fan coral bercabang, anemone, sea urchin, starfish, flora resource, dan indikator struktur memiliki gerakan/pulse; objek dekorasi dibersihkan saat chunk dibongkar.
- **Fauna:** resolusi geometri procedural ditingkatkan, material kulit ikan memakai tekstur sisik/bioluminesen, dan spesies dekat pemain dapat memicu panggilan yang sesuai profilnya.

### Sistem lama yang dipertahankan
Inventory dan equipment, lima Quick Slots, PDA, Fabricator, Lifepod dan hatch, habitat/building, survival, story/cutscene, fauna, tujuh biome hadal, kedalaman dunia 1.500 m, Pelagic Skimmer/Carrier, Nautilus Exosuit, gua dan collision, fluid physics, kontrol sentuh Android, Supabase, offline mode, save schema v11, Application ID `com.abyssal.game`, serta signing assets historis.

### Batas kualitas yang perlu diketahui
Tekstur PBR pada rilis ini dibuat secara procedural dan merupakan aset lokal nyata, bukan hasil pemindaian fotogrametri. Sebagian besar fauna/objek/struktur masih memakai geometri procedural; bukan semua merupakan file model high-poly dengan skeletal rig artistik khusus. Audio merupakan sintesis OGG orisinal, bukan rekaman lapangan atau rekaman studio. Ikon inventory tetap berupa ikon UI 2D; objek 3D di dunia tidak digantikan oleh ikon tersebut. Pembaruan ini meningkatkan kualitas material, dekorasi, panggilan fauna, dan ambience, tetapi belum berarti setiap aset sudah setara produksi AAA/Subnautica.

### Kompatibilitas dan backend
Tidak ada perubahan save schema atau migration Supabase pada 3.1.0. Application ID tetap `com.abyssal.game`. Jangan menghapus atau mengubah migration lama yang sudah diterapkan. Cakupan multiplayer tetap sesuai implementasi sebelumnya, termasuk event dunia bersama, dan bukan simulasi shared-world penuh untuk seluruh state semua pemain, struktur, resource, fauna, serta kendaraan. Pembaruan 3.1.0 tidak mengubah backend atau protokol multiplayer.

### Verifikasi
Jalankan `npm test` untuk tes regresi dan tes baru material/audio/dekorasi. Hasil build produksi/APK, WebGL pada browser/perangkat, hasil suara yang didengar, performa GPU, uji Android fisik, dan Supabase live harus dilaporkan terpisah; kelulusan unit/static test tidak membuktikan aspek runtime tersebut.

Baca `CHANGELOG_3.1.0_ID.md`, `AUDIT_REPORT_3.1.0_ID.md`, `ASSET_QUALITY_MATRIX_3.1.0_ID.md`, `TEST_RESULTS_3.1.0.txt`, dan `BUILD_DARI_PONSEL_3.1.0.md`.
