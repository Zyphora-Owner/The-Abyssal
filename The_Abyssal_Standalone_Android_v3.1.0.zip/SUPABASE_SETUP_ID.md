# Supabase Setup — The Abyssal 3.1.0

Rilis 3.1.0 tidak menambah tabel, function, policy, ataupun migration Supabase. Sistem akun, room, presence, broadcast, chat, event dunia, dan RLS tetap menggunakan migration append-only dari rilis terdahulu.

## Urutan migration historis

1. `supabase/migrations/202611060001_multiplayer.sql`
2. `supabase/migrations/202611060002_room_recovery.sql`
3. `supabase/migrations/202611070001_shared_world_events.sql`
4. `supabase/migrations/202611070002_deep_world_coordinates.sql`
5. `supabase/migrations/202611080001_hadal_depth_coordinates.sql`

Migration nomor 5 memperluas validasi koordinat struktur bersama hingga wilayah hadal. Migration tersebut bersifat append-only. Jangan mengubah atau menghapus migration yang sudah pernah diterapkan pada project Supabase. Jika project sudah menjalankan kelima migration, tidak ada SQL tambahan khusus untuk 3.1.0.

Tetap konfigurasi `VITE_SUPABASE_URL` dan `VITE_SUPABASE_PUBLISHABLE_KEY` menggunakan Project URL dan publishable key dari Supabase Dashboard milikmu. Jangan pernah memasukkan `service_role` key, secret, atau password database ke dalam kode client.

Multiplayer perlu diuji dengan dua akun dan perangkat nyata. Keberadaan event dunia bersama tidak berarti seluruh dunia otomatis tersinkronisasi; jangan menyebutnya simulasi shared-world penuh apabila yang tersinkronisasi hanya posisi pemain atau chat.

Offline mode tetap dapat digunakan saat backend belum dikonfigurasi atau tidak tersedia.
