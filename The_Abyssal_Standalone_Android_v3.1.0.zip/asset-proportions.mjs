/**
 * Shared, authored proportion guides for The Abyssal's original 3D assets.
 * Values describe silhouette/aspect relationships, not copied game assets.
 * Runtime geometry and collision remain owned by their existing systems.
 */

const freezeDeep = value => {
  if (value && typeof value === 'object' && !Object.isFrozen(value)) {
    Object.values(value).forEach(freezeDeep);
    Object.freeze(value);
  }
  return value;
};

export const FAUNA_VISUAL_PROFILES = freezeDeep({
  reef_deep: { body: 'deep', length: 2.05, width: 0.92, height: 1.08, eyeOffset: 0.34, eyeY: 0.13, headZ: -0.72, tailFork: 0.44, dorsalHeight: 0.58, pectoralSpan: 0.78, bellyScale: [0.72, 0.24, 0.72], stripes: 0 },
  oval_reef: { body: 'oval', length: 1.82, width: 0.88, height: 1.22, eyeOffset: 0.32, eyeY: 0.17, headZ: -0.67, tailFork: 0.38, dorsalHeight: 0.78, pectoralSpan: 0.72, bellyScale: [0.70, 0.20, 0.66], stripes: 0 },
  compressed_reef: { body: 'compressed', length: 1.76, width: 0.68, height: 1.34, eyeOffset: 0.30, eyeY: 0.22, headZ: -0.66, tailFork: 0.32, dorsalHeight: 0.92, pectoralSpan: 0.68, bellyScale: [0.64, 0.18, 0.60], stripes: 2 },
  trigger_reef: { body: 'boxy', length: 1.92, width: 0.94, height: 1.02, eyeOffset: 0.36, eyeY: 0.17, headZ: -0.70, tailFork: 0.30, dorsalHeight: 0.60, pectoralSpan: 0.52, bellyScale: [0.72, 0.19, 0.62], stripes: 0 },
  fusiform: { body: 'fusiform', length: 2.35, width: 0.76, height: 0.74, eyeOffset: 0.30, eyeY: 0.09, headZ: -0.82, tailFork: 0.68, dorsalHeight: 0.43, pectoralSpan: 0.58, bellyScale: [0.62, 0.18, 0.78], stripes: 0 },
  predator: { body: 'predator', length: 2.72, width: 0.62, height: 0.66, eyeOffset: 0.27, eyeY: 0.11, headZ: -0.9, tailFork: 0.72, dorsalHeight: 0.62, pectoralSpan: 0.62, bellyScale: [0.55, 0.16, 0.76], stripes: 0 },
  eel: { body: 'eel', length: 3.25, width: 0.46, height: 0.48, eyeOffset: 0.18, eyeY: 0.10, headZ: -0.92, tailFork: 0.16, dorsalHeight: 0.18, pectoralSpan: 0.24, bellyScale: [0.48, 0.12, 0.85], stripes: 0 },
  puffer: { body: 'puffer', length: 1.62, width: 1.04, height: 1.12, eyeOffset: 0.36, eyeY: 0.18, headZ: -0.68, tailFork: 0.28, dorsalHeight: 0.34, pectoralSpan: 0.50, bellyScale: [0.76, 0.19, 0.58], stripes: 0 },
  angler: { body: 'angler', length: 2.24, width: 1.02, height: 1.0, eyeOffset: 0.38, eyeY: 0.22, headZ: -0.78, tailFork: 0.42, dorsalHeight: 0.5, pectoralSpan: 0.72, bellyScale: [0.78, 0.24, 0.74], stripes: 0 },
  hammerhead: { body: 'fusiform', length: 2.62, width: 0.70, height: 0.70, eyeOffset: 0.66, eyeY: 0.18, headZ: -0.87, tailFork: 0.72, dorsalHeight: 0.66, pectoralSpan: 0.88, bellyScale: [0.64, 0.16, 0.8], stripes: 0 },
  manta: { body: 'manta', length: 2.6, width: 2.9, height: 0.42, eyeOffset: 0.4, eyeY: 0.05, headZ: -0.75, tailFork: 0.2, dorsalHeight: 0.22, pectoralSpan: 2.2, bellyScale: [0.72, 0.1, 0.8], stripes: 0 },
  whale: { body: 'whale', length: 4.7, width: 2.35, height: 1.85, eyeOffset: 0.76, eyeY: 0.18, headZ: -0.76, tailFork: 0.78, dorsalHeight: 0.42, pectoralSpan: 1.05, bellyScale: [0.78, 0.14, 0.72], stripes: 0 },
  squid: { body: 'squid', length: 2.2, width: 1.0, height: 1.1, eyeOffset: 0.34, eyeY: 0.2, headZ: -0.6, tailFork: 0.1, dorsalHeight: 0.22, pectoralSpan: 0.4, bellyScale: [0.75, 0.18, 0.68], stripes: 0 },
  jelly: { body: 'jelly', length: 1.25, width: 1.15, height: 0.95, eyeOffset: 0, eyeY: 0, headZ: 0, tailFork: 0, dorsalHeight: 0, pectoralSpan: 0, bellyScale: [0.7, 0.16, 0.7], stripes: 0 },
  siphonophore: { body: 'jelly', length: 3.2, width: 0.92, height: 2.6, eyeOffset: 0, eyeY: 0, headZ: 0, tailFork: 0, dorsalHeight: 0, pectoralSpan: 0.4, bellyScale: [0.46, 0.12, 0.74], stripes: 0 },
  turtle: { body: 'turtle', length: 2.55, width: 2.0, height: 1.45, eyeOffset: 0.25, eyeY: 0.12, headZ: -0.8, tailFork: 0, dorsalHeight: 0, pectoralSpan: 0.92, bellyScale: [0.68, 0.18, 0.8], stripes: 0 },
  seahorse: { body: 'seahorse', length: 1.55, width: 0.72, height: 1.6, eyeOffset: 0.2, eyeY: 0.2, headZ: -0.2, tailFork: 0, dorsalHeight: 0, pectoralSpan: 0.24, bellyScale: [0.5, 0.14, 0.65], stripes: 0 },
  leviathan: { body: 'leviathan', length: 5.5, width: 2.0, height: 1.76, eyeOffset: 0.58, eyeY: 0.28, headZ: -0.78, tailFork: 0.85, dorsalHeight: 0.92, pectoralSpan: 1.4, bellyScale: [0.82, 0.24, 0.74], stripes: 0 }
});

const fishProfileIds = {
  clownfish: 'reef_deep', blue_tang: 'oval_reef', butterflyfish: 'compressed_reef', angelfish: 'compressed_reef',
  parrotfish: 'reef_deep', lionfish: 'reef_deep', yellowfin_tuna: 'fusiform', barracuda: 'predator',
  seahorse: 'seahorse', pufferfish: 'puffer', moorish_idol: 'compressed_reef', triggerfish: 'trigger_reef',
  moray_eel: 'eel', bioluminescent_angler: 'angler', jellyfish: 'jelly', sea_turtle: 'turtle',
  manta_ray: 'manta', reef_shark: 'predator', hammerhead: 'hammerhead', humpback_whale: 'whale',
  sperm_whale: 'whale', blue_whale: 'whale', orca: 'whale', giant_squid: 'squid',
  abyssal_leviathan: 'leviathan', abyssal_stalker: 'predator', trench_leviathan: 'leviathan',
  glass_shrimp: 'fusiform', ribbon_eel: 'eel', reef_cuttlefish: 'squid', vent_crab: 'reef_deep',
  sulfur_masonfish: 'reef_deep', lantern_fish: 'angler',
  abyssal_glassray: 'manta', void_dragonfish: 'angler', hadal_squid: 'squid',
  trench_stalker: 'predator', hadal_leviathan: 'leviathan', abyssal_skater: 'manta',
  glasswing_ray: 'manta', rift_angler: 'angler', abyssal_siphonophore: 'siphonophore'
};

export function getFaunaVisualProfile(speciesId, kind = 'fish') {
  const profileId = fishProfileIds[String(speciesId || '')] || (kind === 'whale' ? 'whale' : kind === 'leviathan' ? 'leviathan' : 'reef_deep');
  return FAUNA_VISUAL_PROFILES[profileId];
}

export const RESOURCE_VISUAL_PROFILES = freezeDeep({
  titanium: { archetype: 'ingot', worldScale: [0.46, 0.34, 0.62], heldScale: [1.12, 0.92, 1.16], roughness: 0.34, metalness: 0.78 },
  copper: { archetype: 'nodule', worldScale: [0.52, 0.44, 0.50], heldScale: [1.0, 0.94, 1.02], roughness: 0.40, metalness: 0.68 },
  quartz: { archetype: 'crystal', worldScale: [0.40, 0.62, 0.42], heldScale: [0.96, 1.12, 0.92], roughness: 0.16, metalness: 0.06 },
  lithium: { archetype: 'crystal_tall', worldScale: [0.36, 0.78, 0.38], heldScale: [0.90, 1.18, 0.90], roughness: 0.22, metalness: 0.06 },
  sulfur: { archetype: 'crystal_cluster', worldScale: [0.48, 0.62, 0.46], heldScale: [1.0, 1.08, 1.0], roughness: 0.46, metalness: 0.04 },
  magnetite: { archetype: 'iron_nodule', worldScale: [0.58, 0.46, 0.54], heldScale: [1.10, 0.94, 1.05], roughness: 0.27, metalness: 0.9 },
  salt: { archetype: 'cubic_cluster', worldScale: [0.42, 0.34, 0.42], heldScale: [0.95, 0.86, 0.92], roughness: 0.72, metalness: 0.05 },
  silver: { archetype: 'metal_nodule', worldScale: [0.50, 0.42, 0.48], heldScale: [1.04, 0.94, 1.0], roughness: 0.22, metalness: 0.92 },
  coral: { archetype: 'branching_organic', worldScale: [0.52, 0.66, 0.48], heldScale: [0.92, 1.06, 0.96], roughness: 0.84, metalness: 0.04 },
  kelp: { archetype: 'leaf_bundle', worldScale: [0.40, 1.8, 0.42], heldScale: [0.86, 1.15, 0.82], roughness: 0.78, metalness: 0.02 },
  glowcap: { archetype: 'mushroom', worldScale: [0.72, 1.2, 0.72], heldScale: [0.92, 0.96, 0.92], roughness: 0.62, metalness: 0.02 },
  fish_meat: { archetype: 'fillet', worldScale: [0.42, 0.24, 0.72], heldScale: [1.0, 0.92, 1.12], roughness: 0.84, metalness: 0.01 },
  battery: { archetype: 'battery', worldScale: [0.42, 0.78, 0.42], heldScale: [1.0, 1.0, 1.0], roughness: 0.48, metalness: 0.28 },
  power_cell: { archetype: 'power_cell', worldScale: [0.64, 0.82, 0.46], heldScale: [1.06, 1.08, 1.0], roughness: 0.42, metalness: 0.32 },
  glass: { archetype: 'glass_shard', worldScale: [0.46, 0.62, 0.44], heldScale: [0.96, 1.02, 0.94], roughness: 0.14, metalness: 0.05 },
  silicone: { archetype: 'sealed_polymer', worldScale: [0.54, 0.42, 0.48], heldScale: [1.0, 1.0, 1.0], roughness: 0.54, metalness: 0.08 },
  fiber_mesh: { archetype: 'woven_fiber', worldScale: [0.62, 0.45, 0.18], heldScale: [1.0, 0.92, 0.86], roughness: 0.9, metalness: 0.03 },
  wiring_kit: { archetype: 'coiled_wiring', worldScale: [0.48, 0.4, 0.46], heldScale: [1.0, 1.0, 1.0], roughness: 0.34, metalness: 0.72 },
  computer_chip: { archetype: 'circuit_board', worldScale: [0.56, 0.34, 0.46], heldScale: [1.0, 0.92, 1.0], roughness: 0.38, metalness: 0.46 },
  lubricant: { archetype: 'canister', worldScale: [0.4, 0.7, 0.4], heldScale: [1.0, 1.0, 1.0], roughness: 0.54, metalness: 0.12 },
  bleach: { archetype: 'sealed_bottle', worldScale: [0.4, 0.7, 0.4], heldScale: [1.0, 1.0, 1.0], roughness: 0.5, metalness: 0.08 },
  medkit: { archetype: 'medical_case', worldScale: [0.78, 0.48, 0.62], heldScale: [1.0, 1.0, 1.0], roughness: 0.58, metalness: 0.12 },
  ration: { archetype: 'sealed_food_can', worldScale: [0.42, 0.72, 0.42], heldScale: [1.0, 1.0, 1.0], roughness: 0.38, metalness: 0.62 },
  water: { archetype: 'water_bottle', worldScale: [0.42, 0.78, 0.42], heldScale: [1.0, 1.0, 1.0], roughness: 0.16, metalness: 0.08 },
  fish_meat: { archetype: 'fillet', worldScale: [0.42, 0.24, 0.72], heldScale: [1.0, 0.92, 1.12], roughness: 0.84, metalness: 0.01 }
});

export function getResourceVisualProfile(resourceId) {
  return RESOURCE_VISUAL_PROFILES[String(resourceId || '')] || Object.freeze({ archetype: 'faceted_ore', worldScale: [0.52, 0.48, 0.52], heldScale: [1, 1, 1], roughness: 0.66, metalness: 0.12 });
}

// Dimensions mirror the existing authored footprints so visuals do not silently
// invalidate placement/collision/save coordinates.
export const STRUCTURE_DIMENSION_PROFILES = freezeDeep({
  beacon: { width: 0.55, height: 2.9, depth: 0.55 },
  foundation: { width: 7.3, height: 0.52, depth: 7.3 },
  compartment: { width: 8.9, height: 4.8, depth: 8.9 },
  storage_locker: { width: 2.1, height: 2.5, depth: 1.7 },
  solar_array: { width: 4.9, height: 4.3, depth: 1.8 },
  vehicle_bay: { width: 8.8, height: 4.7, depth: 7.2 }
});

export const VEHICLE_VISUAL_PROFILES = freezeDeep({
  skimmer: { length: 4.4, width: 2.45, height: 2.15, hullSections: [[-1,0.05,0.05],[-0.82,0.48,0.45],[-0.48,0.88,0.73],[0.24,1.0,0.82],[0.68,0.66,0.58],[1,0.22,0.2]], panelBands: 3 },
  carrier: { length: 15.5, width: 5.2, height: 5.0, hullSections: [[-1,0.08,0.08],[-0.82,0.62,0.62],[-0.55,0.9,0.88],[0.35,1,1],[0.72,0.88,0.85],[1,0.32,0.32]], panelBands: 5 },
  exosuit: { length: 2.5, width: 2.4, height: 4.6, shoulderWidth: 2.1, torsoHeight: 1.75, legLength: 1.45, panelBands: 3 }
});

export function getStructureDimensions(type) {
  return STRUCTURE_DIMENSION_PROFILES[String(type || '')] || null;
}

export function getVehicleVisualProfile(id) {
  return VEHICLE_VISUAL_PROFILES[String(id || '')] || null;
}

export function isValidProportionProfile(profile) {
  if (!profile || typeof profile !== 'object') return false;
  for (const key of ['length', 'width', 'height']) {
    if (key in profile && (!Number.isFinite(profile[key]) || profile[key] <= 0)) return false;
  }
  for (const key of ['worldScale', 'heldScale']) {
    if (key in profile && (!Array.isArray(profile[key]) || profile[key].length !== 3 || !profile[key].every(value => Number.isFinite(value) && value > 0))) return false;
  }
  for (const key of ['eyeOffset', 'eyeY', 'tailFork', 'dorsalHeight', 'pectoralSpan', 'stripes', 'roughness', 'metalness']) {
    if (key in profile && (!Number.isFinite(profile[key]) || profile[key] < 0)) return false;
  }
  return true;
}
