const AUDIO_URLS = Object.freeze({
  reef: new URL('./assets/audio/ambience_reef.ogg', import.meta.url).href,
  kelp: new URL('./assets/audio/ambience_kelp.ogg', import.meta.url).href,
  wreck: new URL('./assets/audio/ambience_wreck.ogg', import.meta.url).href,
  hadal: new URL('./assets/audio/ambience_hadal.ogg', import.meta.url).href,
  cave: new URL('./assets/audio/ambience_cave.ogg', import.meta.url).href,
  bubbles: new URL('./assets/audio/sfx_bubbles.ogg', import.meta.url).href,
  sonar: new URL('./assets/audio/sfx_sonar.ogg', import.meta.url).href,
  leviathan: new URL('./assets/audio/sfx_leviathan_call.ogg', import.meta.url).href,
  fauna: new URL('./assets/audio/sfx_fauna_chirp.ogg', import.meta.url).href,
  hatch: new URL('./assets/audio/sfx_hatch_servo.ogg', import.meta.url).href,
  pickup: new URL('./assets/audio/sfx_item_pickup.ogg', import.meta.url).href,
  scanner: new URL('./assets/audio/sfx_scanner_sweep.ogg', import.meta.url).href,
  impact: new URL('./assets/audio/sfx_hull_impact.ogg', import.meta.url).href,
  mineral: new URL('./assets/audio/sfx_mineral_strike.ogg', import.meta.url).href,
  whale: new URL('./assets/audio/sfx_whale_song.ogg', import.meta.url).href,
  predator: new URL('./assets/audio/sfx_predator_growl.ogg', import.meta.url).href,
  crustacean: new URL('./assets/audio/sfx_crustacean_click.ogg', import.meta.url).href,
  jelly: new URL('./assets/audio/sfx_jelly_pulse.ogg', import.meta.url).href,
  ray: new URL('./assets/audio/sfx_ray_sweep.ogg', import.meta.url).href,
  knife: new URL('./assets/audio/sfx_knife_swipe.ogg', import.meta.url).href,
  fabricator: new URL('./assets/audio/sfx_fabricator_cycle.ogg', import.meta.url).href,
  build: new URL('./assets/audio/sfx_build_seal.ogg', import.meta.url).href,
  repair: new URL('./assets/audio/sfx_repair_tool.ogg', import.meta.url).href,
  oxygen: new URL('./assets/audio/sfx_oxygen_alarm.ogg', import.meta.url).href,
  fin: new URL('./assets/audio/sfx_fin_sweep.ogg', import.meta.url).href,
  switch: new URL('./assets/audio/sfx_switch_click.ogg', import.meta.url).href,
  bite: new URL('./assets/audio/sfx_creature_bite.ogg', import.meta.url).href,
  eat: new URL('./assets/audio/sfx_eating_gulp.ogg', import.meta.url).href,
  engine: new URL('./assets/audio/sfx_engine_start.ogg', import.meta.url).href
});

const EVENT_ASSETS = Object.freeze({
  collect:'pickup', discovery:'sonar', scan:'scanner', hatch:'hatch', enter:'hatch',
  splash:'bubbles', dive:'fin', impact:'impact', creatureAttack:'bite', faunaHit:'fauna', roar:'leviathan',
  oreHit:'mineral', oreBreak:'mineral', caveDrip:'bubbles', caveScrape:'impact', caveRumble:'impact', oxygen:'oxygen',
  craft:'fabricator', fabricatorOpen:'fabricator', repair:'repair', build:'build', knife:'knife', jump:'fin',
  flashlightOn:'switch', flashlightOff:'switch', light:'switch', tap:'switch', panelOpen:'hatch', panelClose:'hatch',
  locker:'hatch', hologram:'sonar', launch:'engine', reentry:'impact', oxygenPlant:'bubbles', equip:'pickup',
  use:'switch', radio:'whale', eat:'eat', damage:'impact', warp:'sonar'
});
const HADAL_BIOMES = new Set(['deep','abyss','abyssal_shelf','blue_void','hadal_rift','hadal_garden']);

const clamp = (value, min, max) => Math.max(min, Math.min(max, Number.isFinite(value) ? value : min));

/**
 * Local, offline-first decoded audio bank. All files are same-origin and can be
 * cached by the service worker. The procedural synth remains the fallback.
 */
export class AudioAssetBank {
  constructor(context, bus, { masterVolume = 1 } = {}) {
    this.context = context;
    this.bus = bus;
    this.masterVolume = clamp(masterVolume, 0, 1);
    this.buffers = new Map();
    this.loading = null;
    this.biome = 'reef';
    this.caveBlend = 0;
    this.baseLoop = null;
    this.caveLoop = null;
    this.disposed = false;
    this.lastCreatureCallAt = -Infinity;
  }

  load() {
    if (this.loading) return this.loading;
    this.loading = Promise.all(Object.entries(AUDIO_URLS).map(async ([key, url]) => {
      try {
        const response = await fetch(url, { cache: 'force-cache' });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const bytes = await response.arrayBuffer();
        const buffer = await this.context.decodeAudioData(bytes.slice(0));
        if (!this.disposed) this.buffers.set(key, buffer);
        return [key, true];
      } catch (error) {
        return [key, false, error?.message || 'audio unavailable'];
      }
    })).then(results => {
      if (!this.disposed) {
        this.setBiome(this.biome);
        this.setCaveBlend(this.caveBlend);
      }
      return results;
    });
    return this.loading;
  }

  _loop(key, slot, targetVolume, fade = 1.2) {
    const existing = this[slot];
    const buffer = this.buffers.get(key);
    if (!buffer) {
      if (existing?.gain) existing.gain.gain.setTargetAtTime(0, this.context.currentTime, Math.max(.08, fade));
      return;
    }
    if (existing?.key === key && existing.source) {
      existing.targetVolume = targetVolume;
      existing.gain.gain.setTargetAtTime(targetVolume * this.masterVolume, this.context.currentTime, Math.max(.08, fade));
      return;
    }
    const source = this.context.createBufferSource();
    const gain = this.context.createGain();
    source.buffer = buffer;
    source.loop = true;
    source.connect(gain);
    gain.connect(this.bus);
    gain.gain.setValueAtTime(0.0001, this.context.currentTime);
    gain.gain.setTargetAtTime(targetVolume * this.masterVolume, this.context.currentTime, Math.max(.08, fade));
    source.start();
    if (existing?.source) {
      try {
        existing.gain.gain.setTargetAtTime(0.0001, this.context.currentTime, Math.max(.08, fade));
        existing.source.stop(this.context.currentTime + fade * 4.5);
        existing.source.onended = () => { try { existing.source.disconnect(); existing.gain.disconnect(); } catch { /* already disconnected */ } };
      } catch { /* already stopped */ }
    }
    this[slot] = { key, source, gain, targetVolume };
  }

  setBiome(biomeId) {
    this.biome = String(biomeId || 'open');
    let key = 'reef';
    if (this.biome === 'kelp') key = 'kelp';
    else if (this.biome === 'wreck' || this.biome === 'thermal') key = 'wreck';
    else if (this.biome === 'midnight_grotto') key = 'hadal';
    else if (HADAL_BIOMES.has(this.biome)) key = 'hadal';
    this._loop(key, 'baseLoop', .22, 1.8);
  }

  setCaveBlend(value) {
    this.caveBlend = clamp(value, 0, 1);
    this._loop('cave', 'caveLoop', this.caveBlend * .19, .8);
  }

  setMasterVolume(value) {
    this.masterVolume = clamp(value, 0, 1);
    const now = this.context.currentTime;
    for (const loop of [this.baseLoop, this.caveLoop]) {
      if (loop?.gain) loop.gain.gain.setTargetAtTime((loop.targetVolume || 0) * this.masterVolume, now, .12);
    }
  }

  play(key, { volume = .7, playbackRate = 1, position = null, loop = false } = {}) {
    const buffer = this.buffers.get(key);
    if (!buffer || this.disposed || !this.context || this.context.state === 'closed') return false;
    try {
      const source = this.context.createBufferSource();
      const gain = this.context.createGain();
      source.buffer = buffer;
      source.loop = Boolean(loop);
      source.playbackRate.value = clamp(playbackRate, .65, 1.45);
      gain.gain.value = clamp(volume, 0, 1) * this.masterVolume;
      source.connect(gain);
      let tail = gain;
      if (position && typeof position === 'object') {
        const panner = this.context.createPanner();
        panner.panningModel = 'HRTF';
        panner.distanceModel = 'inverse';
        panner.refDistance = 3;
        panner.maxDistance = 75;
        panner.rolloffFactor = 1.1;
        if (panner.positionX) {
          panner.positionX.value = Number(position.x) || 0;
          panner.positionY.value = Number(position.y) || 0;
          panner.positionZ.value = Number(position.z) || 0;
        } else panner.setPosition(Number(position.x) || 0, Number(position.y) || 0, Number(position.z) || 0);
        gain.connect(panner);
        tail = panner;
      }
      tail.connect(this.bus);
      source.start();
      if (!loop) source.onended = () => { try { source.disconnect(); gain.disconnect(); tail !== gain && tail.disconnect(); } catch { /* cleanup */ } };
      return true;
    } catch {
      return false;
    }
  }

  playEvent(eventName, options = {}) {
    const key = EVENT_ASSETS[eventName];
    return key ? this.play(key, { volume: .66, ...options }) : false;
  }

  playCreatureCall(speciesId, position = null) {
    if (!this.context || this.context.currentTime - this.lastCreatureCallAt < 1.15) return false;
    const id = String(speciesId || '').toLowerCase();
    const large = id.includes('whale') || id.includes('leviathan') || id.includes('squid') || id.includes('siphonophore');
    let key = 'fauna';
    if (id.includes('whale')) key = 'whale';
    else if (id.includes('leviathan') || id.includes('squid') || id.includes('siphonophore')) key = 'leviathan';
    else if (id.includes('crab') || id.includes('shrimp') || id.includes('urchin')) key = 'crustacean';
    else if (id.includes('jelly') || id.includes('angler') || id.includes('glow')) key = 'jelly';
    else if (id.includes('ray') || id.includes('manta') || id.includes('turtle')) key = 'ray';
    else if (['shark','barracuda','moray','eel','stalker','predator','dragon','hammerhead'].some(token => id.includes(token))) key = 'predator';
    const volume = large ? .30 : key === 'predator' ? .19 : key === 'ray' ? .15 : key === 'crustacean' ? .11 : .12;
    const rate = large ? .88 : key === 'crustacean' ? 1.02 : .9 + Math.random() * .18;
    const played = this.play(key, { volume, playbackRate:rate, position });
    if (played) this.lastCreatureCallAt = this.context.currentTime;
    return played;
  }

  dispose() {
    this.disposed = true;
    for (const loop of [this.baseLoop, this.caveLoop]) {
      try { loop?.source?.stop(); loop?.source?.disconnect(); loop?.gain?.disconnect(); } catch { /* cleanup */ }
    }
    this.baseLoop = this.caveLoop = null;
    this.buffers.clear();
  }
}

export const AUDIO_ASSET_URLS = AUDIO_URLS;
export const AUDIO_EVENT_ASSETS = EVENT_ASSETS;
