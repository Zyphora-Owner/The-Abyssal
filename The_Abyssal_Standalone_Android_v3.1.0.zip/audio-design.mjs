/** Sound-space profiles for underwater attenuation and cave acoustics. */
const clamp = (value, min, max) => Math.max(min, Math.min(max, Number.isFinite(Number(value)) ? Number(value) : min));
const smooth01 = value => { const t = clamp(value, 0, 1); return t * t * (3 - 2 * t); };

export function getUnderwaterAudioProfile(depth = 0, caveBlend = 0, biomeId = 'open') {
  const safeDepth = clamp(depth, 0, 1500);
  const cave = smooth01(caveBlend);
  const deep = smooth01(safeDepth / 1100);
  const hadal = smooth01((safeDepth - 650) / 850);
  const biomeRumble = ['abyss','abyssal_shelf','midnight_grotto','blue_void','hadal_rift','hadal_garden'].includes(biomeId) ? 1 : 0;
  const lowpassHz = clamp(2600 - deep * 1180 - hadal * 420 - cave * 520, 420, 2800);
  const reverbWet = clamp(0.035 + deep * 0.055 + cave * 0.34, 0.025, 0.44);
  const dryGain = clamp(0.94 - cave * 0.20 - deep * 0.08, 0.58, 0.96);
  const ambienceGain = clamp(0.82 + deep * 0.10 + cave * 0.22 + biomeRumble * 0.05, 0.65, 1.18);
  const reverbSeconds = clamp(0.42 + deep * 0.28 + cave * 1.15, 0.35, 1.85);
  return { lowpassHz, reverbWet, dryGain, ambienceGain, reverbSeconds, caveBlend:cave, depth:safeDepth };
}

export function getCaveSoundCue(caveBlend = 0, elapsedSeconds = 0) {
  const cave = smooth01(caveBlend);
  const time = Math.max(0, Number(elapsedSeconds) || 0);
  return {
    entered: cave >= 0.68,
    dripPulse: cave >= 0.55 ? 0.5 + 0.5 * Math.sin(time * 0.37) : 0,
    muffled: cave >= 0.35
  };
}
