/** Deterministic, traversable underwater cave network shared by terrain, audio and collision. */
const clamp01 = value => Math.max(0, Math.min(1, Number.isFinite(Number(value)) ? Number(value) : 0));
const smooth01 = value => { const t = clamp01(value); return t * t * (3 - 2 * t); };

/**
 * The first three thermal basins retain their historic coordinates and depth
 * profile so existing saves keep the same nearby terrain. The remote network
 * adds genuinely traversable passages at several hadal depth bands.
 */
export const CAVE_NETWORKS = Object.freeze([
  Object.freeze({ id:'thermal-bloom-cavern', x:296, z:-217, depth:9, legacyBasin:true, biome:'thermal', glow:0xffa66b }),
  Object.freeze({ id:'sulfur-pocket-cavern', x:-272, z:246, depth:10, legacyBasin:true, biome:'thermal', glow:0xf4d276 }),
  Object.freeze({ id:'vent-tube-cavern', x:448, z:365, depth:8, legacyBasin:true, biome:'thermal', glow:0x87e3d3 }),
  Object.freeze({ id:'abyssal-shelf-arch', x:1360, z:-620, depth:11, width:7.4, length:38, roofHeight:8.0, chamberRadius:10.5, yaw:0.42, biome:'abyss', glow:0x62b5db }),
  Object.freeze({ id:'midnight-grotto-network', x:1200, z:-500, depth:13, width:8.2, length:46, roofHeight:8.8, chamberRadius:12.5, yaw:-0.68, biome:'midnight_grotto', glow:0x8f8bff }),
  Object.freeze({ id:'hadal-rift-cathedral', x:1080, z:-620, depth:14, width:8.8, length:52, roofHeight:9.5, chamberRadius:14, yaw:1.12, biome:'hadal_rift', glow:0xb99aff }),
  Object.freeze({ id:'hadal-garden-vault', x:1010, z:-620, depth:12, width:7.2, length:36, roofHeight:8.0, chamberRadius:11.5, yaw:-0.22, biome:'hadal_garden', glow:0x8ff6dc })
]);

function samplePassage(x, z, site) {
  const dx = Number(x) - site.x;
  const dz = Number(z) - site.z;
  const yaw = Number(site.yaw) || 0;
  // Match Three.js Y-rotation: passage forward points along local -Z.
  const forward = -dx * Math.sin(yaw) - dz * Math.cos(yaw);
  const lateral = dx * Math.cos(yaw) - dz * Math.sin(yaw);
  const width = Math.max(3, Number(site.width) || 7);
  const length = Math.max(18, Number(site.length) || 36);
  const side = 1 - smooth01((Math.abs(lateral) - width * 0.62) / Math.max(0.1, width * 0.48));
  const entrance = smooth01((forward + 7) / 6);
  const tail = 1 - smooth01((forward - (length - 7)) / 10);
  const passage = side * entrance * tail;
  const chamberRadius = Math.max(width + 2, Number(site.chamberRadius) || 11);
  const chamberCenter = length - 2;
  const chamberDistance = Math.hypot((forward - chamberCenter) / (chamberRadius * 0.92), lateral / chamberRadius);
  const chamber = 1 - smooth01((chamberDistance - 0.56) / 0.44);
  const strength = Math.max(passage, chamber * smooth01((forward - length * 0.56) / 7));
  return { strength: clamp01(strength), forward, lateral, width, length, chamber };
}

/** Localized terrain carve depth in metres. Zero means ordinary seabed. */
export function getCaveCarveProfile(x, z, site) {
  if (!site || !Number.isFinite(Number(x)) || !Number.isFinite(Number(z))) return { strength:0, carveDepth:0, roofHeight:0, site:null };
  if (site.legacyBasin) {
    const distance = Math.hypot(Number(x) - site.x, Number(z) - site.z);
    const strength = 1 - smooth01(distance / 18);
    return { strength, carveDepth:Math.max(0, Number(site.depth) || 0) * strength, roofHeight:0, site };
  }
  const passage = samplePassage(Number(x), Number(z), site);
  return {
    ...passage,
    strength: passage.strength,
    carveDepth: Math.max(0, Number(site.depth) || 0) * passage.strength,
    roofHeight: Math.max(0, Number(site.roofHeight) || 8) * passage.strength,
    site
  };
}

/** Strongest cave influence at a world X/Z location. */
export function getCaveProfileAt(x, z, sites = CAVE_NETWORKS) {
  let best = null;
  for (const site of sites) {
    if (site.legacyBasin) continue;
    const profile = getCaveCarveProfile(x, z, site);
    if (!best || profile.strength > best.strength) best = profile;
  }
  return best && best.strength > 0.025 ? best : null;
}

/**
 * Returns the cave roof world height, given the already-carved seafloor height.
 * A null result means the diver/vehicle is outside a carved cave passage.
 */
export function getCaveCeilingY(x, z, carvedFloorY, sites = CAVE_NETWORKS, minStrength = 0.28) {
  const profile = getCaveProfileAt(x, z, sites);
  if (!profile || profile.strength < minStrength) return null;
  const baseFloor = Number(carvedFloorY) + profile.carveDepth;
  return baseFloor + profile.roofHeight;
}

export function getCaveAudioBlend(x, z, sites = CAVE_NETWORKS) {
  const profile = getCaveProfileAt(x, z, sites);
  return profile ? smooth01((profile.strength - 0.18) / 0.62) : 0;
}

export function isInsideCavePassage(x, z, threshold = 0.62, sites = CAVE_NETWORKS) {
  const profile = getCaveProfileAt(x, z, sites);
  return Boolean(profile && profile.strength >= clamp01(threshold));
}

export function isValidCaveSite(site) {
  if (!site || typeof site.id !== 'string' || !site.id || ![site.x, site.z, site.depth].every(Number.isFinite)) return false;
  if (site.depth <= 0 || site.depth > 30) return false;
  if (site.legacyBasin) return true;
  return [site.width, site.length, site.roofHeight, site.chamberRadius, site.yaw].every(Number.isFinite)
    && site.width >= 4 && site.width <= 12 && site.length >= 20 && site.length <= 80
    && site.roofHeight >= 4 && site.roofHeight <= 15 && site.chamberRadius >= site.width;
}


/**
 * Prevent a diver, vehicle, loose resource or fauna from crossing a cave side
 * wall while already inside the passage. The entrance and rear chamber mouth
 * remain valid exits; the helper only constrains lateral motion between them.
 */
export function constrainCaveHorizontalMotion(fromX, fromZ, toX, toZ, bodyRadius = 0.55, sites = CAVE_NETWORKS) {
  const origin = getCaveProfileAt(fromX, fromZ, sites);
  if (!origin || origin.strength < 0.36 || !origin.site) {
    return { x:Number(toX), z:Number(toZ), blocked:false, site:null };
  }
  const site = origin.site;
  const target = samplePassage(Number(toX), Number(toZ), site);
  const entranceExit = target.forward < -7.4;
  const chamberExit = target.forward > site.length + site.chamberRadius * 0.82;
  if (entranceExit || chamberExit) return { x:Number(toX), z:Number(toZ), blocked:false, site:site.id };

  const radius = clamp01(Number(bodyRadius) / 5) * 5;
  const atChamber = target.forward > site.length - site.chamberRadius * 0.72;
  const wallLimit = atChamber ? site.chamberRadius : site.width;
  const safeLateral = Math.max(0.9, wallLimit - Math.max(0.35, radius) - 0.45);
  const lateral = Math.max(-safeLateral, Math.min(safeLateral, target.lateral));
  const yaw = Number(site.yaw) || 0;
  const x = site.x + lateral * Math.cos(yaw) - target.forward * Math.sin(yaw);
  const z = site.z - lateral * Math.sin(yaw) - target.forward * Math.cos(yaw);
  const blocked = Math.hypot(x - Number(toX), z - Number(toZ)) > 0.001;
  return { x, z, blocked, site:site.id };
}
