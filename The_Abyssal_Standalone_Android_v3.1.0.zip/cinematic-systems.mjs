/**
 * Deterministic intro-cutscene camera and subtitle timeline for The Abyssal.
 * The runtime resolves each shot against live Three.js object transforms.
 * Shot offsets move across each interval to avoid static tripod-like framing.
 */
export const INTRO_CINEMATIC_DURATION = 32.8;
export const INTRO_CINEMATIC_LINES_AT = Object.freeze([0, 5.2, 10.1, 15.4, 21.2, 27.2]);

const clamp01 = value => Math.min(1, Math.max(0, Number(value) || 0));
const easeCinematic = value => {
  const t = clamp01(value);
  return t * t * (3 - 2 * t);
};
const mix3 = (start, end, t) => start.map((value, index) => value + (end[index] - value) * t);

const shot = (
  id, start, end, focus, cameraOffset, targetOffset, fov, follow = 1.35,
  cameraOffsetEnd = cameraOffset, targetOffsetEnd = targetOffset, fovEnd = fov, rollAmplitude = 0
) => Object.freeze({
  id, start, end, focus,
  cameraOffset: Object.freeze(cameraOffset),
  targetOffset: Object.freeze(targetOffset),
  cameraOffsetEnd: Object.freeze(cameraOffsetEnd),
  targetOffsetEnd: Object.freeze(targetOffsetEnd),
  fov, fovEnd, follow, rollAmplitude
});

export const INTRO_CAMERA_SHOTS = Object.freeze([
  shot('orbital-establishing', 0, 5.2, 'earth', [24, 10, 42], [0, 0, 0], 54, 0.92, [19, 8, 36], [0, 0, 0], 52, 0.004),
  shot('transfer-craft', 5.2, 9.3, 'transport', [-17, 8, 22], [0, 0, 0], 50, 1.45, [-13, 6.5, 18], [0, 0.4, -0.4], 48, 0.003),
  shot('capsule-separation', 9.3, 12.5, 'pod', [12, 7, 19], [0, 0, 0], 52, 1.55, [8, 5.5, 15], [0, 0, -0.5], 50, 0.006),
  shot('atmospheric-reentry', 12.5, 18.1, 'pod', [10, 4, 15], [0, -0.25, -0.35], 56, 1.7, [7.5, 3.2, 11.5], [0, -0.35, -0.65], 53, 0.012),
  shot('ocean-impact', 18.1, 20.7, 'pod', [18, 9, 20], [0, -0.35, 0], 54, 1.45, [14, 7, 16], [0, -0.25, -0.6], 51, 0.008),
  shot('leviathan-reveal', 20.7, 27.2, 'attacker', [25, 9, -21], [0, 0, -7.5], 50, 1.2, [19, 7, -16], [0, 0.7, -6], 47, 0.01),
  shot('lifepod-threat-establish', 27.2, INTRO_CINEMATIC_DURATION, 'attacker', [22, 8, 15], [-4, -1, -4.5], 55, 1.0, [17, 6.5, 12], [-3, -0.5, -4], 52, 0.004)
]);

export function getIntroCameraShot(elapsedSeconds = 0) {
  const time = Number.isFinite(Number(elapsedSeconds)) ? Math.max(0, Number(elapsedSeconds)) : 0;
  const selected = INTRO_CAMERA_SHOTS.find(item => time >= item.start && time < item.end)
    || INTRO_CAMERA_SHOTS[INTRO_CAMERA_SHOTS.length - 1];
  const duration = Math.max(0.001, selected.end - selected.start);
  const progress = clamp01((time - selected.start) / duration);
  const eased = easeCinematic(progress);
  return {
    ...selected,
    progress,
    easedProgress: eased,
    cameraOffset: mix3(selected.cameraOffset, selected.cameraOffsetEnd, eased),
    targetOffset: mix3(selected.targetOffset, selected.targetOffsetEnd, eased),
    fov: selected.fov + (selected.fovEnd - selected.fov) * eased,
    roll: Math.sin(progress * Math.PI * 2) * selected.rollAmplitude
  };
}

export function getIntroSubtitleIndex(elapsedSeconds = 0) {
  const time = Number.isFinite(Number(elapsedSeconds)) ? Math.max(0, Number(elapsedSeconds)) : 0;
  for (let index = INTRO_CINEMATIC_LINES_AT.length - 1; index >= 0; index--) {
    if (time >= INTRO_CINEMATIC_LINES_AT[index]) return index;
  }
  return 0;
}

/**
 * Short, deterministic camera/body response for the capsule ocean impact.
 * Values are deliberately bounded so the effect remains readable on mobile.
 */
export function getIntroCinematicEffects(elapsedSeconds = 0) {
  const time = Number.isFinite(Number(elapsedSeconds)) ? Math.max(0, Number(elapsedSeconds)) : 0;
  const impactWindow = Math.max(0, 1 - Math.abs(time - 18.92) / 0.74);
  const impact = easeCinematic(impactWindow);
  const secondary = Math.max(0, 1 - Math.abs(time - 19.42) / 0.48);
  const tail = Math.max(0, 1 - Math.abs(time - 20.05) / 0.36);
  return {
    impact,
    cameraShake: Math.min(0.34, impact * 0.27 + secondary * 0.075 + tail * 0.025),
    impactRoll: Math.sin((time - 18.82) * 13.5) * impact * 0.042,
    fovPunch: Math.min(4.2, impact * 3.1 + secondary * 0.9),
    revealPulse: easeCinematic(Math.max(0, 1 - Math.abs(time - 22.15) / 1.25))
  };
}
