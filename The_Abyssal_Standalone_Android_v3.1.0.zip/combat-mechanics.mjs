/**
 * Stylized, non-realistic game melee timing and aim assistance. It only
 * affects The Abyssal's fictional Survival Knife interaction.
 */
export const KNIFE_ATTACK_PROFILE = Object.freeze({
  duration: 0.54,
  hitFrame: 0.225,
  cooldownMs: 620,
  range: 3.6,
  baseSweepRadius: 0.46,
  leadTime: 0.12,
  damage: 24
});

const finite = (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback;

/** Predict a small forward hand-sweep while preserving player movement. */
export function computeMeleeSweep(origin, direction, velocity = null, options = {}) {
  const ox = finite(origin?.x), oy = finite(origin?.y), oz = finite(origin?.z);
  let dx = finite(direction?.x), dy = finite(direction?.y), dz = finite(direction?.z, -1);
  const directionLength = Math.hypot(dx, dy, dz);
  if (directionLength < 1e-6) { dx = 0; dy = 0; dz = -1; }
  else { dx /= directionLength; dy /= directionLength; dz /= directionLength; }
  const vx = finite(velocity?.x), vy = finite(velocity?.y), vz = finite(velocity?.z);
  const speed = Math.hypot(vx, vy, vz);
  const leadTime = Math.max(0, Math.min(0.18, finite(options.leadTime, KNIFE_ATTACK_PROFILE.leadTime)));
  const range = Math.max(0.5, Math.min(6, finite(options.range, KNIFE_ATTACK_PROFILE.range)));
  const baseRadius = Math.max(0.2, Math.min(0.9, finite(options.radius, KNIFE_ATTACK_PROFILE.baseSweepRadius)));
  const movementRadius = Math.min(0.22, speed * 0.035);
  return Object.freeze({
    origin: Object.freeze({ x: ox + vx * leadTime, y: oy + vy * leadTime * 0.35, z: oz + vz * leadTime }),
    direction: Object.freeze({ x: dx, y: dy, z: dz }),
    range,
    radius: baseRadius + movementRadius,
    leadTime,
    movementSpeed: speed
  });
}
