import * as THREE from 'three';
import { clampFaunaDepth } from './player-mechanics.mjs';
import { MAX_DIVE_DEPTH } from './world-generation.mjs';
import { getFaunaVisualProfile } from './asset-proportions.mjs';
import { computeMeleeSweep, KNIFE_ATTACK_PROFILE } from './combat-mechanics.mjs';
import { sampleOceanCurrent } from './ocean-currents.mjs';

// Stylized low-poly marine life. Shared geometry/materials keep draw calls and memory modest on Android.
const SPECIES = [
  { id:'clownfish', name:'Clownfish', kind:'fish', color:0xf28a38, belly:0xffe6c4, scale:0.52, speed:3.1, depth:[-5,-20], weight:10, schooling:true },
  { id:'blue_tang', name:'Blue Tang', kind:'fish', color:0x2377d8, belly:0xe8d8a8, scale:0.62, speed:3.8, depth:[-4,-22], weight:9, schooling:true },
  { id:'butterflyfish', name:'Butterflyfish', kind:'fish', color:0xf5d34d, belly:0xfff1c7, scale:0.55, speed:2.7, depth:[-4,-18], weight:8, schooling:true },
  { id:'angelfish', name:'Angelfish', kind:'fish', color:0x7a8bd8, belly:0xf2d9a0, scale:0.65, speed:2.6, depth:[-8,-28], weight:7 },
  { id:'parrotfish', name:'Parrotfish', kind:'fish', color:0x36ae9a, belly:0xbfe8d1, scale:0.72, speed:2.2, depth:[-7,-25], weight:7 },
  { id:'lionfish', name:'Lionfish', kind:'fish', color:0xd66b48, belly:0xf3d7c8, scale:0.72, speed:1.9, depth:[-10,-32], weight:5 },
  { id:'yellowfin_tuna', name:'Yellowfin Tuna', kind:'fish', color:0xb9c8d1, belly:0xf4e8ca, scale:0.9, speed:5.3, depth:[-8,-32], weight:5, schooling:true },
  { id:'barracuda', name:'Barracuda', kind:'predator', color:0x8399a0, belly:0xd6e1d9, scale:1.0, speed:4.7, depth:[-12,-35], weight:4, hostile:true, damage:7, aggro:22 },
  { id:'seahorse', name:'Seahorse', kind:'seahorse', color:0xe7b45e, belly:0xffe1a0, scale:0.48, speed:1.15, depth:[-6,-25], weight:4 },
  { id:'pufferfish', name:'Pufferfish', kind:'fish', color:0xdba94c, belly:0xf6df9a, scale:0.62, speed:1.35, depth:[-5,-24], weight:5 },
  { id:'moorish_idol', name:'Moorish Idol', kind:'fish', color:0xe8d8a0, belly:0xf4eee0, scale:0.66, speed:3.0, depth:[-5,-22], weight:4 },
  { id:'triggerfish', name:'Titan Triggerfish', kind:'fish', color:0x3a9b8a, belly:0xc9e2ba, scale:0.78, speed:2.1, depth:[-7,-26], weight:3 },
  { id:'moray_eel', name:'Moray Eel', kind:'fish', color:0x778e51, belly:0xb9c28f, scale:0.86, speed:1.75, depth:[-12,-34], weight:3 },
  { id:'bioluminescent_angler', name:'Bioluminescent Anglerfish', kind:'angler', color:0x344d5c, belly:0x82999a, scale:0.92, speed:1.45, depth:[-70,-235], weight:1.2 },
  { id:'jellyfish', name:'Jellyfish', kind:'jelly', color:0x9f8bea, belly:0xd9d0ff, scale:0.8, speed:0.8, depth:[-10,-155], weight:5 },
  { id:'sea_turtle', name:'Green Sea Turtle', kind:'turtle', color:0x528b68, belly:0xc1aa79, scale:1.0, speed:1.6, depth:[-4,-26], weight:4 },
  { id:'manta_ray', name:'Manta Ray', kind:'manta', color:0x344a61, belly:0x91b7bf, scale:1.55, speed:3.2, depth:[-8,-34], weight:3 },
  { id:'reef_shark', name:'Reef Shark', kind:'shark', color:0x657d8b, belly:0xcbd9d9, scale:1.45, speed:4.2, depth:[-12,-82], weight:3, hostile:true, damage:9, aggro:28 },
  { id:'hammerhead', name:'Hammerhead Shark', kind:'hammerhead', color:0x657b88, belly:0xd1dfda, scale:1.9, speed:4.7, depth:[-18,-112], weight:2, hostile:true, damage:12, aggro:32 },
  { id:'humpback_whale', name:'Humpback Whale', kind:'whale', color:0x425e6b, belly:0x9aafb0, scale:3.2, speed:1.8, depth:[-8,-30], weight:1.4 },
  { id:'sperm_whale', name:'Sperm Whale', kind:'whale', color:0x536b73, belly:0xaabbb7, scale:3.7, speed:1.55, depth:[-22,-168], weight:0.8 },
  { id:'blue_whale', name:'Blue Whale', kind:'whale', color:0x3e7180, belly:0xb2ccca, scale:4.8, speed:1.25, depth:[-12,-37], weight:0.45 },
  { id:'orca', name:'Orca', kind:'whale', color:0x182b37, belly:0xe5eeee, scale:3.25, speed:2.4, depth:[-7,-30], weight:0.7 },
  { id:'giant_squid', name:'Giant Squid', kind:'squid', color:0x966075, belly:0xd2a2a9, scale:2.4, speed:1.7, depth:[-35,-205], weight:0.65 },
  { id:'abyssal_leviathan', name:'Abyssal Leviathan', kind:'leviathan', color:0x172c3b, belly:0x45636c, scale:4.5, speed:3.0, depth:[-150,-420], weight:0.16, hostile:true, damage:22, aggro:58 },
  { id:'abyssal_stalker', name:'Abyssal Stalker', kind:'predator', color:0x26384d, belly:0x526a78, scale:1.85, speed:3.7, depth:[-68,-218], weight:1.1, hostile:true, damage:14, aggro:38 },
  { id:'trench_leviathan', name:'Trench Leviathan', kind:'leviathan', color:0x111f31, belly:0x34495f, scale:6.1, speed:2.35, depth:[-220,-980], weight:0.035, hostile:true, damage:26, aggro:64 },
  { id:'glass_shrimp', name:'Glass Shrimp', kind:'fish', color:0x7dbfc0, belly:0xd1f0e8, scale:0.34, speed:2.4, depth:[-4,-19], weight:5, schooling:true },
  { id:'ribbon_eel', name:'Ribbon Eel', kind:'fish', color:0x7b9a4b, belly:0xb8c78a, scale:0.78, speed:1.85, depth:[-12,-31], weight:3 },
  { id:'reef_cuttlefish', name:'Reef Cuttlefish', kind:'squid', color:0xb46d83, belly:0xe3b5b8, scale:0.95, speed:2.0, depth:[-7,-26], weight:2.4 },
  { id:'vent_crab', name:'Ember Vent Crab', kind:'fish', color:0xc45e42, belly:0xf0a16a, scale:0.62, speed:1.05, depth:[-22,-38], weight:2 },
  { id:'sulfur_masonfish', name:'Sulfur Masonfish', kind:'fish', color:0xd5a52c, belly:0xf3df98, scale:0.64, speed:1.05, depth:[-24,-62], weight:2.2 },
  { id:'lantern_fish', name:'Lanternfish', kind:'angler', color:0x365b7a, belly:0x83cad2, scale:0.55, speed:2.1, depth:[-45,-1450], weight:2.6, schooling:true },
  { id:'abyssal_glassray', name:'Abyssal Glassray', kind:'manta', color:0x638fa9, belly:0xb8d5dc, scale:2.15, speed:2.35, depth:[-500,-980], weight:1.2 },
  { id:'void_dragonfish', name:'Void Dragonfish', kind:'angler', color:0x1d2d48, belly:0x536c82, scale:1.18, speed:2.65, depth:[-700,-1220], weight:0.9, hostile:true, damage:16, aggro:36 },
  { id:'hadal_squid', name:'Hadal Glass Squid', kind:'squid', color:0x536b8a, belly:0x9baec2, scale:3.05, speed:1.8, depth:[-880,-1320], weight:0.5, hostile:true, damage:18, aggro:30 },
  { id:'trench_stalker', name:'Trench Stalker', kind:'predator', color:0x263044, belly:0x64798b, scale:2.2, speed:3.55, depth:[-820,-1370], weight:0.65, hostile:true, damage:21, aggro:48 },
  { id:'hadal_leviathan', name:'Hadal Leviathan', kind:'leviathan', color:0x10182b, belly:0x34445d, scale:7.2, speed:2.05, depth:[-1160,-1490], weight:0.012, hostile:true, damage:32, aggro:76 },
  { id:'abyssal_skater', name:'Abyssal Skater', kind:'manta', color:0x354c72, belly:0x8296b0, scale:2.45, speed:2.0, depth:[-1000,-1435], weight:0.7, schooling:true },
  { id:'glasswing_ray', name:'Glasswing Ray', kind:'manta', color:0x527f9c, belly:0xb3d1d8, scale:1.72, speed:2.25, depth:[-470,-860], weight:1.05, schooling:true },
  { id:'rift_angler', name:'Rift Angler', kind:'angler', color:0x27374d, belly:0x6a8492, scale:1.08, speed:1.7, depth:[-560,-980], weight:0.82, hostile:true, damage:15, aggro:32 },
  { id:'abyssal_siphonophore', name:'Abyssal Siphonophore', kind:'siphonophore', color:0x58658d, belly:0x9badd0, scale:1.42, speed:0.72, depth:[-760,-1390], weight:0.55 }
];

const BIOME_SPECIES = {
  reef:['clownfish','blue_tang','butterflyfish','angelfish','parrotfish','pufferfish','moorish_idol','triggerfish','sea_turtle','manta_ray','glass_shrimp','reef_cuttlefish'],
  kelp:['lionfish','seahorse','moray_eel','jellyfish','barracuda','ribbon_eel','reef_shark','glass_shrimp'],
  wreck:['barracuda','moray_eel','reef_shark','hammerhead','lionfish','ribbon_eel','giant_squid'],
  thermal:['bioluminescent_angler','vent_crab','sulfur_masonfish','lantern_fish','giant_squid','jellyfish'],
  deep:['bioluminescent_angler','sperm_whale','giant_squid','abyssal_stalker','lantern_fish'],
  abyss:['bioluminescent_angler','sperm_whale','giant_squid','abyssal_leviathan','trench_leviathan','lantern_fish'],
  abyssal_shelf:['lantern_fish','abyssal_glassray','trench_leviathan','giant_squid','sperm_whale','glasswing_ray'],
  midnight_grotto:['lantern_fish','void_dragonfish','abyssal_glassray','giant_squid','abyssal_stalker','glasswing_ray','rift_angler','abyssal_siphonophore'],
  blue_void:['void_dragonfish','abyssal_glassray','trench_stalker','hadal_squid','lantern_fish','rift_angler','abyssal_siphonophore'],
  hadal_rift:['trench_stalker','hadal_squid','abyssal_skater','void_dragonfish','trench_leviathan','abyssal_siphonophore'],
  hadal_garden:['hadal_leviathan','abyssal_skater','hadal_squid','void_dragonfish','lantern_fish','abyssal_siphonophore'],
  open:['yellowfin_tuna','manta_ray','humpback_whale','blue_whale','orca','reef_shark','glass_shrimp','hammerhead']
};

const QUALITY_COUNTS = { low: 12, balanced: 20, high: 28, ultra: 32 };

// Distinct readable attack rhythms keep each hostile creature from sharing one generic bite.
const ATTACK_PROFILES = Object.freeze({
  barracuda: Object.freeze({ style:'dart-bite', duration:.88, hitAt:.33, lunge:1.55, range:5.0, cooldown:2.45 }),
  reef_shark: Object.freeze({ style:'surge-bite', duration:1.08, hitAt:.50, lunge:1.65, range:5.8, cooldown:3.1 }),
  hammerhead: Object.freeze({ style:'hammer-ram', duration:1.18, hitAt:.56, lunge:1.85, range:6.15, cooldown:3.5 }),
  abyssal_stalker: Object.freeze({ style:'ambush-bite', duration:1.02, hitAt:.46, lunge:1.75, range:5.9, cooldown:3.1 }),
  trench_stalker: Object.freeze({ style:'ambush-bite', duration:1.12, hitAt:.48, lunge:2.0, range:6.3, cooldown:3.7 }),
  void_dragonfish: Object.freeze({ style:'lure-bite', duration:1.22, hitAt:.59, lunge:1.35, range:5.9, cooldown:3.8 }),
  hadal_squid: Object.freeze({ style:'tentacle-sweep', duration:1.42, hitAt:.78, lunge:1.05, range:6.65, cooldown:4.2 }),
  abyssal_leviathan: Object.freeze({ style:'leviathan-charge', duration:1.48, hitAt:.70, lunge:2.55, range:8.0, cooldown:5.0 }),
  trench_leviathan: Object.freeze({ style:'leviathan-charge', duration:1.56, hitAt:.74, lunge:2.8, range:8.5, cooldown:5.4 }),
  hadal_leviathan: Object.freeze({ style:'hadal-crush', duration:1.68, hitAt:.80, lunge:3.0, range:9.0, cooldown:6.0 })
});
const SULFUR_NEST_SITES = Object.freeze([{x:296,z:-217,y:-42},{x:-272,z:246,y:-46},{x:448,z:365,y:-44}]);
const rand = (a,b) => a + Math.random() * (b-a);
const choose = (items) => items[Math.floor(Math.random() * items.length)];
const clamp = (v,a,b) => Math.max(a,Math.min(b,v));

function makeTaperedBodyGeometry(radialSegments=16, rings=14) {
  const positions=[], uvs=[], indices=[];
  const profile=[[-1,0.08],[-0.82,0.24],[-0.52,0.39],[-0.18,0.48],[0.22,0.44],[0.58,0.34],[0.86,0.21],[1,0.07]];
  for(let r=0;r<rings;r++){
    const t=r/(rings-1), p=t*(profile.length-1), i=Math.min(profile.length-2,Math.floor(p)), f=p-i;
    const z=THREE.MathUtils.lerp(profile[i][0],profile[i+1][0],f);
    const radius=THREE.MathUtils.lerp(profile[i][1],profile[i+1][1],f);
    for(let j=0;j<=radialSegments;j++){
      const a=j/radialSegments*Math.PI*2;
      positions.push(Math.cos(a)*radius,Math.sin(a)*radius,z);
      uvs.push(j/radialSegments,t);
    }
  }
  for(let r=0;r<rings-1;r++) for(let j=0;j<radialSegments;j++){
    const a=r*(radialSegments+1)+j,b=a+1,c=a+radialSegments+1,d=c+1;
    indices.push(a,b,c,b,d,c);
  }
  const geo=new THREE.BufferGeometry(); geo.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
  geo.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2)); geo.setIndex(indices); geo.computeVertexNormals(); return geo;
}

function makeTailFinGeometry() {
  const shape=new THREE.Shape();
  shape.moveTo(0,0); shape.quadraticCurveTo(-0.28,0.38,-0.62,0.66);
  shape.quadraticCurveTo(-0.52,0.27,-0.18,0.16); shape.quadraticCurveTo(0,0.28,0.18,0.16);
  shape.quadraticCurveTo(0.52,0.27,0.62,0.66); shape.quadraticCurveTo(0.28,0.38,0,0);
  return new THREE.ExtrudeGeometry(shape,{depth:0.075,bevelEnabled:true,bevelSegments:1,steps:1,bevelSize:0.025,bevelThickness:0.025});
}

const FISH_BODY_REFERENCE = Object.freeze({
  deep:Object.freeze([.94,1.12]), oval:Object.freeze([.86,1.22]), compressed:Object.freeze([.64,1.24]), boxy:Object.freeze([.94,1.0]),
  fusiform:Object.freeze([.76,.80]), predator:Object.freeze([.68,.64]), eel:Object.freeze([.42,.44]), puffer:Object.freeze([1.04,1.26]), angler:Object.freeze([.98,1.04])
});

const FISH_BODY_STATIONS = Object.freeze({
  deep: Object.freeze([[-1,.035,.045],[-.84,.24,.29],[-.60,.39,.47],[-.22,.47,.56],[.16,.42,.47],[.52,.28,.32],[.82,.13,.16],[1,.025,.035]]),
  oval: Object.freeze([[-1,.025,.035],[-.82,.21,.32],[-.58,.37,.52],[-.2,.43,.61],[.18,.39,.55],[.52,.26,.34],[.84,.11,.18],[1,.02,.03]]),
  compressed: Object.freeze([[-1,.02,.035],[-.82,.15,.28],[-.58,.25,.48],[-.20,.32,.64],[.18,.30,.62],[.52,.21,.43],[.84,.08,.19],[1,.015,.028]]),
  boxy: Object.freeze([[-1,.025,.03],[-.84,.20,.20],[-.60,.36,.38],[-.24,.47,.50],[.18,.46,.49],[.56,.31,.34],[.86,.12,.15],[1,.02,.025]]),
  fusiform: Object.freeze([[-1,.025,.03],[-.82,.18,.19],[-.56,.30,.34],[-.20,.38,.40],[.18,.34,.35],[.55,.23,.25],[.84,.09,.11],[1,.018,.025]]),
  predator: Object.freeze([[-1,.012,.018],[-.86,.13,.12],[-.58,.25,.25],[-.18,.34,.32],[.22,.31,.28],[.58,.19,.18],[.86,.07,.08],[1,.012,.018]]),
  eel: Object.freeze([[-1,.015,.02],[-.82,.13,.13],[-.56,.18,.18],[-.2,.21,.22],[.22,.19,.2],[.58,.15,.16],[.86,.08,.1],[1,.015,.02]]),
  puffer: Object.freeze([[-1,.025,.04],[-.8,.25,.30],[-.55,.43,.52],[-.16,.52,.63],[.22,.49,.58],[.56,.34,.40],[.84,.13,.18],[1,.018,.028]]),
  angler: Object.freeze([[-1,.06,.08],[-.82,.34,.34],[-.58,.49,.52],[-.24,.48,.50],[.18,.36,.34],[.55,.23,.23],[.84,.09,.10],[1,.014,.02]])
});

function makeFishBodyGeometry(form='deep', radialSegments=24, rings=24) {
  const stations=FISH_BODY_STATIONS[form]||FISH_BODY_STATIONS.deep;
  const positions=[],uvs=[],indices=[];
  const sample=t=>{
    const z=-1+t*2,scaled=t*(stations.length-1),i=Math.min(stations.length-2,Math.floor(scaled)),f=scaled-i;
    const a=stations[i],b=stations[i+1];
    return [z,THREE.MathUtils.lerp(a[1],b[1],f),THREE.MathUtils.lerp(a[2],b[2],f)];
  };
  for(let r=0;r<rings;r++){
    const t=r/(rings-1),[z,width,height]=sample(t);
    for(let j=0;j<=radialSegments;j++){
      const angle=j/radialSegments*Math.PI*2;
      const dorsalBias=Math.sin(angle)>0?1.025:0.98;
      positions.push(Math.cos(angle)*width,Math.sin(angle)*height*dorsalBias,z);
      uvs.push(j/radialSegments,t);
    }
  }
  for(let r=0;r<rings-1;r++)for(let j=0;j<radialSegments;j++){
    const a=r*(radialSegments+1)+j,b=a+1,c=a+radialSegments+1,d=c+1;
    indices.push(a,b,c,b,d,c);
  }
  const geometry=new THREE.BufferGeometry();
  geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
  geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));
  geometry.setIndex(indices);geometry.computeVertexNormals();
  return geometry;
}

function makeDorsalFinGeometry() {
  const shape=new THREE.Shape();
  shape.moveTo(-.08,0);shape.quadraticCurveTo(-.02,.28,.38,.76);
  shape.quadraticCurveTo(.34,.34,.20,.12);shape.quadraticCurveTo(.08,.015,-.08,0);
  return new THREE.ExtrudeGeometry(shape,{depth:.035,bevelEnabled:true,bevelSegments:2,steps:1,bevelSize:.018,bevelThickness:.012});
}

function makePectoralFinGeometry() {
  const shape=new THREE.Shape();
  shape.moveTo(-.08,0);shape.quadraticCurveTo(.34,-.035,.92,.36);
  shape.quadraticCurveTo(.56,.34,.22,.21);shape.quadraticCurveTo(.02,.12,-.08,0);
  return new THREE.ExtrudeGeometry(shape,{depth:.028,bevelEnabled:true,bevelSegments:2,steps:1,bevelSize:.014,bevelThickness:.01});
}

export class FaunaDirector {
  constructor(scene, onAttack = () => {}, terrainHeight = () => -300, textureSize = 1024, biomeAt = () => null, caveCeilingAt = () => null, caveMotionResolver = null, onVocalize = () => {}) {
    this.scene = scene;
    this.onAttack = onAttack;
    this.terrainHeight = terrainHeight;
    this.biomeAt = typeof biomeAt === 'function' ? biomeAt : () => null;
    this.caveCeilingAt = typeof caveCeilingAt === 'function' ? caveCeilingAt : () => null;
    this.caveMotionResolver = typeof caveMotionResolver === 'function' ? caveMotionResolver : null;
    this.onVocalize = typeof onVocalize === 'function' ? onVocalize : () => {};
    this.surfaceTextures = { scale:null, bio:null };
    this.animals = [];
    this.spawnSerial = 0;
    this.discovered = new Set();
    this.quality = 'balanced';
    this.currentBiome = 'open';
    this.lastReplenish = 0;
    this.elapsed = 0;
    this.shared = {
      sphere: new THREE.SphereGeometry(1, 24, 16),
      cone: new THREE.ConeGeometry(0.45, 0.85, 12, 6),
      fin: new THREE.ConeGeometry(0.42, 0.9, 9, 4),
      smallSphere: new THREE.SphereGeometry(0.12, 12, 9),
      tentacle: new THREE.CylinderGeometry(0.035, 0.018, 1, 10, 4),
      taperedBody: makeTaperedBodyGeometry(28,22),
      tailFin: makeTailFinGeometry(),
      pectoralFin: new THREE.ConeGeometry(0.18,0.68,10,2),
      fishBodies: Object.fromEntries(Object.keys(FISH_BODY_STATIONS).map(form=>[form,makeFishBodyGeometry(form)])),
      dorsalFin: makeDorsalFinGeometry(),
      pectoralFinDetailed: makePectoralFinGeometry(),
      eyeSocket: new THREE.SphereGeometry(0.105,18,12),
      eye: new THREE.SphereGeometry(0.072,20,14),
      pupil: new THREE.SphereGeometry(0.035,14,10),
      eyeGlint: new THREE.SphereGeometry(0.016,10,8)
    };
    this.materials = new Map();
    this.textureSize = Math.max(512, Number(textureSize) || 1024);
    this.scaleTexture = this.createScaleTexture(this.textureSize);
    this.scaleBumpTexture = this.createScaleBumpTexture(this.textureSize);
    this.turtleShellTexture = this.createTurtleShellTexture(false, this.textureSize);
    this.turtleShellBumpTexture = this.createTurtleShellTexture(true, this.textureSize);
    this.turtleShellMaterial = new THREE.MeshStandardMaterial({ color:0x528b68, map:this.turtleShellTexture, bumpMap:this.turtleShellBumpTexture, bumpScale:0.095, roughness:0.76, metalness:0.025 });
    this.shared.turtleShell = new THREE.SphereGeometry(0.82, 32, 18, 0, Math.PI * 2, 0, Math.PI / 2);
    this.shared.turtleRim = new THREE.TorusGeometry(0.76, 0.075, 8, 36);
  }

  createScaleTexture(size = 512) {
    const canvas = document.createElement('canvas');
    canvas.width = size; canvas.height = size;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Canvas 2D tidak tersedia untuk tekstur fauna');
    ctx.scale(size / 128, size / 128);
    const gradient = ctx.createLinearGradient(0, 0, 0, 128);
    gradient.addColorStop(0, '#ffffff'); gradient.addColorStop(1, '#b9d5d7');
    ctx.fillStyle = gradient; ctx.fillRect(0, 0, 128, 128);
    ctx.strokeStyle = 'rgba(24,58,72,.20)'; ctx.lineWidth = 1;
    for (let row = 0; row < 9; row++) {
      const y = row * 16;
      for (let col = -1; col < 9; col++) {
        const x = col * 16 + (row % 2) * 8;
        ctx.beginPath(); ctx.arc(x, y, 9, 0.12, Math.PI - 0.12); ctx.stroke();
        ctx.beginPath(); ctx.arc(x, y + 2, 6.8, 0.18, Math.PI - 0.18);
        ctx.strokeStyle = 'rgba(255,255,255,.25)'; ctx.stroke();
        ctx.strokeStyle = 'rgba(24,58,72,.20)';
      }
    }
    // Add unique high-frequency scale flecks at the real output resolution so
    // a 2K/4K map contains more detail rather than only being an enlarged 128px tile.
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    const microCount = Math.min(14000, Math.floor(size * size / 1150));
    for (let i = 0; i < microCount; i++) {
      const x = ((i * 16807) % 2147483647) / 2147483647 * size;
      const y = ((i * 48271 + 7919) % 2147483647) / 2147483647 * size;
      const r = Math.max(0.45, size / 2048) * (0.45 + (i % 7) * 0.12);
      ctx.fillStyle = i % 3 === 0 ? 'rgba(255,255,255,.12)' : 'rgba(25,58,72,.075)';
      ctx.beginPath(); ctx.ellipse(x, y, r * 1.8, r, (i % 13) * 0.19, 0, Math.PI * 2); ctx.fill();
    }
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(1.6, 1.2);
    texture.minFilter = THREE.LinearMipmapLinearFilter;
    texture.magFilter = THREE.LinearFilter;
    return texture;
  }

  createTurtleShellTexture(bump = false, size = 512) {
    const canvas=document.createElement('canvas'); canvas.width=canvas.height=size;
    const ctx=canvas.getContext('2d');
    if (!ctx) throw new Error('Canvas 2D tidak tersedia untuk tekstur tempurung kura-kura');
    ctx.scale(size / 512, size / 512);
    const base=ctx.createLinearGradient(0,0,512,512);
    if (bump) {
      base.addColorStop(0,'#a8a8a8'); base.addColorStop(1,'#646464');
    } else {
      base.addColorStop(0,'#9eaa67'); base.addColorStop(.48,'#657c4c'); base.addColorStop(1,'#3c5e43');
    }
    ctx.fillStyle=base; ctx.fillRect(0,0,512,512);
    // Hexagonal scutes with inset growth borders and mottled centres.
    const rows=7, cols=7, cellW=74, cellH=65;
    for(let row=0;row<rows;row++) for(let col=0;col<cols;col++) {
      const cx=col*cellW+(row%2)*cellW*.5+18, cy=row*cellH+24;
      const radius=30 + ((row*17+col*11)%7);
      const points=[];
      for(let k=0;k<6;k++){const a=Math.PI/3*k-Math.PI/6;points.push([cx+Math.cos(a)*radius,cy+Math.sin(a)*radius]);}
      ctx.beginPath(); points.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.closePath();
      if(bump){ctx.fillStyle='#858585';ctx.fill();ctx.strokeStyle='#d7d7d7';ctx.lineWidth=5;ctx.stroke();ctx.strokeStyle='#4c4c4c';ctx.lineWidth=2;ctx.stroke();}
      else {
        const hue=(row*13+col*19)%22;
        ctx.fillStyle=`hsl(${76+hue},${23+(row+col)%15}%,${29+(row*3+col*5)%17}%)`;ctx.fill();
        ctx.strokeStyle='rgba(18,35,23,.72)';ctx.lineWidth=5;ctx.stroke();
        ctx.strokeStyle='rgba(207,194,125,.52)';ctx.lineWidth=2;ctx.stroke();
        ctx.save();ctx.beginPath();ctx.arc(cx,cy,radius*.55,0,Math.PI*2);ctx.strokeStyle='rgba(220,213,157,.16)';ctx.lineWidth=2;ctx.stroke();ctx.restore();
      }
    }
    // Fine scratches and shell mottling break up the repeated scute pattern.
    for(let i=0;i<260;i++){
      const x=(i*137.5)%512,y=(i*83.7)%512,r=1+(i%4);
      ctx.fillStyle=bump?`rgba(220,220,220,${.08+(i%5)*.025})`:`rgba(${i%2?18:205},${i%2?39:190},${i%2?27:114},${.05+(i%5)*.025})`;
      ctx.beginPath();ctx.ellipse(x,y,r*1.7,r,((i%9)-4)*.12,0,Math.PI*2);ctx.fill();
    }
    // Fine shell pits and growth streaks scale with the selected texture preset.
    ctx.setTransform(1,0,0,1,0,0);
    const microCount=Math.min(18000,Math.floor(size*size/950));
    for(let i=0;i<microCount;i++){
      const x=((i*1103515245+12345)>>>0)/4294967296*size;
      const y=((i*2654435761+1013904223)>>>0)/4294967296*size;
      const r=Math.max(.45,size/4096)*(0.35+(i%6)*.16);
      ctx.fillStyle=bump?`rgba(${i%2?224:78},${i%2?224:78},${i%2?224:78},${.045+(i%4)*.018})`:`rgba(${i%2?218:20},${i%2?202:42},${i%2?143:26},${.045+(i%5)*.018})`;
      ctx.beginPath();ctx.ellipse(x,y,r*2.1,r,(i%11)*.21,0,Math.PI*2);ctx.fill();
    }
    const texture=new THREE.CanvasTexture(canvas);
    if(!bump) texture.colorSpace=THREE.SRGBColorSpace;
    texture.wrapS=texture.wrapT=THREE.RepeatWrapping;
    texture.minFilter=THREE.LinearMipmapLinearFilter;texture.magFilter=THREE.LinearFilter;
    texture.generateMipmaps=true;
    return texture;
  }

  createScaleBumpTexture(size = 512) {
    const canvas=document.createElement('canvas'); canvas.width=canvas.height=size;
    const ctx=canvas.getContext('2d');
    if (!ctx) throw new Error('Canvas 2D tidak tersedia untuk bump texture fauna');
    ctx.scale(size / 128, size / 128);
    ctx.fillStyle='#777'; ctx.fillRect(0,0,128,128);
    ctx.strokeStyle='#d0d0d0'; ctx.lineWidth=1.6;
    for(let row=0;row<9;row++) for(let col=-1;col<9;col++) {
      const x=col*16+(row%2)*8, y=row*14;
      ctx.beginPath(); ctx.arc(x,y,8,0.12,Math.PI-0.12); ctx.stroke();
    }
    ctx.setTransform(1,0,0,1,0,0);
    const microCount=Math.min(14000,Math.floor(size*size/1150));
    for(let i=0;i<microCount;i++){
      const x=((i*48271+7919)>>>0)/4294967296*size;
      const y=((i*69621+1237)>>>0)/4294967296*size;
      const v=112+(i%9)*4;
      ctx.fillStyle=`rgba(${v},${v},${v},.16)`;
      ctx.fillRect(x,y,Math.max(.6,size/2048),Math.max(.6,size/2048));
    }
    const tex=new THREE.CanvasTexture(canvas);
    tex.wrapS=tex.wrapT=THREE.RepeatWrapping; tex.repeat.set(1.6,1.2);
    tex.minFilter=THREE.LinearMipmapLinearFilter; tex.magFilter=THREE.LinearFilter;
    return tex;
  }

  setSurfaceTextures(scaleMaps = null, bioMaps = null) {
    this.surfaceTextures = { scale:scaleMaps, bio:bioMaps };
    for (const material of this.materials.values()) {
      const skin = material.userData?.abyssalSkin || 'scale';
      const external = this.surfaceTextures[skin];
      if (!external?.base || !external?.normal || !external?.roughness) continue;
      material.map = external.base;
      material.normalMap = external.normal;
      material.roughnessMap = external.roughness;
      material.bumpMap = null;
      material.normalScale.set(0.72,0.72);
      material.needsUpdate = true;
    }
  }

  setDiscoveries(ids = []) {
    this.discovered = new Set(Array.isArray(ids) ? ids.filter(id => SPECIES.some(s => s.id === id)) : []);
  }
  getDiscoveries() { return [...this.discovered]; }
  getDiscoveryRecords() { return SPECIES.filter(s => this.discovered.has(s.id)).map(s => ({ id:s.id, name:s.name, kind:s.kind, depth:s.depth })); }
  setBiome(id) { this.currentBiome = BIOME_SPECIES[id] ? id : 'open'; }
  getSpeciesCount() { return this.discovered.size; }
  setQuality(value, textureSize = null) {
    this.quality = value in QUALITY_COUNTS ? value : 'balanced';
    const fallbackSize = this.quality === 'low' ? 1024 : 2048;
    const nextSize = Math.max(512, Number(textureSize) || fallbackSize);
    if (nextSize === this.textureSize) return;
    const oldTextures = [this.scaleTexture,this.scaleBumpTexture,this.turtleShellTexture,this.turtleShellBumpTexture];
    this.textureSize = nextSize;
    this.scaleTexture = this.createScaleTexture(nextSize);
    this.scaleBumpTexture = this.createScaleBumpTexture(nextSize);
    this.turtleShellTexture = this.createTurtleShellTexture(false, nextSize);
    this.turtleShellBumpTexture = this.createTurtleShellTexture(true, nextSize);
    for (const material of this.materials.values()) {
      const skin = material.userData?.abyssalSkin || 'scale';
      const external = this.surfaceTextures[skin];
      material.map = external?.base || this.scaleTexture;
      material.normalMap = external?.normal || null;
      material.roughnessMap = external?.roughness || null;
      material.bumpMap = external ? null : this.scaleBumpTexture;
      material.needsUpdate = true;
    }
    this.turtleShellMaterial.map = this.turtleShellTexture;
    this.turtleShellMaterial.bumpMap = this.turtleShellBumpTexture;
    this.turtleShellMaterial.needsUpdate = true;
    for (const texture of new Set(oldTextures)) texture?.dispose();
  }

  /** Remove stale actors when loading or starting another save, then repopulate around that diver. */
  resetPopulation(playerPosition = null) {
    for (const animal of this.animals) this.scene.remove(animal.group);
    this.animals.length=0;
    this.lastReplenish=0;
    if (playerPosition) this.ensurePopulation(playerPosition);
  }

  material(color, options = {}) {
    const skin = options.skin === 'bio' ? 'bio' : 'scale';
    const key = `${color}-${options.emissive || 0}-${options.roughness ?? 0.82}-${skin}`;
    if (!this.materials.has(key)) {
      const external = this.surfaceTextures[skin];
      const material = new THREE.MeshStandardMaterial({
        color, map:external?.base || this.scaleTexture,
        normalMap:external?.normal || null, roughnessMap:external?.roughness || null,
        bumpMap:external ? null : this.scaleBumpTexture, bumpScale:0.045,
        roughness: options.roughness ?? 0.82, metalness: 0.02,
        emissive: options.emissive || 0, emissiveIntensity: options.emissive ? 0.8 : 0
      });
      material.userData.abyssalSkin = skin;
      if (external) material.normalScale.set(0.72,0.72);
      this.materials.set(key, material);
    }
    return this.materials.get(key);
  }
  mesh(geometry, material, group, scale, position) {
    const m = new THREE.Mesh(geometry, material);
    if (scale) m.scale.set(...scale);
    if (position) m.position.set(...position);
    group.add(m);
    return m;
  }

  createModel(species) {
    const root = new THREE.Group();
    const skinKind = ['jelly','siphonophore','angler'].includes(species.kind) ? 'bio' : 'scale';
    const main = this.material(species.color, { skin:skinKind });
    const belly = this.material(species.belly || 0xbad0d0, { skin:skinKind });
    const dark = this.material(0x071a25, { roughness:0.45, skin:skinKind });
    const glow = this.material(0x6ce6e4, { emissive:0x1b8f9b, roughness:0.38, skin:'bio' });
    let tail = null, wings = [], jaw = null;

    if (species.kind === 'jelly') {
      this.mesh(this.shared.sphere, main, root, [0.62,0.48,0.62], [0,0,0]);
      const dome = new THREE.Mesh(this.shared.sphere, glow); dome.scale.set(0.38,0.22,0.38); dome.position.y=0.22; root.add(dome);
      for (let i=0;i<6;i++) {
        const strand = this.mesh(this.shared.tentacle, belly, root, [1,rand(1.2,2.2),1], [Math.cos(i*Math.PI/3)*0.34,-0.95,Math.sin(i*Math.PI/3)*0.34]);
        strand.rotation.z = Math.cos(i*Math.PI/3)*0.14;
        wings.push(strand);
        strand.rotation.x = Math.sin(i*Math.PI/3)*0.14;
      }
    } else if (species.kind === 'siphonophore') {
      // A drifting colonial organism: repeated zooids along a translucent-like
      // central cord, with independent luminous bells and long trailing tentacles.
      const cord = this.mesh(this.shared.tentacle, belly, root, [0.58,2.25,0.58], [0,0.08,0.18]);
      cord.rotation.x = Math.PI / 2.9;
      cord.userData.baseRotationX = cord.rotation.x;
      wings.push(cord);
      for (let segment=0; segment<7; segment++) {
        const z = -0.95 + segment * 0.34;
        const bellScale = 0.17 + (segment % 3) * 0.025;
        const bell = this.mesh(this.shared.sphere, segment % 2 ? main : glow, root,
          [bellScale, bellScale * 1.25, bellScale], [Math.sin(segment * 0.8) * 0.11, 0.06 + Math.cos(segment * 0.65) * 0.08, z]);
        bell.userData.baseY = bell.position.y; wings.push(bell);
        const node = this.mesh(this.shared.smallSphere, glow, root, [0.56,0.56,0.56], [bell.position.x, bell.position.y - 0.04, z - 0.11]);
        node.material = glow;
      }
      for (let tentacle=0; tentacle<8; tentacle++) {
        const angle = tentacle / 8 * Math.PI * 2;
        const strand = this.mesh(this.shared.tentacle, belly, root,
          [0.42, 2.3 + (tentacle % 4) * 0.48, 0.42],
          [Math.cos(angle) * 0.22, -0.68, Math.sin(angle) * 0.22 + 0.14]);
        strand.rotation.x = Math.sin(angle) * 0.22;
        strand.rotation.z = Math.cos(angle) * 0.24;
        strand.userData.baseRotationX = strand.rotation.x;
        strand.userData.baseRotationZ = strand.rotation.z;
        wings.push(strand);
      }
      const float = this.mesh(this.shared.sphere, glow, root, [0.28,0.46,0.28], [0,0.42,-1.16]);
      float.material = glow;
      root.userData.morphologyProfile = getFaunaVisualProfile(species.id, species.kind);
      root.userData.visualDimensions = { length:3.2*species.scale, width:0.92*species.scale, height:2.6*species.scale };
    } else if (species.kind === 'squid') {
      this.mesh(this.shared.sphere, main, root, [0.62,0.72,1.35], [0,0,0.42]);
      this.mesh(this.shared.sphere, belly, root, [0.5,0.52,0.68], [0,-0.18,-0.5]);
      for (const side of [-1,1]) this.mesh(this.shared.smallSphere, glow, root, [1.6,1.6,1.6], [side*0.38,0.1,-0.9]);
      for (let i=0;i<8;i++) {
        const angle=(i/8)*Math.PI*2;
        const arm=this.mesh(this.shared.tentacle, main, root, [1,rand(2.1,3.5),1], [Math.cos(angle)*0.38,-0.62,Math.sin(angle)*0.38-0.55]);
        arm.rotation.z=Math.cos(angle)*0.48; arm.rotation.x=Math.sin(angle)*0.42; wings.push(arm);
      }
      tail=this.mesh(this.shared.cone, main, root, [0.72,1.3,0.72], [0,0,1.55]); tail.rotation.x=-Math.PI/2;
    } else if (species.kind === 'turtle') {
      const shell = new THREE.Mesh(this.shared.turtleShell, this.turtleShellMaterial);
      shell.material.color.setHex(species.color);
      shell.scale.set(0.98,0.74,1.22); shell.position.set(0,0.10,0.03); root.add(shell);
      const rim = new THREE.Mesh(this.shared.turtleRim, this.material(0x485a3d,{roughness:0.92}));
      rim.rotation.x=Math.PI/2; rim.scale.set(1.0,1.22,1); rim.position.set(0,0.08,0.03); root.add(rim);
      const plastron = this.mesh(this.shared.sphere, belly, root, [0.66,0.16,0.91], [0,-0.16,0.04]);
      const neck = this.mesh(this.shared.sphere, main, root, [0.25,0.22,0.42], [0,-0.02,-0.83]);
      neck.rotation.x=-0.08;
      const head = this.mesh(this.shared.sphere, main, root, [0.31,0.27,0.40], [0,0.02,-1.12]);
      head.rotation.x=-0.10;
      const beak=this.mesh(this.shared.cone,belly,root,[0.11,0.18,0.10],[0,-0.08,-1.43]);beak.rotation.x=Math.PI/2;
      for (const side of [-1,1]) {
        const eye=this.mesh(this.shared.smallSphere,dark,root,[0.62,0.62,0.62],[side*0.235,0.12,-1.30]);
        const glint=this.mesh(this.shared.smallSphere,this.material(0xeaf5d8),root,[0.18,0.18,0.18],[side*0.26,0.15,-1.335]);
        for (const front of [-1,1]) {
          const flipper=this.mesh(this.shared.sphere, main, root, [0.24,0.12,0.62], [side*0.72,-0.015,front<0?-0.62:0.67]);
          flipper.rotation.y=side*0.42; flipper.rotation.x=front*0.18; wings.push(flipper);
          // Fine scaly ridges on the flippers create visible anatomy at close range.
          for(let ridge=0;ridge<3;ridge++){
            const line=this.mesh(this.shared.smallSphere,belly,root,[0.08,0.07,0.34],[side*(0.73+ridge*0.025),-0.035,front<0?-0.79+ridge*0.13:0.50+ridge*0.13]);
            line.rotation.y=side*0.42;
          }
        }
      }
      tail=this.mesh(this.shared.cone, main, root, [0.13,0.34,0.13], [0,-0.06,1.02]); tail.rotation.x=Math.PI/2;
    } else if (species.kind === 'manta') {
      this.mesh(this.shared.sphere, main, root, [0.72,0.17,1.2], [0,0,0]);
      this.mesh(this.shared.sphere, belly, root, [0.5,0.09,0.65], [0,-0.12,-0.05]);
      for (const side of [-1,1]) {
        const wing=this.mesh(this.shared.pectoralFinDetailed, main, root, [1.75,.34,1.18], [side*.56,-.015,.04]);
        wing.rotation.z=side*.12;wing.rotation.y=side*.08;wings.push(wing);
        const cephalic=this.mesh(this.shared.sphere,main,root,[.16,.12,.48],[side*.50,.015,-.83]);
        cephalic.rotation.y=side*.28;
      }
      tail=this.mesh(this.shared.cone, main, root, [0.12,1.2,0.12], [0,0,1.35]); tail.rotation.x=Math.PI/2;
    } else if (species.kind === 'whale') {
      this.mesh(this.shared.sphere, main, root, [1.12,0.88,2.2], [0,0,0]);
      this.mesh(this.shared.sphere, belly, root, [0.87,0.25,1.55], [0,-0.61,-0.05]);
      const head = this.mesh(this.shared.sphere, main, root, [1.05,0.72,0.95], [0,0.12,-1.45]);
      head.rotation.x=0.05;
      for (const side of [-1,1]) {
        const flipper=this.mesh(this.shared.sphere, main, root, [0.28,0.13,1.0], [side*0.92,-0.25,-0.1]);
        flipper.rotation.y=side*0.42; flipper.rotation.z=side*0.12; wings.push(flipper);
      }
      const tailFork = new THREE.Group(); tailFork.position.z=2.05; root.add(tailFork);
      for (const side of [-1,1]) {
        const l=this.mesh(this.shared.sphere, main, tailFork, [0.62,0.12,0.55], [side*0.48,0,0.2]);
        l.rotation.y=side*0.4; wings.push(l);
      }
      tail=tailFork;
    } else if (species.kind === 'leviathan') {
      this.mesh(this.shared.sphere, main, root, [1.0,0.88,2.75], [0,0,0]);
      this.mesh(this.shared.sphere, belly, root, [0.83,0.3,1.85], [0,-0.59,-0.1]);
      jaw=this.mesh(this.shared.sphere, belly, root, [0.62,0.2,0.95], [0,-0.52,-1.95]); jaw.rotation.x=-0.15;
      for (const side of [-1,1]) {
        this.mesh(this.shared.smallSphere, glow, root, [1.35,1.35,1.35], [side*0.58,0.28,-2.15]);
        this.mesh(this.shared.sphere, dark, root, [0.12,0.1,0.16], [side*0.67,0.28,-2.28]);
        const fin=this.mesh(this.shared.sphere, main, root, [0.22,0.13,1.3], [side*0.83,-0.2,-0.15]); fin.rotation.y=side*0.45; wings.push(fin);
      }
      for (let i=0;i<8;i++) {
        const spine=this.mesh(this.shared.cone, glow, root, [0.16,rand(0.65,1.0),0.16], [0,0.78,0.95-i*0.42]);
        spine.rotation.x=-Math.PI/7;
      }
      tail=this.mesh(this.shared.cone, main, root, [0.6,1.35,0.5], [0,0.06,2.65]); tail.rotation.x=Math.PI/2;
    } else if (species.kind === 'seahorse') {
      this.mesh(this.shared.sphere, main, root, [0.35,0.7,0.3], [0,0.05,0]);
      const head=this.mesh(this.shared.sphere, main, root, [0.33,0.34,0.42], [0,0.62,-0.1]); head.rotation.x=-0.2;
      const snout=this.mesh(this.shared.cone, main, root, [0.13,0.5,0.13], [0.02,0.55,-0.5]); snout.rotation.x=Math.PI/2;
      const curl=this.mesh(this.shared.cone, main, root, [0.18,0.65,0.18], [0,-0.62,0.2]); curl.rotation.x=-Math.PI/2;
      tail=curl;
    } else if (species.id === 'vent_crab') {
      const carapace=this.mesh(this.shared.sphere,main,root,[.78,.34,.82],[0,.06,.08]);
      const shellRim=this.mesh(this.shared.turtleRim,belly,root,[1.0,1.0,1.0],[0,.05,.08]);shellRim.rotation.x=Math.PI/2;shellRim.scale.set(.78,.84,.72);
      this.mesh(this.shared.sphere,belly,root,[.58,.17,.63],[0,-.20,.1]);
      for(const side of [-1,1]){
        const stalk=this.mesh(this.shared.tentacle,main,root,[1,.56,1],[side*.32,.34,-.38]);stalk.rotation.z=side*.18;
        this.mesh(this.shared.eyeSocket,dark,root,[.85,.85,.85],[side*.34,.58,-.47]);
        this.mesh(this.shared.eye,glow,root,[.62,.62,.62],[side*.35,.59,-.49]);
        this.mesh(this.shared.pupil,dark,root,[1,1,1],[side*.38,.59,-.52]);
        for(let leg=0;leg<4;leg++){
          const pivot=new THREE.Group();pivot.position.set(side*(.48+leg*.035),-.02,.42-(leg*.28));root.add(pivot);
          const upper=this.mesh(this.shared.tentacle,main,pivot,[1,.72,1],[side*.25,-.08,.06]);upper.rotation.z=side*.85;
          const lower=this.mesh(this.shared.tentacle,belly,pivot,[1,.68,1],[side*.47,-.35,.18]);lower.rotation.z=side*-.45;
          wings.push(pivot);
        }
        const clawBase=this.mesh(this.shared.sphere,main,root,[.22,.19,.29],[side*.60,-.12,-.48]);
        const claw=this.mesh(this.shared.cone,main,root,[.28,.20,.28],[side*.76,-.12,-.69]);claw.rotation.z=side*.6;
        const pincer=this.mesh(this.shared.cone,belly,root,[.10,.19,.10],[side*.83,-.20,-.83]);pincer.rotation.z=-side*.75;
      }
      for(let plate=0;plate<5;plate++){
        const ridge=this.mesh(this.shared.smallSphere,belly,root,[.72,.18,.44],[0,.28,.48-plate*.18]);
      }
    } else {
      const form=getFaunaVisualProfile(species.id,species.kind);
      const elongated=['shark','hammerhead','predator'].includes(species.kind);
      const bodyGeometry=this.shared.fishBodies[form.body]||this.shared.taperedBody;
      const bodyLength=form.length/2.05;
      const bodyReference=FISH_BODY_REFERENCE[form.body]||FISH_BODY_REFERENCE.deep;
      const body=this.mesh(bodyGeometry,main,root,[form.width/bodyReference[0],form.height/bodyReference[1],bodyLength],[0,0,0]);
      body.castShadow=true;body.receiveShadow=true;
      root.userData.morphologyProfile=form;
      root.userData.visualDimensions={length:form.length*species.scale,width:form.width*species.scale,height:form.height*species.scale};
      const bellyMesh=this.mesh(this.shared.sphere,belly,root,form.bellyScale,[0,-.22,.02]);
      bellyMesh.material=belly;

      // Side eyes, sockets and highlights make the head direction and anatomy readable at gameplay distance.
      if(species.kind!=='seahorse') for(const side of [-1,1]){
        const eyeX=side*form.eyeOffset;
        this.mesh(this.shared.eyeSocket,dark,root,[.96,.96,1],[eyeX,form.eyeY,form.headZ]);
        this.mesh(this.shared.eye,glow,root,[.78,.78,.78],[eyeX+side*.018,form.eyeY,form.headZ-.018]);
        this.mesh(this.shared.pupil,dark,root,[1,1,1],[eyeX+side*.045,form.eyeY-.004,form.headZ-.04]);
        this.mesh(this.shared.eyeGlint,this.material(0xf2ffff),root,[1,1,1],[eyeX+side*.052,form.eyeY+.024,form.headZ-.052]);
      }
      // Mouth and lower jaw are separated from the body to avoid the featureless sphere-fish look.
      const mouth=this.mesh(this.shared.sphere,dark,root,[.145,.065,.085],[0,-.055,-.925]);
      if(species.id==='parrotfish'){
        const beak=this.mesh(this.shared.sphere,main,root,[.22,.16,.16],[0,-.04,-.96]);beak.rotation.x=-.12;
      }
      if(species.id==='barracuda'){
        for(let tooth=0;tooth<5;tooth++){
          const x=(tooth-2)*.052;
          const upper=this.mesh(this.shared.cone,belly,root,[.035,.12,.035],[x,-.075,-.99]);upper.rotation.x=Math.PI;
        }
      }
      // Gill covers and lateral sensory line are small but visible anatomical breaks behind the head.
      for(const side of [-1,1]){
        const gillPlate=this.mesh(this.shared.sphere,main,root,[.055,.25,.18],[side*(form.eyeOffset*.88),-.02,-.38]);
        gillPlate.rotation.y=side*.1;
        for(let g=0;g<3;g++){
          const slit=this.mesh(this.shared.smallSphere,dark,root,[.16,.62,.46],[side*(form.eyeOffset*.98),-.025,-.43+g*.115]);
          slit.rotation.z=side*.08;
        }
        for(let dot=0;dot<7;dot++){
          const z=-.24+dot*.115;
          this.mesh(this.shared.smallSphere,glow,root,[.16,.14,.16],[side*(form.eyeOffset*.95),.015,z]);
        }
      }
      // Dorsal, anal, pelvic and paired pectoral fins use a swept fin silhouette rather than primitive cones.
      const dorsal=this.mesh(this.shared.dorsalFin,main,root,[1,form.dorsalHeight,1],[0,.29,-.1]);
      dorsal.rotation.x=0.02;
      const secondDorsal=this.mesh(this.shared.dorsalFin,main,root,[.52,form.dorsalHeight*.45,.56],[0,.18,.46]);
      secondDorsal.rotation.z=Math.PI;
      const anal=this.mesh(this.shared.dorsalFin,main,root,[.52,form.dorsalHeight*.42,.64],[0,-.29,.40]);
      anal.rotation.z=Math.PI;
      for(const side of [-1,1]){
        const fin=this.mesh(this.shared.pectoralFinDetailed,main,root,[form.pectoralSpan,.78,1],[side*.34,-.11,-.12]);
        fin.rotation.z=side*.68;fin.rotation.y=side*.16;fin.userData.baseZ=fin.rotation.z;wings.push(fin);
        const pelvic=this.mesh(this.shared.pectoralFinDetailed,main,root,[.36,.42,.58],[side*.19,-.23,.42]);
        pelvic.rotation.z=side*.9;wings.push(pelvic);
      }
      tail=new THREE.Group();tail.position.z=form.length*.48;root.add(tail);
      this.mesh(this.shared.sphere,main,tail,[.105,.105,.34],[0,0,.16]);
      const caudalMaterial=species.id==='blue_tang'?this.material(0xf0d448,{roughness:.56}):species.id==='yellowfin_tuna'?this.material(0xe0b849,{roughness:.48}):main;
      const caudal=new THREE.Mesh(this.shared.tailFin,caudalMaterial);
      caudal.position.set(0,0,.39);caudal.scale.set(1,form.tailFork,1);tail.add(caudal);
      // Species-specific silhouette accents: stripes, dorsal spines, puffer tubercles and deep-sea lure.
      if(['clownfish','butterflyfish','angelfish','moorish_idol'].includes(species.id)){
        const stripeMat=species.id==='clownfish'?belly:this.material(0x263643,{roughness:.74});
        const stripeZ=species.id==='clownfish'?[-.48,.02,.49]:species.id==='moorish_idol'?[-.46,-.08,.30]:[-.34,.28];
        for(const z of stripeZ)for(const side of [-1,1]){
          const stripe=this.mesh(this.shared.sphere,stripeMat,root,[.035,.38,.11],[side*(form.eyeOffset*.98),.005,z]);
          stripe.rotation.z=.02;
        }
      }
      if(species.id==='triggerfish'){
        const lockingSpine=this.mesh(this.shared.cone,belly,root,[.065,.36,.065],[0,.62,-.02]);
        lockingSpine.rotation.x=-.12;
        const cheek=this.mesh(this.shared.sphere,belly,root,[.055,.27,.18],[.30,-.02,-.47]);
        cheek.rotation.y=.18;
      }
      if(species.id==='moorish_idol'){
        const streamer=this.mesh(this.shared.dorsalFin,main,root,[.34,1.32,.62],[0,.47,.10]);
        streamer.rotation.z=.04;
      }
      if(species.id==='blue_tang'){
        const marking=this.mesh(this.shared.sphere,dark,root,[.035,.36,.42],[.34,.05,-.16]);marking.rotation.z=-.14;
        const yellowTail=this.mesh(this.shared.sphere,caudalMaterial,root,[.045,.20,.12],[.0,.02,form.length*.45]);
      }
      if(species.id==='lionfish'){
        for(let spine=0;spine<9;spine++){
          const z=-.58+spine*.14;
          const quill=this.mesh(this.shared.cone,belly,root,[.045,.28+(spine%3)*.06,.045],[0,.47,z]);
          quill.rotation.z=(spine%2?-.25:.25);
        }
        for(const side of [-1,1]) for(let ray=0;ray<4;ray++){
          const rayFin=this.mesh(this.shared.cone,main,root,[.035,.72,.035],[side*(.36+ray*.07),-.06,-.02+ray*.12]);
          rayFin.rotation.z=side*(.85+ray*.12);wings.push(rayFin);
        }
      }
      if(species.id==='pufferfish'){
        for(let spike=0;spike<18;spike++){
          const a=(spike/18)*Math.PI*2,z=(spike%6-2.5)*.24;
          const quill=this.mesh(this.shared.cone,main,root,[.045,.18,.045],[Math.cos(a)*.43,Math.sin(a)*.50,z]);
          quill.rotation.z=Math.cos(a)*.85;quill.rotation.x=Math.sin(a)*.7;
        }
      }
      if(species.id==='sulfur_masonfish'){
        const stripeMat=this.material(0x473a24,{roughness:.78});
        const goldMat=this.material(0xffd75c,{roughness:.56,emissive:0x634514,emissiveIntensity:.26});
        for(let band=0;band<3;band++)for(const side of [-1,1]){
          const stripe=this.mesh(this.shared.sphere,stripeMat,root,[.035,.32,.10],[side*.37,.02,-.48+band*.43]);
          stripe.rotation.x=-.22;
        }
        for(const side of [-1,1])this.mesh(this.shared.smallSphere,goldMat,root,[.8,.8,.8],[side*.3,.16,-.78]);
      }
      if(species.kind==='angler'){
        const stalk=this.mesh(this.shared.tentacle,main,root,[1,.82,1],[0,.70,-.62]);stalk.rotation.x=-.45;
        const lure=this.mesh(this.shared.sphere,glow,root,[.18,.18,.18],[0,1.1,-.93]);
        const lureHalo=this.mesh(this.shared.sphere,glow,root,[.34,.34,.34],[0,1.1,-.93]);lureHalo.material=glow;lureHalo.material.transparent=true;lureHalo.material.opacity=.18;
        if(species.id==='void_dragonfish'){
          jaw=this.mesh(this.shared.sphere,belly,root,[.28,.095,.36],[0,-.19,-.90]);
          for(let tooth=0;tooth<7;tooth++){
            const x=(tooth-3)*.065;
            const fang=this.mesh(this.shared.cone,belly,root,[.035,.16,.035],[x,-.13,-1.02]);fang.rotation.x=Math.PI;
          }
          for(const side of [-1,1]){
            const cheek=this.mesh(this.shared.sphere,main,root,[.16,.18,.24],[side*.20,-.015,-.79]);
            cheek.rotation.z=side*.22;
          }
        }
      }
      if(species.id==='moray_eel'||species.id==='ribbon_eel'){
        const ridge=this.mesh(this.shared.dorsalFin,main,root,[.38,.15,2.55],[0,.18,.06]);
        ridge.rotation.z=0.015;
        for(const side of [-1,1]){
          const pectoral=this.mesh(this.shared.pectoralFinDetailed,main,root,[.28,.34,.42],[side*.20,-.05,-.53]);
          pectoral.rotation.z=side*.88;wings.push(pectoral);
        }
        jaw=this.mesh(this.shared.sphere,belly,root,[.13,.055,.18],[0,-.14,-.88]);
      }
      if(species.id==='hammerhead'){
        const cephalofoilMat=main;
        const cephalofoil=this.mesh(new THREE.BoxGeometry(1.45,.19,.32),cephalofoilMat,root,[1,1,1],[0,form.eyeY,-.78]);
        for(const side of [-1,1]){
          const lobe=this.mesh(this.shared.sphere,main,root,[.22,.115,.18],[side*.66,form.eyeY,-.78]);
          const sensoryPore=this.mesh(this.shared.smallSphere,glow,root,[.42,.42,.42],[side*.68,form.eyeY+.02,-.86]);
        }
      }
      if(species.id==='barracuda'||species.id==='reef_shark'||species.id==='abyssal_stalker'||species.id==='hammerhead'||species.id==='trench_stalker'){
        const snout=this.mesh(this.shared.cone,main,root,[.19,.48,.19],[0,-.015,-.96]);
        snout.rotation.x=-Math.PI/2;
        jaw=this.mesh(this.shared.sphere,belly,root,[.20,.07,.24],[0,-.13,-.90]);
      }
    }
    root.scale.setScalar(species.scale);
    if (jaw) jaw.userData.baseRotationX = jaw.rotation.x;
    return { group:root, tail, wings, jaw, species };
  }

  chooseSpecies(depth, biomeId = this.currentBiome) {
    const habitatIds = BIOME_SPECIES[biomeId] || BIOME_SPECIES.open;
    const depthFits = species => depth <= species.depth[0] && depth >= species.depth[1];
    const localSpecies = SPECIES.filter(species => habitatIds.includes(species.id));
    let pool = localSpecies.filter(depthFits);
    // Prefer the local biome's nearest valid depth range before borrowing an
    // adjacent pelagic species. This prevents reef fish appearing in hadal zones.
    // If a biome's local roster has no species at this exact depth, borrow
    // only depth-compatible pelagic fauna; never force a shallow fish into a
    // deep biome simply because it is the nearest local roster entry.
    if (!pool.length) pool = SPECIES.filter(depthFits);
    if (!pool.length) {
      const distanceToBand = species => depth < species.depth[1] ? species.depth[1] - depth : depth > species.depth[0] ? depth - species.depth[0] : 0;
      const nearestDistance = Math.min(...SPECIES.map(distanceToBand));
      pool = SPECIES.filter(species => distanceToBand(species) <= nearestDistance + 0.001);
    }
    if (!pool.length) pool = SPECIES;
    const total = pool.reduce((sum, species) => sum + species.weight, 0) || pool.length;
    let pick = Math.random() * total;
    for (const species of pool) { pick -= species.weight || 1; if (pick <= 0) return species; }
    return pool[pool.length - 1];
  }

  spawnOne(playerPosition, forceRare = false) {
    const angle=rand(0,Math.PI*2), distance=rand(26,118);
    const x=playerPosition.x+Math.cos(angle)*distance;
    const z=playerPosition.z+Math.sin(angle)*distance;
    let depth=clamp(playerPosition.y-rand(-3,22),-MAX_DIVE_DEPTH+30,-4);
    // Spawn above the real local seabed; never create fauna inside the trench floor
    // or on the far side of a sloping shelf.
    const spawnFloor=this.terrainHeight(x,z);
    depth=clamp(depth, Math.min(-4,spawnFloor+1.4), -4);
    const localBiome = this.biomeAt(x, depth, z)?.id || this.currentBiome;
    let species;
    if (forceRare && depth < -1160 && localBiome === 'hadal_garden' && Math.random()<0.004) species=SPECIES.find(s=>s.id==='hadal_leviathan');
    else if (forceRare && depth < -820 && ['blue_void','hadal_rift','hadal_garden'].includes(localBiome) && Math.random()<0.012) species=SPECIES.find(s=>s.id==='trench_stalker');
    else if (forceRare && depth < -500 && depth > -1000 && Math.random()<0.012) species=SPECIES.find(s=>s.id==='trench_leviathan');
    else if (forceRare && depth < -150 && depth > -500 && Math.random()<0.022) species=SPECIES.find(s=>s.id==='abyssal_leviathan');
    else species=this.chooseSpecies(depth, localBiome);
    let nestPosition = null;
    if (species?.id === 'sulfur_masonfish') {
      const nest = SULFUR_NEST_SITES.reduce((best, site) => {
        const d = Math.hypot(site.x-playerPosition.x, site.z-playerPosition.z);
        return !best || d < best.distance ? {site,distance:d} : best;
      }, null)?.site;
      if (nest) {
        nestPosition = {x:nest.x,y:nest.y,z:nest.z};
        const nestAngle = rand(0,Math.PI*2), nestRadius = rand(3.5,10.5);
        const nx = nest.x + Math.cos(nestAngle)*nestRadius;
        const nz = nest.z + Math.sin(nestAngle)*nestRadius;
        const floor = this.terrainHeight(nx,nz);
        depth = clamp(nest.y + rand(-3,3), Math.min(-4,floor+2), -4);
        const model=this.createModel(species);
        model.group.position.set(nx,depth,nz);
        this.scene.add(model.group);
        this.animals.push({ ...model, instanceId:`${species.id}:${++this.spawnSerial}`, species, nestPosition, velocity:rand(0.55,0.9), direction:nestAngle+Math.PI, phase:rand(0,Math.PI*2), attackCooldown:rand(1,3), roamTimer:rand(1,4), vocalCooldown:rand(12,28) });
        return;
      }
    }
    // Keep giant life at a readable distance so it appears as a discovery, not a surprise collision.
    if (species.kind==='leviathan' || species.kind==='whale') {
      const farAngle=rand(0,Math.PI*2), far=rand(85,150);
      const model=this.createModel(species);
      const farX=playerPosition.x+Math.cos(farAngle)*far;
      const farZ=playerPosition.z+Math.sin(farAngle)*far;
      const farFloor=this.terrainHeight(farX,farZ);
      const farDepth=clamp(depth,Math.min(-4,farFloor+species.scale*0.55+1),-4);
      model.group.position.set(farX,farDepth,farZ);
      this.scene.add(model.group);
      this.animals.push({ ...model, instanceId:`${species.id}:${++this.spawnSerial}`, species, velocity:rand(0.65,1.25), direction:farAngle+Math.PI, phase:rand(0,Math.PI*2), attackCooldown:rand(1,4), roamTimer:rand(2,8), vocalCooldown:rand(12,30) });
      return;
    }
    let spawnX=x, spawnZ=z, spawnDepth=depth;
    if(species.schooling){
      const school=this.animals.filter(animal=>animal.species.id===species.id&&!animal.deathAnimation);
      if(school.length&&Math.random()<.72){
        const leader=choose(school);
        const schoolAngle=rand(0,Math.PI*2),schoolRadius=rand(2.6,7.8);
        spawnX=leader.group.position.x+Math.cos(schoolAngle)*schoolRadius;
        spawnZ=leader.group.position.z+Math.sin(schoolAngle)*schoolRadius;
        const schoolFloor=this.terrainHeight(spawnX,spawnZ);
        spawnDepth=clamp(leader.group.position.y+rand(-1.8,1.8),Math.min(-4,schoolFloor+species.scale*.7+1),-4);
      }
    }
    const model=this.createModel(species);
    model.group.position.set(spawnX,spawnDepth,spawnZ);
    this.scene.add(model.group);
    this.animals.push({ ...model, instanceId:`${species.id}:${++this.spawnSerial}`, species, velocity:rand(0.72,1.3), direction:angle+Math.PI, phase:rand(0,Math.PI*2), attackCooldown:rand(1,3), roamTimer:rand(1,5), vocalCooldown:rand(12,28) });
  }

  ensurePopulation(playerPosition) {
    const radius=this.quality==='low'?165:this.quality==='high'?235:200;
    for (let i=this.animals.length-1;i>=0;i--) {
      const animal=this.animals[i];
      const distance=animal.group.position.distanceTo(playerPosition);
      if (distance>radius+45) {
        this.scene.remove(animal.group);
        this.animals.splice(i,1);
      }
    }
    const target=QUALITY_COUNTS[this.quality] || 20;
    while (this.animals.length>target) {
      const removed=this.animals.pop();
      this.scene.remove(removed.group);
    }
    while (this.animals.length<target) this.spawnOne(playerPosition,true);
  }

  update(dt, playerPosition, biomeId = this.currentBiome) {
    this.elapsed += dt;
    this.setBiome(biomeId);
    this.lastReplenish -= dt;
    if (this.lastReplenish <= 0) { this.lastReplenish = 1.8; this.ensurePopulation(playerPosition); }
    let nearest = null, nearestDistance = Infinity;
    for (let index = this.animals.length - 1; index >= 0; index--) {
      const animal = this.animals[index];
      const species = animal.species;
      const pos = animal.group.position;
      const movementStartX = pos.x, movementStartZ = pos.z;
      // Advance each creature's animation clock exactly once per simulation tick.
      animal.phase += dt * 2.2;

      // Non-graphic hit/death reactions keep attacks readable without gore.
      if (animal.deathAnimation) {
        animal.deathAnimation.elapsed += dt;
        const t = clamp(animal.deathAnimation.elapsed / animal.deathAnimation.duration, 0, 1);
        animal.group.rotation.z = Math.sin(t * Math.PI) * 0.38;
        animal.group.rotation.x = t * 0.22;
        animal.group.scale.setScalar(species.scale * (1 - 0.82 * t));
        if (t >= 1) {
          this.scene.remove(animal.group);
          this.animals.splice(index, 1);
        }
        continue;
      }

      const dx = playerPosition.x - pos.x;
      const dy = playerPosition.y - pos.y;
      const dz = playerPosition.z - pos.z;
      const dist = Math.hypot(dx, dy, dz);
      if (dist < nearestDistance) { nearestDistance = dist; nearest = { species, distance: dist }; }
      animal.vocalCooldown = (animal.vocalCooldown ?? rand(12,28)) - dt;
      if (dist < 34 && animal.vocalCooldown <= 0 && !animal.attackAnimation && !animal.deathAnimation) {
        this.onVocalize(species.id, pos);
        animal.vocalCooldown = rand(species.kind === 'whale' || species.kind === 'leviathan' ? 20 : 13, species.kind === 'whale' || species.kind === 'leviathan' ? 36 : 28);
      }
      animal.roamTimer -= dt;
      const aggro = species.aggro || 0;
      let attackPulse = 0;
      let attackTelegraph = 0;
      let nearbyThreat = null;
      if (!species.hostile && !animal.deathAnimation) {
        let threatDistance = 15 + species.scale * 1.8;
        for (const other of this.animals) {
          if (other === animal || !other.species.hostile || other.deathAnimation) continue;
          const distance = other.group.position.distanceTo(pos);
          if (distance < threatDistance) { threatDistance = distance; nearbyThreat = other; }
        }
      }

      // Telegraph, lunge, contact check, and recovery are separate phases.
      // This makes the attack visible and gives the diver a readable reaction window.
      if (animal.attackAnimation) {
        const attack = animal.attackAnimation;
        attack.elapsed += dt;
        const t = attack.elapsed;
        const lungeStart=attack.hitAt*.34;
        const approach = clamp((t-lungeStart) / Math.max(.001,attack.hitAt-lungeStart), 0, 1);
        const recoil = clamp((t - attack.hitAt) / (attack.duration - attack.hitAt), 0, 1);
        const ease = value => value * value * (3 - 2 * value);
        attackTelegraph=1-clamp(t/lungeStart,0,1);
        const desiredOffset = attack.lungeDistance * (ease(approach) - ease(recoil));
        const offsetDelta = desiredOffset - attack.appliedOffset;
        pos.x += attack.dirX * offsetDelta;
        pos.y += attack.dirY * offsetDelta * 0.30;
        pos.z += attack.dirZ * offsetDelta;
        attack.appliedOffset = desiredOffset;
        attackPulse = Math.max(0, 1 - Math.abs(t - attack.hitAt) / 0.34);

        const faceYaw = Math.atan2(attack.dirX, -attack.dirZ);
        let yawDiff = faceYaw - animal.group.rotation.y;
        while (yawDiff > Math.PI) yawDiff -= Math.PI * 2;
        while (yawDiff < -Math.PI) yawDiff += Math.PI * 2;
        animal.group.rotation.y += yawDiff * Math.min(1, dt * 8);
        if(attack.style==='hammer-ram'||attack.style==='leviathan-charge'||attack.style==='hadal-crush') animal.group.rotation.x=-attackTelegraph*.10+attackPulse*.045;
        else if(attack.style==='tentacle-sweep') animal.group.rotation.x=attackTelegraph*.035;

        if (!attack.hitApplied && t >= attack.hitAt) {
          attack.hitApplied = true;
          const toPlayer = playerPosition.clone().sub(pos);
          const contactDistance = toPlayer.length();
          const facingDot = contactDistance > 0.001 ? toPlayer.normalize().dot(new THREE.Vector3(attack.dirX, attack.dirY, attack.dirZ)) : 1;
          if (contactDistance <= attack.range && facingDot >= 0.34) this.onAttack(species.damage || 8, species.name);
        }
        if (t >= attack.duration) animal.attackAnimation = null;
      } else if (species.hostile && dist < aggro && dist > 4.5) {
        animal.group.rotation.x += (0-animal.group.rotation.x)*Math.min(1,dt*3.2);
        const desired = Math.atan2(-dx, -dz);
        let diff = desired - animal.group.rotation.y;
        while (diff > Math.PI) diff -= Math.PI * 2;
        while (diff < -Math.PI) diff += Math.PI * 2;
        animal.group.rotation.y += diff * Math.min(1, dt * 1.6);
        animal.direction = animal.group.rotation.y;
        const speed = species.kind === 'leviathan' ? species.speed : species.speed * 0.78;
        pos.x += Math.sin(animal.direction) * speed * dt;
        pos.z -= Math.cos(animal.direction) * speed * dt;
        pos.y += clamp(dy, -4, 4) * 0.22 * dt;
      } else {
        animal.group.rotation.x += (0-animal.group.rotation.x)*Math.min(1,dt*3.2);
        if (nearbyThreat) {
          const awayX = pos.x - nearbyThreat.group.position.x;
          const awayZ = pos.z - nearbyThreat.group.position.z;
          const awayLength = Math.max(0.001, Math.hypot(awayX, awayZ));
          animal.direction = Math.atan2(awayX / awayLength, -awayZ / awayLength);
          animal.fleeTimer = Math.max(animal.fleeTimer || 0, 1.05);
          animal.fleeTimer = Math.max(0, animal.fleeTimer - dt);
          animal.group.rotation.x = Math.max(-0.18, Math.min(0.18, (nearbyThreat.group.position.y - pos.y) * -0.018));
          const fleeSpeed = species.speed * Math.max(1.35, animal.velocity * 1.45);
          pos.x += Math.sin(animal.direction) * fleeSpeed * dt;
          pos.z -= Math.cos(animal.direction) * fleeSpeed * dt;
          pos.y += Math.max(-1.4, Math.min(1.4, pos.y - nearbyThreat.group.position.y)) * 0.12 * dt;
          animal.behaviorState = 'flee';
        } else if ((animal.fleeTimer || 0) > 0) {
          animal.fleeTimer = Math.max(0, animal.fleeTimer - dt);
          const fleeSpeed = species.speed * Math.max(1.12, animal.velocity * 1.18);
          pos.x += Math.sin(animal.direction) * fleeSpeed * dt;
          pos.z -= Math.cos(animal.direction) * fleeSpeed * dt;
          animal.behaviorState = 'flee';
        } else if (animal.nestPosition) {
          animal.behaviorState = 'nest';
          const homeDX = animal.nestPosition.x - pos.x, homeDZ = animal.nestPosition.z - pos.z;
          const homeDistance = Math.hypot(homeDX, homeDZ);
          if (homeDistance > 8) { animal.direction = Math.atan2(homeDX, -homeDZ); animal.roamTimer = 0.9; }
          else if (animal.roamTimer <= 0) { animal.direction += rand(-0.45, 0.45); animal.roamTimer = rand(2.0, 3.8); }
          animal.nestActivity = (animal.nestActivity || 0) + dt;
          animal.nestPulse = 0.5 + 0.5 * Math.sin(animal.nestActivity * 1.4);
        } else if (animal.roamTimer <= 0) { animal.direction += rand(-0.85, 0.85); animal.roamTimer = rand(2.5, 7); }
        if (!nearbyThreat && !(animal.fleeTimer > 0)) animal.behaviorState = 'roam';
        if(species.schooling&&!species.hostile&&!nearbyThreat&&(animal.fleeTimer||0)<=0){
          let centerX=0,centerZ=0,neighbors=0,sepX=0,sepZ=0;
          for(const other of this.animals){
            if(other===animal||other.species.id!==species.id||other.deathAnimation)continue;
            const ox=other.group.position.x-pos.x,oz=other.group.position.z-pos.z,od=Math.hypot(ox,oz);
            if(od>13)continue;
            centerX+=other.group.position.x;centerZ+=other.group.position.z;neighbors++;
            if(od<3.4&&od>.001){sepX-=ox/od*(3.4-od);sepZ-=oz/od*(3.4-od);}
          }
          if(neighbors){
            centerX/=neighbors;centerZ/=neighbors;
            const cohesionX=centerX-pos.x,cohesionZ=centerZ-pos.z;
            const schoolX=cohesionX*.38+sepX*.62,schoolZ=cohesionZ*.38+sepZ*.62;
            const heading=Math.hypot(schoolX,schoolZ)>.01?Math.atan2(schoolX,-schoolZ):animal.direction;
            let schoolDiff=heading-animal.direction;
            while(schoolDiff>Math.PI)schoolDiff-=Math.PI*2;
            while(schoolDiff< -Math.PI)schoolDiff+=Math.PI*2;
            animal.direction+=schoolDiff*Math.min(1,dt*.85);
          }
        }
        const targetYaw = animal.direction;
        animal.group.rotation.y += ((targetYaw - animal.group.rotation.y + Math.PI * 3) % (Math.PI * 2) - Math.PI) * Math.min(1, dt * 1.2);
        const speed = species.speed * animal.velocity;
        pos.x += Math.sin(animal.direction) * speed * dt;
        pos.z -= Math.cos(animal.direction) * speed * dt;
        if (animal.nestPosition) {
          const homeDistance = Math.hypot(animal.nestPosition.x - pos.x, animal.nestPosition.z - pos.z);
          if (homeDistance > 9) { pos.x += (animal.nestPosition.x - pos.x) * Math.min(1, dt * 1.15); pos.z += (animal.nestPosition.z - pos.z) * Math.min(1, dt * 1.15); }
        }
        if (species.kind === 'jelly' || species.kind === 'siphonophore' || species.kind === 'whale' || species.kind === 'leviathan') pos.y += Math.sin(animal.phase * (species.kind === 'siphonophore' ? 0.42 : 0.7)) * dt * (species.kind === 'jelly' ? 1.2 : species.kind === 'siphonophore' ? 0.62 : 0.35);
        else pos.y += Math.sin(animal.phase * 1.15) * dt * 0.22;
      }

      // Hostile fauna attacks while the diver is moving; no player movement lock is applied.
      const currentDistance = pos.distanceTo(playerPosition);
      if (!animal.attackAnimation && species.hostile && currentDistance <= (4.9 + species.scale * 0.2) && animal.attackCooldown <= 0) {
        const length = Math.max(0.001, currentDistance);
        const dirX = (playerPosition.x - pos.x) / length;
        const dirY = clamp((playerPosition.y - pos.y) / length, -0.25, 0.25);
        const dirZ = (playerPosition.z - pos.z) / length;
        const profile=ATTACK_PROFILES[species.id] || (species.kind==='leviathan'
          ? {style:'leviathan-charge',duration:1.4,hitAt:.66,lunge:2.25,range:7.8,cooldown:4.8}
          : {style:'surge-bite',duration:1.0,hitAt:.44,lunge:1.25,range:5.4,cooldown:3.0});
        animal.attackAnimation = {
          style:profile.style, elapsed:0, duration:profile.duration, hitAt:profile.hitAt,
          lungeDistance:profile.lunge, range:profile.range,
          dirX, dirY, dirZ, appliedOffset:0, hitApplied:false
        };
        animal.attackCooldown = profile.cooldown;
      } else if (!animal.attackAnimation) animal.attackCooldown = Math.max(0, animal.attackCooldown - dt);

      const wave = Math.sin(animal.phase) * 0.19;
      if (animal.tail && animal.tail.rotation) {
        const attackTailKick=animal.attackAnimation?(attackTelegraph*-.12+attackPulse*(animal.attackAnimation.style==='hadal-crush'?.34:.22)):0;
        animal.tail.rotation.y = wave * 1.55 + attackTailKick;
        if (species.kind === 'whale') animal.tail.rotation.x = Math.sin(animal.phase * 0.65) * 0.13;
      }
      if (species.kind === 'manta' && animal.wings.length) {
        const mantaAttack=attackTelegraph*.22+attackPulse*.16;
        animal.wings[0].rotation.z = Math.sin(animal.phase) * (0.25 + attackPulse * 0.13) + 0.1 + mantaAttack;
        animal.wings[1].rotation.z = -Math.sin(animal.phase) * (0.25 + attackPulse * 0.13) - 0.1 - mantaAttack;
      } else if (species.kind === 'whale') {
        for (let i = 0; i < Math.min(2, animal.wings.length); i++) animal.wings[i].rotation.x = Math.sin(animal.phase * 0.75 + i) * 0.08;
      } else if (species.kind === 'turtle') {
        animal.wings.forEach((fin, i) => { fin.rotation.x = Math.sin(animal.phase * 1.8 + i) * 0.22; fin.rotation.z = Math.sin(animal.phase * 1.2 + i) * 0.12; });
      } else if (species.kind === 'squid') {
        animal.wings.forEach((arm, i) => { const tentacleSweep=(animal.attackAnimation?.style==='tentacle-sweep'?attackTelegraph*.30+attackPulse*.42:attackPulse*.14); arm.rotation.x = Math.sin(animal.phase * 1.35 + i * 0.8) * 0.12 - tentacleSweep; arm.rotation.z = Math.cos(animal.phase * 1.15 + i * 0.7) * 0.15 + Math.sin(i * 0.7) * attackPulse * (animal.attackAnimation?.style==='tentacle-sweep'?.42:.18); });
      } else if (species.kind === 'jelly') {
        const pulse = 1 + Math.sin(animal.phase * 1.8) * 0.09;
        animal.group.scale.setScalar(species.scale * pulse);
      } else if (species.kind === 'siphonophore') {
        animal.wings.forEach((part, i) => {
          if (i === 0) { part.rotation.x = (part.userData.baseRotationX || Math.PI / 2.9) + Math.sin(animal.phase * 0.6) * 0.06; return; }
          if (part.userData.baseY !== undefined) { part.position.y = part.userData.baseY + Math.sin(animal.phase * 1.25 + i * 0.48) * 0.045; return; }
          part.rotation.x = (part.userData.baseRotationX || 0) + Math.sin(animal.phase * 0.8 + i) * 0.18;
          part.rotation.z = (part.userData.baseRotationZ || 0) + Math.cos(animal.phase * 0.65 + i * 0.7) * 0.16;
        });
      } else if (animal.wings.length) {
        animal.wings.forEach((fin, i) => { fin.rotation.z = (fin.userData.baseZ || 0) + Math.sin(animal.phase * 1.25 + i * 0.9) * 0.075 * (i % 2 ? 1 : -1) + attackPulse * 0.09; });
      }
      if (animal.jaw) animal.jaw.rotation.x = (animal.jaw.userData.baseRotationX || 0) - attackPulse * (animal.attackAnimation?.style==='hadal-crush'?.72:.48) - attackTelegraph*.13;
      if (animal.hitReact) {
        animal.hitReact.elapsed += dt;
        const hitT = clamp(animal.hitReact.elapsed / animal.hitReact.duration, 0, 1);
        const recoilPulse=Math.sin(hitT*Math.PI);
        const knockback = (1 - hitT) * (1 - hitT);
        if (animal.hitReact.pushX || animal.hitReact.pushZ) {
          pos.x += (animal.hitReact.pushX || 0) * knockback * dt;
          pos.z += (animal.hitReact.pushZ || 0) * knockback * dt;
        }
        animal.group.rotation.z = recoilPulse * 0.2;
        animal.group.scale.setScalar(species.scale * (1 + recoilPulse * 0.08));
        if(animal.tail?.rotation)animal.tail.rotation.y=wave*1.55+(animal.hitReact.direction||1)*recoilPulse*.18;
        if(animal.jaw)animal.jaw.rotation.x=(animal.jaw.userData.baseRotationX||0)+recoilPulse*.24;
        if (hitT >= 1) animal.hitReact = null;
      }

      // Marine life passively rides the same coherent water mass as floating
      // debris. Active swimmers resist it more strongly than gelatinous fauna.
      const localBiome=this.biomeAt(pos.x,pos.y,pos.z)?.id||this.currentBiome;
      const flow=sampleOceanCurrent(pos.x,pos.y,pos.z,this.elapsed,localBiome);
      const flowResponse=species.kind==='jelly'||species.kind==='siphonophore' ? .42
        : species.kind==='whale'||species.kind==='leviathan' ? .12
        : species.hostile ? .055 : .095;
      pos.x+=flow.x*flowResponse*dt;
      pos.y+=flow.y*flowResponse*dt;
      pos.z+=flow.z*flowResponse*dt;

      const seabed = this.terrainHeight(pos.x, pos.z);
      const clearance = Math.max(1.0, species.scale * 0.52);
      pos.y = clampFaunaDepth(pos.y, seabed, clearance, species.depth);
      // Caves are enclosed spaces: small fauna can swim through them, but
      // cannot clip through the roof or side walls. Oversized fauna remain out.
      if (species.scale <= 4.4 && this.caveMotionResolver) {
        const caveMove = this.caveMotionResolver(movementStartX, movementStartZ, pos.x, pos.z, Math.max(0.45, species.scale * 0.36));
        if (caveMove?.blocked) { pos.x = caveMove.x; pos.z = caveMove.z; pos.y = clampFaunaDepth(pos.y, this.terrainHeight(pos.x,pos.z), clearance, species.depth); }
      }
      if (species.scale <= 4.4) {
        const caveCeiling = this.caveCeilingAt(pos.x, pos.z);
        if (Number.isFinite(caveCeiling)) pos.y = Math.min(pos.y, caveCeiling - Math.max(0.7, species.scale * 0.55));
      }
    }
    return {
      count: this.animals.length,
      nearest: nearest && nearestDistance < 95 ? nearest : null,
      threat: this.animals.filter(a => a.species.hostile && !a.deathAnimation).reduce((best, a) => { const d = a.group.position.distanceTo(playerPosition); return d < (best?.distance ?? Infinity) ? { name: a.species.name, distance: d } : best; }, null)
    };
  }

  resolvePlayerCollision(position) {
    // Large fauna have a soft body boundary; small fish remain non-blocking to preserve flow.
    for (const animal of this.animals) {
      const species=animal.species;
      if (species.scale < 1.35 && species.kind !== 'leviathan') continue;
      const dx=position.x-animal.group.position.x;
      const dz=position.z-animal.group.position.z;
      const distance=Math.hypot(dx,dz) || 0.001;
      const radius=Math.max(1.05,species.scale*0.48+0.7);
      if (distance < radius && Math.abs(position.y-animal.group.position.y) < species.scale*0.72+1.2) {
        const push=(radius-distance)*0.72;
        position.x += dx/distance*push;
        position.z += dz/distance*push;
      }
    }
  }

  /** Non-mutating, movement-aware melee sweep used by both HUD aim and hit resolution. */
  getAttackTarget(playerPosition, origin, direction, range = KNIFE_ATTACK_PROFILE.range, options = {}) {
    const sweep = computeMeleeSweep(origin, direction, options.playerVelocity, {
      range,
      radius: options.sweepRadius ?? KNIFE_ATTACK_PROFILE.baseSweepRadius,
      leadTime: options.leadTime ?? KNIFE_ATTACK_PROFILE.leadTime
    });
    const aimOrigin = new THREE.Vector3(sweep.origin.x, sweep.origin.y, sweep.origin.z);
    const aimDirection = new THREE.Vector3(sweep.direction.x, sweep.direction.y, sweep.direction.z);
    let best = null;
    let bestScore = -Infinity;
    for (const animal of this.animals) {
      if (animal.deathAnimation) continue;
      const species = animal.species;
      const predicted = animal.group.position.clone();
      const animalSpeed = Math.max(0, species.speed * (animal.velocity || 1));
      predicted.x += Math.sin(animal.direction || 0) * animalSpeed * sweep.leadTime * 0.52;
      predicted.z -= Math.cos(animal.direction || 0) * animalSpeed * sweep.leadTime * 0.52;
      const offset = predicted.sub(aimOrigin);
      const along = offset.dot(aimDirection);
      if (along < 0.12 || along > sweep.range + species.scale * 0.32) continue;
      const lateralVector = offset.addScaledVector(aimDirection, -along);
      const lateralDistance = lateralVector.length();
      const hitRadius = sweep.radius + Math.min(0.68, species.scale * 0.19);
      if (lateralDistance > hitRadius) continue;
      const score = 1 - along / (sweep.range + species.scale * 0.32) - lateralDistance * 0.55;
      if (score > bestScore) { best = animal; bestScore = score; }
    }
    if (!best) return null;
    return { instanceId:best.instanceId, id:best.species.id, name:best.species.name, distance:best.group.position.distanceTo(playerPosition), position:best.group.position.clone(), hostile:Boolean(best.species.hostile), speciesKind:best.species.kind };
  }

  /** Applies one fictional knife hit after the First-Person swing reaches its active frame. */
  attackTarget(playerPosition, origin, direction, range = KNIFE_ATTACK_PROFILE.range, damage = KNIFE_ATTACK_PROFILE.damage, options = {}) {
    const target = this.getAttackTarget(playerPosition, origin, direction, range, options);
    if (!target) return null;
    const best = this.animals.find(animal => animal.instanceId === target.instanceId);
    if (!best) return null;

    const species = best.species;
    const position = best.group.position.clone();
    const healthMax = Math.max(24, Math.round(species.scale * (species.hostile ? 42 : 30)));
    best.health = Number.isFinite(best.health) ? best.health : healthMax;
    best.health = Math.max(0, best.health - Math.max(1, Number(damage) || KNIFE_ATTACK_PROFILE.damage));
    const away = best.group.position.clone().sub(playerPosition);
    const awayLength = Math.max(0.001, Math.hypot(away.x, away.z));
    best.direction = Math.atan2(away.x, -away.z);
    best.group.rotation.y = best.direction;
    best.velocity = Math.max(best.velocity || 1, 1.35);
    best.roamTimer = Math.max(best.roamTimer || 0, 3.2);
    best.attackCooldown = Math.max(best.attackCooldown || 0, 2.4);
    best.fleeTimer = Math.max(best.fleeTimer || 0, species.hostile ? 0.65 : 1.35);
    best.behaviorState = 'hit-reaction';
    best.hitReact = { elapsed: 0, duration: 0.42, direction: Math.sign(away.x || away.z || 1), pushX:(away.x/awayLength)*2.4, pushZ:(away.z/awayLength)*2.4 };
    best.attackAnimation = null;
    if (best.jaw) best.jaw.rotation.x = (best.jaw.userData.baseRotationX || 0) + 0.22;

    const result = {
      id: species.id,
      name: species.name,
      position,
      health: best.health,
      healthMax,
      killed: best.health <= 0,
      hostile: Boolean(species.hostile),
      speciesKind: species.kind
    };
    if (result.killed) {
      best.deathAnimation = { elapsed: 0, duration: 0.62 };
      best.velocity = 0.35;
      best.attackAnimation = null;
    }
    return result;
  }

  getHarvestTarget(playerPosition, range=6.5, aim=null) {
    let best=null, bestDistance=range, bestScore=-Infinity;
    for(const animal of this.animals){
      if(animal.deathAnimation) continue;
      const species=animal.species;
      // Only small, non-hostile fish can be caught in this early survival build.
      // Large fauna, protected wildlife and predators remain scan-only.
      if(species.kind!=='fish' || species.hostile || species.scale>0.85) continue;
      const position=animal.group.position;
      const distance=position.distanceTo(playerPosition);
      if(distance>=bestDistance)continue;
      let alignment=1;
      if(aim?.origin&&aim?.direction){
        const direction=position.clone().sub(aim.origin);
        if(direction.length()>range)continue;
        alignment=aim.direction.dot(direction.normalize());
        if(alignment<(aim.minAlignment??0.945))continue;
      }
      const score=alignment-distance*0.001;
      if(score>bestScore){bestDistance=distance;bestScore=score;best={id:animal.instanceId || species.id,speciesId:species.id,name:species.name,distance,position:position.clone()};}
    }
    return best;
  }

  harvestNearest(playerPosition, range=6.5, targetId=null) {
    // Prefer the exact instance aimed at. A species-only fallback is retained
    // for older callers, but always selects the nearest individual of that species.
    let index=-1;
    if (targetId) {
      index=this.animals.findIndex(animal=>animal.instanceId===targetId && animal.group.position.distanceTo(playerPosition)<=range);
      if(index<0) {
        let nearest=Infinity;
        this.animals.forEach((animal,i)=>{
          const distance=animal.group.position.distanceTo(playerPosition);
          if(animal.species.id===targetId && distance<=range && distance<nearest){nearest=distance;index=i;}
        });
      }
    } else {
      const target=this.getHarvestTarget(playerPosition,range);
      if(target) index=this.animals.findIndex(animal=>animal.instanceId===target.id);
    }
    if(index<0)return null;
    const animal=this.animals[index];
    const position=animal.group.position.clone();
    this.scene.remove(animal.group);
    this.animals.splice(index,1);
    return {id:animal.species.id,instanceId:animal.instanceId,name:animal.species.name,position};
  }

  getScanTarget(playerPosition, range=58, aim=null) {
    let best=null, bestDistance=range, bestScore=-Infinity;
    for (const animal of this.animals) {
      if (animal.deathAnimation) continue;
      const position=animal.group.position;
      const distance=position.distanceTo(playerPosition);
      if (distance>=bestDistance) continue;
      let alignment=1;
      if (aim?.origin && aim?.direction) {
        const direction=position.clone().sub(aim.origin);
        if (direction.length()>range) continue;
        alignment=aim.direction.dot(direction.normalize());
        if (alignment<(aim.minAlignment??0.94545)) continue;
      }
      const score=alignment-distance*0.001;
      if (score>bestScore) { bestDistance=distance; bestScore=score; best={id:animal.species.id,name:animal.species.name,kind:animal.species.kind,distance,position:position.clone()}; }
    }
    return best;
  }

  scan(playerPosition, range=58, aim=null) {
    const target=this.getScanTarget(playerPosition,range,aim);
    if (!target) return null;
    const isNew=!this.discovered.has(target.id);
    this.discovered.add(target.id);
    return { ...target, distance:Math.round(target.distance), isNew, total:this.discovered.size, maximum:SPECIES.length };
  }

  dispose() {
    for (const animal of this.animals) this.scene.remove(animal.group);
    this.animals.length=0;
    for (const [key, geometry] of Object.entries(this.shared)) {
      if (key === 'fishBodies') Object.values(geometry).forEach(item => item.dispose());
      else geometry?.dispose?.();
    }
    for (const material of this.materials.values()) material.dispose();
    this.materials.clear();
    this.scaleTexture.dispose(); this.scaleBumpTexture.dispose();
    this.turtleShellMaterial.dispose();
    this.turtleShellTexture.dispose(); this.turtleShellBumpTexture.dispose();
  }
}

export const FAUNA_SPECIES_COUNT = SPECIES.length;
