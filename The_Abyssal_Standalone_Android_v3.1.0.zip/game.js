import * as THREE from 'three';
import { FaunaDirector, FAUNA_SPECIES_COUNT } from './fauna.js';
import { normalizeGameSettings, normalizeSaveRecord, normalizeBackupPayload } from './save-schema.mjs';
import { hash2, valueNoise, seaFloorDepth, trenchInfluenceAt, ABYSSAL_TRENCH, MAX_DIVE_DEPTH, getTrenchBiomeId } from './world-generation.mjs';
import { applyTouchLook, canPlayerJump, getLifepodHatchAim, getLifepodExitWorldPosition, lifepodHullBlocksWorld, lifepodInteriorContains, lifepodHatchChannelContains, oxygenUsePerTick, oxygenTankCapacity, oxygenTankDepthRating, depthStressDamage, MAX_OXYGEN_TANK_LEVEL, resolveLifepodMovement, resolveVerticalInput, worldToLifepodLocal } from './player-mechanics.mjs';
import { online } from './multiplayer.js';
import { canBreatheAtSurface, computeDaylight, computeSurfaceBlend, computeSwimPose, waterSurfaceHeightAt, resolveGraphicsTextureProfile } from './environment-simulation.mjs';
import { sampleOceanCurrent, getDiverCurrentResponse, getVehicleCurrentResponse } from './ocean-currents.mjs';
import { VEHICLE_DEFS, VEHICLE_IDS, VEHICLE_UPGRADES, createVehicleState, normalizeVehicleFleet, getVehicleDepthRating, getVehicleMaxHealth, getVehicleCargoCapacity, getVehicleCargoUsed, getVehicleSpeed, vehiclePowerDrainPerSecond, vehicleDepthDamage, canInstallVehicleUpgrade, addVehicleCargo, removeVehicleCargo, integrateVehicleMotion, resolveVehicleSweep } from './vehicle-systems.mjs';
import { INTRO_CINEMATIC_DURATION, INTRO_CINEMATIC_LINES_AT, getIntroCameraShot, getIntroSubtitleIndex, getIntroCinematicEffects } from './cinematic-systems.mjs';
import { resolveHeldItemPresentation, computeHeldItemMotion, getDepthAtmosphereProfile } from './immersive-systems.mjs';
import { getResourceVisualProfile, getStructureDimensions, getVehicleVisualProfile } from './asset-proportions.mjs';
import { getBiomeEcologyProfile } from './ocean-ecology.mjs';
import { CAVE_NETWORKS as CAVE_SITES, getCaveCarveProfile, getCaveCeilingY, getCaveAudioBlend, constrainCaveHorizontalMotion } from './cave-systems.mjs';
import { integrateFluidBody, getDiverBuoyancyTrim, integrateGroundGravity, clampCapsuleBelowCeiling, getResourceDensityRatio } from './physics-systems.mjs';
import { getUnderwaterAudioProfile } from './audio-design.mjs';
import { AudioAssetBank } from './audio-assets.mjs';
import { KNIFE_ATTACK_PROFILE } from './combat-mechanics.mjs';

const $ = (id) => document.getElementById(id);
// Public client key supplied by the project owner. Project URL must still be entered from Supabase Dashboard.
const DEFAULT_SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_lhtTNQ-RM5kh2yTVyex6UQ_LXp1PyBK';
const canvas = $('world-canvas');
const UI = {
  boot: $('boot-screen'), main: $('main-menu'), newGame: $('new-game-screen'), load: $('load-screen'),
  settings: $('settings-screen'), multiplayer: $('multiplayer-screen'), inventory: $('inventory-screen'), build: $('build-screen'), fabricator: $('fabricator-screen'), storage: $('storage-screen'), vehicle: $('vehicle-screen'), pda: $('pda-screen'), hud: $('hud'), pause: $('pause-screen'), exit: $('exit-screen')
};
const STORAGE = { slots: 'the-abyssal-slots-v1', settings: 'the-abyssal-settings-v1' };
const CHUNK_SIZE = 64;
const LIFEPOD_SCALE = 1.32;
const LIFEPOD_POSITION = Object.freeze({x:0,y:-2.40,z:-7.5});
const SULFUR_NEST_SITES = Object.freeze([{x:296,z:-217,y:-42},{x:-272,z:246,y:-46},{x:448,z:365,y:-44}]);
const SURVIVAL_DEFAULTS = { hp: 100, oxygen: 45, food: 100, water: 100, medkits: 2, rations: 3, waterBottles: 2 };
const SURVIVAL_STORAGE_VERSION = 5;
const INVENTORY_DEFAULTS = { titanium: 0, copper: 0, quartz: 0, kelp: 0, coral: 0, lithium: 0, sulfur: 0, magnetite: 0, salt: 0, glowcap: 0, fish_meat: 0, glass: 0, silicone: 0, fiber_mesh: 0, battery: 0, wiring_kit: 0, computer_chip: 0, silver: 0, power_cell: 0, lubricant: 0, bleach: 0 };
const RESOURCE_LABELS = { titanium: 'Titanium', copper: 'Copper Ore', quartz: 'Quartz', kelp: 'Creepvine', coral: 'Coral Sample', lithium: 'Lithium', sulfur: 'Sulfur Crystal', magnetite: 'Magnetite', salt: 'Salt Deposit', glowcap: 'Glowcap Mushroom', fish_meat: 'Fresh Fish', glass: 'Glass', silicone: 'Silicone Rubber', fiber_mesh: 'Fiber Mesh', battery:'Battery', wiring_kit:'Wiring Kit', computer_chip:'Computer Chip', silver:'Silver Ore', power_cell:'Power Cell', lubricant:'Lubricant', bleach:'Bleach' };
const EQUIPMENT_DEFAULTS = { tankLevel: 0, fins: false, rebreather: false, seaglideCharge: 0 };
const MISSION_SEQUENCE = [
  { id:'lifepod', title:'Repair the Lifepod', objective:'Collect Titanium, Creepvine, Copper Ore, and Quartz. Fabricate a Repair Tool in the Lifepod, equip it, then repair the control console.', done:'Lifepod console repaired. Emergency beacon and onboard systems are online.' },
  { id:'scan', title:'Read the Living Ocean', objective:'Scan one nearby life-form with the Explorer PDA.', done:'Life-form data stored. Your scanner can identify local fauna.' },
  { id:'materials', title:'Gather Survival Materials', objective:'Collect 3 resource drops from the seafloor.', target:3, done:'Basic resources secured. A fabricator can turn them into useful supplies.' },
  { id:'fish', title:'Secure Fresh Food', objective:'Catch one small fish for the Fabricator.', done:'Food sample secured. Avoid large predators and keep your distance.' },
  { id:'craft', title:'Prepare a Medical Kit', objective:'Craft a Medkit in your inventory.', done:'Medical supplies ready. Keep monitoring HP and oxygen.' },
  { id:'build', title:'Build a Habitat', objective:'Use the Habitat Builder to place a Multipurpose Room.', done:'Your first habitat is operational. Add a Solar Panel to power its systems.' },
  { id:'wreck', title:'Investigate the Wreck Signal', objective:'Approach the abandoned vessel in Wreckfall Shelf.', done:'Wreck signal located. New expedition data is available.' },
  { id:'freeplay', title:'Explore the Deep Frontier', objective:'Expedition objectives complete. Explore, build, scan, and survive.', done:'All initial directives completed.' }
];
const STORY_DEFAULTS = { introSeen:false, missionIndex:0, counters:{ materials:0 }, completed:[] };

const BIOME_DATA = {
  reef: { id:'reef', label:'Luminous Reef', terrain:0x4e9c91, fog:0x176a78, density:0.0019, temperature:27, note:'Terumbu dangkal dengan karang bercahaya, padang pasir laut, dan ikan kecil.' },
  kelp: { id:'kelp', label:'Sapphire Kelp Forest', terrain:0x3e806d, fog:0x145c63, density:0.00205, temperature:23, note:'Hutan rumput laut tinggi menjadi tempat berlindung fauna dan sumber serat.' },
  wreck: { id:'wreck', label:'Wreckfall Shelf', terrain:0x6e7778, fog:0x244957, density:0.00225, temperature:19, note:'Puing kapal, lorong logam, dan serpihan teknologi tersebar di landas kontinen.' },
  thermal: { id:'thermal', label:'Ember Vent Fields', terrain:0x8b6559, fog:0x493e4b, density:0.00245, temperature:38, note:'Retakan panas bumi memancarkan gelembung, mineral, dan arus termal.' },
  deep: { id:'deep', label:'Twilight Trench', terrain:0x244e68, fog:0x092c49, density:0.00325, temperature:11, note:'Lereng palung mesopelagik. Cahaya matahari mulai hilang dan fauna bercahaya muncul.' },
  abyss: { id:'abyss', label:'The Hadal Reach', terrain:0x26324f, fog:0x070e25, density:0.0041, temperature:5, note:'Basin palung gelap dengan tekanan tinggi, pilar batu, dan predator besar.' },
  abyssal_shelf: { id:'abyssal_shelf', label:'Abyssal Shelf', terrain:0x273f5c, fog:0x091b36, density:0.00445, temperature:4, note:'Teras batu pada 500–720 m. Endapan magnetit dan koloni kaca tumbuh di dinding palung.' },
  midnight_grotto: { id:'midnight_grotto', label:'Midnight Grotto', terrain:0x202e55, fog:0x080f2c, density:0.0048, temperature:3, note:'Jaringan gua gelap dengan jamur bercahaya, ceruk sempit, dan fauna penyergap.' },
  blue_void: { id:'blue_void', label:'Blue Void', terrain:0x182747, fog:0x050c22, density:0.0052, temperature:2, note:'Zona air terbuka tanpa cahaya matahari. Siluet fauna besar muncul dari kabut biru.' },
  hadal_rift: { id:'hadal_rift', label:'Hadal Rift', terrain:0x171d38, fog:0x040817, density:0.00565, temperature:1, note:'Retakan hadal 1.160–1.360 m dengan dinding bergerigi, arus vertikal, dan kehidupan langka.' },
  hadal_garden: { id:'hadal_garden', label:'Hadal Garden', terrain:0x202343, fog:0x05091a, density:0.0060, temperature:1, note:'Dasar terdalam mendekati 1.500 m. Koloni bioluminesen dan spesies hadal bertahan dalam tekanan ekstrem.' },
  open: { id:'open', label:'Pelagic Expanse', terrain:0x397d91, fog:0x0d465e, density:0.0018, temperature:25, note:'Laut terbuka dengan migrasi ikan besar dan predator pelagis.' }
};
const BIOME_CENTERS = { kelp:[[-190,-105],[220,115],[430,-320]], thermal:[[275,-205],[-290,260],[430,380]] };
const BUILD_RECIPES = {
  beacon: { label: 'Beacon', cost: { copper: 1, quartz: 1 } },
  foundation: { label: 'Foundation', cost: { titanium: 2 } },
  compartment: { label: 'Multipurpose Room', cost: { titanium: 6, quartz: 2 } },
  storage_locker: { label: 'Wall Locker', cost: { titanium: 2, copper: 1 } },
  solar_array: { label: 'Solar Panel', cost: { titanium: 2, copper: 2, quartz: 1 } },
  vehicle_bay: { label: 'Vehicle Fabrication Bay', cost: { titanium: 8, copper: 4, computer_chip: 2, lubricant: 2, glass: 2 } }
};
const EQUIPMENT_RECIPES = {
  tank: { label:'O₂ Tank Mk Upgrade', cost:{ titanium:3, glass:1 } },
  fins: { label:'Swim Fins', cost:{ silicone:2, kelp:1 } },
  rebreather: { label:'Rebreather', cost:{ fiber_mesh:1, wiring_kit:1 } }
};
const ITEM_DEFS = {
  explorer_pda:{name:'PDA',icon:'explorer_pda',size:4,kind:'tool',width:2,height:2},
  scanner:{name:'Scanner',icon:'scanner',size:2,kind:'tool',width:1,height:2},
  knife:{name:'Survival Knife',icon:'knife',size:2,kind:'tool',width:1,height:2},
  flashlight:{name:'Flashlight',icon:'flashlight',size:2,kind:'tool',width:1,height:2},
  habitat_builder:{name:'Habitat Builder',icon:'habitat_builder',size:4,kind:'tool',width:2,height:2},
  repair_tool:{name:'Repair Tool',icon:'repair_tool',size:4,kind:'tool',width:2,height:2},
  seaglide:{name:'Seaglide',icon:'seaglide',size:6,kind:'tool',width:2,height:3},
  titanium:{name:'Titanium',icon:'titanium',size:1,stack:4,kind:'resource'},
  copper:{name:'Copper Ore',icon:'copper',size:1,stack:4,kind:'resource'},
  quartz:{name:'Quartz',icon:'quartz',size:1,stack:4,kind:'resource'},
  kelp:{name:'Creepvine',icon:'kelp',size:1,stack:4,kind:'resource'},
  coral:{name:'Coral Sample',icon:'coral',size:1,stack:4,kind:'resource'},
  lithium:{name:'Lithium',icon:'lithium',size:2,stack:2,kind:'resource'},
  sulfur:{name:'Sulfur Crystal',icon:'sulfur',size:2,stack:2,kind:'resource'},
  magnetite:{name:'Magnetite',icon:'magnetite',size:2,stack:2,kind:'resource'},
  salt:{name:'Salt Deposit',icon:'salt',size:1,stack:4,kind:'resource'},
  glowcap:{name:'Glowcap Mushroom',icon:'glowcap',size:1,stack:4,kind:'resource'},
  fish_meat:{name:'Fresh Fish',icon:'fish_meat',size:1,stack:3,kind:'resource'},
  glass:{name:'Glass',icon:'glass',size:2,stack:2,kind:'resource'},
  silicone:{name:'Silicone Rubber',icon:'silicone',size:2,stack:2,kind:'resource'},
  fiber_mesh:{name:'Fiber Mesh',icon:'fiber_mesh',size:2,stack:2,kind:'resource',width:2,height:1},
  battery:{name:'Battery',icon:'battery',size:2,stack:2,kind:'resource',width:2,height:1},
  wiring_kit:{name:'Wiring Kit',icon:'wiring_kit',size:2,stack:2,kind:'resource',width:2,height:1},
  computer_chip:{name:'Computer Chip',icon:'computer_chip',size:2,stack:2,kind:'resource',width:2,height:1},
  silver:{name:'Silver Ore',icon:'silver',size:2,stack:2,kind:'resource'},
  power_cell:{name:'Power Cell',icon:'power_cell',size:4,stack:1,kind:'resource',width:2,height:2},
  lubricant:{name:'Lubricant',icon:'lubricant',size:2,stack:2,kind:'resource',width:2,height:1},
  bleach:{name:'Bleach',icon:'bleach',size:2,stack:2,kind:'resource',width:2,height:1},
  medkit:{name:'Medkit',icon:'medkit',size:1,stack:4,kind:'supply'},
  ration:{name:'Rations',icon:'ration',size:1,stack:4,kind:'supply'},
  water:{name:'Purified Water',icon:'water',size:1,stack:4,kind:'supply'}
};
const STARTER_TOOLS = ['explorer_pda','scanner','knife','flashlight'];
const FABRICATOR_CATEGORIES = {
  sustenance:{title:'Sustenance',recipes:[
    {id:'medkit',name:'First Aid Kit',icon:'medkit',cost:{fiber_mesh:1}},
    {id:'ration',name:'Cooked Fish',icon:'ration',cost:{fish_meat:1}},
    {id:'water',name:'Filtered Water',icon:'water',cost:{bleach:1}}
  ]},
  personal:{title:'Personal',recipes:[
    {id:'tank',name:'O₂ Tank Upgrade',icon:'oxygen_tank',cost:{titanium:3,glass:1}},
    {id:'fins',name:'Swim Fins',icon:'fins',cost:{silicone:2,kelp:1}},
    {id:'rebreather',name:'Rebreather',icon:'rebreather',cost:{fiber_mesh:1,wiring_kit:1}},
    {id:'habitat_builder',name:'Habitat Builder',icon:'habitat_builder',cost:{titanium:2,copper:1,battery:1}},
    {id:'repair_tool',name:'Repair Tool',icon:'repair_tool',cost:{titanium:1,silicone:1,battery:1}},
    {id:'seaglide',name:'Seaglide',icon:'seaglide',cost:{battery:1,copper:1,titanium:1}}
  ]},
  resources:{title:'Resources',recipes:[
    {id:'glass',name:'Glass',icon:'glass',cost:{quartz:2}},
    {id:'silicone',name:'Silicone Rubber',icon:'silicone',cost:{kelp:2}},
    {id:'fiber_mesh',name:'Fiber Mesh',icon:'fiber_mesh',cost:{kelp:2}},
    {id:'lubricant',name:'Lubricant',icon:'lubricant',cost:{kelp:2}},
    {id:'bleach',name:'Bleach',icon:'bleach',cost:{salt:1,coral:1}}
  ]},
  electronics:{title:'Electronics',recipes:[
    {id:'battery',name:'Battery',icon:'battery',cost:{copper:1,quartz:1}},
    {id:'wiring_kit',name:'Wiring Kit',icon:'wiring_kit',cost:{silver:2}},
    {id:'computer_chip',name:'Computer Chip',icon:'computer_chip',cost:{quartz:1,copper:1,coral:1}},
    {id:'power_cell',name:'Power Cell',icon:'power_cell',cost:{battery:2,silicone:1}}
  ]}
};
let inventory = { ...INVENTORY_DEFAULTS };
let equipment = { ...EQUIPMENT_DEFAULTS };
let seaglideChargeUiBucket = -1;
let ownedTools = [...STARTER_TOOLS];
let hotbarSlots = ['scanner','knife','flashlight',null,null];
let selectedHotbarIndex = 0;
let hasUnsavedChanges = false;
let lastSavedRecord = null;
let fabricatorCategory = 'sustenance';
let lockerStorage = { ...INVENTORY_DEFAULTS };
let knownBiomes = new Set();
let currentBiome = BIOME_DATA.open;
let collectedResources = new Set();
let placedStructures = [];
let resourceNodes = new Map();
let oxygenPlantNodes = [];
let hadalFloraNodes = [];
let lavaEffectNodes = [];
let caveDustNodes = [];
let marineDecorationNodes = [];
let resourceBreakActions = [];
let floatingDrops = [];
let physicsDebris = [];
let buildPreviewGroup = null, pendingBuildType = '', buildPreviewValid = false, buildPreviewElapsed = 0;
let dropMaterials = new Map();
let dropGeometry = null;
let debrisGeometry = null;
let storyState = { ...STORY_DEFAULTS, counters:{...STORY_DEFAULTS.counters}, completed:[] };
let lifepodGroup = null;
let vehicleFleet = normalizeVehicleFleet(null);
let vehicleMeshes = new Map();
let activeVehicleId = null;
let activeVehicleVelocity = new THREE.Vector3();
let vehicleDamageTimer = 0, vehicleSpecialCooldown = 0, vehicleSonarWaves = [];
let vehicleActionFlash = 0;
let introSequence = { active:false, elapsed:0, group:null, base:null, attacker:null, pod:null, lights:[], debrisSpawned:false, lineIndex:-1 };
let introDebris = [];
let introDebrisResources = [];
let debrisMaterials = [];
let radioHideTimer = 0;
let viewModel = null;
let lightRayGroup = null;
let hemiLight = null, sunLight = null, fillLight = null;
let terrainTexture = null, rockTexture = null, kelpTexture = null, coralTexture = null, woodTexture = null, metalTexture = null, causticTexture = null;
let waterColorTexture = null, waterNormalTexture = null, waterWaveUpdateInterval = 0.055;
let swimBubbleGroup = null, swimBubblePool = [], swimBubbleSpawnTimer = 0, swimBubbleCursor = 0;
let terrainBumpTexture = null, rockBumpTexture = null, kelpBumpTexture = null, coralBumpTexture = null, woodBumpTexture = null, metalBumpTexture = null;
let surfaceSky = null, surfaceSkyTexture = null, surfaceSun = null, surfaceMoon = null, waterWaveBase = null, waterWaveLastUpdate = 0, surfaceBlend = 0;
let terrainMaterials = {};
let activeGraphicsProfileKey = '';
let activeGraphicsProfile = null;
let kelpShader = null;
let soundNoiseGain = null, sfxNoiseBuffer = null;
let visualViewportResizeTimer = 0;
let updateCheckTimer = 0;

const copy = {
  id: {
    tagline: 'Lautan tak berujung. Rahasia yang menunggu ditemukan.', play: 'Play', continue: 'Continue', settings: 'Settings', exit: 'Exit',
    back: 'Kembali', newGame: 'Permainan Baru', newGameHint: 'Pilih slot untuk memulai ekspedisi baru. Slot berisi data lama akan ditimpa setelah konfirmasi.',
    load: 'Load', loadHint: 'Pilih salah satu dari lima slot untuk melanjutkan perjalanan.', graphics: 'Grafik', renderDistance: 'Jarak render',
    sound: 'Suara', fieldOfView: 'Field of view', cameraSensitivity:'Sensitivitas kamera', hudScale:'Ukuran HUD', replayIntro:'Putar ulang cutscene pembuka', language: 'Bahasa', display: 'Tampilan', fullscreen: 'Fullscreen',
    settingsNote: 'Grafik, suara, jarak render, FOV, sensitivitas kamera, dan ukuran HUD dapat disesuaikan.', sessionEnded: 'Sesi berakhir',
    exitHint: 'Progres telah disimpan. Kamu dapat kembali ke menu atau keluar ke Home Android.', mainMenu: 'Menu Utama'
  },
  en: {
    tagline: 'An endless ocean. Secrets waiting to be discovered.', play: 'Play', continue: 'Continue', settings: 'Settings', exit: 'Exit',
    back: 'Back', newGame: 'New Expedition', newGameHint: 'Choose a slot for a new expedition. Existing data will be replaced after confirmation.',
    load: 'Load', loadHint: 'Choose one of five slots to continue your journey.', graphics: 'Graphics', renderDistance: 'Render distance',
    sound: 'Sound', fieldOfView: 'Field of view', cameraSensitivity:'Camera sensitivity', hudScale:'HUD size', replayIntro:'Replay opening cinematic', language: 'Language', display: 'Display', fullscreen: 'Fullscreen',
    settingsNote: 'Graphics, sound, render distance, FOV, camera sensitivity, and HUD size can be adjusted.', sessionEnded: 'Session ended',
    exitHint: 'Your progress has been saved. Return to the menu or leave to the Android home screen.', mainMenu: 'Main Menu'
  }
};

const defaults = { graphics: 'balanced', renderDistance: 2, volume: 55, fov: 70, language: 'id' };
let settings = normalizeGameSettings(loadJson(STORAGE.settings, defaults));
const rawSlots = loadJson(STORAGE.slots, [null, null, null, null, null]);
let slots = Array.isArray(rawSlots)
  ? Array.from({ length: 5 }, (_, index) => rawSlots[index] ? normalizeSaveRecord(rawSlots[index]) : null)
  : [null, null, null, null, null];

let renderer, scene, camera, water, particleGroup, playerGroup, playerBody, leftArm, rightArm, leftFin, rightFin;
let faunaDirector = null;
let faunaStatus = { count: 0, nearest: null, threat: null };
let survival = { ...SURVIVAL_DEFAULTS };
let oxygenTickTimer = 0, oxygenDamageTimer = 0, hungerDamageTimer = 0, thirstDamageTimer = 0, depthStressTickTimer = 0;
let flashlightEnabled = true;
let lastKnifeAttackAt = 0;
let pendingKnifeAttack = null;
let playerHitReactTimer = 0;
let respawnPoint = new THREE.Vector3(0, -7, 0);
let isRespawning = false;
let collectedCaches = new Set();
let terrainMaterial, rockGeometry, rockMaterial, kelpGeometry, kelpMaterial, coralGeometry, coralMaterial;
let spongeTubeGeometry, spongeMouthGeometry, spongeGlowGeometry, spongeTubeMaterial, spongeMouthMaterial, spongeGlowMaterial;
let chunks = new Map();
let gameActive = false;
let gamePaused = false;
let activeSlot = -1;
let settingsReturn = 'main';
let lastFrame = performance.now();
let lastHudUpdate = 0;
let lastMultiplayerSync = 0;
let multiplayerReturn = 'main';
const remoteDivers = new Map();

let chunkCenterX = NaN, chunkCenterZ = NaN;
let toastTimer = 0;
let ambientContext = null, ambientGain = null, ambientOscillators = [], lastAudioBiome = '';
let sfxBus = null, underwaterFilter = null, sfxDryGain = null, caveConvolver = null, caveWetGain = null;
let audioAssetBank = null;
const pbrTextureOverrides = Object.create(null);
let caveDelay = null, caveEchoFilter = null, caveEchoFeedback = null, caveEchoOut = null;
let audioEnvironmentTimer = 0, caveAudioBlend = 0, caveAudioCueTimer = 0;
let biomeSfxTimer = 0;
let rendererReady = false;

const player = { position: new THREE.Vector3(0, -7, 0), velocity: new THREE.Vector3(), yaw: 0, pitch: 0.08, bob: 0, swimPhase: 0 };
const input = { keys: new Set(), joyX: 0, joyY: 0, vertical: 0, forward: 0, strafe: 0 };
let jumpRequested = false;
let spaceUsedForJump = false;
const look = { active: false, pointerId: null, x: 0, y: 0 };
let animationFrameId = 0;
let animationLoopRunning = false;
let applicationSuspended = Boolean(document.hidden);
let nativeAppInactive = false;
let webglContextLost = false;
let webglRecoveryBound = false;
let runtimeFrameError = null;
let releaseTouchControls = () => {
  input.keys.clear(); input.joyX = 0; input.joyY = 0; input.vertical = 0;
  jumpRequested = false; spaceUsedForJump = false; look.active = false; look.pointerId = null;
};
const islandOfInterest = { x: 98, z: -58, name: 'Verdant Isle' };
const shipOfInterest = { x: -132, z: 150, name: 'Sunken Vessel' };
const supplyCacheLocations = [
  { id: 'verdant_cache', name: 'Verdant Isle Supply Cache', x: 205, y: -4, z: -58 },
  { id: 'wreck_cache', name: 'Sunken Vessel Supply Cache', x: -118, y: -35, z: 145 }
];
const tmpVector = new THREE.Vector3();
const tmpRight = new THREE.Vector3();
const tmpDirection = new THREE.Vector3();
const tmpCamera = new THREE.Vector3();
const tmpPlayerBeforeFauna = new THREE.Vector3();
const audioListenerForward = new THREE.Vector3(0, 0, -1);
const audioListenerUp = new THREE.Vector3(0, 1, 0);
const surfaceWaterTint = new THREE.Color(0x83c9d0);
const waterBiomeTintScratch = new THREE.Color(0x7abdc5);
const clockState = { elapsed: 0 };

function loadJson(key, fallback) {
  try { const value = localStorage.getItem(key); return value ? JSON.parse(value) : fallback; }
  catch { return fallback; }
}
function saveJson(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); return true; }
  catch { showToast('Penyimpanan perangkat penuh atau tidak tersedia.'); return false; }
}
function disposeObjectTree(root, protectedResources = {}) {
  if (!root) return;
  const keepGeometries = new Set(protectedResources.geometries || []);
  const keepMaterials = new Set(protectedResources.materials || []);
  const geometries = new Set();
  const materials = new Set();
  root.traverse(object => {
    if (object.geometry && !keepGeometries.has(object.geometry)) geometries.add(object.geometry);
    const list = Array.isArray(object.material) ? object.material : [object.material];
    for (const material of list) if (material && !keepMaterials.has(material)) materials.add(material);
  });
  for (const geometry of geometries) geometry.dispose();
  for (const material of materials) material.dispose();
}
function clamp(value, min, max) { return Math.max(min, Math.min(max, value)); }
function getGameViewportSize() {
  const rect = $('game-shell').getBoundingClientRect();
  return { width: Math.max(1, Math.round(rect.width)), height: Math.max(1, Math.round(rect.height)) };
}
function lerp(a, b, t) { return a + (b - a) * t; }
function smoothstep(a, b, x) { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); }
function wrapAngle(a) { while (a > Math.PI) a -= Math.PI * 2; while (a < -Math.PI) a += Math.PI * 2; return a; }
function formatTime(value) {
  try { return new Intl.DateTimeFormat(settings.language === 'id' ? 'id-ID' : 'en-US', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)); }
  catch { return new Date(value).toLocaleString(); }
}
function showToast(message) {
  const toast = $('toast');
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2400);
}
function setVisibleScreen(name) {
  if (document.activeElement && /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName)) document.activeElement.blur();
  Object.values(UI).forEach(node => node.classList.add('hidden'));
  if (UI[name]) UI[name].classList.remove('hidden');
  const menuVideo = $('menu-background-video');
  if (menuVideo) {
    if (name === 'main') {
      const playPromise = menuVideo.play();
      if (playPromise?.catch) playPromise.catch(() => { menuVideo.setAttribute('poster', './assets/menu-underwater-frame.png'); });
    } else menuVideo.pause();
  }
  document.body.classList.toggle('game-screen-open', name === 'hud');
}
function applyLanguage() {
  const words = copy[settings.language] || copy.id;
  document.documentElement.lang = settings.language === 'id' ? 'id' : 'en';
  document.querySelectorAll('[data-i18n]').forEach(node => {
    const key = node.dataset.i18n;
    if (words[key]) node.textContent = words[key];
  });
}
function exportSaveBackup() {
  if (gameActive && activeSlot >= 0) {
    slots[activeSlot] = buildSaveRecord();
    if (!saveJson(STORAGE.slots, slots)) { showToast('Backup dibatalkan karena progres aktif gagal disimpan.'); return; }
  }
  const payload = {
    format: 'the-abyssal-save-backup',
    schemaVersion: 2,
    exportedAt: new Date().toISOString(),
    slots: slots.map(record => record ? normalizeSaveRecord(record) : null),
    settings: normalizeGameSettings(settings)
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `the-abyssal-backup-${new Date().toISOString().slice(0,10)}.json`;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
  showToast('Backup lima slot dibuat. Simpan file JSON di Downloads.');
}

async function importSaveBackup(file) {
  if (gameActive) throw new Error('Kembali ke menu utama sebelum memulihkan backup.');
  if (!file || file.size > 2 * 1024 * 1024) throw new Error('File backup tidak valid atau lebih dari 2 MB.');
  const payload = JSON.parse(await file.text());
  const restored = normalizeBackupPayload(payload);
  if (!window.confirm('Pulihkan lima slot dari backup? Data slot yang sekarang akan diganti.')) return;
  if (!saveJson(STORAGE.slots, restored.slots)) throw new Error('Penyimpanan perangkat gagal. Slot lama tidak diubah.');
  slots = restored.slots;
  if (restored.settings) {
    settings = normalizeGameSettings(restored.settings);
    if (!saveJson(STORAGE.settings, settings)) showToast('Slot dipulihkan, tetapi pengaturan tidak dapat disimpan.');
    syncSettingsInputs();
    applySettings();
    applyLanguage();
  }
  renderSlotCards('load-slots', 'load');
  showToast('Backup berhasil dipulihkan ke lima slot lokal.');
}

function syncSettingsInputs() {
  $('graphics-select').value = settings.graphics;
  $('render-select').value = String(settings.renderDistance);
  $('volume-range').value = String(settings.volume);
  $('volume-value').textContent = `${settings.volume}%`;
  $('fov-range').value = String(settings.fov);
  $('fov-value').textContent = `${settings.fov}°`;
  $('camera-sensitivity-range').value = String(Math.round(settings.cameraSensitivity * 100));
  $('camera-sensitivity-value').textContent = `${Math.round(settings.cameraSensitivity * 100)}%`;
  $('hud-scale-range').value = String(settings.hudScale);
  $('hud-scale-value').textContent = `${settings.hudScale}%`;
  $('language-select').value = settings.language;
  updateGraphicsResolutionLabel(activeGraphicsProfile || (rendererReady ? getGraphicsProfile() : null));
}

function getGraphicsProfile() {
  const gpuLimit = renderer?.capabilities?.maxTextureSize || 4096;
  const memory = Number(navigator.deviceMemory) || 0;
  return resolveGraphicsTextureProfile(settings.graphics, gpuLimit, memory);
}

function getActiveGraphicsQuality() {
  return activeGraphicsProfile?.effectivePreset || settings.graphics || 'balanced';
}

function updateGraphicsResolutionLabel(profile) {
  const target = $('graphics-detail');
  if (!target) return;
  const preset = ({low:'Low',balanced:'Medium',high:'High',ultra:'Ultra'})[settings.graphics] || 'Medium';
  if (!profile) {
    const px = settings.graphics === 'low' ? 1024 : (settings.graphics === 'high' || settings.graphics === 'ultra') ? 4096 : 2048;
    target.textContent = `${preset}: target tekstur ${px}×${px}. Resolusi aktif akan menyesuaikan kemampuan GPU dan memori perangkat.`;
    return;
  }
  const targetPx = profile.targetResolution;
  const primaryPx = profile.primaryTextureSize;
  const waterPx = profile.waterTextureSize;
  const detailPx = profile.supportingTextureSize;
  const applied = `Air ${waterPx}×${waterPx} · Terrain utama ${primaryPx}×${primaryPx} · Detail ${detailPx}×${detailPx}`;
  const effectiveLabel = ({low:'Low',balanced:'Medium',high:'High',ultra:'Ultra'})[profile.effectivePreset] || 'Medium';
  const effective = profile.effectivePreset && profile.effectivePreset !== settings.graphics ? ` · Tier performa aktif: ${effectiveLabel}` : '';
  const fallback = profile.fallbackReason ? ` · Penyesuaian perangkat: ${profile.fallbackReason}` : '';
  target.textContent = `${preset}: target ${targetPx}×${targetPx}. Aktif: ${applied}. Batas GPU ${profile.gpuLimit}px${effective}${fallback}.`;
}

function applySettings() {
  if (!rendererReady) return;
  const requestedProfile = getGraphicsProfile();
  const requestedKey = [requestedProfile.preset, requestedProfile.primaryTextureSize, requestedProfile.supportingTextureSize, requestedProfile.waterTextureSize, requestedProfile.bumpTextureSize, requestedProfile.causticTextureSize, requestedProfile.faunaTextureSize].join(':');
  if (requestedKey !== activeGraphicsProfileKey) {
    try {
      const built = makeGraphicsTextureSetWithFallback(requestedProfile);
      applyGraphicsTextureSet(built.textureSet);
      activeGraphicsProfile = built.profile;
      // Cache the requested tier, not the effective fallback dimensions, so a
      // failed 4K allocation is not retried on every unrelated settings change.
      activeGraphicsProfileKey = requestedKey;
      if (built.profile.fallbackReason && built.profile.fallbackReason !== requestedProfile.fallbackReason) {
        showToast(`Grafik disesuaikan: ${built.profile.fallbackReason}`);
      }
    } catch (error) {
      console.error('[The Abyssal] Gagal menerapkan profil tekstur:', error);
      showToast('Tekstur grafik gagal dialokasikan. Kualitas sebelumnya tetap digunakan.');
      settings.graphics = activeGraphicsProfile?.preset || 'balanced';
      syncSettingsInputs();
      return;
    }
  }
  const profile = activeGraphicsProfile || requestedProfile;
  const visualQuality = profile.effectivePreset || settings.graphics;
  const highMemory = profile.is4K;
  const isHighQuality = visualQuality === 'high' || visualQuality === 'ultra';
  const pixelCap = visualQuality === 'ultra' ? 1.6 : isHighQuality ? 1.5 : visualQuality === 'low' ? 0.9 : 1.15;
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, pixelCap));
  document.documentElement.style.setProperty('--abyssal-hud-scale', String(settings.hudScale / 100));
  renderer.shadowMap.enabled = visualQuality !== 'low';
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  if (sunLight) sunLight.castShadow = isHighQuality;
  if (sunLight?.shadow) {
    const shadowSize = visualQuality === 'ultra' ? 2048 : visualQuality === 'high' ? (highMemory ? 2048 : 1024) : visualQuality === 'low' ? 512 : 1024;
    sunLight.shadow.mapSize.set(shadowSize, shadowSize);
    sunLight.shadow.needsUpdate = true;
  }
  applyWaterQualitySettings(profile, visualQuality);
  const viewport = getGameViewportSize();
  renderer.setSize(viewport.width, viewport.height, false);
  camera.fov = Number(settings.fov);
  camera.aspect = viewport.width / viewport.height;
  camera.updateProjectionMatrix();
  updateAmbientVolume();
  if (scene) scene.fog.density = visualQuality === 'low' ? 0.0029 : isHighQuality ? 0.00165 : 0.00215;
  updateChunks(true);
  faunaDirector?.setQuality(visualQuality, profile.faunaTextureSize);
  activeGraphicsProfile = profile;
  updateGraphicsResolutionLabel(profile);
  saveJson(STORAGE.settings, settings);
}

function openSettings(from = 'main') {
  settingsReturn = from;
  syncSettingsInputs();
  $('replay-intro-btn')?.classList.toggle('hidden', !gameActive);
  setVisibleScreen('settings');
  applyLanguage();
}
function closeSettings() {
  if (settingsReturn === 'pause' && gameActive) setVisibleScreen('pause');
  else setVisibleScreen('main');
}
function updateNetworkLabels() {
  const label = $('network-label');
  const dot = $('network-dot');
  if (!label) return;
  if (!online.configured) {
    label.textContent = 'OFFLINE PLAY AVAILABLE · ONLINE SETUP REQUIRED';
    if (dot) dot.style.background = '#d7b873';
  } else if (online.inRoom && online.connectionState === 'error') {
    label.textContent = `ROOM RECONNECTING · ${online.room.code}`;
    if (dot) dot.style.background = '#d7b873';
  } else if (online.inRoom) {
    label.textContent = `MULTIPLAYER ROOM · ${online.room.code}`;
    if (dot) dot.style.background = '#72e8cb';
  } else if (online.user) {
    label.textContent = 'ACCOUNT CONNECTED · NO ACTIVE ROOM';
    if (dot) dot.style.background = '#72e8cb';
  } else {
    label.textContent = 'ONLINE CONFIGURED · LOGIN TO PLAY TOGETHER';
    if (dot) dot.style.background = '#72b9e8';
  }
}

function updateOnlineStatus(message, type = 'info') {
  const status = $('online-status');
  if (!status) return;
  status.textContent = String(message || '');
  status.dataset.kind = type;
}

function explainOnlineError(error, fallback = 'Permintaan online gagal.') {
  const message = String(error?.message || error || '');
  if (/invalid login credentials/i.test(message)) return 'Email atau kata sandi tidak cocok. Periksa kembali, lalu coba Login lagi.';
  if (/email not confirmed|email_not_confirmed/i.test(message)) return 'Email belum diverifikasi. Buka email verifikasi Supabase terlebih dahulu.';
  if (/user already registered|already been registered/i.test(message)) return 'Email ini sudah terdaftar. Gunakan menu Login.';
  if (/password.*(characters|length|short)|weak password/i.test(message)) return 'Kata sandi belum memenuhi aturan keamanan Supabase. Gunakan kata sandi yang lebih kuat.';
  if (/invalid api key|invalid jwt|jwt expired/i.test(message)) return 'Project URL dan Publishable Key tidak cocok atau tidak valid. Periksa konfigurasi backend.';
  if (/failed to fetch|fetch failed|network request failed|networkerror/i.test(message)) return 'Server tidak dapat dijangkau. Periksa koneksi internet dan Project URL Supabase.';
  if (/rate limit|too many requests|email rate limit/i.test(message)) return 'Terlalu banyak percobaan. Tunggu beberapa saat sebelum mencoba lagi.';
  if (/pgrst202|could not find the function|function .* does not exist/i.test(message)) return 'Fungsi database multiplayer belum ditemukan. Jalankan seluruh file migrasi SQL The Abyssal di Supabase SQL Editor.';
  if (/row-level security|permission denied|not authorized|unauthorized/i.test(message)) return 'Akses ditolak oleh kebijakan keamanan database atau Realtime. Jalankan migrasi SQL terbaru dan pastikan akun sudah Login.';
  if (/email rate limit exceeded|over_email_send_rate_limit/i.test(message)) return 'Batas pengiriman email verifikasi tercapai. Periksa email yang sudah dikirim atau coba lagi nanti.';
  if (/user.*already.*registered/i.test(message)) return 'Email ini sudah terdaftar. Beralih ke menu Login.';
  if (/signup.*disabled|signups not allowed|disable_signup/i.test(message)) return 'Pendaftaran akun dinonaktifkan. Aktifkan Sign ups pada Supabase Authentication → Providers → Email.';
  return message || fallback;
}

function updateOnlineConfigNote() {
  const node = $('online-config-note');
  if (!node) return;
  if (online.configured) {
    node.textContent = 'KONFIGURASI TERSIMPAN · Login dan Register akan memeriksa layanan Supabase saat digunakan.';
    node.dataset.kind = 'success';
  } else {
    node.textContent = 'SUPABASE NOT CONNECTED · Masukkan Project URL dan Publishable Key pada bagian Hubungkan Backend di bawah.';
    node.dataset.kind = 'warning';
    const editor = $('backend-config-details');
    if (editor) editor.open = true;
  }
  const loginButton = $('login-submit-btn');
  const registerButton = $('register-submit-btn');
  if (loginButton) loginButton.disabled = !online.authReady;
  if (registerButton) {
    registerButton.disabled = !online.authReady || !online.signupAllowed;
    registerButton.title = online.signupAllowed ? '' : 'Pendaftaran akun dinonaktifkan pada Supabase Auth.';
  }
}

function updateOnlineRoomUi() {
  const authenticated = Boolean(online.user);
  $('online-auth-area')?.classList.toggle('hidden', authenticated);
  $('online-account-area')?.classList.toggle('hidden', !authenticated);
  if (authenticated) {
    $('account-display-name').textContent = online.displayName;
    $('account-email').textContent = online.user.email || 'Akun terhubung';
  }
  const room = online.room;
  $('online-room-state')?.classList.toggle('hidden', !room);
  $('online-chat-section')?.classList.toggle('hidden', !room);
  if (room) {
    $('online-room-code').textContent = room.code;
    $('online-room-name').textContent = room.name;
    const count = Math.max(online.members.length, 1);
    $('online-room-members').textContent = `${count} / ${room.maxPlayers || 4} DIVERS CONNECTED`;
  }
  for (const id of ['create-room-btn','join-room-btn']) {
    const button = $(id);
    if (button) button.disabled = !authenticated || !online.authReady || Boolean(room);
  }
  const leaveButton = $('leave-room-btn');
  if (leaveButton) leaveButton.disabled = !room;
  updateNetworkLabels();
}

function renderOnlineMembers(members = []) {
  online.members = members;
  updateOnlineRoomUi();
  const active = new Set(members.map(member => member.userId).filter(Boolean));
  for (const [userId, diver] of remoteDivers) {
    if (!active.has(userId)) {
      scene?.remove(diver.group);
      diver.labelTexture?.dispose();
      disposeObjectTree(diver.group);
      remoteDivers.delete(userId);
    }
  }
}

function appendOnlineChat(message) {
  const root = $('online-chat-log');
  if (!root || !message) return;
  root.querySelector('.chat-empty')?.remove();
  const row = document.createElement('div');
  row.className = message.senderId === online.userId ? 'chat-line own' : 'chat-line';
  const meta = document.createElement('small');
  meta.textContent = `${message.senderName} · ${new Date(message.sentAt).toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' })}`;
  const text = document.createElement('span');
  text.textContent = message.text;
  row.append(meta, text);
  root.append(row);
  while (root.children.length > 40) root.firstElementChild?.remove();
  root.scrollTop = root.scrollHeight;
}

function publishSharedWorldEvent(eventType, entityId, payload = {}) {
  if (!online.inRoom || !online.user) return;
  online.publishWorldEvent(eventType, entityId, payload).catch(error => {
    console.warn('[The Abyssal] Shared world event was not sent:', error?.message || error);
  });
}

function rebuildChunkAtWorld(x, z) {
  const cx=Math.floor(Number(x)/CHUNK_SIZE), cz=Math.floor(Number(z)/CHUNK_SIZE);
  const key=`${cx},${cz}`;
  const chunk=chunks.get(key);
  if(chunk){disposeChunk(chunk);chunks.delete(key);makeChunk(cx,cz);}
}

function applySharedWorldEvent(event) {
  if (!gameActive || !event || !event.eventType) return;
  const payload=event.payload||{};
  if(event.eventType==='resource_collected'){
    if(collectedResources.has(event.entityId))return;
    collectedResources.add(event.entityId);
    const node=resourceNodes.get(event.entityId);
    if(node){node.mesh.parent?.remove(node.mesh);disposeObjectTree(node.mesh);resourceNodes.delete(event.entityId);}
    markUnsaved();updateInteractionPrompt();
    return;
  }
  if(event.eventType==='structure_placed'){
    if(placedStructures.some(item=>item.id===event.entityId))return;
    const record={id:event.entityId,type:payload.type,x:Number(payload.x),y:Number(payload.y),z:Number(payload.z),yaw:Number(payload.yaw)||0,builtAt:Date.parse(event.createdAt)||Date.now()};
    if(!BUILD_RECIPES[record.type]||![record.x,record.y,record.z,record.yaw].every(Number.isFinite))return;
    placedStructures.push(record);
    const cx=Math.floor(record.x/CHUNK_SIZE),cz=Math.floor(record.z/CHUNK_SIZE);
    const chunk=chunks.get(`${cx},${cz}`);
    if(chunk)addBuiltStructure(chunk.group,record,cx*CHUNK_SIZE,cz*CHUNK_SIZE);
    markUnsaved();updateBuildButtons();
    return;
  }
  if(event.eventType==='cache_collected'){
    const cacheId=String(payload.cacheId||event.entityId);
    if(collectedCaches.has(cacheId))return;
    collectedCaches.add(cacheId);
    const cache=supplyCacheLocations.find(item=>item.id===cacheId);
    if(cache)rebuildChunkAtWorld(cache.x,cache.z);
    markUnsaved();updateInteractionPrompt();
    return;
  }
  if(event.eventType==='fauna_scanned'){
    const speciesId=String(payload.speciesId||event.entityId);
    if(!faunaDirector||faunaDirector.getDiscoveries().includes(speciesId))return;
    faunaDirector.setDiscoveries([...faunaDirector.getDiscoveries(),speciesId]);
    markUnsaved();renderPda();
    return;
  }
  if(event.eventType==='biome_discovered'){
    const biomeId=String(payload.biomeId||event.entityId);
    if(!BIOME_DATA[biomeId]||knownBiomes.has(biomeId))return;
    knownBiomes.add(biomeId);markUnsaved();renderPda();
    return;
  }
  if(event.eventType==='mission_completed'){
    const missionId=String(payload.missionId||event.entityId);
    const index=MISSION_SEQUENCE.findIndex(item=>item.id===missionId);
    if(index<0)return;
    storyState.completed=Array.isArray(storyState.completed)?storyState.completed:[];
    if(!storyState.completed.includes(missionId))storyState.completed.push(missionId);
    const nextIndex=Math.min(index+1,MISSION_SEQUENCE.length-1);
    if(nextIndex>storyState.missionIndex)storyState.missionIndex=nextIndex;
    updateMissionUI();markUnsaved();
  }
}

function openMultiplayer(from = 'main') {
  multiplayerReturn = from;
  setVisibleScreen('multiplayer');
  updateOnlineConfigNote();
  if ($('backend-project-url')) $('backend-project-url').value = online.projectUrl || '';
  if ($('backend-publishable-key')) $('backend-publishable-key').value = online.publishableKey || DEFAULT_SUPABASE_PUBLISHABLE_KEY;
  updateOnlineRoomUi();
}

function closeMultiplayer() {
  if (multiplayerReturn === 'pause' && gameActive) {
    gamePaused = true;
    setVisibleScreen('pause');
  } else {
    setVisibleScreen('main');
  }
}

async function initializeOnlineServices() {
  try {
    await online.init({
      onAuthChange: () => { updateOnlineRoomUi(); updateNetworkLabels(); },
      onStatus: ({ message, type }) => { updateOnlineStatus(message, type); updateNetworkLabels(); },
      onRoomChange: () => { updateOnlineRoomUi(); updateNetworkLabels(); },
      onMembers: members => renderOnlineMembers(members),
      onPlayerState: state => updateRemoteDiver(state),
      onChat: message => appendOnlineChat(message),
      onWorldEvent: event => applySharedWorldEvent(event)
    });
  } catch (error) {
    console.error('[The Abyssal] Online service initialization failed:', error);
    updateOnlineStatus(`Koneksi layanan online gagal: ${error.message || error}`, 'error');
  }
  updateOnlineConfigNote();
  if ($('backend-project-url')) $('backend-project-url').value = online.projectUrl || '';
  if ($('backend-publishable-key')) $('backend-publishable-key').value = online.publishableKey || DEFAULT_SUPABASE_PUBLISHABLE_KEY;
  updateOnlineRoomUi();
  updateNetworkLabels();
}

function makeRemoteDiver(userId, displayName) {
  const group = new THREE.Group();
  const suit = new THREE.MeshStandardMaterial({ color:0xe5e2d8, roughness:0.78, metalness:0.08 });
  const dark = new THREE.MeshStandardMaterial({ color:0x183c4b, roughness:0.7 });
  const visor = new THREE.MeshStandardMaterial({ color:0x62dce5, emissive:0x14545b, emissiveIntensity:0.7, transparent:true, opacity:0.86, roughness:0.16, metalness:0.28 });
  const accent = new THREE.MeshStandardMaterial({ color:0xefa45b, roughness:0.65 });
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.46,0.78,4,8), suit);
  torso.rotation.x = Math.PI / 2;
  torso.position.y = 0.02;
  group.add(torso);
  const chest = new THREE.Mesh(new THREE.BoxGeometry(0.52,0.38,0.22), dark);
  chest.position.set(0,0.12,-0.36); group.add(chest);
  const helmet = new THREE.Mesh(new THREE.SphereGeometry(0.39,12,10), suit);
  helmet.position.set(0,0.88,-0.04); group.add(helmet);
  const face = new THREE.Mesh(new THREE.SphereGeometry(0.29,12,9), visor);
  face.scale.set(1.1,0.72,0.58); face.position.set(0,0.91,-0.31); group.add(face);
  const tank = new THREE.Mesh(new THREE.CylinderGeometry(0.17,0.19,0.94,8), accent);
  tank.position.set(0,0.02,0.42); group.add(tank);
  const armGeo = new THREE.CapsuleGeometry(0.105,0.48,3,6);
  for (const x of [-0.5,0.5]) {
    const arm = new THREE.Mesh(armGeo,suit);
    arm.position.set(x,0.02,-0.02); arm.rotation.z = x < 0 ? -0.22 : 0.22; group.add(arm);
    const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.12,0.52,3,6),dark);
    leg.position.set(x*0.34,-0.66,0.08); group.add(leg);
    const fin = new THREE.Mesh(new THREE.BoxGeometry(0.22,0.09,0.5),accent);
    fin.position.set(x*0.34,-1.03,-0.1); group.add(fin);
  }
  const labelCanvas = document.createElement('canvas');
  labelCanvas.width = 512; labelCanvas.height = 128;
  const ctx = labelCanvas.getContext('2d');
  ctx.fillStyle = 'rgba(3,21,32,0.78)'; ctx.fillRect(16,28,480,74);
  ctx.strokeStyle = 'rgba(111,231,221,0.85)'; ctx.lineWidth = 4; ctx.strokeRect(16,28,480,74);
  ctx.font = '600 34px Arial'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#e4fffb';
  ctx.fillText(String(displayName || 'Diver').slice(0,24),256,66,450);
  const labelTexture = new THREE.CanvasTexture(labelCanvas);
  const label = new THREE.Sprite(new THREE.SpriteMaterial({ map:labelTexture, transparent:true, depthTest:false }));
  label.position.set(0,1.72,0); label.scale.set(2.2,0.55,1); group.add(label);
  group.scale.setScalar(0.92);
  group.visible = false;
  scene.add(group);
  return { userId, group, labelTexture, target:new THREE.Vector3(), targetYaw:0, lastSeen:Date.now(), initialized:false };
}

function updateRemoteDiver(state) {
  if (!gameActive || !state?.userId || state.userId === online.userId || !scene) return;
  let diver = remoteDivers.get(state.userId);
  if (!diver) {
    diver = makeRemoteDiver(state.userId, state.displayName);
    remoteDivers.set(state.userId, diver);
  }
  diver.target.set(state.x,state.y,state.z);
  diver.targetYaw = state.yaw;
  if (!diver.initialized) {
    diver.group.position.copy(diver.target);
    diver.group.rotation.y = diver.targetYaw;
    diver.initialized = true;
  }
  diver.lastSeen = Date.now();
  diver.group.visible = true;
  diver.group.userData.biome = state.biome;
  diver.group.userData.tool = state.tool;
  diver.group.userData.lastDepth = state.depth;
}

function updateRemoteDiverVisuals(dt) {
  for (const [userId, diver] of remoteDivers) {
    if (Date.now() - diver.lastSeen > 12000) {
      scene?.remove(diver.group); diver.labelTexture?.dispose(); disposeObjectTree(diver.group); remoteDivers.delete(userId); continue;
    }
    const blend = 1 - Math.exp(-Math.min(dt,0.08) * 8);
    diver.group.position.lerp(diver.target,blend);
    diver.group.rotation.y += wrapAngle(diver.targetYaw - diver.group.rotation.y) * blend;
  }
}

function clearRemoteDivers() {
  for (const diver of remoteDivers.values()) {
    scene?.remove(diver.group);
    diver.labelTexture?.dispose();
    disposeObjectTree(diver.group);
  }
  remoteDivers.clear();
}


function islandData(ix, iz) {
  const spacing = 280;
  if (ix === 0 && iz === 0) return { x: islandOfInterest.x, z: islandOfInterest.z, radius: 88, height: 27 };
  const rx = hash2(ix + 39, iz - 7);
  const rz = hash2(ix - 15, iz + 61);
  return {
    x: ix * spacing + (rx - 0.5) * 92,
    z: iz * spacing + (rz - 0.5) * 92,
    radius: 54 + hash2(ix + 7, iz + 91) * 34,
    height: 15 + hash2(ix - 55, iz + 8) * 18
  };
}
function heightAt(x, z) {
  const seaFloor = seaFloorDepth(x, z);
  const trenchWeight = trenchInfluenceAt(x, z);
  const gx = Math.round(x / 280), gz = Math.round(z / 280);
  let height = seaFloor;
  for (let ix = gx - 1; ix <= gx + 1; ix++) {
    for (let iz = gz - 1; iz <= gz + 1; iz++) {
      const island = islandData(ix, iz);
      const dx = (x - island.x) / island.radius;
      const dz = (z - island.z) / (island.radius * (0.78 + hash2(ix + 8, iz + 3) * 0.36));
      const q = Math.sqrt(dx * dx + dz * dz);
      // Do not let the procedural island pass raise the authored trench basin.
      const blend = smoothstep(1.13, 0.86, q) * (1 - trenchWeight);
      if (blend > 0) {
        const hill = 2.4 + Math.pow(Math.max(0, 1 - q), 0.66) * island.height + valueNoise(x * 0.1, z * 0.1) * 2.3;
        height = Math.max(height, lerp(seaFloor, hill, blend));
      }
    }
  }
  // Historic thermal basins retain their exact radial floor profile. New remote
  // cave networks carve a continuous, gently tapered floor corridor and chamber.
  for (const cave of CAVE_SITES) {
    const caveProfile = getCaveCarveProfile(x, z, cave);
    if (caveProfile.strength > 0) height -= caveProfile.carveDepth;
  }
  return height;
}

function distance2D(x1, z1, x2, z2) { return Math.hypot(x1 - x2, z1 - z2); }
function getBiomeAt(x, y, z) {
  const depth = Math.max(0, -y);
  const wreckDistance = distance2D(x, z, shipOfInterest.x, shipOfInterest.z);
  const trenchDistance = distance2D(x, z, ABYSSAL_TRENCH.x, ABYSSAL_TRENCH.z);
  if (trenchDistance < ABYSSAL_TRENCH.outerRadius && depth > 62) return BIOME_DATA[getTrenchBiomeId(depth)] || BIOME_DATA.deep;
  if (wreckDistance < 108 && depth > 12) return BIOME_DATA.wreck;
  const ventDistance = Math.min(...BIOME_CENTERS.thermal.map(([vx, vz]) => distance2D(x, z, vx, vz)));
  if (ventDistance < 54 && depth > 19) return BIOME_DATA.thermal;
  const islandDistance = distance2D(x, z, islandOfInterest.x, islandOfInterest.z);
  if (depth < 20 && islandDistance < 178) return BIOME_DATA.reef;
  const kelpDistance = Math.min(...BIOME_CENTERS.kelp.map(([kx, kz]) => distance2D(x, z, kx, kz)));
  if (depth > 7 && depth < 34 && kelpDistance < 150) return BIOME_DATA.kelp;
  return BIOME_DATA.open;
}
function getMaxOxygen() { return oxygenTankCapacity(equipment.tankLevel || 0); }
function nearestBuiltStructure(type, maxDistance = 12) {
  let best = null;
  for (const item of placedStructures) {
    if (type && item.type !== type) continue;
    const d = Math.hypot(player.position.x - item.x, player.position.y - item.y, player.position.z - item.z);
    if (d <= maxDistance && (!best || d < best.distance)) best = { ...item, distance:d };
  }
  return best;
}


const VEHICLE_RESOURCE_KEYS = Object.keys(INVENTORY_DEFAULTS);
const VEHICLE_REPAIR_COSTS = Object.freeze({ skimmer:{titanium:2,silicone:1}, carrier:{titanium:5,silicone:2}, exosuit:{titanium:4,silicone:2} });

function getVehicleState(id) { return vehicleFleet?.[id] || null; }
function getVehicleMesh(id) { return vehicleMeshes.get(id) || null; }
function getVehicleBay(maxDistance=15) { return nearestBuiltStructure('vehicle_bay', maxDistance); }
function hasVehicleServiceAccess(id) { return Boolean(getVehicleBay(18) || (id==='carrier' && activeVehicleId==='carrier')); }
function distanceToVehicle(state) { return state ? Math.hypot(player.position.x-state.position.x, player.position.y-state.position.y, player.position.z-state.position.z) : Infinity; }
function playVehicleSfx(frequency=90, duration=0.18, type='sine', volume=0.045) {
  if (!ambientContext || ambientContext.state === 'closed') return;
  try {
    const oscillator=ambientContext.createOscillator(),gain=ambientContext.createGain();
    oscillator.type=type;oscillator.frequency.setValueAtTime(frequency,ambientContext.currentTime);
    oscillator.frequency.exponentialRampToValueAtTime(Math.max(35,frequency*.58),ambientContext.currentTime+duration);
    gain.gain.setValueAtTime(volume*(settings.volume/55),ambientContext.currentTime);
    gain.gain.exponentialRampToValueAtTime(.0001,ambientContext.currentTime+duration);
    oscillator.connect(gain);gain.connect(sfxBus||ambientContext.destination);oscillator.start();oscillator.stop(ambientContext.currentTime+duration);
  } catch { /* Device audio may be unavailable while the app is backgrounded. */ }
}

function createProfiledHullGeometry(profile, radialSegments=32, subdivisions=4) {
  const sections=Array.isArray(profile?.hullSections)&&profile.hullSections.length>=2?profile.hullSections:[[-1,.1,.1],[-.5,.8,.75],[0,1,1],[.6,.78,.72],[1,.1,.1]];
  const samples=[];
  for(let i=0;i<sections.length-1;i++){
    const a=sections[i],b=sections[i+1];
    for(let step=0;step<subdivisions;step++){
      const t=step/subdivisions;
      samples.push([THREE.MathUtils.lerp(a[0],b[0],t),THREE.MathUtils.lerp(a[1],b[1],t),THREE.MathUtils.lerp(a[2],b[2],t)]);
    }
  }
  samples.push(sections[sections.length-1]);
  const positions=[],uvs=[],indices=[];
  for(let ring=0;ring<samples.length;ring++){
    const [z,width,height]=samples[ring];
    for(let segment=0;segment<=radialSegments;segment++){
      const angle=segment/radialSegments*Math.PI*2;
      const dorsalBias=Math.sin(angle)>0?1.025:.985;
      positions.push(Math.cos(angle)*profile.width*.5*width,Math.sin(angle)*profile.height*.5*height*dorsalBias,z*profile.length*.5);
      uvs.push(segment/radialSegments,ring/(samples.length-1));
    }
  }
  for(let ring=0;ring<samples.length-1;ring++)for(let segment=0;segment<radialSegments;segment++){
    const a=ring*(radialSegments+1)+segment,b=a+1,c=a+radialSegments+1,d=c+1;
    indices.push(a,b,c,b,d,c);
  }
  const geometry=new THREE.BufferGeometry();
  geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
  geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));
  geometry.setIndex(indices);geometry.computeVertexNormals();geometry.computeBoundingSphere();
  return geometry;
}

function createVehicleMesh(id) {
  const definition=VEHICLE_DEFS[id];if(!definition||!scene)return null;
  const root=new THREE.Group();root.name=`Vehicle_${id}`;root.userData.vehicleId=id;
  const hull=new THREE.MeshStandardMaterial({color:id==='carrier'?0xc5d5d3:id==='exosuit'?0xb8c7c6:0xcbd9d7,map:metalTexture,bumpMap:metalBumpTexture,bumpScale:.075,metalness:.64,roughness:.4});
  const dark=new THREE.MeshStandardMaterial({color:0x142f3b,map:metalTexture,bumpMap:metalBumpTexture,bumpScale:.035,metalness:.72,roughness:.48});
  const trim=new THREE.MeshStandardMaterial({color:0xe38b46,metalness:.36,roughness:.48});
  const glow=new THREE.MeshStandardMaterial({color:0x8ffaf0,emissive:0x31c9d5,emissiveIntensity:1.65,roughness:.2,metalness:.2});
  const glass=new THREE.MeshPhysicalMaterial({color:0x5bb5c2,emissive:0x103d53,emissiveIntensity:.24,metalness:.1,roughness:.12,transparent:true,opacity:.72,transmission:.12,thickness:.2});
  const parts={props:[],legs:[],arms:[],lights:[],drill:null,grapple:null,sonar:null};
  const visualProfile=getVehicleVisualProfile(id);
  root.userData.visualProfile=visualProfile;
  root.userData.authoredDimensions=definition.dimensions;
  const mesh=(parent,geo,mat,pos=[0,0,0],rot=[0,0,0],scale=null,name='')=>{const m=new THREE.Mesh(geo,mat);m.position.set(...pos);m.rotation.set(...rot);if(scale)m.scale.set(...scale);m.name=name;m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;};
  const light=(pos,color=0x79f5ef)=>{const lamp=new THREE.PointLight(color,1.8,18,2);lamp.position.set(...pos);root.add(lamp);parts.lights.push(lamp);return lamp;};
  if(id==='skimmer'){
    const body=mesh(root,createProfiledHullGeometry(visualProfile,36,4),hull,[0,0,0],[0,0,0],null,'SkimmerPressureHull');
    body.userData.authoredSilhouette='hydrodynamic-skimmer';
    for(const z of [-1.32,-.34,.72]){const band=mesh(root,new THREE.TorusGeometry(.83,.045,7,28),trim,[0,0,z],[0,0,0],[1,1.04,1],'SkimmerPressureBand');}
    mesh(root,new THREE.SphereGeometry(.82,20,14),glass,[0,.32,-1.08],[0,0,0],[.92,.68,.58],'PilotCanopy');
    mesh(root,new THREE.BoxGeometry(1.6,.14,.32),trim,[0,-.44,-.05],[0,0,0],null,'LowerKeel');
    for(const side of [-1,1]){
      mesh(root,new THREE.BoxGeometry(.16,.34,1.15),dark,[side*1.03,-.05,.3],[0,0,side*.12],null,'StabilizerFin');
      mesh(root,new THREE.CylinderGeometry(.22,.28,.48,16),dark,[side*.52,-.05,1.52],[Math.PI/2,0,0],null,'ThrusterHousing');
      const rotor=new THREE.Group();rotor.position.set(side*.52,-.05,1.79);root.add(rotor);
      mesh(rotor,new THREE.TorusGeometry(.19,.045,8,18),glow,[0,0,0],[Math.PI/2,0,0],null,'ThrusterRing');
      for(let b=0;b<4;b++)mesh(rotor,new THREE.BoxGeometry(.055,.36,.055),trim,[0,0,0],[0,0,b*Math.PI/2],[1,1,.8],'ThrusterBlade');
      parts.props.push(rotor);light([side*.65,.05,-1.15],0x7fefff);
    }
    mesh(root,new THREE.BoxGeometry(.36,.08,.08),glow,[0,.48,-1.16]);
    parts.sonar=mesh(root,new THREE.TorusGeometry(.25,.045,8,24),glow,[0,.44,-1.26],[Math.PI/2,0,0]);
  } else if(id==='carrier'){
    const carrierHull=mesh(root,createProfiledHullGeometry(visualProfile,40,5),hull,[0,0,0],[0,0,0],null,'CarrierPressureHull');
    carrierHull.userData.authoredSilhouette='long-range-pressure-submarine';
    for(const z of [-6.2,-3.7,-.8,2.6,5.7]){const pressureBand=mesh(root,new THREE.TorusGeometry(2.05,.072,8,36),trim,[0,0,z],[0,0,0],[1.12,1.02,1],'CarrierPressureBand');}
    mesh(root,new THREE.SphereGeometry(1.55,24,16),hull,[0,0,-7.25],[0,0,0],[.16,.22,.20],'ReinforcedBowCap');
    mesh(root,new THREE.SphereGeometry(1.65,22,14,0,Math.PI*2,0,Math.PI/2),glass,[0,1.05,-4.2],[0,0,0],[1.08,.65,.72],'CommandBridge');
    mesh(root,new THREE.BoxGeometry(4.4,.28,5.8),dark,[0,-1.75,.15]);
    for(const side of [-1,1]){
      mesh(root,new THREE.CapsuleGeometry(.62,4.6,5,12),dark,[side*2.35,-.05,.6],[Math.PI/2,0,0],null,'CargoPontoons');
      mesh(root,new THREE.BoxGeometry(.12,.55,3.4),trim,[side*2.82,.52,-.15]);
      for(let w=0;w<4;w++)mesh(root,new THREE.BoxGeometry(.045,.3,.44),glow,[side*2.52,.48,-2.5+w*1.45]);
      const prop=new THREE.Group();prop.position.set(side*.86,-.08,5.85);root.add(prop);
      mesh(prop,new THREE.TorusGeometry(.56,.095,8,24),glow,[0,0,0],[Math.PI/2,0,0]);
      for(let blade=0;blade<5;blade++)mesh(prop,new THREE.BoxGeometry(.18,1.0,.12),trim,[0,0,0],[0,0,blade*Math.PI*2/5],[1,1,1]);
      parts.props.push(prop);
      light([side*1.62,.68,-4.8],0xffc27a);
    }
    for(let i=0;i<5;i++)mesh(root,new THREE.BoxGeometry(.5,.36,.12),glass,[-1.25+i*.62,1.05,-5.15]);
    parts.sonar=mesh(root,new THREE.TorusGeometry(1.1,.065,8,32),glow,[0,1.9,-4.55],[Math.PI/2,0,0]);
    mesh(root,new THREE.BoxGeometry(.65,.16,2.1),trim,[0,2.02,.5]);
  } else if(id==='exosuit'){
    mesh(root,new THREE.BoxGeometry(1.55,1.75,.9),hull,[0,.4,0],null,null,'ExosuitTorso');
    mesh(root,new THREE.SphereGeometry(.64,20,14),glass,[0,1.38,-.12],[0,0,0],[1,.72,.74],'PilotDome');
    mesh(root,new THREE.BoxGeometry(1.12,.18,.72),trim,[0,-.52,.02]);
    const frontArmorMesh=mesh(root,new THREE.BoxGeometry(1.26,.72,.20),trim,[0,.48,-.48],[0,0,0],null,'UpperFrontArmorPanel');
    mesh(root,new THREE.BoxGeometry(.82,.46,.07),dark,[0,.52,-.60]);
    mesh(root,new THREE.BoxGeometry(.30,.12,.06),glow,[0,.58,-.65]);
    for(const side of [-1,1]){
      const shoulder=mesh(root,new THREE.SphereGeometry(.46,16,12),hull,[side*.98,.87,.02],[0,0,0],[1.18,.72,1.08],'ShoulderArmor');
      const shoulderPad=mesh(root,new THREE.BoxGeometry(.52,.34,.76),trim,[side*1.02,.93,-.05],[0,0,side*.16]);
      const hydraulic=new THREE.Mesh(new THREE.CylinderGeometry(.075,.075,.86,10),trim);hydraulic.position.set(side*.68,-.72,.12);hydraulic.rotation.z=side*.12;root.add(hydraulic);
    }
    for(const side of [-1,1]){
      const leg=new THREE.Group();leg.position.set(side*.52,-.55,.05);root.add(leg);
      mesh(leg,new THREE.CapsuleGeometry(.23,.82,5,12),dark,[0,-.56,0],[0,0,side*.08]);
      mesh(leg,new THREE.BoxGeometry(.56,.27,.9),hull,[0,-1.12,-.15]);
      mesh(leg,new THREE.BoxGeometry(.64,.55,.18),trim,[0,-.86,-.58],[side*.06,0,0]);
      mesh(leg,new THREE.CylinderGeometry(.28,.28,.13,16),glow,[0,-.15,0],[Math.PI/2,0,0]);
      const kneeGuard=mesh(leg,new THREE.SphereGeometry(.30,14,10),dark,[0,-.15,-.42],[0,0,0],[1,.82,.55]);
      parts.legs.push(leg);
      const arm=new THREE.Group();arm.position.set(side*.95,.8,-.04);root.add(arm);
      mesh(arm,new THREE.CapsuleGeometry(.19,.75,5,12),hull,[side*.12,-.34,0],[0,0,-side*.16]);
      mesh(arm,new THREE.SphereGeometry(.24,14,10),dark,[side*.25,-.78,-.1]);
      mesh(arm,new THREE.BoxGeometry(.44,.58,.25),trim,[side*.22,-.34,-.18],[0,0,-side*.14]);
      const elbow=mesh(arm,new THREE.TorusGeometry(.21,.055,8,18),glow,[side*.25,-.78,-.1],[Math.PI/2,0,0]);
      parts.arms.push(arm);
      light([side*.58,1.22,-.62],0x80f6eb);
    }
    const drill=new THREE.Group();drill.position.set(-1.2,.1,-.18);root.add(drill);
    mesh(drill,new THREE.CylinderGeometry(.22,.36,.85,12),dark,[0,-.44,-.2],[Math.PI/2,0,0]);
    mesh(drill,new THREE.ConeGeometry(.28,.72,8),trim,[0,-.44,-.88],[Math.PI/2,0,0]);
    const drillRotor=mesh(drill,new THREE.TorusGeometry(.25,.065,8,20),glow,[0,-.44,-.56],[Math.PI/2,0,0]);
    drill.userData.rotor=drillRotor;parts.drill=drill;
    const grapple=new THREE.Group();grapple.position.set(1.2,.05,-.15);root.add(grapple);
    mesh(grapple,new THREE.CylinderGeometry(.18,.25,.72,12),dark,[0,-.28,-.12],[Math.PI/2,0,0]);
    for(let claw=0;claw<3;claw++){const a=claw*Math.PI*2/3;mesh(grapple,new THREE.CapsuleGeometry(.075,.42,4,8),trim,[Math.cos(a)*.16,-.34,-.55],[Math.sin(a)*.25,0,a]);}
    parts.grapple=grapple;
  }
  const shadowPad=mesh(root,new THREE.CylinderGeometry(id==='carrier'?2.2:.75,id==='carrier'?2.2:.75,.08,24),dark,[0,-definition.dimensions.clearance*.65,0]);shadowPad.material=dark;
  root.userData.parts=parts;root.userData.definition=definition;root.userData.phase=hash2(id.length,definition.baseDepth)*Math.PI*2;
  root.traverse(o=>{if(o.isMesh){o.frustumCulled=true;o.userData.vehiclePart=true;}});
  return root;
}

function syncVehicleMeshes() {
  for(const [id,mesh] of vehicleMeshes){
    if(!vehicleFleet[id]?.deployed){scene?.remove(mesh);disposeObjectTree(mesh);vehicleMeshes.delete(id);}
  }
  for(const id of VEHICLE_IDS){
    const state=vehicleFleet[id];if(!state?.owned||!state.deployed)continue;
    let mesh=vehicleMeshes.get(id);
    if(!mesh){mesh=createVehicleMesh(id);if(!mesh)continue;scene.add(mesh);vehicleMeshes.set(id,mesh);}
    mesh.position.set(state.position.x,state.position.y,state.position.z);mesh.rotation.y=state.yaw;
    mesh.userData.health=state.health;mesh.userData.power=state.power;
  }
  if(activeVehicleId&&!vehicleFleet[activeVehicleId]?.deployed)activeVehicleId=null;
  if(viewModel)viewModel.visible=gameActive&&!activeVehicleId;
}

function updateVehicleVisuals(dt) {
  for(const [id,mesh] of vehicleMeshes){
    const state=vehicleFleet[id];if(!state?.deployed)continue;
    const parts=mesh.userData.parts||{};mesh.userData.phase+=dt;
    for(const prop of parts.props||[])prop.rotation.z+=dt*(id==='carrier'?5.2:13.5)*(state.power>0?1:.35);
    for(const lamp of parts.lights||[])lamp.intensity=(state.power>0?1.25:.22)+Math.sin(clockState.elapsed*2.4+mesh.userData.phase)*.12;
    if(parts.sonar)parts.sonar.rotation.z+=dt*(id==='carrier'?.28:.52);
    if(id==='exosuit'){
      const moving=activeVehicleId==='exosuit'&&activeVehicleVelocity.length()>.2;
      (parts.legs||[]).forEach((leg,index)=>{leg.rotation.x=moving?Math.sin(clockState.elapsed*5+index*Math.PI)*.20:Math.sin(clockState.elapsed*1.2+index)*.012;});
      if(parts.drill?.userData.rotor)parts.drill.userData.rotor.rotation.z+=dt*(vehicleActionFlash>0?18:1.2);
    }
    const healthRatio=state.health/Math.max(1,getVehicleMaxHealth(id,state));
    mesh.scale.setScalar(1+(1-healthRatio)*.012);
  }
  vehicleActionFlash=Math.max(0,vehicleActionFlash-dt);
  vehicleSpecialCooldown=Math.max(0,vehicleSpecialCooldown-dt);
  for(let i=vehicleSonarWaves.length-1;i>=0;i--){
    const wave=vehicleSonarWaves[i];wave.age+=dt;const t=wave.age/wave.duration;wave.mesh.scale.setScalar(.3+t*wave.maxScale);wave.material.opacity=(1-t)*.5;
    if(t>=1){scene.remove(wave.mesh);wave.mesh.geometry.dispose();wave.material.dispose();vehicleSonarWaves.splice(i,1);}
  }
}

function getAimedVehicleTarget(maxDistance=12) {
  if(activeVehicleId)return null;
  const pitch=clamp(player.pitch,-1.1,1.1);
  const direction=new THREE.Vector3(Math.sin(player.yaw)*Math.cos(pitch),-Math.sin(pitch),-Math.cos(player.yaw)*Math.cos(pitch)).normalize();
  const origin=new THREE.Vector3(player.position.x,player.position.y+.55,player.position.z);
  let best=null;
  for(const id of VEHICLE_IDS){const state=vehicleFleet[id];if(!state?.deployed)continue;const center=new THREE.Vector3(state.position.x,state.position.y,state.position.z);const delta=center.clone().sub(origin);const distance=delta.length();if(distance>maxDistance||distance<.1)continue;const along=delta.dot(direction);if(along<0||along>maxDistance)continue;const lateral=delta.addScaledVector(direction,-along).length();const radius=VEHICLE_DEFS[id].dimensions.width*.72+.9;if(lateral>radius)continue;if(!best||distance<best.distance)best={id,state,distance,center};}
  return best;
}

function renderVehicleBay() {
  const root=$('vehicle-fleet-list');if(!root)return;root.replaceChildren();
  const bay=getVehicleBay(18);
  const status=$('vehicle-bay-status');
  if(status)status.textContent=bay?`PLATFORM ONLINE · ${Math.round(Math.max(0,-bay.y))} M · ${VEHICLE_IDS.filter(id=>vehicleFleet[id]?.owned).length}/3 VEHICLES OWNED`:activeVehicleId==='carrier'?'CARRIER COMMAND DECK · MOBILE CARGO ACCESS': 'VEHICLE BAY DISCONNECTED';
  const mobileDeck=activeVehicleId==='carrier';
  const panelTitle=$('vehicle-bay-title'),panelHint=$('vehicle-bay-hint');
  if(panelTitle)panelTitle.textContent=mobileDeck?'Carrier Command Deck':'Vehicle Fabrication Bay';
  if(panelHint)panelHint.textContent=mobileDeck?'Akses kompartemen kargo kapal selam bergerak. Fabrikasi dan upgrade tetap memerlukan Vehicle Bay di habitat.':'Rakit, luncurkan, tingkatkan, isi daya, dan rawat armada ekspedisi. Posisi, upgrade, energi, hull, serta kargo disimpan pada slot lokal.';
  for(const id of VEHICLE_IDS){
    const def=VEHICLE_DEFS[id],state=vehicleFleet[id]||createVehicleState(id);
    const card=document.createElement('article');card.className='vehicle-card';card.dataset.owned=String(state.owned);
    const title=document.createElement('h3');title.textContent=def.name;
    const role=document.createElement('small');role.className='vehicle-role';role.textContent=def.role;
    const desc=document.createElement('p');desc.className='vehicle-description';desc.textContent=def.description;
    const stats=document.createElement('div');stats.className='vehicle-stat-grid';
    const depth=getVehicleDepthRating(id,state),health=Math.round(state.health),power=Math.round(state.power),cargo=`${getVehicleCargoUsed(state)}/${getVehicleCargoCapacity(id,state)}`;
    for(const [label,value] of [['SAFE DEPTH',`${depth} m`],['HULL',`${health}/${Math.round(getVehicleMaxHealth(id,state))}`],['POWER',`${power}%`],['CARGO',cargo]]){const cell=document.createElement('div');cell.className='vehicle-stat';const small=document.createElement('small');small.textContent=label;const strong=document.createElement('strong');strong.textContent=value;cell.append(small,strong);stats.append(cell);}
    const actions=document.createElement('div');actions.className='vehicle-card-actions';
    const button=(label,handler,disabled=false,primary=false)=>{const b=document.createElement('button');b.type='button';b.textContent=label;b.disabled=disabled;if(primary)b.classList.add('primary');b.addEventListener('click',handler);actions.append(b);return b;};
    if(!state.owned)button('FABRICATE',()=>craftVehicle(id),!bay||!canAfford(def.craftCost),true);
    else if(!state.deployed)button('LAUNCH',()=>deployVehicle(id),!bay,true);
    else if(activeVehicleId===id)button('PILOTING',()=>{},true,true);
    else button('RETRIEVE',()=>retrieveVehicle(id),distanceToVehicle(state)>24,true);
    if(state.owned){
      button('RECHARGE',()=>rechargeVehicle(id),state.power>=def.maxPower||!canAfford({power_cell:1}));
      button('REPAIR',()=>repairVehicle(id),state.health>=getVehicleMaxHealth(id,state)||!canAfford(VEHICLE_REPAIR_COSTS[id]));
    }
    card.append(title,role,desc,stats,actions);
    if(state.owned){
      const upgrades=document.createElement('div');upgrades.className='vehicle-upgrade-list';
      for(const [upgradeId,upgrade] of Object.entries(VEHICLE_UPGRADES[id])){
        const row=document.createElement('div');row.className='vehicle-upgrade-row';const textNode=document.createElement('span');
        const installed=upgrade.depthLevel?state.upgrades.depth>=upgrade.depthLevel:state.upgrades[upgrade.flag]===true;
        textNode.textContent=`${upgrade.label} · ${Object.entries(upgrade.cost).map(([key,value])=>`${value} ${RESOURCE_LABELS[key]||key}`).join(', ')}`;
        const install=document.createElement('button');install.type='button';install.textContent=installed?'INSTALLED':'INSTALL';
        install.disabled=installed||!canInstallVehicleUpgrade(id,state,upgradeId)||!canAfford(upgrade.cost)||!bay;
        install.addEventListener('click',()=>installVehicleUpgrade(id,upgradeId));row.append(textNode,install);upgrades.append(row);
      }
      card.append(upgrades);
      const cargoActions=document.createElement('div');cargoActions.className='vehicle-cargo-actions';
      const store=document.createElement('button');store.type='button';store.textContent='STORE MATERIALS';store.disabled=!state.upgrades.storage||getVehicleCargoUsed(state)>=getVehicleCargoCapacity(id,state)||!hasVehicleServiceAccess(id);store.addEventListener('click',()=>transferMaterialsToVehicle(id));
      const take=document.createElement('button');take.type='button';take.textContent='TAKE MATERIALS';take.disabled=getVehicleCargoUsed(state)<=0||!hasVehicleServiceAccess(id);take.addEventListener('click',()=>transferMaterialsFromVehicle(id));cargoActions.append(store,take);card.append(cargoActions);
    }
    root.append(card);
  }
}

function openVehicleBay() {
  if(!gameActive){return;}
  const mobileCarrierAccess=activeVehicleId==='carrier';
  if(activeVehicleId&&!mobileCarrierAccess){showToast('Keluar dari kendaraan ini sebelum membuka panel armada.');return;}
  if(!getVehicleBay(18)&&!mobileCarrierAccess){showToast('Dekati Vehicle Fabrication Bay yang sudah dibangun.');return;}
  gamePaused=true;renderVehicleBay();setVisibleScreen('vehicle');
}

function craftVehicle(id) {
  const def=VEHICLE_DEFS[id],state=vehicleFleet[id];
  if(!def||!state||state.owned||!getVehicleBay(18)){showToast('Vehicle Bay belum siap atau kendaraan sudah dimiliki.');return;}
  if(!canAfford(def.craftCost)){showToast('Material untuk kendaraan belum mencukupi.');return;}
  spendResources(def.craftCost);state.owned=true;state.deployed=false;state.health=def.maxHealth;state.power=def.maxPower;
  renderInventory();renderVehicleBay();markUnsaved();playSfx('craft');showToast(`${def.name} selesai dirakit. Luncurkan melalui Vehicle Bay.`);
}

function deployVehicle(id) {
  const state=vehicleFleet[id],def=VEHICLE_DEFS[id],bay=getVehicleBay(18);
  if(!state?.owned||state.deployed||!def||!bay||activeVehicleId)return;
  if(state.health<=0||state.power<=0){showToast('Kendaraan harus diperbaiki dan diisi daya sebelum diluncurkan.');return;}
  const yaw=Number(bay.yaw)||0;const x=bay.x+Math.cos(yaw)*9+Math.sin(yaw)*3;const z=bay.z-Math.sin(yaw)*9+Math.cos(yaw)*3;
  const floor=sampleVehicleFloor(id,x,z,yaw);const y=floor+def.dimensions.clearance+1.2;
  if(y>waterSurfaceHeightAt(x,z,clockState.elapsed)-def.dimensions.height*.48){showToast('Area peluncuran terlalu dangkal. Bangun Vehicle Bay di dasar laut yang lebih dalam.');return;}
  if(vehicleBlocksPosition(id,x,y,z)){showToast('Area peluncuran terhalang struktur, wreck, atau kendaraan lain. Kosongkan ruang di depan Vehicle Bay.');return;}
  state.deployed=true;state.position={x,y,z};state.yaw=yaw;syncVehicleMeshes();renderVehicleBay();markUnsaved();playVehicleSfx(115,.32,'triangle',.07);showToast(`${def.name} diluncurkan. Bidik kendaraan dan tekan Interact untuk masuk.`);
}

function retrieveVehicle(id) {
  const state=vehicleFleet[id];if(!state?.deployed||activeVehicleId===id)return;
  if(distanceToVehicle(state)>24){showToast('Dekati kendaraan sebelum menariknya kembali ke Vehicle Bay.');return;}
  state.deployed=false;scene?.remove(vehicleMeshes.get(id));if(vehicleMeshes.has(id)){disposeObjectTree(vehicleMeshes.get(id));vehicleMeshes.delete(id);}renderVehicleBay();markUnsaved();playVehicleSfx(80,.25,'sine',.05);showToast('Kendaraan berhasil ditarik kembali ke Vehicle Bay.');
}

function enterVehicle(id) {
  const state=vehicleFleet[id],def=VEHICLE_DEFS[id],target=getAimedVehicleTarget(13);
  if(!state?.deployed||!def||!target||target.id!==id){showToast('Arahkan reticle ke badan kendaraan dalam jangkauan.');return;}
  if(state.health<=0){showToast('Kendaraan rusak berat. Perbaiki melalui Vehicle Bay.');return;}
  if(state.power<=0){showToast('Daya kendaraan habis. Kembali ke Vehicle Bay untuk mengisi Power Cell.');return;}
  cancelPendingKnifeAttack();activeVehicleId=id;activeVehicleVelocity.set(0,0,0);player.position.set(state.position.x,state.position.y,state.position.z);player.velocity.set(0,0,0);player.yaw=state.yaw;player.pitch=0.02;
  if(viewModel)viewModel.visible=false;document.body.classList.add('vehicle-active-hud');syncVehicleHudActions();playVehicleSfx(155,.22,'triangle',.055);markUnsaved();showToast(`Mengendalikan ${def.name}. Gunakan joystick, kamera, dan tombol naik/turun.`);
}

function exitActiveVehicle() {
  if(!activeVehicleId)return true;
  const id=activeVehicleId,state=vehicleFleet[id],def=VEHICLE_DEFS[id];
  if(!state||!def)return false;
  const forwardX=Math.sin(state.yaw),forwardZ=-Math.cos(state.yaw);
  const rightX=Math.cos(state.yaw),rightZ=Math.sin(state.yaw);
  const side=def.dimensions.width*.5+1.55,front=def.dimensions.length*.5+1.25;
  const offsets=[[rightX*side,rightZ*side],[-rightX*side,-rightZ*side],[forwardX*front,forwardZ*front],[-forwardX*front,-forwardZ*front]];
  for(const radius of [Math.max(side,front)*.72+1.2,Math.max(side,front)+2.0,Math.max(side,front)+4.0]){
    for(let index=0;index<8;index++){const angle=state.yaw+index*Math.PI/4;offsets.push([Math.cos(angle)*radius,Math.sin(angle)*radius]);}
  }
  let safe=null;
  for(let index=0;index<offsets.length;index++){
    const [ox,oz]=offsets[index];
    const x=state.position.x+ox,z=state.position.z+oz;
    const floor=samplePlayerFloor(x,z)+1.9;
    const surface=waterSurfaceHeightAt(x,z,clockState.elapsed)-.72;
    const preferredY=state.position.y+(index>=4?1.25:0);
    const y=Math.max(floor,Math.min(preferredY,surface));
    const insideCompartment=placedStructures.some(item=>item.type==='compartment'&&Math.abs(y-item.y)<3.1&&Math.hypot(x-item.x,z-item.z)<4.0);
    const clear=!insideCompartment&&!structureBlocksPosition(x,y,z)
      && !(lifepodGroup&&lifepodHullBlocksWorld(x,y,z,lifepodGroup.position,lifepodGroup.rotation.y||0,.42,LIFEPOD_SCALE,false))
      && y>=floor-.02;
    if(clear){safe={x,y,z};break;}
  }
  if(!safe){showToast('Tidak ada ruang aman untuk keluar. Geser kendaraan ke area terbuka terlebih dahulu.');return false;}
  player.position.set(safe.x,safe.y,safe.z);player.velocity.set(0,0,0);player.yaw=state.yaw;player.pitch=.02;
  activeVehicleId=null;activeVehicleVelocity.set(0,0,0);vehicleDamageTimer=0;document.body.classList.remove('vehicle-active-hud');if(viewModel)viewModel.visible=true;
  markUnsaved();playVehicleSfx(100,.25,'sine',.045);showToast(`Keluar dari ${def.name}.`);updateInteractionPrompt();return true;
}

function installVehicleUpgrade(id,upgradeId) {
  const state=vehicleFleet[id],upgrade=VEHICLE_UPGRADES[id]?.[upgradeId];
  if(!state?.owned||!upgrade||!canInstallVehicleUpgrade(id,state,upgradeId)||!canAfford(upgrade.cost)||!getVehicleBay(18)){showToast('Upgrade tidak tersedia atau material belum mencukupi.');return;}
  spendResources(upgrade.cost);
  if(upgrade.depthLevel)state.upgrades.depth=upgrade.depthLevel;else state.upgrades[upgrade.flag]=true;
  if(upgrade.flag==='hull')state.health=Math.min(getVehicleMaxHealth(id,state),state.health+40);
  renderInventory();renderVehicleBay();syncVehicleHudActions();markUnsaved();playSfx('craft');showToast(`${upgrade.label} terpasang pada ${VEHICLE_DEFS[id].name}.`);
}

function repairVehicle(id) {
  const state=vehicleFleet[id],cost=VEHICLE_REPAIR_COSTS[id];if(!state||!state.owned||!cost||!canAfford(cost)||!getVehicleBay(18)){showToast('Material perbaikan belum cukup atau kendaraan terlalu jauh.');return;}
  spendResources(cost);state.health=getVehicleMaxHealth(id,state);renderInventory();renderVehicleBay();markUnsaved();playSfx('repair');showToast(`${VEHICLE_DEFS[id].name} diperbaiki sepenuhnya.`);
}

function rechargeVehicle(id) {
  const state=vehicleFleet[id],def=VEHICLE_DEFS[id];if(!state?.owned||!def||!canAfford({power_cell:1})||!getVehicleBay(18)){showToast('Butuh satu Power Cell dan akses ke Vehicle Bay.');return;}
  if(state.power>=def.maxPower){showToast('Daya kendaraan sudah penuh.');return;}
  inventory.power_cell-=1;state.power=def.maxPower;renderInventory();renderVehicleBay();markUnsaved();playSfx('craft');showToast(`${VEHICLE_DEFS[id].name} terisi daya penuh.`);
}

function transferMaterialsToVehicle(id) {
  const state=vehicleFleet[id];if(!state?.owned||!state.upgrades.storage||!hasVehicleServiceAccess(id)){showToast('Storage Module harus terpasang dan akses Vehicle Bay atau Carrier Command Deck tersedia.');return;}
  let moved=0;for(const key of VEHICLE_RESOURCE_KEYS){const available=inventory[key]||0;if(available<=0)continue;const accepted=addVehicleCargo(state,key,available);inventory[key]-=accepted;moved+=accepted;if(getVehicleCargoUsed(state)>=getVehicleCargoCapacity(id,state))break;}
  if(moved){renderInventory();renderVehicleBay();markUnsaved();playSfx('collect');}showToast(moved?`${moved} material dipindahkan ke kompartemen kendaraan.`:'Tidak ada material atau ruang kargo kosong.');
}

function transferMaterialsFromVehicle(id) {
  const state=vehicleFleet[id];if(!state?.owned||!hasVehicleServiceAccess(id)){showToast('Dekati Vehicle Bay atau buka Carrier Command Deck untuk memindahkan kargo.');return;}
  let moved=0;for(const key of VEHICLE_RESOURCE_KEYS){const count=state.cargo[key]||0;if(count<=0)continue;const accepted=Math.min(count,Math.max(0,999-(inventory[key]||0)));if(accepted>0&&!canFitResource(key,accepted))continue;inventory[key]=(inventory[key]||0)+accepted;state.cargo[key]-=accepted;moved+=accepted;}
  if(moved){renderInventory();renderVehicleBay();markUnsaved();playSfx('collect');}showToast(moved?`${moved} material dipindahkan ke Backpack.`:'Backpack tidak memiliki ruang untuk kargo.');
}

function spawnVehicleSonar(id) {
  const state=vehicleFleet[id],def=VEHICLE_DEFS[id];if(!state||!def||!state.upgrades.sonar||state.power<8||vehicleSpecialCooldown>0)return false;
  state.power=Math.max(0,state.power-(id==='carrier'?14:8));vehicleSpecialCooldown=7;
  const mesh=new THREE.Mesh(new THREE.TorusGeometry(1,.045,8,64),new THREE.MeshBasicMaterial({color:0x67e8ef,transparent:true,opacity:.5,depthWrite:false}));mesh.rotation.x=Math.PI/2;mesh.position.set(state.position.x,state.position.y,state.position.z);mesh.renderOrder=4;scene.add(mesh);vehicleSonarWaves.push({mesh,material:mesh.material,age:0,duration:2.2,maxScale:id==='carrier'?95:58});
  playVehicleSfx(id==='carrier'?48:95,.42,'sine',.075);markUnsaved();return true;
}

function drillVehicleResource() {
  if(activeVehicleId!=='exosuit')return false;
  const state=vehicleFleet.exosuit;if(!state?.upgrades.drill||state.power<2||vehicleSpecialCooldown>0){showToast('Mining Drill Arm belum terpasang, daya rendah, atau sedang cooldown.');return false;}
  const target=getAimedWorldTarget();if(!target||target.kind!=='resource'||target.object.type==='kelp'){showToast('Arahkan reticle ke deposit Ore yang dapat ditambang.');return false;}
  const node=resourceNodes.get(target.id);if(!node||node.breaking)return false;
  const position=node.mesh.getWorldPosition(new THREE.Vector3());const color=node.type==='copper'?0xc47b4b:node.type==='quartz'?0xb8eff0:node.type==='silver'?0xc3ced8:0x9fb2b7;
  node.breaking=true;resourceBreakActions.push({id:target.id,node,type:node.type,position,color,elapsed:0,duration:.72,baseScale:node.mesh.scale.clone(),baseRotation:node.mesh.rotation.clone(),crackBurst:false});
  state.power=Math.max(0,state.power-2);vehicleSpecialCooldown=1.1;vehicleActionFlash=.7;spawnDebrisBurst(position,color,7);playVehicleSfx(72,.32,'sawtooth',.07);showToast('Exosuit drill memecah deposit mineral...');markUnsaved();return true;
}

function activateExosuitGrapple() {
  const state=vehicleFleet.exosuit;if(!state?.upgrades.grapple||state.power<4||vehicleSpecialCooldown>0)return false;
  const pitch=clamp(player.pitch,-.8,.8);const forward=new THREE.Vector3(Math.sin(player.yaw)*Math.cos(pitch),-Math.sin(pitch),-Math.cos(player.yaw)*Math.cos(pitch)).normalize();
  activeVehicleVelocity.addScaledVector(forward,18);state.power=Math.max(0,state.power-4);vehicleSpecialCooldown=3.4;vehicleActionFlash=.5;playVehicleSfx(135,.32,'sawtooth',.06);markUnsaved();showToast('Grappling arm menarik rangka menuju arah bidikan.');return true;
}

function activateVehicleSpecial() {
  if(!activeVehicleId)return;
  const id=activeVehicleId,state=vehicleFleet[id];
  if(id==='exosuit'){
    const target=getAimedWorldTarget();if(target?.kind==='resource'&&state.upgrades.drill){drillVehicleResource();return;}
    if(state.upgrades.grapple&&activateExosuitGrapple())return;
    showToast('Pasang Drill Arm atau Grappling Arm pada Vehicle Bay untuk aksi khusus.');return;
  }
  if(!state.upgrades.sonar){showToast('Pasang Sonar Module di Vehicle Bay terlebih dahulu.');return;}
  if(!spawnVehicleSonar(id))showToast('Daya belum cukup atau sonar sedang cooldown.');else showToast('Sonar aktif · gelombang pemetaan dikirim.');
}

function syncVehicleHudActions() {
  const button=$('vehicle-special-btn');
  const panel=$('vehicle-hud-panel');
  if(!activeVehicleId){button?.classList.add('hidden');panel?.classList.add('hidden');$('vehicle-cargo-btn')?.classList.add('hidden');document.body.classList.remove('vehicle-active-hud');return;}
  const state=vehicleFleet[activeVehicleId],def=VEHICLE_DEFS[activeVehicleId];if(!state||!def)return;
  let label='SONAR',available=false;
  if(activeVehicleId==='exosuit'){
    const target=getAimedWorldTarget();label=target?.kind==='resource'&&state.upgrades.drill?'DRILL':state.upgrades.grapple?'GRAPPLE':'TOOL';available=state.health>0&&state.power>0&&Boolean(state.upgrades.drill||state.upgrades.grapple);
  }else{label='SONAR';available=state.health>0&&state.power>=8&&state.upgrades.sonar;}
  if(button){button.dataset.hudLabel=label;button.title=label;button.setAttribute('aria-label',`Aksi kendaraan ${label}`);button.classList.toggle('hidden',!available);}
  $('vehicle-cargo-btn')?.classList.toggle('hidden',activeVehicleId!=='carrier');
  if(panel){
    panel.classList.remove('hidden');
    const hullRatio=clamp(state.health/Math.max(1,getVehicleMaxHealth(activeVehicleId,state)),0,1);
    const powerRatio=clamp(state.power/Math.max(1,def.maxPower),0,1);
    $('vehicle-hud-name').textContent=def.name.toUpperCase();
    $('vehicle-hud-hull').textContent=`HULL ${Math.round(hullRatio*100)}%`;
    $('vehicle-hud-power').textContent=`POWER ${Math.round(powerRatio*100)}%`;
    $('vehicle-hud-hull-fill').style.transform=`scaleX(${hullRatio})`;
    $('vehicle-hud-power-fill').style.transform=`scaleX(${powerRatio})`;
  }
  document.body.classList.add('vehicle-active-hud');
}

function sampleVehicleFloor(id,x,z,yaw=0) {
  const def=VEHICLE_DEFS[id];if(!def)return heightAt(x,z);
  const halfL=def.dimensions.length*.34,halfW=def.dimensions.width*.36;
  const c=Math.cos(yaw),s=Math.sin(yaw);
  const points=[[0,0],[0,halfL],[0,-halfL],[halfW,0],[-halfW,0],[halfW*.58,halfL*.58],[-halfW*.58,-halfL*.58]];
  let floor=-Infinity;
  for(const [lx,lz] of points){const wx=x+lx*c+lz*s,wz=z-lx*s+lz*c;floor=Math.max(floor,heightAt(wx,wz));}
  return Number.isFinite(floor)?floor:heightAt(x,z);
}

function vehicleBlocksPosition(id,x,y,z) {
  const def=VEHICLE_DEFS[id];if(!def)return true;
  const radius=Math.max(def.dimensions.width*.48,def.dimensions.length*.24);
  const verticalHalf=def.dimensions.height*.43;
  for(const item of placedStructures){
    if(item.type==='foundation'||item.type==='vehicle_bay')continue;
    const structureRadius=item.type==='compartment'?4.0:item.type==='solar_array'?1.7:item.type==='storage_locker'?.9:.72;
    const structureHalf=item.type==='compartment'?3.1:item.type==='solar_array'?1.4:.9;
    if(Math.abs(y-item.y)<verticalHalf+structureHalf && Math.hypot(x-item.x,z-item.z)<radius+structureRadius)return true;
  }
  for(const otherId of VEHICLE_IDS){
    if(otherId===id)continue;
    const other=vehicleFleet[otherId];if(!other?.deployed)continue;
    const otherDef=VEHICLE_DEFS[otherId];
    const otherRadius=Math.max(otherDef.dimensions.width*.48,otherDef.dimensions.length*.24);
    if(Math.abs(y-other.position.y)<verticalHalf+otherDef.dimensions.height*.43&&Math.hypot(x-other.position.x,z-other.position.z)<radius+otherRadius)return true;
  }
  if(lifepodGroup&&lifepodHullBlocksWorld(x,y,z,lifepodGroup.position,lifepodGroup.rotation.y||0,radius,LIFEPOD_SCALE,false))return true;
  const wreckDx=x-shipOfInterest.x,wreckDz=z-shipOfInterest.z,wreckAngle=.72;
  const wreckX=wreckDx*Math.cos(wreckAngle)-wreckDz*Math.sin(wreckAngle);
  const wreckZ=wreckDx*Math.sin(wreckAngle)+wreckDz*Math.cos(wreckAngle);
  if(Math.abs(y+37)<verticalHalf+4.2&&Math.abs(wreckX)<16.5+radius&&Math.abs(wreckZ)<4.7+radius*.55)return true;
  for(const cache of supplyCacheLocations){if(Math.abs(y-cache.y)<verticalHalf+1.5&&Math.abs(x-cache.x)<1.85+radius*.6&&Math.abs(z-cache.z)<1.45+radius*.6)return true;}
  return false;
}

function updateVehicleMovement(dt) {
  const id=activeVehicleId,state=vehicleFleet[id],def=VEHICLE_DEFS[id];if(!state?.deployed||!def){exitActiveVehicle();return;}
  if(state.health<=0){
    activeVehicleVelocity.set(0,0,0);player.velocity.set(0,0,0);
    if(exitActiveVehicle())showToast(`${def.name} tidak dapat dikendalikan. Perbaiki di Vehicle Bay.`);
    return;
  }
  const keyForward=(input.keys.has('KeyW')||input.keys.has('ArrowUp')?1:0)-(input.keys.has('KeyS')||input.keys.has('ArrowDown')?1:0);
  const keyStrafe=(input.keys.has('KeyD')||input.keys.has('ArrowRight')?1:0)-(input.keys.has('KeyA')||input.keys.has('ArrowLeft')?1:0);
  const forward=clamp(keyForward-input.joyY,-1,1),strafe=clamp(keyStrafe+input.joyX,-1,1),vertical=clamp(input.vertical,-1,1);
  const moving=Math.abs(forward)+Math.abs(strafe)+Math.abs(vertical)>.04;
  const next=integrateVehicleMotion({id,state,position:state.position,velocity:activeVehicleVelocity,yaw:state.yaw,pitch:player.pitch,forward,strafe,vertical,dt});
  const localBiome=getBiomeAt(state.position.x,state.position.y,state.position.z);
  const flow=sampleOceanCurrent(state.position.x,state.position.y,state.position.z,clockState.elapsed,localBiome.id);
  const flowResponse=getVehicleCurrentResponse(id);
  next.velocity.x+=flow.x*flowResponse*dt;
  next.velocity.y+=flow.y*flowResponse*dt;
  next.velocity.z+=flow.z*flowResponse*dt;
  next.position.x+=flow.x*flowResponse*dt*dt;
  next.position.y+=flow.y*flowResponse*dt*dt;
  next.position.z+=flow.z*flowResponse*dt*dt;
  const floor=sampleVehicleFloor(id,next.position.x,next.position.z,next.yaw)+def.dimensions.clearance;
  const surface=waterSurfaceHeightAt(next.position.x,next.position.z,clockState.elapsed)-def.dimensions.height*.48;
  next.position.y=clamp(next.position.y,floor,Math.max(floor,surface));
  const caveFloor=heightAt(next.position.x,next.position.z);
  const caveRoof=getCaveCeilingY(next.position.x,next.position.z,caveFloor,CAVE_SITES,0.34);
  if (caveRoof !== null) next.position.y=clampCapsuleBelowCeiling(next.position.y,caveRoof,def.dimensions.height*.52,0.12);
  const caveMove=constrainCaveHorizontalMotion(state.position.x,state.position.z,next.position.x,next.position.z,def.dimensions.width*.38,CAVE_SITES);
  if(caveMove.blocked){next.position.x=caveMove.x;next.position.z=caveMove.z;next.velocity.x=0;next.velocity.z=0;}
  // Resolve each local axis through short swept steps. This prevents a fast
  // scout sub or a large carrier from tunnelling through hulls/terrain between
  // animation frames, while retaining wall sliding when one axis is blocked.
  const sweep=resolveVehicleSweep(state.position,next.position,(probe)=>{
    const probeFloor=sampleVehicleFloor(id,probe.x,probe.z,next.yaw)+def.dimensions.clearance;
    const roof=getCaveCeilingY(probe.x,probe.z,heightAt(probe.x,probe.z),CAVE_SITES,0.34);
    const roofHit=roof!==null && probe.y+def.dimensions.height*.52>roof-.12;
    return probe.y<probeFloor-.01||roofHit||vehicleBlocksPosition(id,probe.x,probe.y,probe.z);
  },.38);
  next.position=sweep.position;
  for(const axis of ['x','y','z'])if(sweep.blocked[axis])next.velocity[axis]=0;
  state.position=next.position;state.yaw=next.yaw;activeVehicleVelocity.set(next.velocity.x,next.velocity.y,next.velocity.z);player.position.set(next.position.x,next.position.y,next.position.z);player.yaw=next.yaw;player.pitch=next.pitch;player.velocity.copy(activeVehicleVelocity);
  const depth=Math.max(0,-state.position.y);const movingNow=activeVehicleVelocity.length()>.22;
  const drain=vehiclePowerDrainPerSecond(id,state,movingNow,false);if(drain>0)state.power=Math.max(0,state.power-drain*dt);
  if(id==='carrier'&&state.upgrades.reactor&&currentBiome.id==='thermal'&&state.power<VEHICLE_DEFS.carrier.maxPower)state.power=Math.min(VEHICLE_DEFS.carrier.maxPower,state.power+1.6*dt);
  const rating=getVehicleDepthRating(id,state);
  if(depth>rating){
    vehicleDamageTimer+=dt;
    while(vehicleDamageTimer>=1){
      vehicleDamageTimer-=1;
      const damage=vehicleDepthDamage(id,state,depth);
      state.health=Math.max(0,state.health-damage);
      playVehicleSfx(42,.12,'triangle',.035);
      if(state.health<=0){state.power=0;break;}
    }
  }else vehicleDamageTimer=0;
  if(state.health<=0){
    state.health=0;state.power=0;activeVehicleVelocity.set(0,0,0);player.velocity.set(0,0,0);markUnsaved();
    if(exitActiveVehicle())showToast(`${def.name} rusak karena tekanan. Perbaiki di Vehicle Bay.`);
    else showToast(`${def.name} rusak dan tidak dapat bergerak. Tidak ada ruang aman untuk keluar.`);
    syncVehicleHudActions();return;
  }
  const mesh=vehicleMeshes.get(id);if(mesh){mesh.position.set(state.position.x,state.position.y,state.position.z);mesh.rotation.y=state.yaw;}
  if(Math.abs(drain)>0||moving||Math.floor(clockState.elapsed)!==Math.floor(clockState.elapsed-dt))markUnsaved();
  if(Math.abs(depth-rating)<4||state.power<18){const target=$('poi-banner');if(target)target.innerHTML=`VEHICLE ALERT · ${state.power<18?'LOW POWER':'DEPTH LIMIT'} <span>— ${Math.round(depth)} m / ${rating} m</span>`;}
  syncVehicleHudActions();
}

function makeSeamlessDetailNoise(size = 512, seed = 1) {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = size;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  const image = ctx.createImageData(size, size);
  const tau = Math.PI * 2;
  for (let y = 0; y < size; y++) {
    const v = y / size;
    for (let x = 0; x < size; x++) {
      const u = x / size;
      const value = 128
        + Math.sin(tau * (u * 17 + v * 11 + seed * 0.013)) * 27
        + Math.cos(tau * (u * 29 - v * 23 + seed * 0.021)) * 18
        + Math.sin(tau * (u * 47 + v * 37 + seed * 0.007)) * 9;
      const i = (y * size + x) * 4;
      image.data[i] = image.data[i + 1] = image.data[i + 2] = clamp(value, 0, 255);
      image.data[i + 3] = 255;
    }
  }
  ctx.putImageData(image, 0, 0);
  return canvas;
}

function configureWorldTexture(texture, color = true, anisotropy = null) {
  if (color) texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  texture.generateMipmaps = true;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.magFilter = THREE.LinearFilter;
  texture.anisotropy = anisotropy ?? (renderer?.capabilities?.getMaxAnisotropy ? Math.min(8, renderer.capabilities.getMaxAnisotropy()) : 4);
  texture.needsUpdate = true;
  return texture;
}

function makeProceduralTexture(kind = 'stone', size = 1024) {
  const sourceSize = size >= 4096 ? 2048 : Math.min(size, 1024);
  const source = document.createElement('canvas');
  source.width = source.height = sourceSize;
  const ctx = source.getContext('2d', { willReadFrequently: true });
  const palettes = {
    sand: [178, 157, 117], stone: [83, 111, 119], kelp: [31, 91, 70], coral: [159, 105, 133],
    wood: [110, 76, 48], metal: [82, 119, 128]
  };
  const base = palettes[kind] || palettes.stone;
  const image = ctx.createImageData(sourceSize, sourceSize);
  const hash = (x,y) => { const n=Math.sin(x*127.1+y*311.7+17.3)*43758.5453; return n-Math.floor(n); };
  for (let y = 0; y < sourceSize; y++) {
    for (let x = 0; x < sourceSize; x++) {
      const i = (y * sourceSize + x) * 4;
      const broad = Math.sin(x * 0.045 + Math.sin(y * 0.026) * 2.1) * 6 + Math.cos(y * 0.038) * 4;
      const medium = (hash(Math.floor(x/4),Math.floor(y/4)) - 0.5) * 19;
      const fine = (hash(x,y) - 0.5) * (kind === 'sand' ? 25 : 18);
      let detail = broad + medium + fine;
      if (kind === 'sand') detail += Math.sin((x + Math.sin(y*.05)*9) * .17) * 5;
      if (kind === 'stone') detail += Math.sin(x*.11+y*.07)*7 + Math.sin(x*.037-y*.061)*4;
      if (kind === 'metal') detail += (hash(Math.floor(x/18),Math.floor(y/3))-.5)*24;
      image.data[i] = clamp(base[0] + detail, 0, 255);
      image.data[i + 1] = clamp(base[1] + detail, 0, 255);
      image.data[i + 2] = clamp(base[2] + detail, 0, 255);
      image.data[i + 3] = 255;
    }
  }
  ctx.putImageData(image, 0, 0);
  if (kind === 'sand') {
    for(let y=5;y<sourceSize;y+=13){ctx.strokeStyle='rgba(255,236,190,.12)';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(0,y);ctx.bezierCurveTo(sourceSize*.28,y-5,sourceSize*.62,y+5,sourceSize,y-2);ctx.stroke();}
    for(let i=0;i<360;i++){const x=hash(i,3)*sourceSize,y=hash(7,i)*sourceSize;ctx.fillStyle=`rgba(65,74,68,${.06+hash(i,9)*.15})`;ctx.beginPath();ctx.ellipse(x,y,.7+hash(i,1)*2.5,.45+hash(i,2)*1.2,hash(i,6),0,Math.PI*2);ctx.fill();}
  } else if (kind === 'wood') {
    ctx.strokeStyle = 'rgba(32,18,10,.25)'; ctx.lineWidth = 2;
    for (let y = 8; y < sourceSize; y += 18) { ctx.beginPath(); ctx.moveTo(0, y); ctx.bezierCurveTo(38, y - 5, 82, y + 5, sourceSize, y - 2); ctx.stroke(); }
    for(let i=0;i<18;i++){const x=hash(i,22)*sourceSize,y=hash(31,i)*sourceSize;ctx.strokeStyle='rgba(35,21,12,.18)';ctx.beginPath();ctx.ellipse(x,y,5+hash(i,8)*9,2,0,0,Math.PI*2);ctx.stroke();}
  } else if (kind === 'coral') {
    ctx.strokeStyle = 'rgba(255,220,235,.22)'; ctx.lineWidth = 1.5;
    for (let i = 0; i < 120; i++) { const x=hash(i,5)*sourceSize,y=hash(12,i)*sourceSize,r=2+hash(i,8)*15;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.stroke(); }
    for(let i=0;i<180;i++){const x=hash(i,47)*sourceSize,y=hash(57,i)*sourceSize;ctx.fillStyle=`rgba(47,39,62,${.07+hash(i,12)*.1})`;ctx.beginPath();ctx.arc(x,y,.7+hash(i,5)*2.2,0,Math.PI*2);ctx.fill();}
  } else if (kind === 'stone') {
    ctx.strokeStyle='rgba(14,28,34,.28)'; ctx.lineWidth=1.5;
    for(let i=0;i<120;i++){const x=hash(i,71)*sourceSize,y=hash(39,i)*sourceSize,dx=(hash(i,12)-.5)*42,dy=(hash(i,17)-.5)*32;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+dx,y+dy);ctx.lineTo(x+dx+(hash(i,5)-.5)*17,y+dy+(hash(i,6)-.5)*13);ctx.stroke();}
    for(let i=0;i<260;i++){const x=hash(i,42)*sourceSize,y=hash(81,i)*sourceSize,r=.7+hash(i,14)*3.2;ctx.fillStyle=`rgba(10,24,31,${.07+hash(i,3)*.16})`;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill();}
    for(let i=0;i<32;i++){const x=hash(i,91)*sourceSize,y=hash(19,i)*sourceSize;ctx.fillStyle=`rgba(188,210,207,${.035+hash(i,8)*.06})`;ctx.beginPath();ctx.ellipse(x,y,10+hash(i,4)*28,2+hash(i,5)*5,hash(i,6)*Math.PI,0,Math.PI*2);ctx.fill();}
  } else if (kind === 'metal') {
    ctx.strokeStyle='rgba(220,246,241,.19)';ctx.lineWidth=1;
    for(let i=0;i<105;i++){const x=hash(i,11)*sourceSize,y=hash(21,i)*sourceSize;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+4+hash(i,4)*34,y+(hash(i,6)-.5)*5);ctx.stroke();}
    for(let i=0;i<80;i++){const x=hash(i,31)*sourceSize,y=hash(51,i)*sourceSize;ctx.fillStyle=`rgba(35,68,72,${.05+hash(i,4)*.09})`;ctx.beginPath();ctx.arc(x,y,.8+hash(i,9)*2.8,0,Math.PI*2);ctx.fill();}
  } else if (kind === 'kelp') {
    ctx.strokeStyle='rgba(170,231,180,.25)';ctx.lineWidth=2;
    for(let x=8;x<sourceSize;x+=12){ctx.beginPath();ctx.moveTo(x,sourceSize);ctx.quadraticCurveTo(x+10,sourceSize*.5,x-3,0);ctx.stroke();}
    ctx.strokeStyle='rgba(9,42,36,.22)';ctx.lineWidth=1;
    for(let x=5;x<sourceSize;x+=24){ctx.beginPath();ctx.moveTo(x,sourceSize);ctx.quadraticCurveTo(x+7,sourceSize*.5,x-2,0);ctx.stroke();}
  }

  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = size;
  const out = canvas.getContext('2d');
  out.imageSmoothingEnabled = true;
  out.imageSmoothingQuality = 'high';
  out.drawImage(source, 0, 0, size, size);
  if (size > sourceSize) {
    const noise = makeSeamlessDetailNoise(size >= 4096 ? 1024 : size >= 2048 ? 512 : 256, kind.length * 19 + size);
    out.save();
    out.globalCompositeOperation = 'soft-light';
    out.globalAlpha = size >= 4096 ? 0.25 : 0.16;
    out.fillStyle = out.createPattern(noise, 'repeat');
    out.fillRect(0, 0, size, size);
    out.restore();
    const fineCount = Math.min(28000, Math.round(size * size / 950));
    for (let i = 0; i < fineCount; i++) {
      const x = hash(i, kind.length * 7) * size;
      const y = hash(kind.length * 13, i) * size;
      const radius = 0.45 + hash(i, 29) * (size >= 4096 ? 2.1 : 1.25);
      out.fillStyle = kind === 'metal' ? `rgba(215,245,245,${0.035 + hash(i,7)*0.08})` : `rgba(12,28,30,${0.025 + hash(i,7)*0.07})`;
      out.beginPath(); out.ellipse(x, y, radius * 1.8, radius, hash(i,3) * Math.PI, 0, Math.PI * 2); out.fill();
    }
  }
  return configureWorldTexture(new THREE.CanvasTexture(canvas), true);
}

function makeHeightTexture(kind = 'sand', size = 1024) {
  // A shared 1K cap keeps six distinct relief maps inside a predictable mobile
  // memory budget while retaining enough texel density for nearby surfaces.
  const sourceSize = Math.min(Math.max(256, Number(size) || 1024), 1024);
  const source = document.createElement('canvas'); source.width = source.height = sourceSize;
  const sourceCtx = source.getContext('2d', { willReadFrequently:true });
  const image = sourceCtx.createImageData(sourceSize, sourceSize);
  const seed = kind.split('').reduce((n,c)=>n+c.charCodeAt(0),0) * 0.013;
  const tau = Math.PI * 2;
  const heightAt = (u, v) => {
    const a = tau * (u + seed * 0.07), b = tau * (v - seed * 0.05);
    const broad = Math.sin(a * 7 + Math.sin(b * 3) * 0.16) * 0.22
      + Math.cos(b * 9 - Math.sin(a * 4) * 0.12) * 0.18;
    const micro = Math.sin(a * 37 + b * 29) * 0.07
      + Math.cos(a * 61 - b * 47) * 0.035
      + Math.sin(a * 113 + b * 97) * 0.018;
    if (kind === 'sand') {
      const ripples = Math.sin(b * 19 + Math.sin(a * 5) * 0.42) * 0.34
        + Math.sin(b * 43 + Math.sin(a * 9) * 0.24) * 0.12;
      return ripples + broad * 0.16 + micro * 0.30;
    }
    if (kind === 'metal') {
      const scratches = Math.sin(a * 151 + Math.sin(b * 7) * 0.7) * 0.18
        + Math.sin(a * 311 + b * 13) * 0.05;
      const pits = Math.sin(a * 23 + b * 31) * Math.cos(a * 29 - b * 19) * 0.20;
      return broad * 0.10 + scratches + pits + micro * 0.22;
    }
    if (kind === 'wood') {
      const grain = Math.sin(a * 13 + Math.sin(b * 5) * 0.55) * 0.32
        + Math.sin(a * 47 + Math.sin(b * 11) * 0.32) * 0.11;
      return grain + broad * 0.14 + micro * 0.18;
    }
    if (kind === 'kelp') {
      const ridges = Math.sin(a * 21 + Math.sin(b * 3) * 0.18) * 0.34
        + Math.sin(a * 67 + Math.sin(b * 7) * 0.12) * 0.13;
      return ridges + broad * 0.12 + micro * 0.20;
    }
    if (kind === 'coral') {
      const pores = Math.sin(a * 31 + Math.sin(b * 17) * 0.18)
        * Math.cos(b * 29 + Math.sin(a * 13) * 0.16) * 0.36;
      const ridges = Math.sin(a * 73 + b * 59) * 0.12;
      return pores + ridges + broad * 0.12 + micro * 0.25;
    }
    const strata = Math.sin(a * 11 + b * 7) * 0.22
      + Math.sin(a * 23 - b * 17) * 0.16
      + Math.cos(a * 43 + b * 37) * 0.10;
    const fracture = Math.sin(a * 17 + Math.sin(b * 23) * 0.35)
      * Math.sin(b * 19 + Math.sin(a * 29) * 0.28) * 0.18;
    return strata + fracture + micro * 0.34;
  };
  for (let y=0;y<sourceSize;y++) for (let x=0;x<sourceSize;x++) {
    const i=(y*sourceSize+x)*4;
    const value=clamp(128+heightAt(x/sourceSize,y/sourceSize)*82,0,255);
    image.data[i]=image.data[i+1]=image.data[i+2]=value; image.data[i+3]=255;
  }
  sourceCtx.putImageData(image,0,0);
  const canvas=document.createElement('canvas'); canvas.width=canvas.height=size;
  const ctx=canvas.getContext('2d'); ctx.imageSmoothingEnabled=true; ctx.imageSmoothingQuality='high'; ctx.drawImage(source,0,0,size,size);
  if(size>sourceSize){
    const noise=makeSeamlessDetailNoise(size>=4096?1024:size>=2048?512:256,seed+size);
    ctx.save();ctx.globalCompositeOperation='soft-light';ctx.globalAlpha=0.17;ctx.fillStyle=ctx.createPattern(noise,'repeat');ctx.fillRect(0,0,size,size);ctx.restore();
  }
  const texture=new THREE.CanvasTexture(canvas);
  return configureWorldTexture(texture,false,renderer?.capabilities?.getMaxAnisotropy?Math.min(12,renderer.capabilities.getMaxAnisotropy()):4);
}
function makeCausticTexture(size = 1024) {
  const c = document.createElement('canvas'); c.width = c.height = size;
  const ctx = c.getContext('2d');
  ctx.clearRect(0, 0, size, size);
  ctx.globalCompositeOperation = 'screen';
  const count = Math.min(900, Math.max(90, Math.round(90 * (size / 512) ** 1.3)));
  for (let i = 0; i < count; i++) {
    const x = hash2(i * 7, 13) * size, y = hash2(19, i * 11) * size;
    const r = 6 + hash2(i * 3, i * 5) * (size / 18);
    ctx.strokeStyle = `rgba(123,226,218,${0.07 + hash2(i, 17) * 0.14})`;
    ctx.lineWidth = Math.max(1, size / 1800) + hash2(i * 9, 3) * Math.max(1, size / 900);
    for (const ox of [-size, 0, size]) for (const oy of [-size, 0, size]) {
      ctx.beginPath(); ctx.ellipse(x + ox, y + oy, r * 1.6, r * 0.55, hash2(i, i + 2) * Math.PI, 0, Math.PI * 2); ctx.stroke();
    }
  }
  const tex = new THREE.CanvasTexture(c);
  return configureWorldTexture(tex, true);
}

/** Seamless high-resolution surface-water colour texture with layered wave interference. */
function makeWaterColorTexture(size = 2048) {
  const sourceSize = size >= 4096 ? 2048 : Math.min(size, 1024);
  const source = document.createElement('canvas'); source.width = source.height = sourceSize;
  const ctx = source.getContext('2d', { willReadFrequently: true });
  const image = ctx.createImageData(sourceSize, sourceSize);
  const tau = Math.PI * 2;
  for (let y = 0; y < sourceSize; y++) {
    const v = y / sourceSize;
    for (let x = 0; x < sourceSize; x++) {
      const u = x / sourceSize;
      const phaseA = tau * (u * 11 + Math.sin(tau * v * 3) * 0.19);
      const phaseB = tau * (v * 9 - Math.sin(tau * u * 4) * 0.16);
      const phaseC = tau * (u * 17 + v * 13 + Math.sin(tau * (u + v) * 5) * 0.055);
      const crest = Math.pow(Math.max(0, Math.sin(phaseA) * 0.52 + Math.sin(phaseB) * 0.34 + Math.sin(phaseC) * 0.14), 5);
      const micro = (Math.sin(tau * (u * 37 + v * 29)) + Math.cos(tau * (u * 23 - v * 31))) * 0.5;
      const lum = crest * 52 + micro * 3.2;
      const i = (y * sourceSize + x) * 4;
      image.data[i] = clamp(27 + lum * 0.52, 0, 255);
      image.data[i + 1] = clamp(103 + lum * 0.92, 0, 255);
      image.data[i + 2] = clamp(132 + lum * 1.08, 0, 255);
      image.data[i + 3] = 255;
    }
  }
  ctx.putImageData(image, 0, 0);
  const canvas = document.createElement('canvas'); canvas.width = canvas.height = size;
  const out = canvas.getContext('2d'); out.imageSmoothingEnabled = true; out.imageSmoothingQuality = 'high'; out.drawImage(source,0,0,size,size);
  out.globalCompositeOperation = 'screen'; out.lineCap = 'round';
  const lineCount = Math.max(96, Math.floor(size / 6));
  for (let row = 0; row < lineCount; row++) {
    const y = (row / lineCount) * size;
    const amp = (2 + (row % 7) * 1.35) * (size / 1024);
    out.strokeStyle = `rgba(190,250,244,${0.018 + (row % 5) * 0.008})`;
    out.lineWidth = Math.max(0.7, size / 3200) + (row % 3) * 0.25;
    out.beginPath(); out.moveTo(0, y);
    out.bezierCurveTo(size * 0.28, y + amp, size * 0.68, y - amp, size, y); out.stroke();
  }
  const noise=makeSeamlessDetailNoise(size >= 4096 ? 1024 : size >= 2048 ? 512 : 256, size+91);
  out.save();out.globalCompositeOperation='soft-light';out.globalAlpha=0.18;out.fillStyle=out.createPattern(noise,'repeat');out.fillRect(0,0,size,size);out.restore();
  return configureWorldTexture(new THREE.CanvasTexture(canvas), true, renderer?.capabilities?.getMaxAnisotropy ? Math.min(16,renderer.capabilities.getMaxAnisotropy()) : 4);
}

/** Tangent-space wave normal map. The 4K output is upsampled from a detailed seamless field to keep mobile generation bounded. */
function makeWaterNormalTexture(size = 2048) {
  const baseSize = Math.min(size, size >= 4096 ? 2048 : 1024);
  const base = new Uint8Array(baseSize * baseSize * 4);
  const tau = Math.PI * 2;
  const heightAt = (u, v) =>
    Math.sin(tau * (u * 13 + Math.sin(tau * v * 4) * 0.13)) * 0.34
    + Math.sin(tau * (v * 10 - Math.sin(tau * u * 5) * 0.12)) * 0.27
    + Math.sin(tau * (u * 23 + v * 19)) * 0.13
    + Math.cos(tau * (u * 31 - v * 27)) * 0.08;
  const delta = 1 / baseSize;
  for (let y = 0; y < baseSize; y++) for (let x = 0; x < baseSize; x++) {
    const u=x/baseSize,v=y/baseSize;
    const dx=(heightAt(u+delta,v)-heightAt(u-delta,v))*2.25;
    const dy=(heightAt(u,v+delta)-heightAt(u,v-delta))*2.25;
    let nx=-dx,ny=-dy,nz=1;const length=Math.hypot(nx,ny,nz)||1;nx/=length;ny/=length;nz/=length;
    const i=(y*baseSize+x)*4;base[i]=Math.round((nx*.5+.5)*255);base[i+1]=Math.round((ny*.5+.5)*255);base[i+2]=Math.round((nz*.5+.5)*255);base[i+3]=255;
  }
  const data = new Uint8Array(size * size * 4);
  for (let y=0;y<size;y++) {
    const sy=Math.min(baseSize-1,Math.floor(y*baseSize/size));
    for (let x=0;x<size;x++) {
      const sx=Math.min(baseSize-1,Math.floor(x*baseSize/size));
      const src=(sy*baseSize+sx)*4,dst=(y*size+x)*4;
      data[dst]=base[src];data[dst+1]=base[src+1];data[dst+2]=base[src+2];data[dst+3]=255;
    }
  }
  const texture = new THREE.DataTexture(data, size, size, THREE.RGBAFormat, THREE.UnsignedByteType);
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(8, 8);
  texture.generateMipmaps = true;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.magFilter = THREE.LinearFilter;
  texture.anisotropy = renderer?.capabilities?.getMaxAnisotropy ? Math.min(16, renderer.capabilities.getMaxAnisotropy()) : 4;
  texture.needsUpdate = true;
  return texture;
}

function configureLoadedPbrTexture(texture, oldTexture, colorMap = false, mapKind = 'base') {
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  if (oldTexture?.repeat) texture.repeat.copy(oldTexture.repeat);
  texture.colorSpace = colorMap ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  const deviceMemory = Number(navigator.deviceMemory) || 4;
  const requestedQuality = settings.graphics || 'balanced';
  let targetSize = requestedQuality === 'ultra' && deviceMemory >= 8 ? 2048
    : requestedQuality === 'high' && deviceMemory >= 6 ? 1536
    : (requestedQuality === 'low' || deviceMemory <= 2) ? 512 : 1024;
  targetSize = Math.min(targetSize, renderer?.capabilities?.maxTextureSize || 2048);
  // Normal/roughness maps need less spatial detail than the albedo map.
  if (mapKind !== 'base') targetSize = Math.min(targetSize, 1024);
  const source = texture.image;
  const width = source?.naturalWidth || source?.videoWidth || source?.width || 0;
  const height = source?.naturalHeight || source?.videoHeight || source?.height || 0;
  if (width > targetSize || height > targetSize) {
    const ratio = Math.min(targetSize / Math.max(1, width), targetSize / Math.max(1, height));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(width * ratio));
    canvas.height = Math.max(1, Math.round(height * ratio));
    const context = canvas.getContext('2d', { alpha: false });
    if (context) {
      context.imageSmoothingEnabled = true;
      context.imageSmoothingQuality = 'high';
      context.drawImage(source, 0, 0, canvas.width, canvas.height);
      texture.image = canvas;
    }
  }
  const maxAnisotropy = renderer?.capabilities?.getMaxAnisotropy?.() || 4;
  texture.anisotropy = Math.min(maxAnisotropy, requestedQuality === 'ultra' ? 12 : requestedQuality === 'high' ? 8 : 4);
  texture.generateMipmaps = true;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.magFilter = THREE.LinearFilter;
  texture.needsUpdate = true;
  return texture;
}

function applyPbrOverridesToScene() {
  if (!scene) return;
  const surfaceTargets = [
    ['sand','terrainTexture'], ['basalt','rockTexture'], ['kelp','kelpTexture'],
    ['coral','coralTexture'], ['wreck_wood','woodTexture'], ['oxidized_metal','metalTexture']
  ];
  const currentTextures = { terrainTexture, rockTexture, kelpTexture, coralTexture, woodTexture, metalTexture };
  for (const [materialKey, globalName] of surfaceTargets) {
    const maps = pbrTextureOverrides[materialKey];
    if (!maps?.base || !maps?.normal || !maps?.roughness) continue;
    const oldTexture = currentTextures[globalName];
    if (oldTexture && oldTexture !== maps.base) {
      scene.traverse(object => {
        const materials = Array.isArray(object.material) ? object.material : object.material ? [object.material] : [];
        for (const material of materials) if (material.map === oldTexture) material.map = maps.base;
      });
    }
    if (globalName === 'terrainTexture') terrainTexture = maps.base;
    else if (globalName === 'rockTexture') rockTexture = maps.base;
    else if (globalName === 'kelpTexture') kelpTexture = maps.base;
    else if (globalName === 'coralTexture') coralTexture = maps.base;
    else if (globalName === 'woodTexture') woodTexture = maps.base;
    else if (globalName === 'metalTexture') metalTexture = maps.base;
    scene.traverse(object => {
      const materials = Array.isArray(object.material) ? object.material : object.material ? [object.material] : [];
      for (const material of materials) if (material.map === maps.base) {
        material.normalMap = maps.normal;
        material.roughnessMap = maps.roughness;
        material.bumpMap = null;
        if (material.normalScale?.set) material.normalScale.set(0.62, 0.62);
        material.needsUpdate = true;
      }
    });
  }
  faunaDirector?.setSurfaceTextures?.(pbrTextureOverrides.fish_scales || null, pbrTextureOverrides.biolum_tissue || null);
}

function loadWorldPbrTextures() {
  if (!rendererReady || !THREE.TextureLoader) return;
  const loader = new THREE.TextureLoader();
  // Keep each URL literal so Vite/Capacitor include and hash the local binary assets.
  const specs = [
    { key:'sand', base:new URL('./assets/pbr/sand_base.webp', import.meta.url).href, normal:new URL('./assets/pbr/sand_normal.webp', import.meta.url).href, roughness:new URL('./assets/pbr/sand_rough.webp', import.meta.url).href, target:'terrainTexture' },
    { key:'basalt', base:new URL('./assets/pbr/basalt_base.webp', import.meta.url).href, normal:new URL('./assets/pbr/basalt_normal.webp', import.meta.url).href, roughness:new URL('./assets/pbr/basalt_rough.webp', import.meta.url).href, target:'rockTexture' },
    { key:'kelp', base:new URL('./assets/pbr/kelp_base.webp', import.meta.url).href, normal:new URL('./assets/pbr/kelp_normal.webp', import.meta.url).href, roughness:new URL('./assets/pbr/kelp_rough.webp', import.meta.url).href, target:'kelpTexture' },
    { key:'coral', base:new URL('./assets/pbr/coral_base.webp', import.meta.url).href, normal:new URL('./assets/pbr/coral_normal.webp', import.meta.url).href, roughness:new URL('./assets/pbr/coral_rough.webp', import.meta.url).href, target:'coralTexture' },
    { key:'wreck_wood', base:new URL('./assets/pbr/wreck_wood_base.webp', import.meta.url).href, normal:new URL('./assets/pbr/wreck_wood_normal.webp', import.meta.url).href, roughness:new URL('./assets/pbr/wreck_wood_rough.webp', import.meta.url).href, target:'woodTexture' },
    { key:'oxidized_metal', base:new URL('./assets/pbr/oxidized_metal_base.webp', import.meta.url).href, normal:new URL('./assets/pbr/oxidized_metal_normal.webp', import.meta.url).href, roughness:new URL('./assets/pbr/oxidized_metal_rough.webp', import.meta.url).href, target:'metalTexture' },
    { key:'fish_scales', base:new URL('./assets/pbr/fish_scales_base.webp', import.meta.url).href, normal:new URL('./assets/pbr/fish_scales_normal.webp', import.meta.url).href, roughness:new URL('./assets/pbr/fish_scales_rough.webp', import.meta.url).href, target:null },
    { key:'biolum_tissue', base:new URL('./assets/pbr/biolum_tissue_base.webp', import.meta.url).href, normal:new URL('./assets/pbr/biolum_tissue_normal.webp', import.meta.url).href, roughness:new URL('./assets/pbr/biolum_tissue_rough.webp', import.meta.url).href, target:null }
  ];
  for (const spec of specs) {
    const { key, target } = spec;
    const bundle = pbrTextureOverrides[key] = pbrTextureOverrides[key] || {};
    const oldTexture = target ? ({terrainTexture,rockTexture,kelpTexture,coralTexture,woodTexture,metalTexture})[target] : null;
    const loadOne = (url, mapKind, color = false) => new Promise(resolve => {
      loader.load(url, texture => {
        bundle[mapKind] = configureLoadedPbrTexture(texture, oldTexture, color, mapKind);
        resolve(true);
      }, undefined, error => {
        console.warn(`[Abyssal] PBR ${key}/${mapKind} gagal dimuat`, error?.message || error);
        resolve(false);
      });
    });
    Promise.all([loadOne(spec.base,'base',true),loadOne(spec.normal,'normal',false),loadOne(spec.roughness,'roughness',false)]).then(results => {
      if (!results.every(Boolean)) return;
      const repeats = { sand:[4,4],basalt:[1.8,1.8],kelp:[1,2],coral:[1,1],wreck_wood:[2,1],oxidized_metal:[1,1],fish_scales:[2,1],biolum_tissue:[1.6,1.6] }[key] || [1,1];
      for (const map of Object.values(bundle)) map.repeat.set(...repeats);
      if (target) applyPbrOverridesToScene();
      else faunaDirector?.setSurfaceTextures?.(pbrTextureOverrides.fish_scales || null, pbrTextureOverrides.biolum_tissue || null);
    });
  }
}

function makeGraphicsTextureSet(profile) {
  const set = {};
  try {
    set.terrain = makeProceduralTexture('sand', profile.primaryTextureSize);
    set.rock = makeProceduralTexture('stone', profile.primaryTextureSize);
    set.kelp = makeProceduralTexture('kelp', profile.supportingTextureSize);
    set.coral = makeProceduralTexture('coral', profile.supportingTextureSize);
    set.wood = makeProceduralTexture('wood', profile.supportingTextureSize);
    set.metal = makeProceduralTexture('metal', profile.supportingTextureSize);
    const reliefSize = Math.min(profile.bumpTextureSize, profile.preset === 'low' ? 512 : 1024);
    set.terrainBump = makeHeightTexture('sand', reliefSize);
    set.rockBump = makeHeightTexture('stone', reliefSize);
    set.kelpBump = makeHeightTexture('kelp', reliefSize);
    set.coralBump = makeHeightTexture('coral', reliefSize);
    set.woodBump = makeHeightTexture('wood', reliefSize);
    set.metalBump = makeHeightTexture('metal', reliefSize);
    set.caustic = makeCausticTexture(profile.causticTextureSize);
    set.waterColor = makeWaterColorTexture(profile.waterTextureSize);
    set.waterNormal = makeWaterNormalTexture(profile.waterTextureSize);
    set.terrain.repeat.set(4,4); set.rock.repeat.set(1.8,1.8); set.kelp.repeat.set(1,2);
    set.coral.repeat.set(1,1); set.wood.repeat.set(2,1); set.metal.repeat.set(1,1);
    // Shared micro-relief avoids six duplicate GPU allocations.
    set.terrainBump.repeat.set(4,4);
    set.rockBump.repeat.set(2,2);
    set.kelpBump.repeat.set(1,2);
    set.coralBump.repeat.set(1.5,1.5);
    set.woodBump.repeat.set(2,1);
    set.metalBump.repeat.set(1,1);
    const maxAnisotropy = renderer?.capabilities?.getMaxAnisotropy ? renderer.capabilities.getMaxAnisotropy() : 4;
    const anisotropy = Math.min(maxAnisotropy, profile.preset === 'low' ? 4 : profile.is4K ? 16 : 8);
    for (const texture of Object.values(set)) {
      texture.anisotropy = anisotropy;
      texture.needsUpdate = true;
    }
    return set;
  } catch (error) {
    // Release any canvases/DataTextures created before a later allocation failed.
    for (const texture of new Set(Object.values(set))) texture?.dispose?.();
    throw new Error(`Pembuatan tekstur ${profile.primaryTextureSize}px gagal: ${error?.message || error}`);
  }
}

function makeGraphicsTextureSetWithFallback(requestedProfile) {
  const memory = requestedProfile.deviceMemoryGB || 0;
  const gpuLimit = requestedProfile.gpuLimit;
  const candidates = [requestedProfile];
  if (requestedProfile.primaryTextureSize > 2048 || requestedProfile.waterTextureSize > 2048) {
    candidates.push(resolveGraphicsTextureProfile('balanced', gpuLimit, memory));
  }
  if (requestedProfile.primaryTextureSize > 1024 || requestedProfile.waterTextureSize > 1024) {
    candidates.push(resolveGraphicsTextureProfile('low', gpuLimit, memory));
  }
  const seen = new Set();
  let lastError = null;
  for (const candidate of candidates) {
    const key = [candidate.primaryTextureSize,candidate.supportingTextureSize,candidate.waterTextureSize,candidate.bumpTextureSize,candidate.causticTextureSize,candidate.faunaTextureSize].join(':');
    if (seen.has(key)) continue;
    seen.add(key);
    try {
      const textureSet = makeGraphicsTextureSet(candidate);
      const isFallback = candidate !== requestedProfile;
      const effectiveProfile = isFallback ? {
        ...candidate,
        preset: requestedProfile.preset,
        targetResolution: requestedProfile.targetResolution,
        fallbackReason: `Alokasi tekstur ${requestedProfile.primaryTextureSize}px tidak tersedia; memakai ${candidate.primaryTextureSize}px. ${lastError?.message || 'Memori grafis terbatas.'}`
      } : candidate;
      return { profile: effectiveProfile, textureSet };
    } catch (error) {
      lastError = error;
    }
  }
  throw new Error(`Semua tingkat tekstur gagal dibuat. ${lastError?.message || 'Periksa memori dan dukungan grafis perangkat.'}`);
}

function applyGraphicsTextureSet(set, disposePrevious = true) {
  const previous = [terrainTexture,rockTexture,kelpTexture,coralTexture,woodTexture,metalTexture,
    terrainBumpTexture,rockBumpTexture,kelpBumpTexture,coralBumpTexture,woodBumpTexture,metalBumpTexture,
    causticTexture,waterColorTexture,waterNormalTexture];
  const oldBumps = new Set([terrainBumpTexture,rockBumpTexture,kelpBumpTexture,coralBumpTexture,woodBumpTexture,metalBumpTexture].filter(Boolean));
  const replacements = new Map([
    [terrainTexture,set.terrain],[rockTexture,set.rock],[kelpTexture,set.kelp],[coralTexture,set.coral],[woodTexture,set.wood],[metalTexture,set.metal],
    [causticTexture,set.caustic],[waterColorTexture,set.waterColor],[waterNormalTexture,set.waterNormal]
  ].filter(([from]) => from));
  const bumpByColor = new Map([
    [terrainTexture,set.terrainBump],[rockTexture,set.rockBump],[kelpTexture,set.kelpBump],
    [coralTexture,set.coralBump],[woodTexture,set.woodBump],[metalTexture,set.metalBump]
  ].filter(([from]) => from));
  if (scene && (replacements.size || oldBumps.size)) {
    scene.traverse(object => {
      const materials = Array.isArray(object.material) ? object.material : object.material ? [object.material] : [];
      for (const material of materials) {
        let changed = false;
        const previousColorMap = material.map;
        for (const key of ['map','normalMap','emissiveMap','roughnessMap','metalnessMap','alphaMap']) {
          const replacement = replacements.get(material[key]);
          if (replacement) { material[key] = replacement; changed = true; }
        }
        if (material.bumpMap && oldBumps.has(material.bumpMap)) {
          material.bumpMap = bumpByColor.get(previousColorMap) || set.rockBump;
          changed = true;
        }
        if (changed) material.needsUpdate = true;
      }
    });
  }
  terrainTexture=set.terrain; rockTexture=set.rock; kelpTexture=set.kelp; coralTexture=set.coral; woodTexture=set.wood; metalTexture=set.metal;
  terrainBumpTexture=set.terrainBump; rockBumpTexture=set.rockBump; kelpBumpTexture=set.kelpBump;
  coralBumpTexture=set.coralBump; woodBumpTexture=set.woodBump; metalBumpTexture=set.metalBump;
  causticTexture=set.caustic; waterColorTexture=set.waterColor; waterNormalTexture=set.waterNormal;
  if (water?.material) {
    water.material.map=waterColorTexture; water.material.normalMap=waterNormalTexture; water.material.needsUpdate=true;
  }
  if (Object.keys(pbrTextureOverrides).length) applyPbrOverridesToScene();
  if (disposePrevious) {
    const next = new Set(Object.values(set));
    for (const maps of Object.values(pbrTextureOverrides)) for (const texture of Object.values(maps || {})) if (texture) next.add(texture);
    for (const texture of new Set(previous)) if (texture && !next.has(texture)) texture.dispose();
  }
}
/** One reusable radial sprite texture for diver-generated air bubbles. */
function makeBubbleTexture() {
  const canvas = document.createElement('canvas'); canvas.width = canvas.height = 64;
  const ctx = canvas.getContext('2d');
  const gradient = ctx.createRadialGradient(24, 22, 2, 32, 32, 29);
  gradient.addColorStop(0, 'rgba(241,255,255,0.95)');
  gradient.addColorStop(0.26, 'rgba(174,244,247,0.55)');
  gradient.addColorStop(0.62, 'rgba(80,190,206,0.18)');
  gradient.addColorStop(1, 'rgba(50,150,180,0)');
  ctx.fillStyle = gradient; ctx.fillRect(0, 0, 64, 64);
  ctx.strokeStyle = 'rgba(220,255,255,0.52)'; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.arc(32, 32, 23, 0.35, Math.PI * 1.72); ctx.stroke();
  const texture = new THREE.CanvasTexture(canvas); texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function createSwimBubblePool() {
  swimBubbleGroup = new THREE.Group();
  swimBubbleGroup.name = 'DiverBubbleParticles';
  const texture = makeBubbleTexture();
  for (let i = 0; i < 22; i++) {
    const material = new THREE.SpriteMaterial({ map: texture, color: 0xc5f7f4, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending });
    const sprite = new THREE.Sprite(material);
    sprite.visible = false;
    sprite.userData = { life: 0, duration: 1.4, velocity: new THREE.Vector3(), baseSize: 0.08 };
    swimBubbleGroup.add(sprite);
    swimBubblePool.push(sprite);
  }
  scene.add(swimBubbleGroup);
}

function updateSwimBubbles(dt) {
  if (!swimBubblePool.length || !swimBubbleGroup) return;
  const depth = Math.max(0, -player.position.y);
  const swimmingSpeed = player.velocity.length();
  const underwater = surfaceBlend < 0.9 && player.position.y < -0.18;
  const insideHabitat = Boolean(getInsideHabitat());
  const usingSeaglide = getSelectedHotbarItem() === 'seaglide' && equipment.seaglideCharge > 0;
  const current=underwater&&!insideHabitat?sampleOceanCurrent(player.position.x,player.position.y,player.position.z,clockState.elapsed,currentBiome?.id||'open'):{x:0,y:0,z:0};
  const emission = underwater && !insideHabitat && swimmingSpeed > 1.7;
  if (emission) {
    swimBubbleSpawnTimer -= dt;
    const interval = usingSeaglide ? 0.42 : clamp(0.34 - swimmingSpeed * 0.025, 0.16, 0.30);
    if (swimBubbleSpawnTimer <= 0) {
      swimBubbleSpawnTimer = interval;
      const sprite = swimBubblePool[swimBubbleCursor++ % swimBubblePool.length];
      const yaw = player.yaw;
      const backX = -Math.sin(yaw), backZ = Math.cos(yaw);
      sprite.position.set(
        player.position.x + backX * 0.42 + (Math.random() - 0.5) * 0.28,
        player.position.y + 0.35 + Math.random() * 0.42,
        player.position.z + backZ * 0.42 + (Math.random() - 0.5) * 0.28
      );
      const baseSize = 0.045 + Math.random() * 0.055;
      const duration = 1.0 + Math.random() * 0.9;
      sprite.userData.life = duration;
      sprite.userData.duration = duration;
      sprite.userData.baseSize = baseSize;
      sprite.userData.velocity.set(
        player.velocity.x * -0.025 + (Math.random() - 0.5) * 0.16,
        0.34 + Math.random() * 0.34 + Math.min(0.2, depth * 0.0004),
        player.velocity.z * -0.025 + (Math.random() - 0.5) * 0.16
      );
      sprite.scale.setScalar(baseSize);
      sprite.material.opacity = 0.48;
      sprite.visible = true;
    }
  } else swimBubbleSpawnTimer = Math.min(swimBubbleSpawnTimer, 0.08);

  for (const sprite of swimBubblePool) {
    const state = sprite.userData;
    if (state.life <= 0) continue;
    state.life = Math.max(0, state.life - dt);
    sprite.position.addScaledVector(state.velocity, dt);
    state.velocity.x += (Math.sin(clockState.elapsed * 1.7 + sprite.position.z) * 0.035 + current.x * 0.16) * dt;
    state.velocity.y += current.y * 0.10 * dt;
    state.velocity.z += (Math.cos(clockState.elapsed * 1.4 + sprite.position.x) * 0.035 + current.z * 0.16) * dt;
    const progress = 1 - state.life / state.duration;
    sprite.scale.setScalar(state.baseSize * (1 + progress * 0.85));
    sprite.material.opacity = 0.48 * (1 - progress) * Math.min(1, state.life * 2.5);
    if (state.life <= 0) sprite.visible = false;
  }
}

function makeFirstPersonViewModel() {
  // First-person rig: each held object is a real local Three.js model. The
  // equipment is positioned against the diver's palm and a separate glove
  // overlay curls around its grip, so tools no longer float in front of an
  // open hand. All geometry is generated locally; no remote model is needed.
  viewModel = new THREE.Group();
  viewModel.name = 'DiverFirstPersonRig';

  const suit = new THREE.MeshStandardMaterial({ color: 0xd9e5df, map: rockTexture, roughness: 0.76, metalness: 0.10 });
  const glove = new THREE.MeshStandardMaterial({ color: 0x173b48, roughness: 0.62, metalness: 0.10 });
  const gloveEdge = new THREE.MeshStandardMaterial({ color: 0x285c68, roughness: 0.52, metalness: 0.18 });
  const deviceDark = new THREE.MeshStandardMaterial({ color: 0x102b3a, map: metalTexture, bumpMap: metalBumpTexture, bumpScale: 0.035, roughness: 0.42, metalness: 0.52 });
  const deviceMid = new THREE.MeshStandardMaterial({ color: 0x58737c, map: metalTexture, bumpMap: metalBumpTexture, bumpScale: 0.028, roughness: 0.48, metalness: 0.62 });
  const trim = new THREE.MeshStandardMaterial({ color: 0x47bfc0, emissive: 0x0b5963, emissiveIntensity: 0.48, roughness: 0.34, metalness: 0.35 });
  const orange = new THREE.MeshStandardMaterial({ color: 0xe08b43, roughness: 0.53, metalness: 0.22 });
  const rubber = new THREE.MeshStandardMaterial({ color: 0x172a31, roughness: 0.88, metalness: 0.04 });
  const bladeMat = new THREE.MeshStandardMaterial({ color: 0xc7d9d8, map: metalTexture, bumpMap: metalBumpTexture, bumpScale: 0.012, metalness: 0.86, roughness: 0.22 });
  const glassMat = new THREE.MeshPhysicalMaterial({ color: 0x9eeff0, emissive: 0x165b69, emissiveIntensity: 0.28, roughness: 0.12, metalness: 0.06, transmission: 0.18, transparent: true, opacity: 0.88, thickness: 0.08 });
  const screenMat = new THREE.MeshBasicMaterial({ color: 0x3ce7df, toneMapped: false });
  const screenDark = new THREE.MeshStandardMaterial({ color: 0x061923, emissive: 0x052c3b, emissiveIntensity: 0.48, roughness: 0.24, metalness: 0.16 });
  const glowBlue = new THREE.MeshStandardMaterial({ color: 0x8ff8f2, emissive: 0x36d8dc, emissiveIntensity: 1.35, roughness: 0.24, metalness: 0.12 });
  const glowAmber = new THREE.MeshStandardMaterial({ color: 0xffcb70, emissive: 0xe58a29, emissiveIntensity: 0.95, roughness: 0.28, metalness: 0.12 });

  const left = new THREE.Group(), right = new THREE.Group();
  left.name = 'LeftDiverArm'; right.name = 'RightDiverArm';

  const addMesh = (group, geometry, material, position = [0, 0, 0], scale = null, rotation = null) => {
    const mesh = new THREE.Mesh(geometry, material);
    mesh.position.set(position[0], position[1], position[2]);
    if (scale) mesh.scale.set(scale[0], scale[1], scale[2]);
    if (rotation) mesh.rotation.set(rotation[0], rotation[1], rotation[2]);
    mesh.castShadow = false; mesh.receiveShadow = false;
    group.add(mesh); return mesh;
  };
  const addCylinderZ = (group, material, radiusTop, radiusBottom, length, position, segments = 16) => {
    const mesh = addMesh(group, new THREE.CylinderGeometry(radiusTop, radiusBottom, length, segments), material, position, null, [Math.PI / 2, 0, 0]);
    return mesh;
  };
  const addRingZ = (group, material, radius, tube, position, segments = 20) =>
    addMesh(group, new THREE.TorusGeometry(radius, tube, 7, segments), material, position);
  const addLine = (group, material, points, radius = 0.012) => {
    const curve = new THREE.CatmullRomCurve3(points.map(point => new THREE.Vector3(point[0], point[1], point[2])));
    return addMesh(group, new THREE.TubeGeometry(curve, 12, radius, 5, false), material);
  };
  const setLayer = (root, layer) => root.traverse(object => {
    if (!object.isMesh) return;
    object.frustumCulled = false; object.renderOrder = layer;
    const materials = Array.isArray(object.material) ? object.material : [object.material];
    for (const material of materials) if (material) { material.depthTest = false; material.depthWrite = false; material.needsUpdate = true; }
  });
  const setGripAnchor = (group, anchor = [0, -0.015, -0.025]) => {
    group.userData.gripOffset = new THREE.Vector3(anchor[0], anchor[1], anchor[2]);
    group.userData.basePosition = group.position.clone();
    group.userData.baseRotation = group.rotation.clone();
    group.userData.baseScale = group.scale.clone();
    return group;
  };

  const makeArm = (group, side) => {
    const upper = addMesh(group, new THREE.CapsuleGeometry(0.105, 0.26, 5, 12), suit, [0, -0.055, 0.12], null, [-0.48, 0, 0]);
    const forearm = addMesh(group, new THREE.CapsuleGeometry(0.115, 0.34, 5, 12), suit, [0, -0.205, -0.13], null, [-0.34, 0, 0]);
    const shoulder = addMesh(group, new THREE.SphereGeometry(0.145, 16, 12), suit, [0, 0.02, 0.16], [1, 0.9, 1.05]);
    const forearmPanel = addMesh(group, new THREE.BoxGeometry(0.16, 0.20, 0.12), gloveEdge, [0, -0.205, -0.24], [1, 1, 0.72]);
    const cuff = addMesh(group, new THREE.CylinderGeometry(0.12, 0.12, 0.09, 16), trim, [0, -0.31, -0.27], null, [Math.PI / 2, 0, 0]);
    const cuffOuter = addMesh(group, new THREE.TorusGeometry(0.12, 0.012, 6, 18), orange, [0, -0.31, -0.27], null, [Math.PI / 2, 0, 0]);
    const palm = addMesh(group, new THREE.SphereGeometry(0.125, 16, 12), glove, [0, -0.39, -0.39], [0.98, 0.75, 1.28]);
    const knuckle = addMesh(group, new THREE.BoxGeometry(0.17, 0.045, 0.075), gloveEdge, [0, -0.405, -0.475], [1, 1, 1]);
    const fingers = [];
    for (let finger = 0; finger < 4; finger++) {
      const x = (finger - 1.5) * 0.052;
      const digit = new THREE.Group();
      const proximal = addMesh(digit, new THREE.CapsuleGeometry(0.025, 0.075, 4, 8), glove, [0, -0.012, -0.012], null, [-0.26, 0, 0]);
      const distal = addMesh(digit, new THREE.CapsuleGeometry(0.022, 0.055, 4, 8), gloveEdge, [0, -0.065, -0.03], null, [-0.52, 0, 0]);
      digit.position.set(x, -0.438, -0.505); group.add(digit); fingers.push(digit);
    }
    const thumb = addMesh(group, new THREE.CapsuleGeometry(0.032, 0.09, 4, 8), glove, [side * 0.13, -0.39, -0.44], null, [0.18, 0, -side * 0.68]);
    const thumbPad = addMesh(group, new THREE.SphereGeometry(0.036, 10, 8), gloveEdge, [side * 0.13, -0.405, -0.49], [1, 0.8, 0.7]);
    group.userData.fingers = fingers;
    group.userData.palm = palm;
    return { upper, forearm, shoulder, forearmPanel, cuff, cuffOuter, palm, knuckle, thumb, thumbPad };
  };
  makeArm(left, -1); makeArm(right, 1);
  left.position.set(-0.48, -0.19, -0.58);
  right.position.set(0.48, -0.19, -0.58);

  // Curved rubberised fingertips are rendered above the selected object. The
  // arcs follow a cylindrical grip axis and are repositioned to each model's
  // authored grip point every frame.
  const makeGripOverlay = (parent, name = 'RightToolGrip') => {
    const grip = new THREE.Group(); grip.name = name;
    const fingerMat = new THREE.MeshStandardMaterial({ color: 0x143642, roughness: 0.74, metalness: 0.06 });
    const seamMat = new THREE.MeshStandardMaterial({ color: 0x48aeb3, roughness: 0.48, metalness: 0.22 });
    for (let finger = 0; finger < 4; finger++) {
      const z = 0.055 - finger * 0.055;
      const points = [];
      for (let step = 0; step <= 10; step++) {
        const angle = 0.26 + (Math.PI * 2 - 0.52) * (step / 10);
        points.push([Math.cos(angle) * 0.073, Math.sin(angle) * 0.073, z]);
      }
      addLine(grip, fingerMat, points, 0.018 - finger * 0.001);
      addMesh(grip, new THREE.SphereGeometry(0.022, 8, 6), seamMat, [0.066, 0.028, z], [1, 0.78, 0.72]);
    }
    addLine(grip, fingerMat, [[-0.075, 0.01, 0.09], [-0.12, -0.015, 0.04], [-0.115, -0.06, -0.015], [-0.075, -0.078, -0.065]], 0.022);
    addMesh(grip, new THREE.SphereGeometry(0.035, 10, 8), seamMat, [-0.078, -0.076, -0.064], [1, 0.82, 0.78]);
    grip.visible = false; parent.add(grip); setLayer(grip, 1002); return grip;
  };
  const rightGrip = makeGripOverlay(right, 'RightGloveGrip');
  const leftGrip = makeGripOverlay(left, 'LeftSeaglideGrip');
  leftGrip.position.set(0.03, -0.47, -0.45);

  // Scanner: industrial handle, raised screen, side rails and a concentric
  // optical emitter. The display and emitter animate independently.
  const scanner = new THREE.Group(); scanner.name = 'ScannerViewModel';
  addCylinderZ(scanner, glove, 0.065, 0.073, 0.30, [0, -0.04, 0.02], 14);
  addCylinderZ(scanner, rubber, 0.071, 0.071, 0.18, [0, -0.055, 0.02], 14);
  for (let i = 0; i < 4; i++) addRingZ(scanner, gloveEdge, 0.071, 0.009, [0, -0.04, 0.09 - i * 0.055], 18);
  addMesh(scanner, new THREE.BoxGeometry(0.34, 0.22, 0.34), deviceDark, [0, 0.105, -0.22], [1, 1, 0.9]);
  addMesh(scanner, new THREE.BoxGeometry(0.37, 0.045, 0.36), deviceMid, [0, 0.225, -0.22]);
  addMesh(scanner, new THREE.BoxGeometry(0.255, 0.012, 0.155), trim, [0, 0.252, -0.205]);
  addMesh(scanner, new THREE.BoxGeometry(0.225, 0.008, 0.125), screenDark, [0, 0.261, -0.205]);
  addMesh(scanner, new THREE.BoxGeometry(0.145, 0.004, 0.009), screenMat, [0, 0.268, -0.22]);
  addMesh(scanner, new THREE.BoxGeometry(0.105, 0.004, 0.008), glowBlue, [0, 0.268, -0.188]);
  addMesh(scanner, new THREE.BoxGeometry(0.18, 0.006, 0.008), trim, [0, 0.268, -0.245]);
  for (const x of [-0.14, 0.14]) {
    addMesh(scanner, new THREE.BoxGeometry(0.025, 0.16, 0.26), orange, [x, 0.10, -0.22]);
    addMesh(scanner, new THREE.SphereGeometry(0.018, 8, 6), glowAmber, [x, 0.20, -0.20]);
  }
  addCylinderZ(scanner, deviceMid, 0.105, 0.105, 0.07, [0, 0.04, -0.415], 20);
  addRingZ(scanner, trim, 0.104, 0.019, [0, 0.04, -0.455], 24);
  addCylinderZ(scanner, screenDark, 0.077, 0.077, 0.025, [0, 0.04, -0.466], 20);
  const scannerLensMat = new THREE.MeshStandardMaterial({ color: 0x77f4ef, emissive: 0x2ccbd2, emissiveIntensity: 1.15, roughness: 0.16, metalness: 0.12 });
  addCylinderZ(scanner, scannerLensMat, 0.058, 0.058, 0.014, [0, 0.04, -0.484], 20);
  const scanRings = new THREE.Group();
  for (let i = 0; i < 3; i++) {
    const ring = addMesh(scanRings, new THREE.TorusGeometry(0.07 + i * 0.024, 0.006, 5, 24), i === 1 ? glowBlue : trim, [0, 0.04, -0.50 - i * 0.012]);
    ring.rotation.y = i * 0.28;
  }
  scanner.add(scanRings);
  const scannerGlow = new THREE.PointLight(0x70f5f1, 0.75, 3.2); scannerGlow.position.set(0, 0.08, -0.49); scanner.add(scannerGlow);
  scanner.position.set(0.02, -0.39, -0.39); scanner.visible = false; setGripAnchor(scanner, [0, -0.04, 0.02]); right.add(scanner);
  scanner.userData.scanRings = scanRings;

  // Survival knife: textured handle, grip rings, guard, a tapered metal blade
  // and a visible spine/edge highlight rather than a flat rectangular slab.
  const knife = new THREE.Group(); knife.name = 'SurvivalKnifeViewModel';
  addCylinderZ(knife, orange, 0.055, 0.061, 0.30, [0, -0.02, 0.015], 12);
  addCylinderZ(knife, rubber, 0.058, 0.058, 0.18, [0, -0.02, 0.02], 12);
  for (let i = 0; i < 5; i++) addRingZ(knife, gloveEdge, 0.059, 0.009, [0, -0.02, 0.11 - i * 0.046], 16);
  addMesh(knife, new THREE.BoxGeometry(0.21, 0.055, 0.07), trim, [0, -0.02, -0.16]);
  addMesh(knife, new THREE.BoxGeometry(0.13, 0.025, 0.055), orange, [0, -0.02, -0.205]);
  addMesh(knife, new THREE.BoxGeometry(0.095, 0.038, 0.38), bladeMat, [0, -0.012, -0.405]);
  addMesh(knife, new THREE.ConeGeometry(0.051, 0.17, 4), bladeMat, [0, -0.012, -0.675], [1, 1, 1], [-Math.PI / 2, 0, 0]);
  addMesh(knife, new THREE.BoxGeometry(0.012, 0.012, 0.39), new THREE.MeshStandardMaterial({ color: 0xf1ffff, metalness: 0.9, roughness: 0.18 }), [0.043, 0.009, -0.405]);
  addMesh(knife, new THREE.SphereGeometry(0.018, 8, 6), glowAmber, [0, -0.02, 0.17]);
  knife.position.set(0.02, -0.39, -0.39); knife.visible = false; setGripAnchor(knife, [0, -0.012, 0.02]); right.add(knife);

  // Flashlight: ribbed grip, stepped reflector head, glass lens, working SpotLight
  // and a restrained volumetric-style beam mesh.
  const flashlight = new THREE.Group(); flashlight.name = 'FlashlightViewModel';
  addCylinderZ(flashlight, glove, 0.075, 0.087, 0.38, [0, -0.015, 0.025], 16);
  addCylinderZ(flashlight, rubber, 0.078, 0.078, 0.21, [0, -0.015, 0.035], 16);
  for (let i = 0; i < 6; i++) addRingZ(flashlight, gloveEdge, 0.081, 0.008, [0, -0.015, 0.14 - i * 0.052], 18);
  addRingZ(flashlight, orange, 0.087, 0.012, [0, -0.015, -0.18], 20);
  addCylinderZ(flashlight, deviceMid, 0.118, 0.09, 0.16, [0, -0.015, -0.255], 20);
  addRingZ(flashlight, trim, 0.119, 0.018, [0, -0.015, -0.325], 24);
  addCylinderZ(flashlight, screenDark, 0.094, 0.094, 0.018, [0, -0.015, -0.344], 24);
  const torchLensMat = new THREE.MeshStandardMaterial({ color: 0x9ffaf1, emissive: 0x48e9df, emissiveIntensity: 0.08, metalness: 0.08, roughness: 0.12 });
  addCylinderZ(flashlight, torchLensMat, 0.078, 0.078, 0.012, [0, -0.015, -0.357], 24);
  addMesh(flashlight, new THREE.BoxGeometry(0.045, 0.025, 0.035), orange, [0.075, 0.055, -0.04]);
  const flashlightBeam = new THREE.SpotLight(0xc8fbff, 46, 58, Math.PI / 9, 0.68, 1.15);
  flashlightBeam.position.set(0, -0.015, -0.36);
  flashlightBeam.target.position.set(0, -0.02, -20);
  flashlightBeam.castShadow = false;
  flashlight.add(flashlightBeam, flashlightBeam.target);
  const flashlightNearLight = new THREE.PointLight(0x8defff, 0, 7.2, 1.45);
  flashlightNearLight.position.set(0, -0.02, -0.39); flashlight.add(flashlightNearLight);
  const flashlightConeMat = new THREE.MeshBasicMaterial({ color: 0x8ceeff, transparent: true, opacity: 0.075, depthTest: false, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending });
  const flashlightCone = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.68, 13.5, 28, 1, true), flashlightConeMat);
  flashlightCone.rotation.x = -Math.PI / 2; flashlightCone.position.set(0, -0.015, -7.1); flashlightCone.renderOrder = 1001; flashlight.add(flashlightCone);
  flashlight.position.set(0.02, -0.39, -0.39); flashlight.visible = false; setGripAnchor(flashlight, [0, -0.015, 0.035]); right.add(flashlight);

  // Habitat Builder: hand grip, articulated side rails and twin projection heads.
  const builder = new THREE.Group(); builder.name = 'HabitatBuilderViewModel';
  addCylinderZ(builder, glove, 0.073, 0.08, 0.32, [0, -0.035, 0.015], 14);
  addCylinderZ(builder, rubber, 0.076, 0.076, 0.19, [0, -0.035, 0.02], 14);
  for (let i = 0; i < 4; i++) addRingZ(builder, gloveEdge, 0.077, 0.008, [0, -0.035, 0.105 - i * 0.052], 18);
  addMesh(builder, new THREE.BoxGeometry(0.34, 0.22, 0.38), orange, [0, 0.12, -0.22]);
  addMesh(builder, new THREE.BoxGeometry(0.29, 0.045, 0.30), deviceDark, [0, 0.245, -0.22]);
  addMesh(builder, new THREE.BoxGeometry(0.205, 0.012, 0.105), screenDark, [0, 0.273, -0.22]);
  addMesh(builder, new THREE.BoxGeometry(0.14, 0.004, 0.008), glowBlue, [0, 0.281, -0.22]);
  for (const side of [-1, 1]) {
    addMesh(builder, new THREE.BoxGeometry(0.055, 0.25, 0.12), deviceMid, [side * 0.17, 0.04, -0.30], null, [0, 0, side * 0.12]);
    addCylinderZ(builder, glowBlue, 0.045, 0.045, 0.04, [side * 0.13, 0.02, -0.43], 16);
  }
  const builderEmitters = new THREE.Group();
  for (const side of [-1, 1]) {
    const ring = addMesh(builderEmitters, new THREE.TorusGeometry(0.075, 0.008, 6, 20), glowBlue, [side * 0.13, 0.02, -0.46]);
    ring.rotation.y = side * 0.18;
    addMesh(builderEmitters, new THREE.SphereGeometry(0.034, 12, 8), glowAmber, [side * 0.13, 0.02, -0.46]);
  }
  builder.add(builderEmitters);
  const builderGlow = new THREE.PointLight(0x67f7e8, 0.8, 4.5); builderGlow.position.set(0, 0.04, -0.48); builder.add(builderGlow);
  builder.position.set(0.02, -0.39, -0.39); builder.visible = false; setGripAnchor(builder, [0, -0.025, 0.02]); right.add(builder);
  builder.userData.emitters = builderEmitters;

  // Repair Tool: insulated barrel, copper collar, repair nozzle and animated coil.
  const repairTool = new THREE.Group(); repairTool.name = 'RepairToolViewModel';
  addCylinderZ(repairTool, glove, 0.083, 0.11, 0.39, [0, -0.02, 0.015], 14);
  addCylinderZ(repairTool, rubber, 0.086, 0.086, 0.22, [0, -0.02, 0.02], 14);
  for (let i = 0; i < 4; i++) addRingZ(repairTool, gloveEdge, 0.088, 0.009, [0, -0.02, 0.10 - i * 0.06], 18);
  addRingZ(repairTool, orange, 0.112, 0.018, [0, -0.02, -0.19], 20);
  addCylinderZ(repairTool, deviceMid, 0.105, 0.095, 0.16, [0, -0.02, -0.28], 16);
  addMesh(repairTool, new THREE.BoxGeometry(0.27, 0.13, 0.18), deviceDark, [0, 0.035, -0.34]);
  addCylinderZ(repairTool, glowBlue, 0.063, 0.063, 0.035, [0, 0.035, -0.445], 16);
  const repairCoil = new THREE.Group();
  for (let i = 0; i < 3; i++) addMesh(repairCoil, new THREE.TorusGeometry(0.10 + i * 0.013, 0.008, 6, 20), i === 1 ? glowBlue : trim, [0, 0.035, -0.46 - i * 0.018]);
  repairTool.add(repairCoil);
  const repairGlow = new THREE.PointLight(0x73e8e0, 0.8, 3); repairGlow.position.set(0, 0.04, -0.49); repairTool.add(repairGlow);
  repairTool.position.set(0.02, -0.39, -0.39); repairTool.visible = false; setGripAnchor(repairTool, [0, -0.02, 0.02]); right.add(repairTool);
  repairTool.userData.coil = repairCoil;

  // Seaglide: wider propulsion housing, guarded propeller, display and twin
  // side handles. It remains one of the five selectable Quick Slot items.
  const seaglide = new THREE.Group(); seaglide.name = 'SeaglideViewModel';
  const glideBody = addMesh(seaglide, new THREE.BoxGeometry(0.76, 0.33, 0.68), deviceDark, [0, 0.02, -0.22], [1, 1, 1]);
  addMesh(seaglide, new THREE.BoxGeometry(0.69, 0.065, 0.48), deviceMid, [0, 0.185, -0.22]);
  addMesh(seaglide, new THREE.BoxGeometry(0.255, 0.016, 0.145), trim, [0, 0.225, -0.18]);
  addMesh(seaglide, new THREE.BoxGeometry(0.22, 0.008, 0.115), screenDark, [0, 0.237, -0.18]);
  addMesh(seaglide, new THREE.BoxGeometry(0.14, 0.004, 0.008), glowBlue, [0, 0.244, -0.20]);
  const glideRing = addMesh(seaglide, new THREE.TorusGeometry(0.205, 0.032, 9, 24), trim, [0, 0.02, -0.61]);
  const propGuard = addMesh(seaglide, new THREE.TorusGeometry(0.235, 0.016, 7, 24), deviceMid, [0, 0.02, -0.63]);
  const glideProp = new THREE.Group();
  const propMaterial = new THREE.MeshStandardMaterial({ color: 0x9bd9d6, metalness: 0.72, roughness: 0.3 });
  for (let i = 0; i < 5; i++) {
    const blade = addMesh(glideProp, new THREE.BoxGeometry(0.052, 0.245, 0.034), propMaterial, [0, 0.125, 0], [1, 1, 1], [0, 0, i * Math.PI * 2 / 5]);
    blade.position.y = 0.12;
  }
  glideProp.position.set(0, 0.02, -0.64); seaglide.add(glideProp);
  for (const side of [-1, 1]) {
    addCylinderZ(seaglide, rubber, 0.06, 0.06, 0.29, [side * 0.45, -0.10, -0.015], 12);
    addRingZ(seaglide, orange, 0.061, 0.008, [side * 0.45, -0.10, 0.10], 16);
    addRingZ(seaglide, gloveEdge, 0.061, 0.008, [side * 0.45, -0.10, -0.12], 16);
  }
  const glideLamp = new THREE.PointLight(0x5ee7dc, 0.9, 4); glideLamp.position.set(0, 0.03, -0.70); seaglide.add(glideLamp);
  seaglide.position.set(-0.48, -0.38, -0.43); seaglide.visible = false; setGripAnchor(seaglide, [0.45, -0.10, -0.02]); right.add(seaglide);

  // Generic resource/supply models. Each item has a distinct silhouette and
  // material so a selected resource is still represented by a visible 3D mesh.
  const heldItems = Object.create(null);
  const makeHeldMaterial = (color, options = {}) => new THREE.MeshStandardMaterial({
    color, map: options.map || null, bumpMap: options.bumpMap || null, bumpScale: options.bumpScale || 0.035,
    metalness: options.metalness ?? 0.12, roughness: options.roughness ?? 0.68,
    emissive: options.emissive || 0x000000, emissiveIntensity: options.emissiveIntensity ?? 0,
    transparent: Boolean(options.transparent), opacity: options.opacity ?? 1, side: THREE.DoubleSide
  });
  const heldRock = makeHeldMaterial(0xb0b7a9, { map: rockTexture, bumpMap: rockBumpTexture, metalness: 0.25 });
  const heldMetal = makeHeldMaterial(0x82999b, { map: metalTexture, bumpMap: metalBumpTexture, metalness: 0.7, roughness: 0.36 });
  const heldPlant = makeHeldMaterial(0x4b9b79, { map: kelpTexture, bumpMap: kelpBumpTexture, roughness: 0.78 });
  const heldCoral = makeHeldMaterial(0xd47b69, { map: coralTexture, bumpMap: coralBumpTexture, roughness: 0.82 });
  const heldWhite = makeHeldMaterial(0xe4e9e1, { roughness: 0.58 });
  const heldAccent = makeHeldMaterial(0xd44f4d, { roughness: 0.58 });
  const heldGlow = new THREE.MeshStandardMaterial({ color: 0x8fe7df, emissive: 0x1b8b88, emissiveIntensity: 0.32, roughness: 0.32, metalness: 0.24 });
  const makeHeldItem = (id) => {
    if (['explorer_pda', 'scanner', 'knife', 'flashlight', 'habitat_builder', 'repair_tool', 'seaglide'].includes(id)) return;
    const group = new THREE.Group(); group.name = `Held_${id}`;
    const mineral = ['titanium', 'copper', 'quartz', 'lithium', 'sulfur', 'magnetite', 'salt', 'silver', 'glowcap', 'coral'];
    if (id === 'kelp') {
      addMesh(group,new THREE.CylinderGeometry(.018,.026,.34,8),heldPlant,[0,-.01,-.04]);
      const kelpVeinMaterial=makeHeldMaterial(0x9bd9b2,{roughness:.82,metalness:.02});
      const makeKelpBlade=(length,width,curve=0)=>{
        const shape=new THREE.Shape();
        shape.moveTo(0,0);shape.quadraticCurveTo(width*.58,length*.24,width*.50,length*.58);
        shape.quadraticCurveTo(width*.36,length*.88,curve,length);
        shape.quadraticCurveTo(-width*.22,length*.79,-width*.46,length*.53);
        shape.quadraticCurveTo(-width*.62,length*.19,0,0);
        return new THREE.ShapeGeometry(shape,12);
      };
      for (let i = 0; i < 5; i++) {
        const length=.27+(i%3)*.055,width=.085+(i%2)*.018,x=(i-2)*.038;
        const blade=addMesh(group,makeKelpBlade(length,width,(i-2)*.012),heldPlant,[x,-.015,-.055+(i%2)*.018],[1,1,1],[0,0,(i-2)*.18]);
        blade.material.side=THREE.DoubleSide;
        addLine(group,kelpVeinMaterial,[[x,-.01,-.046],[x+(i-2)*.012,length*.34,-.046],[x+(i-2)*.018,length*.70,-.046],[x+(i-2)*.012,length*.96,-.046]],.0045);
      }
      addMesh(group,new THREE.TorusGeometry(.055,.012,5,14),heldGlow,[0,-.17,-.04],[1,1,.42],[Math.PI/2,0,0]);
    } else if (mineral.includes(id)) {
      const color = ({ titanium: 0x899ba1, copper: 0xb87849, quartz: 0xb8e5e0, lithium: 0xa8b6d7, sulfur: 0xe1c85d, magnetite: 0x3f535f, salt: 0xe3e5df, silver: 0xc6d1d4, glowcap: 0xb2d96c, coral: 0xd47b69 })[id];
      const material = ['quartz','lithium'].includes(id)
        ? new THREE.MeshPhysicalMaterial({
            color, map: rockTexture, bumpMap: rockBumpTexture, bumpScale: 0.018,
            roughness: id === 'quartz' ? 0.16 : 0.22, metalness: 0.06,
            transmission: id === 'quartz' ? 0.42 : 0.18, thickness: 0.22, ior: 1.42,
            clearcoat: 0.92, clearcoatRoughness: 0.12, transparent: true, opacity: 0.94,
            emissive: id === 'lithium' ? 0x3d4c91 : 0x183e48,
            emissiveIntensity: id === 'lithium' ? 0.24 : 0.08, side: THREE.DoubleSide
          })
        : makeHeldMaterial(color, {
            map: id === 'coral' || id === 'glowcap' ? coralTexture : ['titanium','copper','magnetite','silver'].includes(id) ? metalTexture : rockTexture,
            bumpMap: id === 'coral' || id === 'glowcap' ? coralBumpTexture : rockBumpTexture,
            metalness: ({titanium:.78,copper:.68,magnetite:.9,silver:.92,sulfur:.06,salt:.08,coral:.04,glowcap:.04})[id] ?? 0.08,
            roughness: ({titanium:.34,copper:.39,magnetite:.27,silver:.22,sulfur:.43,salt:.7,coral:.82,glowcap:.38})[id] ?? .62,
            emissive: id === 'sulfur' ? 0x74551a : id === 'glowcap' ? 0x285d25 : 0x000000,
            emissiveIntensity: id === 'sulfur' ? .19 : id === 'glowcap' ? .42 : 0
          });
      if (id === 'coral') {
        addMesh(group, new THREE.IcosahedronGeometry(0.12, 1), heldCoral, [0, 0, -0.03], [0.9, 0.72, 0.8]);
        for (let i = 0; i < 4; i++) addMesh(group, new THREE.CapsuleGeometry(0.022, 0.14, 3, 6), heldCoral, [(i - 1.5) * 0.055, 0.065, -0.05 + (i % 2) * 0.025], [1, 1, 1], [0, 0, (i - 1.5) * 0.38]);
        for (let i = 0; i < 3; i++) addMesh(group, new THREE.SphereGeometry(0.019, 8, 6), glowAmber, [(i - 1) * 0.055, 0.11, -0.06], [1, 1, 0.8]);
      } else if (id === 'glowcap') {
        addCylinderZ(group, heldPlant, 0.035, 0.035, 0.18, [0, -0.025, -0.02], 10);
        addMesh(group, new THREE.SphereGeometry(0.105, 14, 10), heldGlow, [0, 0.09, -0.02], [1, 0.62, 1]);
        addRingZ(group, glowAmber, 0.073, 0.008, [0, 0.09, -0.065], 16);
      } else {
        const visualProfile=getResourceVisualProfile(id);
        const radius = id === 'salt' ? 0.105 : 0.125;
        const metallicOre = ['titanium','copper','magnetite','silver'].includes(id);
        if(id==='titanium'){
          const ingotShape=new THREE.Shape();
          ingotShape.moveTo(-.13,-.075);ingotShape.lineTo(.12,-.075);ingotShape.lineTo(.16,-.03);ingotShape.lineTo(.13,.075);ingotShape.lineTo(-.11,.075);ingotShape.lineTo(-.16,.025);ingotShape.closePath();
          const ingot=new THREE.Mesh(new THREE.ExtrudeGeometry(ingotShape,{depth:.28,bevelEnabled:true,bevelSegments:2,steps:1,bevelSize:.018,bevelThickness:.018}),material);
          ingot.position.set(0,-.035,-.19);ingot.rotation.set(.08,.12,-.06);group.add(ingot);
          addMesh(group,new THREE.BoxGeometry(.018,.12,.018),heldWhite,[.10,.005,-.08],[1,1,1],[0,.12,.08]);
        } else if(id==='salt'){
          for(let crystal=0;crystal<4;crystal++){
            const a=crystal*Math.PI*.5;const cube=new THREE.Mesh(new THREE.BoxGeometry(.105,.105,.105),material);
            cube.position.set(Math.cos(a)*.07,(crystal%2)*.04-.02,-.045+Math.sin(a)*.045);cube.rotation.set(.14*crystal,a*.3,.11*crystal);group.add(cube);
          }
        } else {
          const oreGeometry = id==='magnetite'?new THREE.OctahedronGeometry(radius,1):metallicOre?new THREE.DodecahedronGeometry(radius,1):new THREE.IcosahedronGeometry(radius,id==='sulfur'?0:1);
          const core = addMesh(group, oreGeometry, material, [0, 0, -0.04], [0.95, 1.08, 0.82], [0.12, id.length * 0.11, -0.08]);
          core.castShadow = true;
          if (['quartz', 'lithium', 'sulfur'].includes(id)) {
            const clusterMaterial = id === 'sulfur' ? glowAmber : material;
            const shardCount = id === 'quartz' ? 5 : id === 'lithium' ? 4 : 3;
            for (let shard = 0; shard < shardCount; shard++) {
              const angle = shard / shardCount * Math.PI * 2;
              const height = (id === 'quartz' ? .22 : id === 'lithium' ? .19 : .14) + (shard % 2) * .065;
              const width=id==='lithium'?.025:id==='sulfur'?.038:.031;
              const crystal=new THREE.Mesh(new THREE.CylinderGeometry(width*.12,width,height,6,1),clusterMaterial);
              crystal.position.set(Math.cos(angle)*.074, .05 + (shard%2)*.018, -.055 + Math.sin(angle)*.035);
              crystal.rotation.z=.11+shard*.035;crystal.rotation.y=angle;group.add(crystal);
              addMesh(group,new THREE.ConeGeometry(width,height*.22,6),clusterMaterial,[crystal.position.x,crystal.position.y+height*.48,crystal.position.z],[1,1,1],[0,angle,0]);
            }
          }
          if (metallicOre) {
            const seamMat = id === 'copper' ? orange : deviceMid;
            for (let i = 0; i < 4; i++) {
              const angle=i*Math.PI*.5;
              addMesh(group,new THREE.BoxGeometry(.022,.105,.018),seamMat,[Math.cos(angle)*.083,-.005,-.13+Math.sin(angle)*.025],[1,1,1],[.1,angle*.3,(i-1.5)*.14]);
            }
            for(let nugget=0;nugget<(id==='copper'?3:2);nugget++){
              const a=nugget*Math.PI*2/3;const fleck=new THREE.Mesh(new THREE.DodecahedronGeometry(.035,0),id==='copper'?orange:heldWhite);
              fleck.position.set(Math.cos(a)*.085,.075,Math.sin(a)*.07-.11);group.add(fleck);
            }
          }
        }
      }
    } else if (id === 'fish_meat') {
      const meat = makeHeldMaterial(0xb96f68, { map: coralTexture, roughness: 0.83 });
      addMesh(group, new THREE.SphereGeometry(0.14, 16, 12), meat, [0, 0, -0.04], [0.82, 0.55, 1.25], [0.1, 0, 0.18]);
      addMesh(group, new THREE.SphereGeometry(0.075, 12, 8), heldWhite, [0.07, 0.045, -0.10], [0.55, 0.35, 0.7]);
      addMesh(group, new THREE.BoxGeometry(0.018, 0.11, 0.14), heldWhite, [-0.045, 0.005, -0.06], [1, 1, 1], [0, 0, 0.12]);
    } else if (id === 'medkit') {
      addMesh(group, new THREE.BoxGeometry(0.29, 0.19, 0.24), heldWhite, [0, 0, -0.08]);
      addMesh(group, new THREE.BoxGeometry(0.055, 0.14, 0.018), heldAccent, [0, 0.005, -0.206]);
      addMesh(group, new THREE.BoxGeometry(0.15, 0.05, 0.018), heldAccent, [0, 0.005, -0.206]);
      addMesh(group, new THREE.BoxGeometry(0.3, 0.025, 0.26), heldMetal, [0, 0.105, -0.08]);
      addMesh(group, new THREE.BoxGeometry(0.045, 0.012, 0.02), orange, [0.10, 0.12, -0.08]);
    } else if (id === 'ration') {
      const can = makeHeldMaterial(0xd9a45a, { map: metalTexture, metalness: 0.62, roughness: 0.38 });
      addCylinderZ(group, can, 0.105, 0.105, 0.27, [0, 0, -0.04]);
      addCylinderZ(group, heldMetal, 0.105, 0.105, 0.025, [0, 0, -0.19]);
      addMesh(group, new THREE.BoxGeometry(0.12, 0.11, 0.016), heldAccent, [0, 0, -0.20]);
      addRingZ(group, orange, 0.098, 0.007, [0, 0, 0.09], 18);
    } else if (id === 'water') {
      const bottle = makeHeldMaterial(0x74b9c0, { transparent: true, opacity: 0.76, roughness: 0.16, metalness: 0.08 });
      addCylinderZ(group, bottle, 0.074, 0.09, 0.25, [0, -0.01, -0.04], 12);
      addCylinderZ(group, bottle, 0.045, 0.074, 0.06, [0, 0.145, -0.04], 12);
      addCylinderZ(group, heldAccent, 0.048, 0.048, 0.045, [0, 0.195, -0.04], 12);
      addMesh(group, new THREE.BoxGeometry(0.09, 0.065, 0.012), heldGlow, [0, 0, -0.17]);
      addMesh(group, new THREE.BoxGeometry(0.018, 0.055, 0.014), heldWhite, [0, 0.002, -0.18]);
    } else if (id === 'battery' || id === 'power_cell') {
      const length = id === 'power_cell' ? 0.38 : 0.25;
      addCylinderZ(group, heldMetal, 0.085, 0.085, length, [0, 0, -0.04], 14);
      addCylinderZ(group, heldGlow, 0.071, 0.071, 0.035, [0, 0, -length / 2 - 0.035], 14);
      addCylinderZ(group, orange, 0.052, 0.052, 0.028, [0, 0, length / 2 + 0.01], 12);
      addMesh(group, new THREE.BoxGeometry(0.065, 0.06, 0.025), heldAccent, [0, 0.055, -0.04]);
      addRingZ(group, trim, 0.087, 0.007, [0, 0, 0.045], 18);
    } else if (id === 'wiring_kit') {
      const wire = makeHeldMaterial(0x4a7180, { metalness: 0.72, roughness: 0.34 });
      for (let i = 0; i < 3; i++) {
        const loop = addMesh(group, new THREE.TorusGeometry(0.075, 0.012, 7, 20), wire, [(i - 1) * 0.07, 0, -0.04]);
        loop.rotation.y = i * 0.22;
      }
      addMesh(group, new THREE.BoxGeometry(0.08, 0.035, 0.08), heldAccent, [0, -0.095, -0.04]);
    } else if (id === 'computer_chip') {
      addMesh(group, new THREE.BoxGeometry(0.22, 0.035, 0.19), heldMetal, [0, 0, -0.04]);
      addMesh(group, new THREE.BoxGeometry(0.11, 0.018, 0.09), heldGlow, [0, 0.027, -0.04]);
      for (let i = 0; i < 4; i++) {
        addMesh(group, new THREE.BoxGeometry(0.025, 0.018, 0.012), heldAccent, [-0.075 + i * 0.05, -0.018, -0.14]);
        addMesh(group, new THREE.BoxGeometry(0.025, 0.018, 0.012), heldAccent, [-0.075 + i * 0.05, -0.018, 0.06]);
      }
    } else if (id === 'glass') {
      const glass = makeHeldMaterial(0x9bd8d4, { transparent: true, opacity: 0.72, roughness: 0.12, metalness: 0.04 });
      addMesh(group, new THREE.OctahedronGeometry(0.15, 0), glass, [0, 0, -0.04], [0.72, 1.2, 0.58]);
      addMesh(group, new THREE.OctahedronGeometry(0.075, 0), heldWhite, [0.035, 0.04, -0.10], [0.8, 1.1, 0.5]);
    } else if (id === 'fiber_mesh') {
      const meshMat = makeHeldMaterial(0x638f7b, { map: kelpTexture, roughness: 0.9 });
      addMesh(group, new THREE.BoxGeometry(0.25, 0.17, 0.035), meshMat, [0, 0, -0.04]);
      for (let i = 0; i < 5; i++) addMesh(group, new THREE.BoxGeometry(0.012, 0.16, 0.012), heldWhite, [-0.1 + i * 0.05, 0, -0.012]);
      addMesh(group, new THREE.BoxGeometry(0.27, 0.018, 0.045), heldPlant, [0, 0.09, -0.04]);
    } else if (['silicone', 'lubricant', 'bleach'].includes(id)) {
      const bottleMat = makeHeldMaterial(id === 'bleach' ? 0xe2e5db : id === 'lubricant' ? 0x9fbd77 : 0xa3c8bd, { map: metalTexture, roughness: 0.54 });
      addCylinderZ(group, bottleMat, 0.09, 0.105, 0.23, [0, -0.015, -0.04], 12);
      addCylinderZ(group, heldMetal, 0.045, 0.045, 0.05, [0, 0.13, -0.04], 12);
      addCylinderZ(group, heldAccent, 0.052, 0.052, 0.035, [0, 0.17, -0.04], 12);
      addMesh(group, new THREE.BoxGeometry(0.10, 0.07, 0.012), heldWhite, [0, 0, -0.145]);
      addMesh(group, new THREE.BoxGeometry(0.055, 0.012, 0.014), heldGlow, [0, 0.015, -0.155]);
    } else {
      addMesh(group, new THREE.IcosahedronGeometry(0.13, 1), heldRock, [0, 0, -0.04]);
    }
    const heldPresentation = resolveHeldItemPresentation(id);
    group.position.set(...heldPresentation.position);
    group.rotation.set(...heldPresentation.rotation);
    const itemProportions=getResourceVisualProfile(id).heldScale||[1,1,1];
    group.scale.set(heldPresentation.scale*itemProportions[0],heldPresentation.scale*itemProportions[1],heldPresentation.scale*itemProportions[2]);
    group.visible = false;
    group.userData.heldItemId=id;
    group.userData.heldPresentation=heldPresentation;
    setGripAnchor(group, heldPresentation.gripOffset);
    right.add(group); heldItems[id] = group;
  };
  for (const id of Object.keys(ITEM_DEFS)) makeHeldItem(id);

  // Attach every model to a stable, hand-sized mount. The open right hand is
  // hidden by the selected object's grip overlay instead of competing with it.
  viewModel.add(left, right);
  viewModel.position.set(0, 0, 0);
  viewModel.frustumCulled = false;
  viewModel.renderOrder = 20;
  camera.add(viewModel);
  setLayer(left, 1000); setLayer(right, 1000);
  for (const model of [scanner, knife, flashlight, builder, repairTool, seaglide, ...Object.values(heldItems)]) setLayer(model, 1001);
  setLayer(rightGrip, 1002); setLayer(leftGrip, 1002);

  viewModel.userData.left = left; viewModel.userData.right = right;
  viewModel.userData.scanner = scanner; viewModel.userData.knife = knife; viewModel.userData.flashlight = flashlight;
  viewModel.userData.builder = builder; viewModel.userData.repairTool = repairTool;
  viewModel.userData.seaglide = seaglide; viewModel.userData.seaglideProp = glideProp;
  viewModel.userData.flashlightBeam = flashlightBeam; viewModel.userData.flashlightCone = flashlightCone;
  viewModel.userData.flashlightNearLight = flashlightNearLight; viewModel.userData.flashlightLensMat = torchLensMat;
  viewModel.userData.heldItems = heldItems; viewModel.userData.rightGrip = rightGrip; viewModel.userData.leftGrip = leftGrip;
  viewModel.userData.equipTimer = 0; viewModel.userData.actionTimer = 0; viewModel.userData.actionType = '';
  viewModel.userData.toolModels = { scanner, knife, flashlight, habitat_builder: builder, repair_tool: repairTool, seaglide };
}

function makePlayer() {
  playerGroup = new THREE.Group();
  const suit = new THREE.MeshStandardMaterial({ color: 0xe0ded2, roughness: 0.82, metalness: 0.08 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x183f4d, roughness: 0.8 });
  const glass = new THREE.MeshStandardMaterial({ color: 0x5ed6df, roughness: 0.18, metalness: 0.35, transparent: true, opacity: 0.78 });
  const orange = new THREE.MeshStandardMaterial({ color: 0xd18b49, roughness: 0.7 });
  playerBody = new THREE.Group();
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.72, 1.25, 4, 8), suit);
  torso.rotation.x = Math.PI / 2;
  torso.position.y = 0.1;
  playerBody.add(torso);
  const chest = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.52, 0.28), dark);
  chest.position.set(0, 0.22, -0.55);
  playerBody.add(chest);
  const helmet = new THREE.Mesh(new THREE.SphereGeometry(0.55, 12, 9), suit);
  helmet.position.set(0, 1.24, -0.05);
  playerBody.add(helmet);
  const visor = new THREE.Mesh(new THREE.SphereGeometry(0.38, 12, 8), glass);
  visor.scale.set(1.08, 0.72, 0.55);
  visor.position.set(0, 1.26, -0.44);
  playerBody.add(visor);
  const tank = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.32, 1.4, 8), orange);
  tank.position.set(0, 0.16, 0.62);
  playerBody.add(tank);
  const armGeo = new THREE.CapsuleGeometry(0.19, 0.72, 3, 6);
  leftArm = new THREE.Group();
  rightArm = new THREE.Group();
  const armL = new THREE.Mesh(armGeo, suit), armR = new THREE.Mesh(armGeo, suit);
  armL.position.y = -0.39; armR.position.y = -0.39;
  leftArm.add(armL); rightArm.add(armR);
  leftArm.position.set(-0.78, 0.42, -0.1); rightArm.position.set(0.78, 0.42, -0.1);
  playerBody.add(leftArm, rightArm);
  const legGeo = new THREE.CapsuleGeometry(0.23, 0.75, 3, 6);
  const legL = new THREE.Mesh(legGeo, dark), legR = new THREE.Mesh(legGeo, dark);
  legL.position.set(-0.3, -0.92, 0.03); legR.position.set(0.3, -0.92, 0.03);
  playerBody.add(legL, legR);
  const finGeo = new THREE.BoxGeometry(0.32, 0.13, 0.83);
  leftFin = new THREE.Mesh(finGeo, orange); rightFin = new THREE.Mesh(finGeo, orange);
  leftFin.position.set(-0.3, -1.45, -0.38); rightFin.position.set(0.3, -1.45, -0.38);
  playerBody.add(leftFin, rightFin);
  playerGroup.add(playerBody);
  playerGroup.scale.setScalar(0.86);
  scene.add(playerGroup);
}

function makePalm(group, localX, localZ, baseY, scale = 1) {
  const trunkMaterial = new THREE.MeshStandardMaterial({ color: 0x77583b, roughness: 1 });
  const leafMaterial = new THREE.MeshStandardMaterial({ color: 0x2d755e, roughness: 0.9, flatShading: true });
  const palm = new THREE.Group();
  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.42, 6.2, 6), trunkMaterial);
  trunk.position.y = 3.1;
  palm.add(trunk);
  for (let i = 0; i < 7; i++) {
    const leaf = new THREE.Mesh(new THREE.ConeGeometry(0.48, 4.6, 5), leafMaterial);
    const angle = (i / 7) * Math.PI * 2;
    leaf.position.set(Math.cos(angle) * 1.2, 6.0, Math.sin(angle) * 1.2);
    leaf.rotation.z = Math.cos(angle) * 0.92;
    leaf.rotation.x = Math.sin(angle) * 0.92;
    leaf.rotation.y = angle;
    palm.add(leaf);
  }
  palm.position.set(localX, baseY, localZ);
  palm.scale.setScalar(scale);
  group.add(palm);
}

function makeWreck(group, baseX, baseZ) {
  const wreck = new THREE.Group();
  const hullMat = new THREE.MeshStandardMaterial({ color: 0x684934, map:woodTexture, bumpMap:woodBumpTexture, bumpScale:0.24, roughness: 0.98, flatShading: true });
  const plankMat = new THREE.MeshStandardMaterial({ color: 0x947052, map:woodTexture, bumpMap:woodBumpTexture, bumpScale:0.18, roughness: 0.98 });
  const metalMat = new THREE.MeshStandardMaterial({ color: 0x314b51, map:metalTexture, bumpMap:metalBumpTexture, bumpScale:0.12, metalness: 0.58, roughness: 0.82 });
  const hull = new THREE.Mesh(new THREE.BoxGeometry(30, 6, 8), hullMat);
  hull.scale.set(1, 0.82, 1);
  wreck.add(hull);
  const bow = new THREE.Mesh(new THREE.ConeGeometry(4.2, 8, 4), hullMat);
  bow.rotation.z = Math.PI / 2;
  bow.rotation.y = Math.PI / 4;
  bow.position.x = 17.5;
  wreck.add(bow);
  const deck = new THREE.Mesh(new THREE.BoxGeometry(23, 0.65, 7.3), plankMat);
  deck.position.y = 3.1;
  wreck.add(deck);
  const cabin = new THREE.Mesh(new THREE.BoxGeometry(7, 4.3, 5.2), plankMat);
  cabin.position.set(-4, 5.4, 0);
  cabin.rotation.z = -0.12;
  wreck.add(cabin);
  const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.38, 15, 6), metalMat);
  mast.position.set(6, 9.5, 0);
  mast.rotation.z = 0.28;
  wreck.add(mast);
  const beam = new THREE.Mesh(new THREE.BoxGeometry(10, 0.28, 0.28), metalMat);
  beam.position.set(5.5, 11.8, 0);
  beam.rotation.z = 0.23;
  wreck.add(beam);
  const brokenPlank = new THREE.Mesh(new THREE.BoxGeometry(10, 0.45, 0.5), plankMat);
  brokenPlank.position.set(-12, 5.2, 5.4);
  brokenPlank.rotation.z = 0.4;
  wreck.add(brokenPlank);
  const beacon = new THREE.PointLight(0x63e0d6, 1.4, 28);
  beacon.position.set(-5, 7, 0);
  wreck.add(beacon);
  wreck.position.set(shipOfInterest.x - baseX, -37, shipOfInterest.z - baseZ);
  wreck.rotation.y = 0.72;
  wreck.rotation.z = 0.035;
  wreck.scale.setScalar(1.05);
  group.add(wreck);
}

function makeSupplyCache(group, cache, baseX, baseZ) {
  if (collectedCaches.has(cache.id)) return;
  const crate = new THREE.Group();
  const hull = new THREE.MeshStandardMaterial({ color: 0x315e66, roughness: 0.72, metalness: 0.25 });
  const trim = new THREE.MeshStandardMaterial({ color: 0xd2a967, roughness: 0.52, metalness: 0.58 });
  const glow = new THREE.MeshStandardMaterial({ color: 0x79e8df, emissive: 0x168b91, emissiveIntensity: 1.1 });
  const body = new THREE.Mesh(new THREE.BoxGeometry(2.8, 1.45, 2.0), hull);
  crate.add(body);
  const lid = new THREE.Mesh(new THREE.BoxGeometry(2.94, 0.24, 2.12), trim);
  lid.position.y = 0.84;
  crate.add(lid);
  for (const side of [-1, 1]) {
    const band = new THREE.Mesh(new THREE.BoxGeometry(0.16, 1.58, 2.16), trim);
    band.position.x = side * 0.82;
    crate.add(band);
  }
  const beacon = new THREE.Mesh(new THREE.SphereGeometry(0.2, 8, 6), glow);
  beacon.position.set(0, 1.12, 0);
  crate.add(beacon);
  const lamp = new THREE.PointLight(0x61e5dc, 0.9, 16);
  lamp.position.set(0, 1.4, 0);
  crate.add(lamp);
  crate.position.set(cache.x - baseX, cache.y, cache.z - baseZ);
  crate.rotation.y = cache.id === 'wreck_cache' ? 0.4 : -0.3;
  group.add(crate);
}

function makeResourceNode(group, cx, cz, index, localX, localZ, groundY, type) {
  const id = `${cx}:${cz}:ore:${index}`;
  if (collectedResources.has(id)) return;
  const colors = { titanium: 0x9fb2b7, copper: 0xc47b4b, quartz: 0xb8eff0, kelp: 0x53be94, coral: 0xd47eae, lithium: 0xa59bdc, sulfur: 0xe6ca69, magnetite: 0x526d85, salt: 0xd8e8e6, glowcap: 0x83d9d0, silver:0xc3ced8 };
  const profile=getResourceVisualProfile(type);
  const material = new THREE.MeshStandardMaterial({
    color: colors[type], roughness: profile.roughness ?? (type === 'glowcap' ? 0.72 : 0.72),
    metalness: profile.metalness ?? 0.12, flatShading: ['titanium','copper','quartz','lithium','sulfur','magnetite','salt','silver'].includes(type),
    emissive: colors[type], emissiveIntensity: type === 'quartz' || type === 'glowcap' ? 0.26 : type === 'sulfur' ? 0.18 : 0.035,
    map: type === 'coral' ? coralTexture : type === 'kelp' || type === 'glowcap' ? kelpTexture : rockTexture,
    bumpMap:type === 'coral' || type === 'kelp' || type === 'glowcap' ? coralBumpTexture : rockBumpTexture,
    bumpScale: type === 'coral' ? 0.16 : 0.075
  });
  const node = new THREE.Group();
  const animatedParts=[];
  const dimensions=profile.worldScale||[.52,.48,.52];
  if (profile.archetype === 'mushroom') {
    const stemMat=new THREE.MeshStandardMaterial({color:0xd7c5a0,map:rockTexture,bumpMap:rockBumpTexture,bumpScale:.045,roughness:.92});
    const stem=new THREE.Mesh(new THREE.CylinderGeometry(.16,.22,.92,12),stemMat);stem.position.y=.46;stem.scale.set(dimensions[0]*1.5,1,dimensions[2]*1.5);node.add(stem);
    const cap=new THREE.Mesh(new THREE.SphereGeometry(.68,20,12,0,Math.PI*2,0,Math.PI*.56),material);cap.scale.set(dimensions[0]*1.65,dimensions[1]*.92,dimensions[2]*1.65);cap.position.y=.92;node.add(cap);
    const underside=new THREE.Mesh(new THREE.CylinderGeometry(.31,.48,.08,18),new THREE.MeshStandardMaterial({color:0x8ebc9f,roughness:.94}));underside.position.y=.78;node.add(underside);
    for(let gill=0;gill<9;gill++){
      const a=gill/9*Math.PI*2;const vein=new THREE.Mesh(new THREE.CylinderGeometry(.006,.009,.48,5),stemMat);
      vein.position.set(Math.cos(a)*.34,.80,Math.sin(a)*.34);vein.rotation.z=Math.PI/2;vein.rotation.y=-a;node.add(vein);
    }
    for(let spot=0;spot<7;spot++){
      const a=spot/7*Math.PI*2;const dot=new THREE.Mesh(new THREE.SphereGeometry(.045,8,6),new THREE.MeshBasicMaterial({color:0xd7fff5}));
      dot.position.set(Math.cos(a)*.48,1.18,Math.sin(a)*.48);node.add(dot);
    }
  } else if (profile.archetype === 'leaf_bundle') {
    const stalkMat=new THREE.MeshStandardMaterial({color:0x2d8970,map:kelpTexture,bumpMap:kelpBumpTexture,bumpScale:.08,roughness:.82});
    const leafMat=new THREE.MeshStandardMaterial({color:0x4ec49b,map:kelpTexture,bumpMap:kelpBumpTexture,bumpScale:.10,roughness:.7,side:THREE.DoubleSide});
    const stalk=new THREE.Mesh(new THREE.CylinderGeometry(.065,.11,1.1,9),stalkMat);stalk.position.y=.55;node.add(stalk);
    for(let leaf=0;leaf<6;leaf++){
      const angle=leaf/6*Math.PI*2;const blade=new THREE.Mesh(new THREE.ConeGeometry(.18,1.0+(leaf%3)*.16,7,2),leafMat);
      blade.position.set(Math.cos(angle)*.18,.85,Math.sin(angle)*.18);blade.rotation.z=-Math.cos(angle)*.55;blade.rotation.x=Math.sin(angle)*.52;blade.scale.set(.7,1,.22);node.add(blade);
    }
  } else if (profile.archetype === 'branching_organic') {
    const base=new THREE.Mesh(new THREE.IcosahedronGeometry(.32,1),material);base.scale.set(1,.65,.82);base.position.y=.22;node.add(base);
    const branches=6;
    for(let branch=0;branch<branches;branch++){
      const a=branch/branches*Math.PI*2;const length=.52+(branch%3)*.17;
      const limb=new THREE.Mesh(new THREE.CapsuleGeometry(.075,length*.55,6,9),material);
      limb.position.set(Math.cos(a)*.18,.48+length*.30,Math.sin(a)*.18);limb.rotation.z=-Math.cos(a)*.46;limb.rotation.x=Math.sin(a)*.46;limb.userData.baseZ=limb.rotation.z;limb.userData.baseX=limb.rotation.x;node.add(limb);animatedParts.push(limb);
      const tip=new THREE.Mesh(new THREE.SphereGeometry(.085,8,6),material);tip.position.set(Math.cos(a)*(.25+length*.13),.70+length*.48,Math.sin(a)*(.25+length*.13));node.add(tip);
    }
  } else if (profile.archetype === 'crystal' || profile.archetype === 'crystal_tall' || profile.archetype === 'crystal_cluster') {
    const baseGeo=new THREE.DodecahedronGeometry(.42,0);const base=new THREE.Mesh(baseGeo,material);base.scale.set(dimensions[0]*1.4,dimensions[1]*.72,dimensions[2]*1.4);base.position.y=.30;node.add(base);
    const shardCount=profile.archetype==='crystal_tall'?5:profile.archetype==='crystal_cluster'?7:4;
    for(let shard=0;shard<shardCount;shard++){
      const a=shard/shardCount*Math.PI*2+hash2(cx+index,cz+shard)*.24;
      const height=(profile.archetype==='crystal_tall'?1.05:profile.archetype==='crystal_cluster'?.55:.72)*(0.72+hash2(index+shard,cx-cz)*.48);
      const radius=profile.archetype==='crystal_tall'?.18:.14;
      const crystal=new THREE.Mesh(new THREE.CylinderGeometry(radius*.16,radius,height,6,1),material);
      crystal.position.set(Math.cos(a)*.24,.38+height*.46,Math.sin(a)*.24);crystal.rotation.z=Math.cos(a)*.16;crystal.rotation.x=Math.sin(a)*.16;node.add(crystal);
      const facet=new THREE.Mesh(new THREE.ConeGeometry(radius*.86,.16,6),material);facet.position.copy(crystal.position);facet.position.y+=height*.48;node.add(facet);
    }
  } else {
    const radius=profile.archetype==='ingot'?.56:profile.archetype==='cubic_cluster'?.36:.58;
    const geo=profile.archetype==='ingot'?new THREE.BoxGeometry(1,.58,1.35,2,1,2):profile.archetype==='cubic_cluster'?new THREE.BoxGeometry(.72,.62,.74):new THREE.DodecahedronGeometry(radius,1);
    const mesh = new THREE.Mesh(geo, material);
    const jitter = .88 + hash2(cx*37+index*11,cz*29-index*7) * .24;
    mesh.scale.set(dimensions[0]*1.45*jitter,dimensions[1]*1.45*jitter,dimensions[2]*1.45*jitter);
    mesh.position.y = .40;mesh.rotation.set(.12,hash2(cx+index,cz-index)*Math.PI,.12);node.add(mesh);
    if(profile.archetype==='ingot'){
      const edge=new THREE.Mesh(new THREE.BoxGeometry(.055,.62,.08),new THREE.MeshStandardMaterial({color:0xd7e1df,metalness:.88,roughness:.22}));edge.position.set(.26,.42,-.18);edge.rotation.z=.08;node.add(edge);
    }
    if(profile.archetype==='nodule'||profile.archetype==='metal_nodule'){
      for(let n=0;n<3;n++){
        const nugget=new THREE.Mesh(new THREE.DodecahedronGeometry(.18+(n%2)*.07,0),material);
        const a=n/3*Math.PI*2;nugget.position.set(Math.cos(a)*.28,.45+(n%2)*.1,Math.sin(a)*.28);nugget.scale.set(1,.74,1.12);node.add(nugget);
      }
    }
    if(profile.archetype==='iron_nodule'){
      const seamMat=new THREE.MeshStandardMaterial({color:0x9bb4c1,metalness:.84,roughness:.3});
      for(let seam=0;seam<4;seam++){
        const a=seam*Math.PI/2;const vein=new THREE.Mesh(new THREE.BoxGeometry(.025,.46,.03),seamMat);
        vein.position.set(Math.cos(a)*.28,.42,Math.sin(a)*.28);vein.rotation.y=-a;node.add(vein);
      }
    }
  }
  const glow = new THREE.Mesh(new THREE.SphereGeometry(type === 'glowcap' ? 0.12 : 0.09, 8, 6), new THREE.MeshBasicMaterial({ color: colors[type], transparent: true, opacity: 0.56 }));
  glow.position.set(0, profile.archetype==='leaf_bundle'?1.65:profile.archetype==='mushroom'?1.38:profile.archetype.startsWith('crystal')?1.15:.88, 0); node.add(glow);
  node.position.set(localX, groundY, localZ);
  node.userData.resourceId = id;
  node.userData.resourceType = type;
  node.userData.visualArchetype=profile.archetype;
  node.userData.dimensions={width:dimensions[0]*2.9,height:dimensions[1]*2.9,depth:dimensions[2]*2.9};
  node.userData.chunkKey = `${cx},${cz}`;
  group.add(node);
  resourceNodes.set(id, { mesh: node, type, chunkKey: `${cx},${cz}` });
  if(animatedParts.length || type==='glowcap') marineDecorationNodes.push({type:'resource',root:node,animated:animatedParts,glow,phase:hash2(cx+index,cz-index)*Math.PI*2,rate:0.65,chunkKey:`${cx},${cz}`,resourceType:type});
}

function addBuiltStructure(group, structure, baseX, baseZ) {
  const root = new THREE.Group();
  const dark = new THREE.MeshStandardMaterial({ color: 0x183d4b, roughness: 0.52, metalness: 0.62, map: metalTexture, bumpMap:metalBumpTexture, bumpScale:0.1 });
  const glass = new THREE.MeshStandardMaterial({ color: 0x76d7dc, roughness: 0.18, metalness: 0.12, transparent: true, opacity: 0.32 });
  const glow = new THREE.MeshStandardMaterial({ color: 0x74f0e4, emissive: 0x168c8b, emissiveIntensity: 1.4 });
  const trim = new THREE.MeshStandardMaterial({color:0xd68a4d,map:metalTexture,bumpMap:metalBumpTexture,bumpScale:.025,metalness:.55,roughness:.42});
  const rubber = new THREE.MeshStandardMaterial({color:0x0c202b,roughness:.92,metalness:.03});
  const addBolt=(x,y,z,r=.045)=>{const bolt=new THREE.Mesh(new THREE.CylinderGeometry(r,r,.035,8),trim);bolt.position.set(x,y,z);root.add(bolt);return bolt;};
  const addBar=(x,y,z,w,h,d,mat=dark)=>{const bar=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat);bar.position.set(x,y,z);root.add(bar);return bar;};
  const addBarToGroup=(parent,x,y,z,w,h,d,mat=dark,rotateZ=false)=>{const bar=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat);bar.position.set(x,y,z);if(rotateZ)bar.rotation.y=Math.PI/2;parent.add(bar);return bar;};
  if (structure.type === 'beacon') {
    const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.2, 2.5, 8), dark); mast.position.y = 1.2; root.add(mast);
    const orb = new THREE.Mesh(new THREE.SphereGeometry(0.28, 12, 8), glow); orb.position.y = 2.55; root.add(orb);
    const collar=new THREE.Mesh(new THREE.TorusGeometry(.24,.055,8,20),trim);collar.rotation.x=Math.PI/2;collar.position.y=2.38;root.add(collar);
    const cage=new THREE.Mesh(new THREE.TorusGeometry(.34,.035,7,24),dark);cage.position.y=2.55;root.add(cage);
    for(let fin=0;fin<4;fin++){const a=fin*Math.PI/2;const stabilizer=addBar(Math.cos(a)*.20,1.05,Math.sin(a)*.20,.12,.62,.18,trim);stabilizer.rotation.y=-a;}
    for(let bolt=0;bolt<6;bolt++){const a=bolt/6*Math.PI*2;addBolt(Math.cos(a)*.19,.36,Math.sin(a)*.19,.035);}
    const light = new THREE.PointLight(0x65e9df, 1.5, 25); light.position.y = 2.6; root.add(light);
  } else if (structure.type === 'foundation') {
    const base = new THREE.Mesh(new THREE.CylinderGeometry(3.4, 3.65, 0.42, 12), dark); base.position.y = 0.22; root.add(base);
    const rim = new THREE.Mesh(new THREE.TorusGeometry(3.1, 0.09, 6, 32), glow); rim.rotation.x = Math.PI / 2; rim.position.y = 0.48; root.add(rim);
    const innerRim=new THREE.Mesh(new THREE.TorusGeometry(2.78,.055,6,32),trim);innerRim.rotation.x=Math.PI/2;innerRim.position.y=.44;root.add(innerRim);
    for(let spoke=0;spoke<8;spoke++){
      const a=spoke*Math.PI/4;const beam=addBar(Math.cos(a)*1.72,.34,Math.sin(a)*1.72,3.4,.16,.22,dark);beam.rotation.y=-a;
      addBolt(Math.cos(a)*3.1,.49,Math.sin(a)*3.1,.055);
      const foot=new THREE.Mesh(new THREE.CylinderGeometry(.26,.34,.28,10),trim);foot.position.set(Math.cos(a)*3.05,.18,Math.sin(a)*3.05);root.add(foot);
    }
  } else if (structure.type === 'compartment') {
    // A walk-in underwater habitat with a sealed shell, entry arch, lighting, and a fabricator console.
    const floorMat = new THREE.MeshStandardMaterial({ color:0x294b57, map:metalTexture, metalness:0.55, roughness:0.68 });
    const floor = new THREE.Mesh(new THREE.CylinderGeometry(4.35,4.45,0.28,24),floorMat); floor.position.y=0.18; root.add(floor);
    const floorRing = new THREE.Mesh(new THREE.TorusGeometry(4.17,0.12,8,32),glow); floorRing.rotation.x=Math.PI/2; floorRing.position.y=0.38; root.add(floorRing);
    const dome = new THREE.Mesh(new THREE.SphereGeometry(4.35,24,14,0,Math.PI*2,0,Math.PI/2),glass); dome.position.y=0.34; root.add(dome);
    for (let i=0;i<6;i++) {
      const angle=i*Math.PI/3; const post=new THREE.Mesh(new THREE.CylinderGeometry(0.11,0.16,4.2,8),dark);
      post.position.set(Math.cos(angle)*4.0,2.35,Math.sin(angle)*4.0); root.add(post);
    }
    const entry = new THREE.Mesh(new THREE.TorusGeometry(1.35,0.13,8,20),glow); entry.position.set(0,1.65,-4.18); root.add(entry);
    const fabBase = new THREE.Mesh(new THREE.BoxGeometry(1.55,1.65,1.05),dark); fabBase.position.set(2.25,1.13,0.8); root.add(fabBase);
    const fabTop = new THREE.Mesh(new THREE.BoxGeometry(1.35,0.1,0.9),glow); fabTop.position.set(2.25,2.02,0.8); root.add(fabTop);
    const fabScreen = new THREE.Mesh(new THREE.BoxGeometry(0.94,0.66,0.08),new THREE.MeshStandardMaterial({color:0x0c2734,emissive:0x0b6b75,emissiveIntensity:0.7})); fabScreen.position.set(2.25,1.58,0.24); root.add(fabScreen);
    const lamp = new THREE.PointLight(0x5ccbd4, 1.25, 17); lamp.position.set(0,4.1,0); root.add(lamp);
    const interiorLight = new THREE.PointLight(0x7ee9d9, 0.6, 9); interiorLight.position.set(2.1,2.9,0.8); root.add(interiorLight);
    // External pressure-frame ribs and segmented portholes give the room a built submarine-habitat silhouette.
    for(const y of [.82,2.10,3.42]){
      const rib=new THREE.Mesh(new THREE.TorusGeometry(4.28,.075,7,40),trim);rib.rotation.x=Math.PI/2;rib.position.y=y;root.add(rib);
    }
    for(let i=0;i<8;i++){
      const a=i*Math.PI/4;const x=Math.cos(a)*4.18,z=Math.sin(a)*4.18;
      const brace=new THREE.Mesh(new THREE.CylinderGeometry(.075,.10,3.55,8),dark);brace.position.set(x,2.18,z);root.add(brace);
      const port=new THREE.Mesh(new THREE.CylinderGeometry(.36,.36,.10,20),glass);port.position.set(Math.cos(a)*4.20,2.25,Math.sin(a)*4.20);port.rotation.z=Math.cos(a)*Math.PI/2;port.rotation.x=Math.sin(a)*Math.PI/2;root.add(port);
      const portRim=new THREE.Mesh(new THREE.TorusGeometry(.37,.045,7,20),trim);portRim.position.copy(port.position);portRim.rotation.copy(port.rotation);root.add(portRim);
      addBolt(x,1.02,z,.04);addBolt(x,3.28,z,.04);
    }
    const airlockFrame=new THREE.Mesh(new THREE.TorusGeometry(1.32,.19,10,28),dark);airlockFrame.position.set(0,1.68,-4.27);root.add(airlockFrame);
    const airlockGasket=new THREE.Mesh(new THREE.TorusGeometry(1.23,.075,8,28),rubber);airlockGasket.position.copy(airlockFrame.position);root.add(airlockGasket);
    const airlockTrim=new THREE.Mesh(new THREE.TorusGeometry(1.18,.065,8,28),trim);airlockTrim.position.copy(airlockFrame.position);root.add(airlockTrim);
    // Eight pressure-rated lower wall panels make the room read as a modular
    // cylindrical habitat instead of a bare glass dome. The existing footprint
    // and collision volume remain unchanged.
    for(let panel=0;panel<8;panel++){
      const a=panel/8*Math.PI*2,px=Math.cos(a)*4.12,pz=Math.sin(a)*4.12,rotation=Math.PI/2-a;
      const wallPanel=addBar(px,1.35,pz,2.78,1.46,.15,dark);wallPanel.rotation.y=rotation;
      const upperSeam=addBar(px,2.12,pz,2.72,.075,.19,trim);upperSeam.rotation.y=rotation;
      const lowerSeam=addBar(px,.58,pz,2.72,.075,.19,trim);lowerSeam.rotation.y=rotation;
      for(const side of [-1,1]){
        const boltPos=new THREE.Vector3(side*1.28,1.35,0).applyAxisAngle(new THREE.Vector3(0,1,0),-rotation);
        addBolt(px+boltPos.x,1.35,pz+boltPos.z,.035);
      }
    }
    const roofAntenna=new THREE.Mesh(new THREE.CylinderGeometry(.035,.06,.72,8),dark);roofAntenna.position.set(0,4.55,.5);root.add(roofAntenna);
  } else if (structure.type === 'storage_locker') {
    const box = new THREE.Mesh(new THREE.BoxGeometry(2.1,2.5,1.7),dark); box.position.y=1.35; root.add(box);
    const door = new THREE.Mesh(new THREE.BoxGeometry(1.75,2.12,0.08),glass); door.position.set(0,1.38,-0.88); root.add(door);
    const latch = new THREE.Mesh(new THREE.BoxGeometry(0.12,0.55,0.12),glow); latch.position.set(0.66,1.38,-0.98); root.add(latch);
    for(const side of [-1,1]){
      const rail=new THREE.Mesh(new THREE.BoxGeometry(.08,2.42,.12),trim);rail.position.set(side*.96,1.35,-.9);root.add(rail);
      for(const hingeY of [.48,2.18]){const hinge=new THREE.Mesh(new THREE.CylinderGeometry(.075,.075,.22,10),dark);hinge.position.set(side*.89,hingeY,-.94);hinge.rotation.z=Math.PI/2;root.add(hinge);}
    }
    for(let vent=0;vent<5;vent++)addBar(-.42+vent*.21,2.18,-.91,.12,.035,.035,trim);
    for(let bolt=0;bolt<8;bolt++){const side=bolt%2?1:-1;addBolt(side*.82,.42+Math.floor(bolt/2)*.56,-.96,.028);}
    const status=new THREE.Mesh(new THREE.BoxGeometry(.22,.08,.035),glow);status.position.set(-.62,2.02,-.94);root.add(status);
  } else if (structure.type === 'solar_array') {
    const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.12,0.2,3.5,8),dark); mast.position.y=1.75; root.add(mast);
    const panelMat = new THREE.MeshStandardMaterial({color:0x245e7b,metalness:0.72,roughness:0.28,emissive:0x082d45,emissiveIntensity:0.35});
    for (const side of [-1,1]) {
      const panelRoot=new THREE.Group();panelRoot.position.set(side*1.25,3.35,0);panelRoot.rotation.z=side*0.16;root.add(panelRoot);
      const panel = new THREE.Mesh(new THREE.BoxGeometry(2.2,0.12,1.6),panelMat);panelRoot.add(panel);
      const frame=new THREE.Mesh(new THREE.BoxGeometry(2.30,.06,1.70),trim);frame.position.y=.08;panelRoot.add(frame);
      for(let row=0;row<3;row++)addBarToGroup(panelRoot,-.63+row*.63,.105,0,.035,.018,1.52,trim);
      for(let col=0;col<4;col++)addBarToGroup(panelRoot,-1.0+col*.66,.105,0,.018,.018,1.52,trim,true);
      const hinge=new THREE.Mesh(new THREE.CylinderGeometry(.10,.10,.52,10),dark);hinge.position.set(-side*.16,-.18,0);hinge.rotation.z=Math.PI/2;root.add(hinge);
    }
    const beacon = new THREE.Mesh(new THREE.SphereGeometry(0.18,8,6),glow); beacon.position.y=4.1; root.add(beacon);
  } else if (structure.type === 'vehicle_bay') {
    const deck = new THREE.Mesh(new THREE.BoxGeometry(8.8,.42,7.2),dark); deck.position.y=.28;root.add(deck);
    const deckTop = new THREE.Mesh(new THREE.BoxGeometry(8.25,.09,6.7),glass);deckTop.position.y=.53;root.add(deckTop);
    for(const side of [-1,1]){
      const rail=new THREE.Mesh(new THREE.BoxGeometry(.22,2.1,6.5),dark);rail.position.set(side*4.15,1.45,0);root.add(rail);
      const railGlow=new THREE.Mesh(new THREE.BoxGeometry(.08,.09,6.0),glow);railGlow.position.set(side*4.15,2.55,0);root.add(railGlow);
      const gantry=new THREE.Mesh(new THREE.CylinderGeometry(.13,.18,4.2,10),dark);gantry.position.set(side*3.7,3.0,-2.8);root.add(gantry);
      const lamp=new THREE.PointLight(0x5eece5,1.4,18);lamp.position.set(side*3.7,4.6,-2.8);root.add(lamp);
    }
    const arch=new THREE.Mesh(new THREE.TorusGeometry(2.25,.16,10,36,Math.PI),glow);arch.position.set(0,3.5,-2.8);root.add(arch);
    const console=new THREE.Mesh(new THREE.BoxGeometry(1.45,1.9,.82),dark);console.position.set(0,1.45,3.0);root.add(console);
    const screen=new THREE.Mesh(new THREE.BoxGeometry(1.12,.75,.07),new THREE.MeshStandardMaterial({color:0x0b2736,emissive:0x087c86,emissiveIntensity:.8,metalness:.2,roughness:.22}));screen.position.set(0,1.8,2.55);root.add(screen);
    const consoleGlow=new THREE.Mesh(new THREE.BoxGeometry(1.2,.07,.1),glow);consoleGlow.position.set(0,2.28,2.54);root.add(consoleGlow);
    for(let i=0;i<4;i++){const guide=new THREE.Mesh(new THREE.BoxGeometry(.18,.04,5.7),glow);guide.position.set(-2.8+i*1.87,.59,0);root.add(guide);}
    for(const side of [-1,1]){
      const outerBrace=new THREE.Mesh(new THREE.CylinderGeometry(.12,.16,4.4,8),trim);outerBrace.position.set(side*4.05,2.25,-2.35);root.add(outerBrace);
      const clamp=new THREE.Mesh(new THREE.TorusGeometry(.34,.085,8,18),dark);clamp.position.set(side*3.65,1.2,2.9);clamp.rotation.x=Math.PI/2;root.add(clamp);
      for(let lampIndex=0;lampIndex<3;lampIndex++){
        const lamp=new THREE.Mesh(new THREE.SphereGeometry(.10,9,7),glow);lamp.position.set(side*3.9,2.15+lampIndex*.55,-2.2);root.add(lamp);
      }
    }
    const crossBeam=new THREE.Mesh(new THREE.BoxGeometry(8.1,.22,.28),trim);crossBeam.position.set(0,4.15,-2.8);root.add(crossBeam);
    const aftDock=new THREE.Mesh(new THREE.TorusGeometry(1.6,.12,8,30),glow);aftDock.rotation.x=Math.PI/2;aftDock.position.set(0,.72,2.65);root.add(aftDock);
  }
  root.position.set(structure.x - baseX, structure.y, structure.z - baseZ);
  root.rotation.y = Number(structure.yaw) || 0;
  root.userData.structureId = structure.id;
  root.userData.dimensions = getStructureDimensions(structure.type);
  const indicatorMaterial = new THREE.MeshStandardMaterial({ color:0x8bf5ea, emissive:0x1c9e91, emissiveIntensity:0.62, roughness:0.3 });
  const indicator = new THREE.Mesh(new THREE.SphereGeometry(0.085,14,10),indicatorMaterial);
  const indicatorY = Math.max(1.25, Number(root.userData.dimensions?.height) * 0.72 || 2.15);
  indicator.position.set(0,indicatorY,0);
  root.add(indicator);
  const indicatorLight = new THREE.PointLight(0x58e5d7,0.18,3.2,2);
  indicatorLight.position.copy(indicator.position);root.add(indicatorLight);
  marineDecorationNodes.push({type:'structure',root,indicator,indicatorLight,phase:hash2(structure.x,structure.z)*Math.PI*2,rate:0.6,chunkKey:`${Math.floor(structure.x/CHUNK_SIZE)},${Math.floor(structure.z/CHUNK_SIZE)}`});
  group.add(root);
}

function makeFanCoral(group, x, y, z, scale = 1) {
  const seed = Math.floor((x + 1.7) * 37 + (z - 2.3) * 19);
  const hue = hash2(seed, Math.floor(z * 7));
  const palette = [0xb96f91,0xc886a4,0x9f789f,0xd08b73];
  const coralMat = new THREE.MeshStandardMaterial({ color:palette[Math.floor(hue*palette.length)%palette.length], roughness:0.86, map:coralTexture, bumpMap:coralBumpTexture, bumpScale:0.07 });
  const tipMat = new THREE.MeshStandardMaterial({ color:0xffb4d1, emissive:0x5d203b, emissiveIntensity:0.28, roughness:0.52 });
  const root = new THREE.Group();
  const base = new THREE.Mesh(new THREE.DodecahedronGeometry(0.38,1),coralMat);
  base.scale.set(1.2,0.55,0.9); base.position.y=0.18; root.add(base);
  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.07,0.14,0.95,10,3),coralMat);
  trunk.position.y=0.54; root.add(trunk);
  const branches=[];
  const branchCount=8;
  for(let i=0;i<branchCount;i++){
    const a=(i/(branchCount-1)-0.5)*2.15;
    const length=1.15+hash2(seed+i*5,Math.floor(z*11))*0.82;
    const pivot=new THREE.Group();
    pivot.position.set(Math.sin(a)*0.13,0.82+Math.abs(a)*0.07,0);
    const curve=new THREE.CatmullRomCurve3([
      new THREE.Vector3(0,0,0),
      new THREE.Vector3(Math.sin(a)*0.22,length*0.34,0.035),
      new THREE.Vector3(Math.sin(a)*0.47,length*0.72,0.07),
      new THREE.Vector3(Math.sin(a)*0.66,length,0.11)
    ]);
    const tube=new THREE.Mesh(new THREE.TubeGeometry(curve,12,0.075,7,false),coralMat);
    pivot.add(tube);
    for(let sub=0;sub<2;sub++){
      const t=0.42+sub*0.22;
      const point=curve.getPoint(t);
      const side=(sub===0?-1:1)*(0.34+hash2(i,sub)*0.18);
      const subCurve=new THREE.CatmullRomCurve3([
        point.clone(),
        point.clone().add(new THREE.Vector3(side*0.4,0.20,0.035)),
        point.clone().add(new THREE.Vector3(side,0.48,0.07))
      ]);
      pivot.add(new THREE.Mesh(new THREE.TubeGeometry(subCurve,7,0.041,6,false),coralMat));
      const polyp=new THREE.Mesh(new THREE.SphereGeometry(0.075,10,8),tipMat);
      polyp.position.copy(subCurve.getPoint(1)); pivot.add(polyp);
    }
    const terminal=new THREE.Mesh(new THREE.SphereGeometry(0.095,10,8),tipMat);
    terminal.position.copy(curve.getPoint(1)); pivot.add(terminal);
    root.add(pivot); branches.push(pivot);
  }
  root.scale.setScalar(scale);
  root.position.set(x,y+0.12,z);
  root.rotation.y=hash2(x*3,z*5)*Math.PI*2;
  group.add(root);
  const wx=group.position.x+x, wz=group.position.z+z;
  marineDecorationNodes.push({type:'fan',root,branches,phase:hue*Math.PI*2,rate:0.55+hash2(seed,5)*0.35,chunkKey:`${Math.floor(wx/CHUNK_SIZE)},${Math.floor(wz/CHUNK_SIZE)}`});
}

function makeMarineDecoration(group, localX, localZ, groundY, biomeId, seed, variant=0) {
  const root=new THREE.Group();
  const coralMat=new THREE.MeshStandardMaterial({color:biomeId==='hadal_garden'?0x4f9c91:0xb77993,map:coralTexture,bumpMap:coralBumpTexture,bumpScale:0.055,roughness:0.84});
  const rockMat=new THREE.MeshStandardMaterial({color:0x697c7c,map:rockTexture,bumpMap:rockBumpTexture,bumpScale:0.08,roughness:0.95});
  const glowMat=new THREE.MeshStandardMaterial({color:0x7eeedc,emissive:0x1c8c83,emissiveIntensity:0.72,roughness:0.32});
  const animated=[];
  let type='urchin';
  if(variant===0){
    type='anemone';
    const foot=new THREE.Mesh(new THREE.SphereGeometry(0.62,18,12),rockMat);foot.scale.set(1.1,0.42,1.05);foot.position.y=0.28;root.add(foot);
    const crown=new THREE.Mesh(new THREE.SphereGeometry(0.72,20,14),coralMat);crown.scale.set(1,0.48,1);crown.position.y=0.67;root.add(crown);
    const count=9;
    for(let i=0;i<count;i++){
      const angle=i/count*Math.PI*2+hash2(seed,i)*0.14;
      const pivot=new THREE.Group();pivot.position.set(Math.cos(angle)*0.28,0.82,Math.sin(angle)*0.28);
      const length=0.95+hash2(seed+i*7,variant+3)*0.68;
      const curve=new THREE.CatmullRomCurve3([
        new THREE.Vector3(0,0,0),
        new THREE.Vector3(Math.cos(angle)*0.16,length*0.36,Math.sin(angle)*0.16),
        new THREE.Vector3(Math.cos(angle)*0.42,length*0.74,Math.sin(angle)*0.42),
        new THREE.Vector3(Math.cos(angle)*0.48,length,Math.sin(angle)*0.48)
      ]);
      pivot.add(new THREE.Mesh(new THREE.TubeGeometry(curve,12,0.075,7,false),coralMat));
      const tip=new THREE.Mesh(new THREE.SphereGeometry(0.095,10,8),glowMat);tip.position.copy(curve.getPoint(1));pivot.add(tip);
      root.add(pivot);animated.push(pivot);
    }
  } else if(variant===1){
    type='urchin';
    const body=new THREE.Mesh(new THREE.IcosahedronGeometry(0.65,2),rockMat);body.scale.set(1,0.9,1);body.position.y=0.68;root.add(body);
    const spines=16;
    for(let i=0;i<spines;i++){
      const yy=1-2*(i+0.5)/spines;
      const rr=Math.sqrt(Math.max(0,1-yy*yy));
      const angle=i*Math.PI*(3-Math.sqrt(5));
      const dir=new THREE.Vector3(Math.cos(angle)*rr,yy,Math.sin(angle)*rr).normalize();
      const length=0.38+hash2(seed,i)*0.34;
      const spine=new THREE.Mesh(new THREE.ConeGeometry(0.055,length,7,2),coralMat);
      spine.position.copy(dir.clone().multiplyScalar(0.70+length*0.42)).add(new THREE.Vector3(0,0.68,0));
      spine.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),dir);root.add(spine);
      if(i%4===0){const node=new THREE.Mesh(new THREE.SphereGeometry(0.075,9,7),glowMat);node.position.copy(dir.clone().multiplyScalar(0.65).add(new THREE.Vector3(0,0.68,0)));root.add(node);}
    }
  } else {
    type='star';
    const shape=new THREE.Shape();
    for(let i=0;i<10;i++){
      const a=-Math.PI/2+i*Math.PI/5;
      const r=i%2===0?0.92:0.42;
      const px=Math.cos(a)*r,py=Math.sin(a)*r;
      if(i===0)shape.moveTo(px,py);else shape.lineTo(px,py);
    }
    shape.closePath();
    const geo=new THREE.ExtrudeGeometry(shape,{depth:0.18,bevelEnabled:true,bevelSegments:2,steps:1,bevelSize:0.08,bevelThickness:0.06,curveSegments:5});
    const star=new THREE.Mesh(geo,coralMat);star.rotation.x=-Math.PI/2;star.position.y=0.24;root.add(star);
    const center=new THREE.Mesh(new THREE.SphereGeometry(0.24,16,10),glowMat);center.position.y=0.35;root.add(center);
    for(let i=0;i<5;i++){
      const a=-Math.PI/2+i*Math.PI*2/5;
      const eye=new THREE.Mesh(new THREE.SphereGeometry(0.055,8,6),rockMat);
      eye.position.set(Math.cos(a)*0.42,0.42,Math.sin(a)*0.42);root.add(eye);
    }
  }
  root.position.set(localX,groundY+0.04,localZ);
  root.rotation.y=hash2(seed,variant+9)*Math.PI*2;
  root.scale.setScalar(0.72+hash2(seed+4,variant+12)*0.58);
  group.add(root);
  marineDecorationNodes.push({type,root,animated,baseScale:root.scale.x,phase:hash2(seed,17)*Math.PI*2,rate:0.55+hash2(seed,23)*0.35,chunkKey:`${Math.floor((group.position.x+localX)/CHUNK_SIZE)},${Math.floor((group.position.z+localZ)/CHUNK_SIZE)}`});
  return root;
}

function makeThermalVent(group, x, z, groundY) {
  const root = new THREE.Group();
  const basalt = new THREE.MeshStandardMaterial({ color:0x354b52, roughness:0.98, flatShading:true, map:rockTexture });
  const hot = new THREE.MeshStandardMaterial({ color:0xe58d51, emissive:0xb84a23, emissiveIntensity:1.4, roughness:0.55 });
  for (let i=0;i<3;i++) {
    const h = 3.5 + i * 1.1;
    const chimney = new THREE.Mesh(new THREE.CylinderGeometry(0.55+i*0.15,1.2+i*0.22,h,7),basalt);
    chimney.position.set((i-1)*1.5,h/2,Math.cos(i*2)*1.2); root.add(chimney);
    const rim = new THREE.Mesh(new THREE.TorusGeometry(0.62+i*0.14,0.15,6,12),hot);
    rim.rotation.x=Math.PI/2; rim.position.set((i-1)*1.5,h,Math.cos(i*2)*1.2); root.add(rim);
  }
  const lavaMat = new THREE.MeshStandardMaterial({color:0xff783c,emissive:0xff3c12,emissiveIntensity:2.15,roughness:0.36,metalness:0.02,transparent:true,opacity:0.94});
  const lavaPool = new THREE.Mesh(new THREE.CircleGeometry(2.65,32),lavaMat); lavaPool.rotation.x=-Math.PI/2; lavaPool.position.set(0,0.16,0); root.add(lavaPool);
  const lavaRim = new THREE.Mesh(new THREE.TorusGeometry(2.8,0.24,8,36),hot); lavaRim.rotation.x=Math.PI/2; lavaRim.position.y=0.12; root.add(lavaRim);
  for(let channel=0;channel<3;channel++){
    const arc=new THREE.Mesh(new THREE.TorusGeometry(1.35+channel*.62,.075,6,32,Math.PI*.72),hot);
    arc.rotation.set(Math.PI/2,0,channel*Math.PI*.66);arc.position.set((channel-1)*.7,.08,(channel-1)*.55);root.add(arc);
  }
  const glow = new THREE.PointLight(0xff8652,1.65,28); glow.position.y=4; root.add(glow);
  root.position.set(x,groundY,z); group.add(root);
  lavaEffectNodes.push({root,lavaPool,glow,phase:hash2(x,z)*Math.PI*2,chunkKey:`${Math.floor((group.position.x+x)/CHUNK_SIZE)},${Math.floor((group.position.z+z)/CHUNK_SIZE)}`});
}

function makeCaveEntrance(group, cx, cz, localX, localZ, floorY, seed=0) {
  const root=new THREE.Group();
  const basalt=new THREE.MeshStandardMaterial({color:0x243a42,map:rockTexture,bumpMap:rockBumpTexture,bumpScale:.18,roughness:.98,flatShading:true});
  const inner=new THREE.MeshStandardMaterial({color:0x020b13,roughness:1,side:THREE.DoubleSide});
  const mineral=new THREE.MeshStandardMaterial({color:0x4f8e9a,emissive:0x155a66,emissiveIntensity:.7,roughness:.34,metalness:.18});
  const arch=new THREE.Mesh(new THREE.TorusGeometry(6.1,1.15,9,28),basalt);arch.position.set(0,6.0,0);root.add(arch);
  const throat=new THREE.Mesh(new THREE.CylinderGeometry(5.05,5.4,25,20,1,true),basalt);throat.rotation.x=Math.PI/2;throat.position.set(0,6.0,-12);root.add(throat);
  const darkness=new THREE.Mesh(new THREE.CircleGeometry(4.8,24),inner);darkness.position.set(0,6,-24.3);root.add(darkness);
  for(let i=0;i<9;i++){
    const a=i/9*Math.PI*2;const rock=new THREE.Mesh(new THREE.IcosahedronGeometry(.9+hash2(seed+i,cz)*1.25,1),basalt);
    rock.position.set(Math.cos(a)*(5.7+hash2(seed,i)*.6),1.0+hash2(i,seed)*2.0,Math.sin(a)*(5.5+hash2(seed-i,cz)*.7));
    rock.scale.set(1.15,.85,1.05);root.add(rock);
  }
  for(let i=0;i<4;i++){
    const crystal=new THREE.Mesh(new THREE.ConeGeometry(.22,.9+hash2(seed,i)*1.4,6),mineral);
    crystal.position.set((hash2(seed+i,cz)-.5)*5.8,5.2+hash2(i,seed)*1.6,-2-i*3.6);crystal.rotation.z=(hash2(seed-i,cz)-.5)*.5;root.add(crystal);
  }
  root.position.set(localX,floorY,localZ);root.rotation.y=(hash2(seed,cx)-.5)*.65;group.add(root);
  return root;
}


function makeDeepCaveEntrance(group, cx, cz, site, localX, localZ, floorY, seed = 0) {
  const root = new THREE.Group();
  const width = Math.max(4.5, Number(site.width) || 7);
  const length = Math.max(24, Number(site.length) || 38);
  const verticalSpan = Math.max(10, (Number(site.depth) || 12) + (Number(site.roofHeight) || 8));
  const verticalRadius = verticalSpan * 0.5;
  const centerY = verticalRadius;
  const rockMat = new THREE.MeshStandardMaterial({
    color: site.biome === 'hadal_garden' ? 0x334b4d : site.biome === 'hadal_rift' ? 0x302e49 : 0x2b4554,
    map: rockTexture, bumpMap: rockBumpTexture, bumpScale: 0.24,
    roughness: 0.985, metalness: 0.025, side: THREE.BackSide
  });
  const chamberMat = new THREE.MeshStandardMaterial({
    color: site.biome === 'hadal_garden' ? 0x405b57 : 0x293d54,
    map: rockTexture, bumpMap: rockBumpTexture, bumpScale: 0.30,
    roughness: 1, side: THREE.BackSide
  });
  const lipMat = new THREE.MeshStandardMaterial({
    color: 0x637b7d, map: rockTexture, bumpMap: rockBumpTexture,
    bumpScale: 0.18, roughness: 0.94, metalness: 0.025
  });
  const glowColor = new THREE.Color(site.glow || 0x76d9e8);
  const glowMat = new THREE.MeshStandardMaterial({
    color: glowColor, emissive: glowColor, emissiveIntensity: 1.5,
    roughness: 0.24, metalness: 0.04
  });

  // A deformed interior tube produces a traversable arched passage, not a flat
  // dark decal. BackSide shading exposes the rock ceiling and side walls from inside.
  const curve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, centerY, 1.5),
    new THREE.Vector3(0.35, centerY + 0.12, -length * 0.28),
    new THREE.Vector3(-0.25, centerY - 0.20, -length * 0.68),
    new THREE.Vector3(0.2, centerY, -length)
  ]);
  const tunnelGeometry = new THREE.TubeGeometry(curve, 48, 1, 28, false);
  const tunnelPositions = tunnelGeometry.getAttribute('position');
  for (let i = 0; i < tunnelPositions.count; i++) {
    const x = tunnelPositions.getX(i) * (width + 0.35);
    const y = centerY + (tunnelPositions.getY(i) - centerY) * (verticalRadius - 0.12);
    tunnelPositions.setXYZ(i, x, y, tunnelPositions.getZ(i));
  }
  tunnelPositions.needsUpdate = true;
  tunnelGeometry.computeVertexNormals();
  tunnelGeometry.computeBoundingSphere();
  const tunnel = new THREE.Mesh(tunnelGeometry, rockMat);
  tunnel.name = `CavePassage_${site.id}`;
  tunnel.frustumCulled = true;
  root.add(tunnel);

  // A larger terminal chamber lets the passage open into an explorable grotto.
  const chamber = new THREE.Mesh(new THREE.SphereGeometry(1, 28, 18), chamberMat);
  chamber.position.set(0, centerY, -length + 2.5);
  chamber.scale.set(width * 1.42, verticalRadius * 1.08, Math.max(7.5, Number(site.chamberRadius) || 11));
  chamber.name = `CaveChamber_${site.id}`;
  root.add(chamber);

  const entranceRim = new THREE.Mesh(new THREE.TorusGeometry(width * 0.88, 0.72, 9, 36), lipMat);
  entranceRim.position.set(0, centerY, 0.8);
  root.add(entranceRim);
  const secondaryRim = new THREE.Mesh(new THREE.TorusGeometry(width * 0.69, 0.20, 7, 32), glowMat);
  secondaryRim.position.set(0, centerY, 0.96);
  secondaryRim.material = glowMat;
  root.add(secondaryRim);

  // Stalactites and matching floor teeth frame the passage edges while keeping
  // the centre line clear for the diver and the small scout vehicle.
  for (let index = 0; index < 7; index++) {
    const along = 5 + index * (length - 11) / 6;
    const side = index % 2 ? -1 : 1;
    const lateral = side * width * (0.72 + hash2(seed + index, 7) * 0.13);
    const tall = 2.2 + hash2(seed + index * 3, 13) * 3.4;
    const stalactite = new THREE.Mesh(new THREE.ConeGeometry(0.38 + hash2(index, seed) * 0.42, tall, 6, 1), lipMat);
    stalactite.position.set(lateral, verticalSpan - tall * 0.47, -along);
    stalactite.rotation.z = Math.PI + (hash2(index + seed, 19) - 0.5) * 0.24;
    root.add(stalactite);
    const floorTooth = new THREE.Mesh(new THREE.ConeGeometry(0.35 + hash2(seed, index + 5) * 0.32, 1.5 + hash2(index, seed + 8) * 2.4, 6, 1), lipMat);
    floorTooth.position.set(-lateral * 0.88, 0.5 + floorTooth.geometry.parameters.height * 0.34, -along - 1.2);
    root.add(floorTooth);
  }

  // Luminous crystal fans and mineral seams provide a readable route marker.
  for (let cluster = 0; cluster < 5; cluster++) {
    const along = 8 + cluster * (length - 13) / 4;
    const side = cluster % 2 ? -1 : 1;
    const crystalRoot = new THREE.Group();
    for (let crystal = 0; crystal < 4; crystal++) {
      const h = 0.8 + hash2(seed + cluster * 7, crystal * 11) * 2.2;
      const shard = new THREE.Mesh(new THREE.ConeGeometry(0.16 + hash2(crystal, seed) * 0.12, h, 5, 1), glowMat);
      shard.position.set((crystal - 1.5) * 0.34, h * 0.42, (crystal % 2) * 0.26);
      shard.rotation.z = (crystal - 1.5) * 0.16;
      crystalRoot.add(shard);
    }
    crystalRoot.position.set(side * width * 0.83, 1.1 + hash2(cluster, seed + 2) * 2, -along);
    root.add(crystalRoot);
  }
  const caveLight = new THREE.PointLight(glowColor, 0.72, width * 4.4, 2);
  caveLight.position.set(0, centerY * 0.82, -length * 0.60);
  root.add(caveLight);
  const entranceLight = new THREE.PointLight(glowColor, 0.34, width * 2.0, 2);
  entranceLight.position.set(0, centerY, -4);
  root.add(entranceLight);

  // Drifting sediment motes make the enclosed space feel volumetric without
  // requiring expensive GPU particles or a post-processing pipeline.
  const dustPositions = [];
  for (let mote = 0; mote < 76; mote++) {
    const along = 4 + hash2(seed + mote * 7, 29) * (length - 7);
    const lateral = (hash2(seed + mote * 13, 37) - 0.5) * width * 1.15;
    const vertical = 2 + hash2(seed + mote * 17, 41) * Math.max(3, verticalSpan - 4);
    dustPositions.push(lateral, vertical, -along);
  }
  const dustGeometry = new THREE.BufferGeometry();
  dustGeometry.setAttribute('position', new THREE.Float32BufferAttribute(dustPositions, 3));
  dustGeometry.userData.baseY = dustPositions.filter((_, index) => index % 3 === 1);
  const dustMaterial = new THREE.PointsMaterial({ color: glowColor, size: 0.16, transparent: true, opacity: 0.25, depthWrite: false, sizeAttenuation: true });
  const dust = new THREE.Points(dustGeometry, dustMaterial);
  root.add(dust);

  root.position.set(localX, floorY, localZ);
  root.rotation.y = Number(site.yaw) || 0;
  group.add(root);
  caveDustNodes.push({ root, dust, light:caveLight, entranceLight, chunkKey:`${cx},${cz}`, phase:hash2(cx * 17 + seed, cz * 23) * Math.PI * 2 });
  return root;
}

function makeOxygenPlant(group,cx,cz,index,localX,localZ,groundY) {
  const root=new THREE.Group();
  const stalkMat=new THREE.MeshStandardMaterial({color:0x2b8679,map:kelpTexture,bumpMap:kelpBumpTexture,bumpScale:.08,roughness:.78});
  const leafMat=new THREE.MeshStandardMaterial({color:0x4bc5a2,map:kelpTexture,bumpMap:kelpBumpTexture,bumpScale:.12,roughness:.68,side:THREE.DoubleSide});
  const bulbMat=new THREE.MeshStandardMaterial({color:0x9effd7,emissive:0x30e7ac,emissiveIntensity:1.7,roughness:.23});
  const stalk=new THREE.Mesh(new THREE.CylinderGeometry(.12,.20,1.55,9),stalkMat);stalk.position.y=.78;root.add(stalk);
  const leaves=[];
  for(let i=0;i<7;i++){
    const leaf=new THREE.Mesh(new THREE.ConeGeometry(.20,2.0+(i%3)*.28,7,2),leafMat);
    const angle=i/7*Math.PI*2;leaf.position.set(Math.cos(angle)*.43,1.12+((i%2)*.14),Math.sin(angle)*.43);leaf.rotation.z=-Math.cos(angle)*.58;leaf.rotation.x=Math.sin(angle)*.45;leaf.userData.baseZ=leaf.rotation.z;leaf.userData.baseX=leaf.rotation.x;root.add(leaf);leaves.push(leaf);
  }
  const sacs=[];
  for(let i=0;i<3;i++){
    const sac=new THREE.Mesh(new THREE.SphereGeometry(.30,12,8),bulbMat);const a=i*Math.PI*2/3;sac.position.set(Math.cos(a)*.38,1.98+i*.15,Math.sin(a)*.38);root.add(sac);sacs.push(sac);
  }
  const light=new THREE.PointLight(0x5cf5d0,.48,7);light.position.y=2.0;root.add(light);
  root.position.set(localX,groundY,localZ);root.rotation.y=hash2(cx*19+index,cz*11-index)*Math.PI*2;group.add(root);
  oxygenPlantNodes.push({root,leaves,sacs,light,chunkKey:`${cx},${cz}`,charge:100,rechargeTimer:0,phase:hash2(cx+index,cz-index)*Math.PI*2});
  return root;
}

function makeHadalBloom(group,cx,cz,index,localX,localZ,groundY,biomeId='hadal_garden') {
  const palettes={
    midnight_grotto:{stem:0x33445f,leaf:0x4b6c8d,glow:0x68d9ee,emissive:0x155c82},
    blue_void:{stem:0x273957,leaf:0x426f9f,glow:0x73bfff,emissive:0x1b559d},
    hadal_rift:{stem:0x34334d,leaf:0x685b9b,glow:0xb58cff,emissive:0x4c237f},
    hadal_garden:{stem:0x283f4a,leaf:0x3c837c,glow:0x8bf5d4,emissive:0x1a806b}
  };
  const palette=palettes[biomeId]||palettes.hadal_garden;
  const root=new THREE.Group();
  const stemMat=new THREE.MeshStandardMaterial({color:palette.stem,map:rockTexture,bumpMap:rockBumpTexture,bumpScale:.09,roughness:.92});
  const leafMat=new THREE.MeshStandardMaterial({color:palette.leaf,map:kelpTexture,bumpMap:kelpBumpTexture,bumpScale:.06,roughness:.74,side:THREE.DoubleSide});
  const glowMat=new THREE.MeshStandardMaterial({color:palette.glow,emissive:palette.emissive,emissiveIntensity:1.35,roughness:.26,metalness:.02});
  const base=new THREE.Mesh(new THREE.DodecahedronGeometry(.72,1),stemMat);base.scale.set(1,.42,1);base.position.y=.24;root.add(base);
  const stalks=[];
  const count=5+Math.floor(hash2(cx*17+index,cz*13-index)*4);
  for(let i=0;i<count;i++){
    const angle=i/count*Math.PI*2+hash2(i,cx+cz)*.25;
    const height=2.4+hash2(cx+i*5,cz-i*3)*3.2;
    const stalk=new THREE.Mesh(new THREE.CylinderGeometry(.055,.12,height,6,2),stemMat);
    stalk.position.set(Math.cos(angle)*.42,height*.48,Math.sin(angle)*.42);stalk.rotation.z=-Math.cos(angle)*.20;stalk.rotation.x=Math.sin(angle)*.20;root.add(stalk);
    const blade=new THREE.Mesh(new THREE.ConeGeometry(.19,height*.48,6,2),leafMat);
    blade.position.set(Math.cos(angle)*.62,height*.78,Math.sin(angle)*.62);blade.rotation.z=-Math.cos(angle)*.42;blade.rotation.x=Math.sin(angle)*.42;blade.userData.baseZ=blade.rotation.z;blade.userData.baseX=blade.rotation.x;root.add(blade);stalks.push(blade);
    const bulb=new THREE.Mesh(new THREE.SphereGeometry(.17+hash2(i,index)*.09,10,8),glowMat);
    bulb.position.set(Math.cos(angle)*.68,height*.91,Math.sin(angle)*.68);root.add(bulb);
  }
  const light=new THREE.PointLight(palette.glow,.48,9);light.position.y=2.6;root.add(light);
  root.position.set(localX,groundY,localZ);root.rotation.y=hash2(cx*31+index,cz*17-index)*Math.PI*2;group.add(root);
  hadalFloraNodes.push({root,stalks,light,phase:hash2(cx+index,cz-index)*Math.PI*2,chunkKey:`${cx},${cz}`});
  return root;
}

function makeTrenchFormation(group,cx,cz,index,localX,localZ,groundY,biomeId='hadal_rift') {
  const palettes={
    abyss:{rock:0x27354a,vein:0x456b83},
    abyssal_shelf:{rock:0x42556a,vein:0x668a9b},
    midnight_grotto:{rock:0x263149,vein:0x52728a},
    blue_void:{rock:0x18283f,vein:0x4b6f99},
    hadal_rift:{rock:0x25243a,vein:0x8b6bb3},
    hadal_garden:{rock:0x2b4149,vein:0x68b6a4}
  };
  const palette=palettes[biomeId]||palettes.abyss;
  const root=new THREE.Group();
  const basalt=new THREE.MeshStandardMaterial({color:palette.rock,map:rockTexture,bumpMap:rockBumpTexture,bumpScale:.14,roughness:.98,metalness:.015});
  const seam=new THREE.MeshStandardMaterial({color:palette.vein,map:rockTexture,bumpMap:rockBumpTexture,bumpScale:.08,roughness:.78,emissive:palette.vein,emissiveIntensity:biomeId==='hadal_garden'?.20:.09});
  const seed=cx*97+cz*131+index*19;
  const count=biomeId==='hadal_garden'?4:biomeId==='midnight_grotto'?3:5;
  const maxHeight=biomeId==='abyssal_shelf'?10.5:biomeId==='blue_void'?12:biomeId==='hadal_rift'?13.5:biomeId==='hadal_garden'?6.5:8.5;
  for(let i=0;i<count;i++){
    const angle=i/count*Math.PI*2+hash2(seed+i,cz)*.28;
    const radius=.9+hash2(seed-i,cx)*1.8;
    const width=.5+hash2(cx+i,seed)*.52;
    const height=2.4+hash2(seed+i*7,cz-i)*maxHeight;
    const column=new THREE.Mesh(new THREE.CylinderGeometry(width*.48,width,height,5+Math.floor(hash2(i,seed)*3),2),basalt);
    column.position.set(Math.cos(angle)*radius,height*.48,Math.sin(angle)*radius);
    column.rotation.z=(hash2(seed+i,cz+1)-.5)*.25;
    column.rotation.x=(hash2(seed-i,cz-1)-.5)*.25;
    root.add(column);
    const crown=new THREE.Mesh(new THREE.ConeGeometry(width*.7,.7+height*.08,5),basalt);
    crown.position.set(column.position.x,height+.05,column.position.z);
    crown.rotation.z=column.rotation.z*.7;crown.rotation.x=column.rotation.x*.7;root.add(crown);
    if(i%2===0){
      const seamMesh=new THREE.Mesh(new THREE.BoxGeometry(.045,height*.55,.055),seam);
      seamMesh.position.set(column.position.x+width*.28,height*.49,column.position.z-width*.18);
      seamMesh.rotation.y=-angle;root.add(seamMesh);
    }
  }
  const foot=new THREE.Mesh(new THREE.DodecahedronGeometry(1.55,1),basalt);
  foot.scale.set(1.25,.32,1.08);foot.position.y=.28;root.add(foot);
  root.position.set(localX,groundY,localZ);
  root.rotation.y=hash2(seed,cx-cz)*Math.PI*2;
  group.add(root);
  return root;
}

function makeSulfurNest(group,cx,cz,index,localX,localZ,groundY) {
  const root=new THREE.Group();
  const basalt=new THREE.MeshStandardMaterial({color:0x3e4141,map:rockTexture,bumpMap:rockBumpTexture,bumpScale:.12,roughness:.98});
  const sulfurMat=new THREE.MeshStandardMaterial({color:0xe8c84a,map:rockTexture,bumpMap:rockBumpTexture,bumpScale:.08,emissive:0x5e4510,emissiveIntensity:.42,roughness:.48});
  const bowl=new THREE.Mesh(new THREE.TorusGeometry(1.65,.48,8,20),basalt);bowl.rotation.x=Math.PI/2;bowl.position.y=.38;root.add(bowl);
  const bed=new THREE.Mesh(new THREE.CircleGeometry(1.35,18),new THREE.MeshStandardMaterial({color:0x706146,roughness:1}));bed.rotation.x=-Math.PI/2;bed.position.y=.18;root.add(bed);
  for(let i=0;i<7;i++){
    const angle=i/7*Math.PI*2;const crystal=new THREE.Mesh(new THREE.ConeGeometry(.20+hash2(index,i)*.12,.65+hash2(i,index)*.7,6),sulfurMat);
    crystal.position.set(Math.cos(angle)*1.22,.55,Math.sin(angle)*1.22);crystal.rotation.z=Math.cos(angle)*.25;root.add(crystal);
  }
  for(let i=0;i<4;i++){
    const egg=new THREE.Mesh(new THREE.SphereGeometry(.19,10,7),new THREE.MeshStandardMaterial({color:0xb8d99a,emissive:0x406d31,emissiveIntensity:.32,roughness:.42}));
    const angle=i/4*Math.PI*2;egg.position.set(Math.cos(angle)*.52,.38,Math.sin(angle)*.52);root.add(egg);
  }
  root.position.set(localX,groundY,localZ);group.add(root);
  makeResourceNode(group,cx,cz,100+index,localX+2.25,localZ,groundY+.12,'sulfur');
  return root;
}

function updateMarineDecorationAnimations(dt) {
  for(const node of marineDecorationNodes){
    if(!node.root?.parent)continue;
    node.phase+=dt*node.rate;
    if(node.type==='fan'){
      const pos=node.root.getWorldPosition(tmpVector);
      const flow=sampleOceanCurrent(pos.x,pos.y,pos.z,clockState.elapsed,currentBiome?.id||'open');
      node.root.rotation.x=Math.sin(node.phase*0.82)*0.045+clamp(flow.z*0.055,-0.035,0.035);
      node.root.rotation.z=Math.cos(node.phase*0.74)*0.055+clamp(flow.x*0.055,-0.035,0.035);
      node.branches?.forEach((branch,index)=>{branch.rotation.z=Math.sin(node.phase+index*0.61)*0.045;branch.rotation.x=Math.cos(node.phase*0.72+index)*0.032;});
    }else if(node.type==='anemone'){
      const pos=node.root.getWorldPosition(tmpVector);
      const flow=sampleOceanCurrent(pos.x,pos.y,pos.z,clockState.elapsed,currentBiome?.id||'open');
      node.animated?.forEach((arm,index)=>{arm.rotation.z=Math.sin(node.phase+index*.72)*.12+flow.x*.07;arm.rotation.x=Math.cos(node.phase*.86+index*.61)*.09+flow.z*.07;});
    }else if(node.type==='star'){
      node.root.rotation.y+=Math.sin(node.phase)*dt*.018;
      const pulse=1+Math.sin(node.phase*1.7)*.018;
      node.root.scale.setScalar((node.baseScale||1)*pulse);
    }else if(node.type==='urchin'){
      node.root.rotation.y+=dt*.012;
      node.root.rotation.z=Math.sin(node.phase*.62)*.018;
    }else if(node.type==='resource'){
      node.animated?.forEach((part,index)=>{
        part.rotation.z=(part.userData.baseZ??0)+Math.sin(node.phase+index*.72)*.06;
        part.rotation.x=(part.userData.baseX??0)+Math.cos(node.phase*.85+index*.64)*.045;
      });
      if(node.resourceType==='glowcap'){
        const pulse=0.94+Math.sin(node.phase*1.65)*0.08;
        node.glow?.scale.setScalar(pulse);
        if(node.glow?.material)node.glow.material.opacity=0.42+0.12*pulse;
      }
    }else if(node.type==='structure'){
      const pulse=0.42+0.22*(0.5+0.5*Math.sin(node.phase*1.3));
      if(node.indicator?.material)node.indicator.material.emissiveIntensity=0.38+1.1*pulse;
      if(node.indicatorLight)node.indicatorLight.intensity=pulse;
    }
  }
}

function updateWorldVisualEffects(dt) {
  updateMarineDecorationAnimations(dt);
  for(const bloom of hadalFloraNodes){
    if(!bloom.root?.parent)continue;
    bloom.phase+=dt*.55;
    const worldPos=bloom.root.getWorldPosition(tmpVector);
    const flow=sampleOceanCurrent(worldPos.x,worldPos.y,worldPos.z,clockState.elapsed,(getBiomeAt(worldPos.x,worldPos.y,worldPos.z)?.id||currentBiome?.id||'open'));
    const flowTiltX=clamp(flow.x*.045,-.055,.055),flowTiltZ=clamp(flow.z*.045,-.055,.055);
    bloom.stalks.forEach((blade,index)=>{blade.rotation.z=(blade.userData.baseZ??0)+Math.sin(bloom.phase+index*.8)*.085+flowTiltX;blade.rotation.x=(blade.userData.baseX??0)+Math.cos(bloom.phase*.86+index)*.065+flowTiltZ;});
    bloom.light.intensity=.36+.16*Math.sin(bloom.phase*1.8);
  }
  for (const cave of caveDustNodes) {
    if (!cave.root?.parent || !cave.dust?.geometry) continue;
    cave.phase += dt * 0.22;
    const attr = cave.dust.geometry.getAttribute('position');
    for (let i = 0; i < attr.count; i++) {
      const baseY = cave.dust.geometry.userData?.baseY?.[i] ?? attr.getY(i);
      attr.setY(i, baseY + Math.sin(cave.phase + i * 0.41) * 0.075);
      attr.setX(i, attr.getX(i) + Math.sin(cave.phase * 0.63 + i) * dt * 0.018);
    }
    attr.needsUpdate = true;
    const pulse=0.5+0.5*Math.sin(cave.phase*0.74);
    cave.dust.material.opacity = 0.19 + 0.06 * pulse;
    if(cave.light)cave.light.intensity=0.64+0.16*pulse;
    if(cave.entranceLight)cave.entranceLight.intensity=0.29+0.08*(1-pulse);
  }
  for(const plant of oxygenPlantNodes){
    if(!plant.root?.parent)continue;
    plant.phase+=dt;
    const worldPos=plant.root.getWorldPosition(tmpVector);
    const flow=sampleOceanCurrent(worldPos.x,worldPos.y,worldPos.z,clockState.elapsed,(getBiomeAt(worldPos.x,worldPos.y,worldPos.z)?.id||currentBiome?.id||'open'));
    const sway=Math.sin(plant.phase*.78)*.14;
    plant.root.rotation.z=sway+clamp(flow.x*.075,-.08,.08);
    plant.root.rotation.x=clamp(flow.z*.055,-.06,.06);
    plant.leaves.forEach((leaf,index)=>{leaf.rotation.z=(leaf.userData.baseZ??0)+Math.sin(plant.phase+index*.7)*.14+flow.x*.045;leaf.rotation.x=(leaf.userData.baseX??0)+Math.cos(plant.phase*.8+index)*.10+flow.z*.04;});
    plant.sacs.forEach((sac,index)=>{const pulse=1+Math.sin(plant.phase*2.1+index)*.055;sac.scale.setScalar(pulse);});
    plant.light.intensity=.38+(.12*Math.sin(plant.phase*1.7));
    if(plant.rechargeTimer>0){plant.rechargeTimer=Math.max(0,plant.rechargeTimer-dt);if(plant.rechargeTimer===0)plant.charge=100;}
  }
  for(const vent of lavaEffectNodes){
    if(!vent.root?.parent)continue;
    vent.phase+=dt;
    const pulse=.78+Math.sin(vent.phase*1.55)*.18;
    vent.lavaPool.material.emissiveIntensity=1.65+pulse*.7;
    vent.lavaPool.scale.set(1+pulse*.035,1+pulse*.035,1);
    vent.glow.intensity=1.25+pulse*.65;
  }
}

function makeCrystalCluster(group, x, y, z, biomeId, seed = 0) {
  const isThermal = biomeId === 'thermal';
  const crystal = new THREE.MeshStandardMaterial({
    color: isThermal ? 0xc87956 : 0x5cb9d4,
    emissive: isThermal ? 0x7c2f1c : 0x145b83,
    emissiveIntensity: isThermal ? 0.78 : 0.95,
    metalness: 0.24,
    roughness: 0.28,
    flatShading: true
  });
  const root = new THREE.Group();
  const count = 3 + Math.floor(hash2(seed, seed + 9) * 3);
  for (let i = 0; i < count; i++) {
    const height = 1.2 + hash2(seed + i * 3, seed - i * 5) * 3.2;
    const radius = 0.18 + hash2(seed + i * 7, seed + i * 11) * 0.34;
    const shard = new THREE.Mesh(new THREE.CylinderGeometry(radius * 0.22, radius, height, 5, 1), crystal);
    shard.position.set((hash2(seed + i * 13, seed - i * 2) - 0.5) * 1.4, height * 0.48, (hash2(seed - i * 9, seed + i * 17) - 0.5) * 1.4);
    shard.rotation.z = (hash2(seed + i * 5, seed + i) - 0.5) * 0.42;
    shard.rotation.x = (hash2(seed - i, seed + i * 4) - 0.5) * 0.35;
    root.add(shard);
  }
  root.position.set(x, y, z);
  group.add(root);
}

function makeChunk(cx, cz) {
  const baseX = cx * CHUNK_SIZE, baseZ = cz * CHUNK_SIZE;
  const group = new THREE.Group();
  group.position.set(baseX, 0, baseZ);
  const visualQuality = getActiveGraphicsQuality();
  const segments = visualQuality === 'low' ? 18 : visualQuality === 'ultra' ? 44 : visualQuality === 'high' ? 36 : 28;
  const positions = [], colors = [], indices = [], uvs = [];
  const deep = new THREE.Color(0x0b3448), mid = new THREE.Color(0x286a78), sand = new THREE.Color(0xc1ad7c);
  const grass = new THREE.Color(0x527d63), rock = new THREE.Color(0x77796b);
  const color = new THREE.Color();
  for (let z = 0; z <= segments; z++) {
    for (let x = 0; x <= segments; x++) {
      const wx = baseX + (x / segments) * CHUNK_SIZE;
      const wz = baseZ + (z / segments) * CHUNK_SIZE;
      const h = heightAt(wx, wz);
      positions.push((x / segments) * CHUNK_SIZE, h, (z / segments) * CHUNK_SIZE);
      uvs.push((x / segments) * 5, (z / segments) * 5);
      if (h < -24) color.copy(deep).lerp(mid, clamp((h + 44) / 20, 0, 1));
      else if (h < -2) color.copy(mid).lerp(sand, clamp((h + 24) / 22, 0, 1));
      else if (h < 13) color.copy(sand).lerp(grass, clamp((h + 2) / 15, 0, 1));
      else color.copy(grass).lerp(rock, clamp((h - 13) / 17, 0, 1));
      const biomeTint = new THREE.Color(getBiomeAt(wx, h - 2, wz).terrain);
      color.lerp(biomeTint, 0.12);
      const variation = 0.90 + (valueNoise(wx * 0.09, wz * 0.09) + 1) * 0.09;
      colors.push(color.r * variation, color.g * variation, color.b * variation);
    }
  }
  for (let z = 0; z < segments; z++) {
    for (let x = 0; x < segments; x++) {
      const a = z * (segments + 1) + x;
      const b = a + 1, c = a + segments + 1, d = c + 1;
      indices.push(a, c, b, b, c, d);
    }
  }
  const chunkCenterX = baseX + CHUNK_SIZE * 0.5, chunkCenterZ = baseZ + CHUNK_SIZE * 0.5;
  const chunkFloor = heightAt(chunkCenterX, chunkCenterZ);
  const chunkBiome = getBiomeAt(chunkCenterX, Math.min(-2, chunkFloor + 3), chunkCenterZ);
  const ecology = getBiomeEcologyProfile(chunkBiome.id, visualQuality);
  const terrainGeometry = new THREE.BufferGeometry();
  terrainGeometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  terrainGeometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  terrainGeometry.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  terrainGeometry.setIndex(indices);
  terrainGeometry.computeVertexNormals();
  // Steeper faces receive a darker mineral tint, helping cliffs and ridges read as geology.
  const terrainNormals = terrainGeometry.getAttribute('normal');
  const terrainColors = terrainGeometry.getAttribute('color');
  const slopeRock = new THREE.Color(0x515d60);
  const slopeColor = new THREE.Color();
  for (let vertex = 0; vertex < terrainColors.count; vertex++) {
    const slope = 1 - Math.max(0, terrainNormals.getY(vertex));
    if (slope > 0.16) {
      slopeColor.fromArray(terrainColors.array, vertex * 3).lerp(slopeRock, clamp((slope - 0.16) * 0.66, 0, 0.34));
      terrainColors.setXYZ(vertex, slopeColor.r, slopeColor.g, slopeColor.b);
    }
  }
  terrainColors.needsUpdate = true;
  const terrain = new THREE.Mesh(terrainGeometry, terrainMaterials[chunkBiome.id] || terrainMaterial);
  terrain.receiveShadow = visualQuality === 'high' || visualQuality === 'ultra';
  terrain.frustumCulled = true;
  terrain.userData.chunkTerrain = true;
  group.add(terrain);

  // Small instanced seafloor details keep draw calls low as chunks stream in and out.
  const kelpAttempts = ecology.seagrass;
  // Keep rock/coral's original 20 deterministic samples, but provide enough
  // independent samples for every kelp instance plus its offset lookups. This
  // prevents high-quality kelp patches from repeating the same 20 placements.
  const randomCount = Math.max(20, kelpAttempts + 12);
  const randoms = [];
  for (let i = 0; i < randomCount; i++) randoms.push(hash2(cx * 101 + i * 13, cz * 103 - i * 7));
  const rocks = new THREE.InstancedMesh(rockGeometry, rockMaterial, 20);
  const kelp = new THREE.InstancedMesh(kelpGeometry, kelpMaterial, Math.max(1,kelpAttempts));
  const coralAttempts = ecology.coral;
  const coral = new THREE.InstancedMesh(coralGeometry, coralMaterial, Math.max(1,coralAttempts));
  const coralPalette = [new THREE.Color(0xd27671), new THREE.Color(0x9c7bce), new THREE.Color(0xe0ad65), new THREE.Color(0x5eafa5)];
  const dummy = new THREE.Object3D();
  let rockCount = 0, kelpCount = 0, coralCount = 0;
  for (let i = 0; i < 20; i++) {
    const wx = baseX + randoms[i % 20] * CHUNK_SIZE;
    const wz = baseZ + randoms[(i + 6) % 20] * CHUNK_SIZE;
    const h = heightAt(wx, wz);
    if (h > -4) continue;
    const s = 0.45 + randoms[(i + 3) % 20] * 1.2;
    dummy.position.set(wx - baseX, h + s * 0.45, wz - baseZ);
    dummy.rotation.set(randoms[(i + 2) % 20], randoms[(i + 7) % 20] * Math.PI, 0.2);
    dummy.scale.set(s, s * (0.7 + randoms[(i + 9) % 20]), s);
    dummy.updateMatrix();
    rocks.setMatrixAt(rockCount++, dummy.matrix);
  }
  rocks.count = rockCount;
  rocks.instanceMatrix.needsUpdate = true;
  if (rockCount) { rocks.castShadow=visualQuality==='high'; rocks.receiveShadow=visualQuality==='high'; group.add(rocks); }
  for (let i = 0; i < kelpAttempts; i++) {
    const wx = baseX + randoms[(i + 4) % randoms.length] * CHUNK_SIZE;
    const wz = baseZ + randoms[(i + 12) % randoms.length] * CHUNK_SIZE;
    const h = heightAt(wx, wz);
    if (h > -7 || randoms[i] < 0.25) continue;
    const s = 0.72 + randoms[(i + 8) % randoms.length] * 0.95;
    dummy.position.set(wx - baseX, h, wz - baseZ);
    dummy.rotation.set(0, randoms[(i + 2) % randoms.length] * 6, (randoms[(i + 5) % randoms.length] - 0.5) * 0.16);
    dummy.scale.set(s, s, s);
    dummy.updateMatrix();
    kelp.setMatrixAt(kelpCount++, dummy.matrix);
  }
  kelp.count = kelpCount;
  kelp.instanceMatrix.needsUpdate = true;
  if (kelpCount) group.add(kelp);
  for (let i = 0; i < coralAttempts; i++) {
    const wx = baseX + randoms[(i + 2) % 20] * CHUNK_SIZE;
    const wz = baseZ + randoms[(i + 11) % 20] * CHUNK_SIZE;
    const h = heightAt(wx, wz);
    if (h > -7 || randoms[(i + 5) % 20] < 0.32) continue;
    const scale = 0.45 + randoms[(i + 9) % 20] * 0.85;
    dummy.position.set(wx - baseX, h + scale * 0.82, wz - baseZ);
    dummy.rotation.set(0, randoms[(i + 7) % 20] * Math.PI * 2, (randoms[(i + 3) % 20] - 0.5) * 0.28);
    dummy.scale.set(scale * 0.78, scale, scale * 0.78);
    dummy.updateMatrix();
    coral.setMatrixAt(coralCount, dummy.matrix);
    coral.setColorAt(coralCount, coralPalette[Math.floor(randoms[(i + 14) % 20] * coralPalette.length)]);
    coralCount++;
  }
  coral.count = coralCount;
  coral.instanceMatrix.needsUpdate = true;
  if (coral.instanceColor) coral.instanceColor.needsUpdate = true;
  if (coralCount) group.add(coral);

  // Hadal and deep-shelf sponge gardens provide a second recognizable flora
  // silhouette alongside the existing luminous blooms and basalt columns.
  if (ecology.spongeClusters > 0 && spongeTubeGeometry && spongeTubeMaterial) {
    const tubeCapacity = ecology.spongeClusters * 6;
    const tubeInstances = new THREE.InstancedMesh(spongeTubeGeometry, spongeTubeMaterial, tubeCapacity);
    const mouthInstances = new THREE.InstancedMesh(spongeMouthGeometry, spongeMouthMaterial, tubeCapacity);
    const glowInstances = new THREE.InstancedMesh(spongeGlowGeometry, spongeGlowMaterial, tubeCapacity);
    const spongePalettes = {
      wreck:[0x6d8790,0x8da9a9,0x557987], thermal:[0xc06c49,0xe1a06b,0x8d554f],
      deep:[0x426c83,0x6396a2,0x31556d], abyss:[0x36546e,0x4f7590,0x263d5d],
      abyssal_shelf:[0x668c97,0x86a9a7,0x486b82], midnight_grotto:[0x665e91,0x8b7ab3,0x455c83],
      blue_void:[0x456c9b,0x638fb9,0x2f4e7d], hadal_rift:[0x846ba9,0xa58dc7,0x514a83],
      hadal_garden:[0x55a69a,0x80d1bd,0x3e7f81]
    };
    const glowPalettes = {
      wreck:0x9ee4df, thermal:0xffa16e, deep:0x70d7e8, abyss:0x5ca9d4,
      abyssal_shelf:0x9ce8dc, midnight_grotto:0x8c8aff, blue_void:0x75caff,
      hadal_rift:0xc3a1ff, hadal_garden:0x9dffe1
    };
    const palette = spongePalettes[chunkBiome.id] || spongePalettes.deep;
    const glowColor = new THREE.Color(glowPalettes[chunkBiome.id] || 0x78dce2);
    const spongeDummy = new THREE.Object3D();
    const spongeMaterialColor = new THREE.Color();
    let spongeCount = 0;
    for (let cluster = 0; cluster < ecology.spongeClusters; cluster++) {
      const clusterX = 7 + hash2(cx * 71 + cluster * 13, cz * 23 - cluster) * 50;
      const clusterZ = 7 + hash2(cx * 37 - cluster * 5, cz * 61 + cluster * 7) * 50;
      const ground = heightAt(baseX + clusterX, baseZ + clusterZ);
      const minDepth = ['thermal','wreck'].includes(chunkBiome.id) ? -18 : -58;
      if (ground > minDepth) continue;
      const tubesInCluster = 4 + Math.floor(hash2(cx + cluster * 11, cz - cluster * 3) * 3);
      for (let tube = 0; tube < tubesInCluster && spongeCount < tubeCapacity; tube++) {
        const angle = tube / tubesInCluster * Math.PI * 2 + hash2(cluster + cx, tube + cz) * 0.55;
        const radius = 0.22 + hash2(cx + tube * 5, cz + cluster * 9) * 0.8;
        const height = 1.2 + hash2(cx * 3 + cluster, cz * 5 + tube) * (chunkBiome.id === 'hadal_garden' ? 3.2 : 2.45);
        const scale = 0.72 + hash2(cx - tube, cz + cluster) * 0.55;
        const px = clusterX + Math.cos(angle) * radius;
        const pz = clusterZ + Math.sin(angle) * radius;
        const localFloor = heightAt(baseX + px, baseZ + pz);
        spongeDummy.position.set(px, localFloor + height * 0.5, pz);
        spongeDummy.rotation.set((hash2(cluster, tube + 4) - 0.5) * 0.18, angle, (hash2(tube + 8, cluster) - 0.5) * 0.18);
        spongeDummy.scale.set(scale, height, scale);
        spongeDummy.updateMatrix();
        tubeInstances.setMatrixAt(spongeCount, spongeDummy.matrix);
        mouthInstances.setMatrixAt(spongeCount, (() => {
          const mouth = new THREE.Object3D();
          mouth.position.set(px, localFloor + height * 0.97, pz);
          mouth.rotation.set(Math.PI / 2 + spongeDummy.rotation.x, angle, spongeDummy.rotation.z);
          mouth.scale.setScalar(scale);
          mouth.updateMatrix();
          return mouth.matrix;
        })());
        const glow = new THREE.Object3D();
        glow.position.set(baseX + px, localFloor + height * 0.91, baseZ + pz);
        glow.scale.setScalar(0.55 + hash2(tube, cluster) * 0.45);
        glow.updateMatrix();
        const glowMatrix = glow.matrix.clone();
        glowMatrix.elements[12] = px; glowMatrix.elements[14] = pz;
        glowInstances.setMatrixAt(spongeCount, glowMatrix);
        spongeMaterialColor.setHex(palette[(cluster + tube) % palette.length]);
        tubeInstances.setColorAt(spongeCount, spongeMaterialColor);
        mouthInstances.setColorAt(spongeCount, spongeMaterialColor.clone().lerp(new THREE.Color(0xc3d9d0),0.24));
        glowInstances.setColorAt(spongeCount, glowColor);
        spongeCount++;
      }
    }
    tubeInstances.count = spongeCount; mouthInstances.count = spongeCount; glowInstances.count = spongeCount;
    for (const mesh of [tubeInstances,mouthInstances,glowInstances]) {
      mesh.instanceMatrix.needsUpdate = true;
      if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
      mesh.frustumCulled = true;
    }
    if (spongeCount) { group.add(tubeInstances,mouthInstances,glowInstances); }
    else { tubeInstances.dispose?.(); mouthInstances.dispose?.(); glowInstances.dispose?.(); }
  }

  // Palm trees are only created for island centers inside this streamed chunk.
  const minIslandX = Math.floor((baseX - 100) / 280), maxIslandX = Math.floor((baseX + CHUNK_SIZE + 100) / 280);
  const minIslandZ = Math.floor((baseZ - 100) / 280), maxIslandZ = Math.floor((baseZ + CHUNK_SIZE + 100) / 280);
  for (let ix = minIslandX; ix <= maxIslandX; ix++) {
    for (let iz = minIslandZ; iz <= maxIslandZ; iz++) {
      const island = islandData(ix, iz);
      if (island.x < baseX || island.x >= baseX + CHUNK_SIZE || island.z < baseZ || island.z >= baseZ + CHUNK_SIZE) continue;
      const treeCount = 2 + Math.floor(hash2(ix + 5, iz + 2) * 3);
      for (let t = 0; t < treeCount; t++) {
        const angle = hash2(ix * 13 + t, iz * 9 - t) * Math.PI * 2;
        const radius = island.radius * (0.18 + hash2(ix + t * 7, iz + t * 5) * 0.34);
        const tx = island.x + Math.cos(angle) * radius;
        const tz = island.z + Math.sin(angle) * radius;
        const th = heightAt(tx, tz);
        if (th > 3) makePalm(group, tx - baseX, tz - baseZ, th, 0.72 + hash2(t + ix, iz - t) * 0.5);
      }
    }
  }
  if (Math.floor(shipOfInterest.x / CHUNK_SIZE) === cx && Math.floor(shipOfInterest.z / CHUNK_SIZE) === cz) makeWreck(group, baseX, baseZ);
  for (const cache of supplyCacheLocations) {
    if (Math.floor(cache.x / CHUNK_SIZE) === cx && Math.floor(cache.z / CHUNK_SIZE) === cz) makeSupplyCache(group, cache, baseX, baseZ);
  }
  // Deterministic mineral and flora nodes are streamed with their terrain chunk.
  const resourceSets = {
    reef:['titanium','copper','quartz','kelp','coral','salt','glowcap','silver'],
    kelp:['titanium','copper','kelp','coral','salt','glowcap','silver'],
    wreck:['titanium','copper','quartz','magnetite','silver'],
    thermal:['lithium','sulfur','magnetite','copper','titanium'],
    deep:['lithium','magnetite','sulfur','quartz','glowcap','silver'],
    abyss:['lithium','magnetite','sulfur','quartz','glowcap','silver'],
    abyssal_shelf:['lithium','magnetite','quartz','silver','salt','glowcap'],
    midnight_grotto:['magnetite','lithium','glowcap','silver','quartz','sulfur'],
    blue_void:['magnetite','lithium','silver','quartz','glowcap'],
    hadal_rift:['magnetite','lithium','silver','sulfur','glowcap'],
    hadal_garden:['magnetite','lithium','silver','glowcap','quartz'],
    open:['titanium','copper','quartz','salt','coral']
  };
  const resourceTypes = resourceSets[chunkBiome.id] || resourceSets.open;
  for (let i = 0; i < 5; i++) {
    const rx = hash2(cx * 17 + i * 23, cz * 19 - i * 11);
    const rz = hash2(cx * 29 - i * 7, cz * 31 + i * 13);
    const wx = baseX + 5 + rx * (CHUNK_SIZE - 10);
    const wz = baseZ + 5 + rz * (CHUNK_SIZE - 10);
    const ground = heightAt(wx, wz);
    if (ground < -8) makeResourceNode(group, cx, cz, i, wx - baseX, wz - baseZ, ground + 0.1, resourceTypes[Math.floor(hash2(cx + i, cz - i) * resourceTypes.length)]);
  }
  for (const [vx, vz] of BIOME_CENTERS.thermal) {
    if (Math.floor(vx / CHUNK_SIZE) === cx && Math.floor(vz / CHUNK_SIZE) === cz) makeThermalVent(group, vx - baseX, vz - baseZ, heightAt(vx, vz));
  }
  for(let i=0;i<CAVE_SITES.length;i++){
    const site=CAVE_SITES[i];
    if(Math.floor(site.x/CHUNK_SIZE)===cx&&Math.floor(site.z/CHUNK_SIZE)===cz){
      const floor=heightAt(site.x,site.z);
      if (site.legacyBasin) {
        makeCaveEntrance(group,cx,cz,site.x-baseX,site.z-baseZ,floor+.15,cx*73+cz*31+i);
        makeSulfurNest(group,cx,cz,i,site.x-baseX+7.4,site.z-baseZ-3.0,floor+.12);
      } else {
        makeDeepCaveEntrance(group,cx,cz,site,site.x-baseX,site.z-baseZ,floor+.08,cx*73+cz*31+i);
      }
    }
  }
  const plantAttempts = ecology.oxygenPlants;
  for(let i=0;i<plantAttempts;i++){
    const px=10+hash2(cx*41+i*13,cz*23-i*7)*(CHUNK_SIZE-20);
    const pz=10+hash2(cx*17-i*9,cz*37+i*11)*(CHUNK_SIZE-20);
    const floor=heightAt(baseX+px,baseZ+pz);
    if(floor < -8)makeOxygenPlant(group,cx,cz,i,px,pz,floor+.1);
  }
  if (['thermal','deep','abyss','abyssal_shelf','midnight_grotto','blue_void','hadal_rift','hadal_garden'].includes(chunkBiome.id)) {
    for (let i = 0; i < 2; i++) {
      const gx = baseX + 10 + hash2(cx * 37 + i * 9, cz * 17 - i) * 44;
      const gz = baseZ + 10 + hash2(cx * 19 - i * 3, cz * 41 + i) * 44;
      const ground = heightAt(gx, gz);
      if (ground < -17) makeCrystalCluster(group, gx - baseX, ground + 0.12, gz - baseZ, chunkBiome.id, cx * 101 + cz * 53 + i * 17);
    }
  }
  if (ecology.hadalBlooms > 0) {
    const bloomCount = ecology.hadalBlooms;
    for (let i = 0; i < bloomCount; i++) {
      const bx = baseX + 8 + hash2(cx * 53 + i * 7, cz * 29 - i) * 48;
      const bz = baseZ + 8 + hash2(cx * 31 - i * 5, cz * 47 + i) * 48;
      const by = heightAt(bx,bz);
      if (by < -80) makeHadalBloom(group,cx,cz,i,bx-baseX,bz-baseZ,by+0.08,chunkBiome.id);
    }
  }
  if (ecology.basaltFormations > 0) {
    const formationCount=ecology.basaltFormations;
    for(let i=0;i<formationCount;i++){
      const fx=baseX+7+hash2(cx*61+i*13,cz*23-i*3)*(CHUNK_SIZE-14);
      const fz=baseZ+7+hash2(cx*29-i*5,cz*47+i*11)*(CHUNK_SIZE-14);
      const floor=heightAt(fx,fz);
      if(floor<-90)makeTrenchFormation(group,cx,cz,i,fx-baseX,fz-baseZ,floor+.06,chunkBiome.id);
    }
  }
  const decorCount = visualQuality === 'high' || visualQuality === 'ultra' ? 2 : 1;
  const decorAllowed = chunkBiome.id !== 'open' || chunkFloor < -14;
  if(decorAllowed){
    for(let i=0;i<decorCount;i++){
      const dx=8+hash2(cx*47+i*17,cz*29-i*5)*(CHUNK_SIZE-16);
      const dz=8+hash2(cx*31-i*7,cz*53+i*11)*(CHUNK_SIZE-16);
      const wx=baseX+dx,wz=baseZ+dz;
      const floor=heightAt(wx,wz);
      if(floor>-12)continue;
      const variant=Math.floor(hash2(cx*71+i*13,cz*37-i*19)*3);
      makeMarineDecoration(group,dx,dz,floor,chunkBiome.id,cx*101+cz*59+i*31,variant);
    }
  }
  for (let i = 0; i < ecology.fanCoral; i++) {
    const px = 6 + hash2(cx * 31 + i * 3, cz * 17 - i) * 52;
    const pz = 6 + hash2(cx * 13 - i * 5, cz * 29 + i * 7) * 52;
    const py = heightAt(baseX + px, baseZ + pz);
    if (py < -7) makeFanCoral(group, px, py, pz, 0.58 + hash2(i + cx, cz + i) * 0.92);
  }
  for (const structure of placedStructures) {
    if (Math.floor(structure.x / CHUNK_SIZE) === cx && Math.floor(structure.z / CHUNK_SIZE) === cz) addBuiltStructure(group, structure, baseX, baseZ);
  }
  scene.add(group);
  chunks.set(`${cx},${cz}`, { group, terrainGeometry, cx, cz });
}

function disposeChunk(chunk) {
  scene.remove(chunk.group);
  const chunkId=`${chunk.cx},${chunk.cz}`;
  oxygenPlantNodes=oxygenPlantNodes.filter(node=>node.chunkKey!==chunkId);
  hadalFloraNodes=hadalFloraNodes.filter(node=>node.chunkKey!==chunkId);
  lavaEffectNodes=lavaEffectNodes.filter(node=>node.chunkKey!==chunkId);
  caveDustNodes=caveDustNodes.filter(node=>node.chunkKey!==chunkId);
  marineDecorationNodes=marineDecorationNodes.filter(node=>node.chunkKey!==chunkId);
  for (const [id, node] of resourceNodes) if (node.chunkKey === `${chunk.cx},${chunk.cz}`) resourceNodes.delete(id);
  const sharedGeometries = new Set([rockGeometry, kelpGeometry, coralGeometry, spongeTubeGeometry, spongeMouthGeometry, spongeGlowGeometry]);
  const sharedMaterials = new Set([terrainMaterial, ...Object.values(terrainMaterials), rockMaterial, kelpMaterial, coralMaterial, spongeTubeMaterial, spongeMouthMaterial, spongeGlowMaterial]);
  const disposedGeometries = new Set();
  const disposedMaterials = new Set();
  chunk.group.traverse(object => {
    if (!object.isMesh && !object.isInstancedMesh && !object.isPoints && !object.isLine && !object.isLineSegments) return;
    if (object.geometry && object.geometry !== chunk.terrainGeometry && !sharedGeometries.has(object.geometry) && !disposedGeometries.has(object.geometry)) {
      object.geometry.dispose();
      disposedGeometries.add(object.geometry);
    }
    const materials = Array.isArray(object.material) ? object.material : [object.material];
    for (const material of materials) if (material && !sharedMaterials.has(material) && !disposedMaterials.has(material)) {
      material.dispose();
      disposedMaterials.add(material);
    }
  });
  chunk.terrainGeometry.dispose();
}

function updateChunks(force = false) {
  if (!scene || !gameActive && !rendererReady) return;
  const cx = Math.floor(player.position.x / CHUNK_SIZE);
  const cz = Math.floor(player.position.z / CHUNK_SIZE);
  if (!force && cx === chunkCenterX && cz === chunkCenterZ) return;
  chunkCenterX = cx; chunkCenterZ = cz;
  const radius = clamp(Number(settings.renderDistance) || 2, 1, 3);
  for (let z = cz - radius; z <= cz + radius; z++) {
    for (let x = cx - radius; x <= cx + radius; x++) {
      const key = `${x},${z}`;
      if (!chunks.has(key)) makeChunk(x, z);
    }
  }
  for (const [key, chunk] of chunks) {
    if (Math.abs(chunk.cx - cx) > radius || Math.abs(chunk.cz - cz) > radius) {
      disposeChunk(chunk);
      chunks.delete(key);
    }
  }
}

function makeSurfaceSkyTexture() {
  const canvas=document.createElement('canvas');canvas.width=1024;canvas.height=512;
  const ctx=canvas.getContext('2d');
  const gradient=ctx.createLinearGradient(0,0,0,512);
  gradient.addColorStop(0,'#164c72');gradient.addColorStop(0.42,'#4e8eaa');gradient.addColorStop(0.78,'#b7c9c1');gradient.addColorStop(1,'#e3d3ae');
  ctx.fillStyle=gradient;ctx.fillRect(0,0,1024,512);
  // Soft, original cloud banks create a horizon cue without expensive volumetrics.
  for(let i=0;i<70;i++){
    const x=(i*173.3)%1024,y=130+(i*47.9)%220,w=35+(i%9)*18,h=5+(i%4)*3;
    const cloud=ctx.createRadialGradient(x,y,1,x,y,w);
    cloud.addColorStop(0,`rgba(237,247,239,${0.06+(i%5)*0.012})`);cloud.addColorStop(1,'rgba(237,247,239,0)');
    ctx.fillStyle=cloud;ctx.beginPath();ctx.ellipse(x,y,w,h,0,0,Math.PI*2);ctx.fill();
  }
  const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;texture.minFilter=THREE.LinearMipmapLinearFilter;texture.magFilter=THREE.LinearFilter;return texture;
}

function makeSunSpriteTexture() {
  const canvas=document.createElement('canvas');canvas.width=256;canvas.height=256;
  const ctx=canvas.getContext('2d');
  const g=ctx.createRadialGradient(128,128,8,128,128,124);
  g.addColorStop(0,'rgba(255,252,222,1)');g.addColorStop(.22,'rgba(255,231,175,.82)');g.addColorStop(.5,'rgba(255,218,164,.2)');g.addColorStop(1,'rgba(255,218,164,0)');
  ctx.fillStyle=g;ctx.fillRect(0,0,256,256);
  const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;return texture;
}

function makeSeagrassTuftGeometry() {
  const positions = [], uvs = [], colors = [], indices = [];
  const bladeCount = 11;
  const segments = 9;
  const rootColor = new THREE.Color(0x174e3d);
  const midColor = new THREE.Color(0x3d9b70);
  const tipColor = new THREE.Color(0x91c98a);
  for (let blade = 0; blade < bladeCount; blade++) {
    const angle = (blade / bladeCount) * Math.PI * 2 + (blade % 3) * 0.19;
    const length = 3.0 + ((blade * 7) % 9) * 0.22;
    const width = 0.085 + ((blade * 5) % 6) * 0.012;
    const rootRadius = 0.045 + (blade % 3) * 0.035;
    const dirX = Math.cos(angle), dirZ = Math.sin(angle);
    const sideX = -dirZ, sideZ = dirX;
    const start = positions.length / 3;
    for (let row = 0; row <= segments; row++) {
      const t = row / segments;
      const curve = t * t * (0.12 + (blade % 4) * 0.027);
      const centerX = dirX * (rootRadius + curve) + Math.sin(t * Math.PI) * dirZ * 0.055;
      const centerZ = dirZ * (rootRadius + curve) - Math.sin(t * Math.PI) * dirX * 0.055;
      const taper = Math.pow(1 - t, 0.68) * (0.82 + 0.18 * Math.sin(t * Math.PI));
      const halfWidth = Math.max(0.003, width * taper * 0.5);
      const y = t * length;
      positions.push(centerX + sideX * halfWidth, y, centerZ + sideZ * halfWidth);
      positions.push(centerX - sideX * halfWidth, y, centerZ - sideZ * halfWidth);
      uvs.push(0, t, 1, t);
      const bladeColor = rootColor.clone().lerp(midColor, clamp(t * 1.25, 0, 1)).lerp(tipColor, Math.pow(t, 2.1) * 0.45);
      const variation = 0.9 + (blade % 5) * 0.035;
      colors.push(bladeColor.r * variation, bladeColor.g * variation, bladeColor.b * variation);
      colors.push(bladeColor.r * variation, bladeColor.g * variation, bladeColor.b * variation);
    }
    for (let row = 0; row < segments; row++) {
      const a = start + row * 2, b = a + 1, c = a + 2, d = a + 3;
      indices.push(a, c, b, b, c, d);
    }
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();
  geometry.computeBoundingSphere();
  return geometry;
}

function makeWaterAndParticles() {
  const visualQuality = getActiveGraphicsQuality();
  const waterSegments = visualQuality === 'low' ? 72 : (visualQuality === 'high' || visualQuality === 'ultra') ? (activeGraphicsProfile?.is4K ? 192 : 160) : 112;
  const waterGeometry = new THREE.PlaneGeometry(1900, 1900, waterSegments, waterSegments);
  const waterMaterial = new THREE.MeshPhysicalMaterial({
    color: 0x68b9bd, map: waterColorTexture, normalMap: waterNormalTexture,
    normalScale: new THREE.Vector2(0.42, 0.42),
    transparent: true, opacity: 0.19, roughness: 0.27, metalness: 0.045,
    clearcoat: 0.9, clearcoatRoughness: 0.16, envMapIntensity: 1.15,
    depthWrite: false, side: THREE.DoubleSide
  });
  water = new THREE.Mesh(waterGeometry, waterMaterial);
  water.rotation.x = -Math.PI / 2;
  water.position.y = 0;
  water.renderOrder = 2;
  waterWaveBase = waterGeometry.attributes.position.array.slice();
  scene.add(water);
  createSwimBubblePool();

  surfaceSkyTexture=makeSurfaceSkyTexture();
  surfaceSky=new THREE.Group();
  const skyDome=new THREE.Mesh(new THREE.SphereGeometry(1100,40,24),new THREE.MeshBasicMaterial({map:surfaceSkyTexture,side:THREE.BackSide,transparent:true,opacity:0,depthWrite:false,fog:false}));
  skyDome.frustumCulled=false;surfaceSky.add(skyDome);
  const sunTexture=makeSunSpriteTexture();
  surfaceSun=new THREE.Sprite(new THREE.SpriteMaterial({map:sunTexture,color:0xffffff,transparent:true,opacity:0,depthWrite:false,fog:false,blending:THREE.AdditiveBlending}));
  surfaceSun.scale.set(54,54,1);surfaceSky.add(surfaceSun);
  surfaceMoon=new THREE.Sprite(new THREE.SpriteMaterial({map:sunTexture,color:0x9bc8e8,transparent:true,opacity:0,depthWrite:false,fog:false,blending:THREE.AdditiveBlending}));
  surfaceMoon.scale.set(32,32,1);surfaceSky.add(surfaceMoon);
  surfaceSky.userData.dome=skyDome;surfaceSky.userData.sunTexture=sunTexture;
  scene.add(surfaceSky);

  const particlePositions = [];
  for (let i = 0; i < 260; i++) particlePositions.push((Math.random() - 0.5) * 190, (Math.random() - 0.5) * 70, (Math.random() - 0.5) * 190);
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(particlePositions, 3));
  const mat = new THREE.PointsMaterial({ color: 0xc2f5f3, size: 0.32, transparent: true, opacity: 0.54, depthWrite: false, sizeAttenuation: true });
  particleGroup = new THREE.Group();
  particleGroup.add(new THREE.Points(geo, mat));
  scene.add(particleGroup);

  // Soft underwater god-rays: lightweight textured planes, not expensive volumetric fog.
  lightRayGroup = new THREE.Group();
  const rayCanvas = document.createElement('canvas'); rayCanvas.width = 32; rayCanvas.height = 256;
  const rayCtx = rayCanvas.getContext('2d');
  const gradient = rayCtx.createLinearGradient(0, 0, 0, 256);
  gradient.addColorStop(0, 'rgba(146,244,239,0.34)');
  gradient.addColorStop(0.35, 'rgba(100,211,221,0.13)');
  gradient.addColorStop(1, 'rgba(66,177,196,0)');
  rayCtx.fillStyle = gradient; rayCtx.fillRect(0, 0, 32, 256);
  const rayTexture = new THREE.CanvasTexture(rayCanvas); rayTexture.colorSpace = THREE.SRGBColorSpace;
  const rayMaterial = new THREE.MeshBasicMaterial({ map: rayTexture, color: 0xc4ffff, transparent: true, opacity: 0.62, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide });
  for (let i = 0; i < 7; i++) {
    const ray = new THREE.Mesh(new THREE.PlaneGeometry(3.5 + (i % 3) * 1.5, 42), rayMaterial);
    const angle = i / 7 * Math.PI * 2;
    ray.position.set(Math.cos(angle) * (10 + i * 1.1), -16, Math.sin(angle) * (10 + i * 1.1));
    ray.rotation.y = angle * 0.37;
    lightRayGroup.add(ray);
  }
  lightRayGroup.userData.rayMaterial = rayMaterial;
  scene.add(lightRayGroup);
}

function updateWaterSurface(dt) {
  if(!water || !waterWaveBase || clockState.elapsed-waterWaveLastUpdate<waterWaveUpdateInterval) return;
  waterWaveLastUpdate=clockState.elapsed;
  const attribute=water.geometry.attributes.position;
  const values=attribute.array;
  for(let i=0;i<attribute.count;i++){
    const offset=i*3;
    const worldX=water.position.x+waterWaveBase[offset];
    const worldZ=water.position.z-waterWaveBase[offset+1];
    values[offset+2]=waterSurfaceHeightAt(worldX,worldZ,clockState.elapsed);
  }
  attribute.needsUpdate=true;
  water.geometry.computeVertexNormals();
}

function applyWaterQualitySettings(profile = activeGraphicsProfile || getGraphicsProfile(), quality = profile?.effectivePreset || settings.graphics) {
  waterWaveUpdateInterval = quality === 'low' ? 0.085 : quality === 'high' ? 0.045 : 0.06;
  if (!water || !water.material) return;
  const waterSegments = quality === 'low' ? 72 : (quality === 'high' || quality === 'ultra') ? (profile?.is4K ? 192 : 160) : 128;
  if (water.geometry.parameters?.widthSegments !== waterSegments) {
    const oldGeometry = water.geometry;
    water.geometry = new THREE.PlaneGeometry(1900, 1900, waterSegments, waterSegments);
    waterWaveBase = water.geometry.attributes.position.array.slice();
    oldGeometry.dispose();
  }
  const normalStrength = quality === 'ultra' ? 0.60 : quality === 'high' ? (profile?.is4K ? 0.58 : 0.50) : quality === 'low' ? 0.36 : 0.46;
  water.material.normalScale.set(normalStrength, normalStrength);
  water.material.needsUpdate = true;
}

function updateSurfacePresentation(eyeY, waterY, biome) {
  const previous=surfaceBlend;
  surfaceBlend=computeSurfaceBlend(eyeY,waterY);
  const above=surfaceBlend>0.62;
  $('game-shell')?.classList.toggle('surface-above-water',above);
  const shell=$('game-shell');
  shell?.classList.toggle('surface-transition',surfaceBlend>0.03&&surfaceBlend<0.97);
  shell?.style.setProperty('--surface-blend',surfaceBlend.toFixed(3));
  if(surfaceSky){
    surfaceSky.visible=surfaceBlend>0.005;
    surfaceSky.position.set(player.position.x,0,player.position.z);
    const day=computeDaylight(clockState.elapsed,1080);
    const angle=day.phase*Math.PI*2;
    surfaceSun.position.set(Math.cos(angle)*280,150+day.sunElevation*45,-220);
    surfaceMoon.position.set(-Math.cos(angle)*260,125-day.sunElevation*35,210);
    surfaceSky.userData.dome.material.opacity=surfaceBlend;
    surfaceSun.material.opacity=surfaceBlend*day.daylight*0.92;
    surfaceMoon.material.opacity=surfaceBlend*day.night*0.5;
    surfaceSky.userData.dome.material.color.setRGB(0.78+day.daylight*0.22,0.84+day.daylight*0.16,0.92+day.daylight*0.08);
  }
  if(particleGroup)particleGroup.visible=surfaceBlend<0.82;
  if(lightRayGroup)lightRayGroup.visible=surfaceBlend<0.82;
  if(water?.material){
    water.material.opacity=lerp(0.22,0.50,surfaceBlend);
    if(water.material.color){water.material.color.setHex(biome?.fog||0x176a78).lerp(waterBiomeTintScratch,0.62).lerp(surfaceWaterTint,surfaceBlend*0.72);}
  }
  if(scene?.fog){
    const depth=Math.max(0,-player.position.y);
    const visualQuality=getActiveGraphicsQuality();
    const atmosphere=getDepthAtmosphereProfile(depth,surfaceBlend,visualQuality);
    const baseDensity=visualQuality==='low'?(biome?.density||0.002)*1.22:visualQuality==='high'?(biome?.density||0.002)*0.82:(biome?.density||0.002);
    const depthTint=new THREE.Color(0x071a31);
    const biomeTint=new THREE.Color(biome?.fog||0x176a78).lerp(depthTint,Math.min(0.94,atmosphere.deepBlend*0.72+atmosphere.hadalBlend*0.24));
    biomeTint.lerp(surfaceWaterTint,surfaceBlend);
    scene.fog.color.copy(biomeTint);
    scene.fog.density=lerp((baseDensity+Math.min(0.0048,depth*0.000012))*atmosphere.fogScale,0.00022,surfaceBlend);
  }
  const day=computeDaylight(clockState.elapsed,1080);
  if(hemiLight)hemiLight.intensity=lerp(0.52+ (1-smoothstep(12,175,Math.max(0,-player.position.y)))*1.38,0.82+day.daylight*0.9,surfaceBlend);
  if(sunLight){sunLight.intensity=lerp(0.08+(1-smoothstep(12,175,Math.max(0,-player.position.y)))*(0.28+day.daylight*1.25),0.55+day.daylight*1.65,surfaceBlend);sunLight.position.set(player.position.x-60+Math.cos(day.phase*Math.PI*2)*35,110+day.sunElevation*20,player.position.z+40);}
  if(previous<0.55&&surfaceBlend>=0.55)playSfx('splash');
  if(previous>=0.55&&surfaceBlend<0.55)playSfx('dive');
}

function createWorld() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x0b3446);
  scene.fog = new THREE.FogExp2(0x0b4051, 0.00195);
  const viewport = getGameViewportSize();
  camera = new THREE.PerspectiveCamera(settings.fov, viewport.width / viewport.height, 0.08, 1300);
  camera.position.set(0, -2.5, 11);
  try {
    renderer = new THREE.WebGLRenderer({ canvas, antialias: settings.graphics !== 'low', alpha: false, powerPreference: 'high-performance', stencil: false, depth: true });
  } catch (error) {
    const webglAvailable = Boolean(window.WebGLRenderingContext || window.WebGL2RenderingContext);
    throw new Error(webglAvailable
      ? `Inisialisasi WebGL gagal (${error?.message || 'konteks grafis tidak tersedia'})`
      : 'Perangkat atau WebView tidak mendukung WebGL 2. Aktifkan akselerasi perangkat keras dan perbarui Android System WebView.');
  }
  bindWebGLContextRecovery();
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.shadowMap.enabled = settings.graphics === 'high' || settings.graphics === 'ultra';
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.2;
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, settings.graphics === 'ultra' ? 1.6 : settings.graphics === 'high' ? 1.5 : settings.graphics === 'low' ? 0.8 : 1.05));
  renderer.setSize(viewport.width, viewport.height, false);
  rendererReady = true;

  hemiLight = new THREE.HemisphereLight(0xb8f2f2, 0x071b2a, 1.9);
  scene.add(hemiLight);
  sunLight = new THREE.DirectionalLight(0xb9f7f0, 1.65);
  sunLight.position.set(-60, 110, 40);
  sunLight.castShadow=settings.graphics==='high'||settings.graphics==='ultra';
  sunLight.shadow.mapSize.set(1024,1024);
  sunLight.shadow.camera.left=-110; sunLight.shadow.camera.right=110; sunLight.shadow.camera.top=110; sunLight.shadow.camera.bottom=-110;
  sunLight.shadow.bias=-0.00018;
  scene.add(sunLight);
  fillLight = new THREE.PointLight(0x287f9e, 1.5, 220);
  fillLight.position.set(20, -10, 20); scene.add(fillLight);
  const rim = new THREE.PointLight(0x56c7c6, 0.85, 90); rim.position.set(-32, -22, -28); scene.add(rim);

  const requestedGraphicsProfile = getGraphicsProfile();
  const initialProfileKey = [requestedGraphicsProfile.preset,requestedGraphicsProfile.primaryTextureSize,requestedGraphicsProfile.supportingTextureSize,requestedGraphicsProfile.waterTextureSize,requestedGraphicsProfile.bumpTextureSize,requestedGraphicsProfile.causticTextureSize,requestedGraphicsProfile.faunaTextureSize].join(':');
  const initialTextureBuild = makeGraphicsTextureSetWithFallback(requestedGraphicsProfile);
  applyGraphicsTextureSet(initialTextureBuild.textureSet, false);
  activeGraphicsProfile = initialTextureBuild.profile;
  activeGraphicsProfileKey = initialProfileKey;
  waterWaveUpdateInterval = getActiveGraphicsQuality() === 'low' ? 0.085 : getActiveGraphicsQuality() === 'high' ? 0.045 : 0.06;
  terrainMaterial = new THREE.MeshStandardMaterial({ vertexColors: true, map: terrainTexture, bumpMap:terrainBumpTexture, bumpScale:0.15, emissive:0x1a4044, emissiveMap:causticTexture, emissiveIntensity:0.16, roughness: 0.96, metalness: 0.01, side: THREE.DoubleSide, flatShading: false });
  terrainMaterials = {
    reef: new THREE.MeshStandardMaterial({vertexColors:true,map:coralTexture,bumpMap:coralBumpTexture,bumpScale:0.10,emissive:0x173e43,emissiveMap:causticTexture,emissiveIntensity:0.13,roughness:0.91,side:THREE.DoubleSide}),
    kelp: new THREE.MeshStandardMaterial({vertexColors:true,map:kelpTexture,bumpMap:kelpBumpTexture,bumpScale:0.12,emissive:0x163d3c,emissiveMap:causticTexture,emissiveIntensity:0.12,roughness:0.95,side:THREE.DoubleSide}),
    wreck: new THREE.MeshStandardMaterial({vertexColors:true,map:rockTexture,bumpMap:rockBumpTexture,bumpScale:0.24,roughness:0.97,side:THREE.DoubleSide}),
    thermal: new THREE.MeshStandardMaterial({vertexColors:true,map:metalTexture,bumpMap:metalBumpTexture,bumpScale:0.16,roughness:0.82,metalness:0.08,side:THREE.DoubleSide}),
    deep: new THREE.MeshStandardMaterial({vertexColors:true,map:rockTexture,bumpMap:rockBumpTexture,bumpScale:0.24,roughness:0.98,metalness:0.04,side:THREE.DoubleSide}),
    abyss: new THREE.MeshStandardMaterial({vertexColors:true,map:rockTexture,bumpMap:rockBumpTexture,bumpScale:0.28,roughness:0.995,metalness:0.06,side:THREE.DoubleSide}),
    abyssal_shelf: new THREE.MeshStandardMaterial({vertexColors:true,map:rockTexture,bumpMap:rockBumpTexture,bumpScale:0.31,roughness:0.99,metalness:0.08,side:THREE.DoubleSide}),
    midnight_grotto: new THREE.MeshStandardMaterial({vertexColors:true,map:rockTexture,bumpMap:rockBumpTexture,bumpScale:0.34,roughness:0.995,metalness:0.03,side:THREE.DoubleSide}),
    blue_void: new THREE.MeshStandardMaterial({vertexColors:true,map:rockTexture,bumpMap:rockBumpTexture,bumpScale:0.36,roughness:0.995,metalness:0.035,side:THREE.DoubleSide}),
    hadal_rift: new THREE.MeshStandardMaterial({vertexColors:true,map:rockTexture,bumpMap:rockBumpTexture,bumpScale:0.39,roughness:1,metalness:0.02,side:THREE.DoubleSide}),
    hadal_garden: new THREE.MeshStandardMaterial({vertexColors:true,map:rockTexture,bumpMap:rockBumpTexture,bumpScale:0.42,roughness:0.99,metalness:0.025,side:THREE.DoubleSide}),
    open: terrainMaterial
  };
  rockGeometry = new THREE.DodecahedronGeometry(1.5, 2);
  // Deterministic vertex deformation avoids identical low-poly boulders while keeping one instanced mesh.
  const rockPosition=rockGeometry.getAttribute('position');
  for(let vertex=0;vertex<rockPosition.count;vertex++){
    const x=rockPosition.getX(vertex),y=rockPosition.getY(vertex),z=rockPosition.getZ(vertex);
    const ripple=1+Math.sin(x*2.3+z*1.7)*0.075+Math.cos(y*2.8-x*1.2)*0.055;
    rockPosition.setXYZ(vertex,x*ripple,y*(ripple+Math.sin(z*2.1)*0.035),z*ripple);
  }
  rockPosition.needsUpdate=true;rockGeometry.computeVertexNormals();rockGeometry.computeBoundingSphere();
  rockMaterial = new THREE.MeshStandardMaterial({ color: 0x91aeb1, map: rockTexture, bumpMap:rockBumpTexture, bumpScale:0.22, roughness: 0.96, flatShading: true });
  // A tuft contains multiple tapered ribbon blades rather than a single trunk.
  // Shared geometry + InstancedMesh keep the meadow inexpensive on mobile GPUs.
  kelpGeometry = makeSeagrassTuftGeometry();
  kelpMaterial = new THREE.MeshStandardMaterial({
    color: 0xffffff, vertexColors: true, map: kelpTexture,
    bumpMap: kelpBumpTexture, bumpScale: 0.055,
    roughness: 0.9, metalness: 0.015, flatShading: false, side: THREE.DoubleSide
  });
  kelpMaterial.onBeforeCompile = shader => {
    shader.uniforms.uAbyssTime={value:0};
    shader.vertexShader=shader.vertexShader.replace('#include <common>','#include <common>\nuniform float uAbyssTime;');
    shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>', `#include <begin_vertex>
#ifdef USE_INSTANCING
vec3 kelpRoot = instanceMatrix[3].xyz;
#else
vec3 kelpRoot = vec3(0.0);
#endif
float kelpWeight = clamp(position.y / 4.8, 0.0, 1.0);
float kelpBend = kelpWeight * kelpWeight;
float kelpPhase = uAbyssTime * 0.82 + kelpRoot.x * 0.037 + kelpRoot.z * 0.041;
float kelpPrimary = sin(kelpPhase + position.y * 0.52 + position.x * 1.6);
float kelpSecondary = sin(kelpPhase * 0.67 + position.y * 0.93 + position.z * 2.1);
float kelpTertiary = cos(kelpPhase * 0.82 + position.y * 0.61);
transformed.x += (kelpPrimary * 0.24 + kelpSecondary * 0.045) * kelpBend;
transformed.z += (kelpTertiary * 0.15 + sin(kelpPhase * 1.1 + position.x) * 0.025) * kelpBend;
// Approximate the bend gradient so the lighting follows the moving blades.
float kelpSlopeX = (cos(kelpPhase + position.y * 0.52 + position.x * 1.6) * 0.52 * 0.24 + cos(kelpPhase * 0.67 + position.y * 0.93 + position.z * 2.1) * 0.93 * 0.045) * kelpBend;
float kelpSlopeZ = (-sin(kelpPhase * 0.82 + position.y * 0.61) * 0.82 * 0.61 * 0.15 + cos(kelpPhase * 1.1 + position.x) * 1.1 * 0.025) * kelpBend;
objectNormal.x -= kelpSlopeX * 0.65;
objectNormal.z -= kelpSlopeZ * 0.65;
objectNormal = normalize(objectNormal);`);
    kelpShader=shader;
  };
  coralGeometry = new THREE.ConeGeometry(0.72, 2.1, 9, 2);
  coralMaterial = new THREE.MeshStandardMaterial({ color: 0xffffff, map: coralTexture, bumpMap:coralBumpTexture, bumpScale:0.12, roughness: 0.92, flatShading: false });
  // Shared instanced tube-sponge assets add recognizable hadal reef silhouettes
  // without creating hundreds of independent draw calls in streamed chunks.
  spongeTubeGeometry = new THREE.CylinderGeometry(0.17, 0.28, 1, 8, 2);
  spongeMouthGeometry = new THREE.TorusGeometry(0.16, 0.035, 6, 12);
  spongeGlowGeometry = new THREE.SphereGeometry(0.075, 8, 6);
  spongeTubeMaterial = new THREE.MeshStandardMaterial({ color:0xffffff, vertexColors:true, map:coralTexture, bumpMap:coralBumpTexture, bumpScale:0.055, roughness:0.9, metalness:0.015 });
  spongeMouthMaterial = new THREE.MeshStandardMaterial({ color:0xffffff, vertexColors:true, roughness:0.48, metalness:0.04 });
  spongeGlowMaterial = new THREE.MeshStandardMaterial({ color:0xffffff, vertexColors:true, emissive:0xffffff, emissiveIntensity:0.72, roughness:0.24, metalness:0.02 });
  makeWaterAndParticles();
  makePlayer();
  playerGroup.visible = false; // First-person only; no third-person diver model.
  makeFirstPersonViewModel();
  faunaDirector = new FaunaDirector(scene, applyDamage, heightAt, initialTextureBuild.profile.faunaTextureSize, getBiomeAt, (x,z)=>getCaveCeilingY(x,z,heightAt(x,z),CAVE_SITES,0.28), (fromX,fromZ,toX,toZ,radius)=>constrainCaveHorizontalMotion(fromX,fromZ,toX,toZ,radius,CAVE_SITES), (speciesId,position)=>audioAssetBank?.playCreatureCall(speciesId,position));
  faunaDirector.setQuality(initialTextureBuild.profile.effectivePreset || settings.graphics, initialTextureBuild.profile.faunaTextureSize);
  loadWorldPbrTextures();
  updateChunks(true);
  applySettings();
}

function getCurrentMission() {
  return MISSION_SEQUENCE[clamp(storyState.missionIndex || 0, 0, MISSION_SEQUENCE.length - 1)];
}

function updateMissionUI() {
  const mission = getCurrentMission();
  const title = $('mission-title');
  const objective = $('mission-objective');
  const progress = $('mission-progress');
  if (title) title.textContent = mission.title;
  if (objective) objective.textContent = mission.objective;
  if (progress) {
    const count = mission.id === 'materials' ? `${Math.min(3, storyState.counters?.materials || 0)}/3 COLLECTED` : `DIRECTIVE ${Math.min(storyState.missionIndex + 1, MISSION_SEQUENCE.length)}/${MISSION_SEQUENCE.length}`;
    progress.textContent = count;
  }
  const root = $('mission-log');
  if (root) {
    root.replaceChildren();
    MISSION_SEQUENCE.forEach((entry, index) => {
      const card = document.createElement('article');
      const complete = (storyState.completed || []).includes(entry.id);
      const active = index === storyState.missionIndex;
      card.className = `pda-entry ${complete ? 'is-known' : 'is-unknown'}`;
      const heading = document.createElement('strong');
      heading.textContent = `${complete ? '✓ ' : active ? '▸ ' : '○ '}${entry.title}`;
      const note = document.createElement('p');
      note.textContent = entry.objective;
      const status = document.createElement('small');
      status.textContent = complete ? 'DIRECTIVE COMPLETE' : active ? 'ACTIVE DIRECTIVE' : 'LOCKED / PENDING';
      card.append(heading, note, status);
      root.append(card);
    });
  }
}

function speakRadio(speaker, text, cinematic = false) {
  const speakerNode = $(cinematic ? 'cinematic-speaker' : 'radio-speaker');
  const lineNode = $(cinematic ? 'cinematic-line' : 'radio-line');
  if (speakerNode) speakerNode.textContent = speaker;
  if (lineNode) lineNode.textContent = text;
  if (!cinematic) {
    $('radio-subtitle')?.classList.remove('hidden');
    clearTimeout(radioHideTimer);
    radioHideTimer = setTimeout(() => $('radio-subtitle')?.classList.add('hidden'), 5600);
  }
  playSfx('radio');
  try {
    if ('speechSynthesis' in window && typeof SpeechSynthesisUtterance !== 'undefined') {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = settings.language === 'id' ? 'id-ID' : 'en-US';
      utterance.rate = 0.91;
      utterance.pitch = 0.88;
      utterance.volume = clamp(settings.volume / 100, 0, 1);
      const voices = window.speechSynthesis.getVoices?.() || [];
      const voice = voices.find(item => item.lang?.toLowerCase().startsWith(settings.language === 'id' ? 'id' : 'en'));
      if (voice) utterance.voice = voice;
      window.speechSynthesis.speak(utterance);
    }
  } catch (error) {
    console.info('Voice synthesis unavailable; subtitles remain enabled.', error);
  }
}

function advanceMission(eventId) {
  const mission = getCurrentMission();
  if (!mission || mission.id !== eventId || mission.id === 'freeplay') return false;
  publishSharedWorldEvent('mission_completed',mission.id,{missionId:mission.id});
  storyState.completed = Array.isArray(storyState.completed) ? storyState.completed : [];
  if (!storyState.completed.includes(mission.id)) storyState.completed.push(mission.id);
  storyState.missionIndex = Math.min(storyState.missionIndex + 1, MISSION_SEQUENCE.length - 1);
  speakRadio('ABYSSAL GUIDANCE', mission.done);
  updateMissionUI();
  playSfx('discovery');
  if (activeSlot >= 0) markUnsaved();
  const next = getCurrentMission();
  if (next && next.id !== 'freeplay') setTimeout(() => speakRadio('MISSION UPDATE', next.objective), 1200);
  return true;
}

function recordMissionMaterial() {
  if (getCurrentMission()?.id !== 'materials') return;
  storyState.counters.materials = Math.min(3, (storyState.counters.materials || 0) + 1);
  updateMissionUI();
  if (storyState.counters.materials >= 3) advanceMission('materials');
  else markUnsaved();
}

function makeLifePod() {
  if (lifepodGroup) { scene.remove(lifepodGroup); disposeObjectTree(lifepodGroup); lifepodGroup = null; }
  const root = new THREE.Group();
  const shellMat = new THREE.MeshStandardMaterial({ color:0xe6e5d7, map:metalTexture, bumpMap:metalBumpTexture, bumpScale:0.095, roughness:0.58, metalness:0.32, transparent:false, opacity:1, depthWrite:true, side:THREE.FrontSide });
  const orangeMat = new THREE.MeshStandardMaterial({ color:0xd88445, map:metalTexture, roughness:0.52, metalness:0.28, emissive:0x4b1908, emissiveIntensity:0.12 });
  const glassMat = new THREE.MeshPhysicalMaterial({ color:0x83dce0, roughness:0.12, metalness:0.12, transparent:true, opacity:0.66, transmission:0.12 });
  const exteriorParts = [];
  const interiorParts = [];
  const body = new THREE.Mesh(new THREE.CylinderGeometry(1.42,1.55,3.4,40,4), shellMat);
  body.rotation.x = Math.PI / 2; body.position.z = 0.15; root.add(body); exteriorParts.push(body);
  // Structural pressure ribs and segmented service panels make the capsule read as a built vessel.
  const ribMat = new THREE.MeshStandardMaterial({color:0x718990,map:metalTexture,bumpMap:metalBumpTexture,bumpScale:0.035,metalness:0.72,roughness:0.44});
  for (const ribZ of [-1.02,-0.12,0.78,1.52]) {
    const pressureRib=new THREE.Mesh(new THREE.TorusGeometry(1.47,0.045,7,40),ribMat);
    pressureRib.rotation.x=Math.PI/2;pressureRib.position.set(0,0.15,ribZ);root.add(pressureRib);exteriorParts.push(pressureRib);
  }
  const servicePanelMat=new THREE.MeshStandardMaterial({color:0x3c5964,map:metalTexture,bumpMap:metalBumpTexture,bumpScale:0.04,metalness:0.72,roughness:0.46});
  const panelTrimMat=new THREE.MeshStandardMaterial({color:0xd98548,metalness:0.48,roughness:0.48,emissive:0x321407,emissiveIntensity:0.12});
  for (const side of [-1,1]) {
    const panel=new THREE.Mesh(new THREE.BoxGeometry(0.09,0.62,0.72),servicePanelMat);
    panel.position.set(side*1.405,0.22,0.18);panel.rotation.z=side*0.08;root.add(panel);exteriorParts.push(panel);
    const statusStrip=new THREE.Mesh(new THREE.BoxGeometry(0.035,0.42,0.10),panelTrimMat);
    statusStrip.position.set(side*1.46,0.22,0.18);root.add(statusStrip);exteriorParts.push(statusStrip);
  }
  const fastenerGeometry=new THREE.SphereGeometry(0.038,7,5);
  const fasteners=new THREE.InstancedMesh(fastenerGeometry,panelTrimMat,36);
  const fastenerDummy=new THREE.Object3D();let fastenerIndex=0;
  for(const ringZ of [-0.78,0.24,1.16]) for(let bolt=0;bolt<12;bolt++){
    const angle=bolt/12*Math.PI*2;fastenerDummy.position.set(Math.cos(angle)*1.49,Math.sin(angle)*1.49+0.15,ringZ);
    fastenerDummy.updateMatrix();fasteners.setMatrixAt(fastenerIndex++,fastenerDummy.matrix);
  }
  fasteners.count=fastenerIndex;fasteners.instanceMatrix.needsUpdate=true;root.add(fasteners);exteriorParts.push(fasteners);
  const nose = new THREE.Mesh(new THREE.SphereGeometry(1.43,16,10,0,Math.PI*2,0,Math.PI/2), shellMat);
  nose.position.z = -1.55; nose.rotation.x = -Math.PI/2; root.add(nose); exteriorParts.push(nose);
  const rear = new THREE.Mesh(new THREE.ConeGeometry(1.52,1.25,20), orangeMat); rear.rotation.x = Math.PI/2; rear.position.z = 2.35; root.add(rear); exteriorParts.push(rear);
  const windowMesh = new THREE.Mesh(new THREE.CircleGeometry(0.56,24), glassMat); windowMesh.position.set(0,0.16,-1.0); windowMesh.rotation.y = Math.PI; root.add(windowMesh); exteriorParts.push(windowMesh);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(1.48,0.10,10,36), orangeMat); ring.rotation.x = Math.PI/2; ring.position.z = 0.75; root.add(ring); exteriorParts.push(ring);
  const finMat = new THREE.MeshStandardMaterial({color:0x385866,map:metalTexture,bumpMap:metalBumpTexture,roughness:0.68,metalness:0.45});
  for(let i=0;i<4;i++){
    const fin = new THREE.Mesh(new THREE.BoxGeometry(0.22,1.15,1.5),finMat);
    const angle=i*Math.PI/2; fin.position.set(Math.cos(angle)*1.4,Math.sin(angle)*1.4,1.35); fin.rotation.z=angle; root.add(fin); exteriorParts.push(fin);
  }
  // Extra structural skin: raised service rails, caution panels, beacon mast and exterior flood lamps.
  const cautionMat=new THREE.MeshStandardMaterial({color:0xe2a04f,map:metalTexture,bumpMap:metalBumpTexture,bumpScale:.025,metalness:.5,roughness:.48});
  const darkTrimMat=new THREE.MeshStandardMaterial({color:0x243f4b,map:metalTexture,metalness:.7,roughness:.5});
  for(const side of [-1,1]){
    for(let panelIndex=0;panelIndex<3;panelIndex++){
      const panel=new THREE.Mesh(new THREE.BoxGeometry(.055,.16,.46),cautionMat);
      panel.position.set(side*1.49,.48,-.78+panelIndex*.74);panel.rotation.z=side*.05;root.add(panel);exteriorParts.push(panel);
    }
    const rail=new THREE.Mesh(new THREE.CylinderGeometry(.045,.045,2.5,8),darkTrimMat);
    rail.position.set(side*1.43,.06,.18);rail.rotation.x=Math.PI/2;root.add(rail);exteriorParts.push(rail);
    const flood=new THREE.Mesh(new THREE.SphereGeometry(.13,10,8),new THREE.MeshStandardMaterial({color:0xb7fff4,emissive:0x4ce8d8,emissiveIntensity:1.8}));
    flood.position.set(side*1.44,.55,-.86);root.add(flood);exteriorParts.push(flood);
    const floodLight=new THREE.PointLight(0x67e9dd,.48,7);floodLight.position.copy(flood.position);root.add(floodLight);exteriorParts.push(floodLight);
  }
  const beaconMast=new THREE.Mesh(new THREE.CylinderGeometry(.045,.075,.72,8),darkTrimMat);beaconMast.position.set(0,1.84,.15);root.add(beaconMast);exteriorParts.push(beaconMast);
  const beaconLens=new THREE.Mesh(new THREE.SphereGeometry(.15,12,8),new THREE.MeshStandardMaterial({color:0x9ffcf0,emissive:0x36ddca,emissiveIntensity:2.1}));beaconLens.position.set(0,2.23,.15);root.add(beaconLens);exteriorParts.push(beaconLens);
  const beaconLight=new THREE.PointLight(0x45e7d6,.85,12);beaconLight.position.copy(beaconLens.position);root.add(beaconLight);exteriorParts.push(beaconLight);
  // Dedicated roof entry hatch: it is a visible aim target, not a pass-through wall.
  const hatchFrameMat = new THREE.MeshStandardMaterial({color:0xe28a46,map:metalTexture,metalness:0.62,roughness:0.34,emissive:0x55220b,emissiveIntensity:0.18});
  const hatchDarkMat = new THREE.MeshStandardMaterial({color:0x071b27,metalness:0.35,roughness:0.74});
  const hatchFrame = new THREE.Mesh(new THREE.TorusGeometry(0.74,0.12,10,36),hatchFrameMat);
  hatchFrame.rotation.x=Math.PI/2; hatchFrame.position.set(0,1.43,0.15); root.add(hatchFrame); exteriorParts.push(hatchFrame);
  const hatchWell = new THREE.Mesh(new THREE.CylinderGeometry(0.63,0.63,0.12,32,1,true),hatchDarkMat);
  hatchWell.position.set(0,1.37,0.15); root.add(hatchWell); exteriorParts.push(hatchWell);
  const hatchApertureMat=new THREE.MeshStandardMaterial({color:0x020910,emissive:0x061c28,emissiveIntensity:.22,roughness:.94,metalness:.08,side:THREE.DoubleSide});
  const hatchAperture=new THREE.Mesh(new THREE.CircleGeometry(.60,32),hatchApertureMat);hatchAperture.rotation.x=-Math.PI/2;hatchAperture.position.set(0,1.505,.15);root.add(hatchAperture);exteriorParts.push(hatchAperture);
  const hatchShaft=new THREE.Mesh(new THREE.CylinderGeometry(.59,.59,.86,32,1,true),hatchDarkMat);hatchShaft.position.set(0,1.04,.15);root.add(hatchShaft);exteriorParts.push(hatchShaft);
  const hatchInnerRing=new THREE.Mesh(new THREE.TorusGeometry(.53,.045,7,28),hatchFrameMat);hatchInnerRing.rotation.x=Math.PI/2;hatchInnerRing.position.set(0,.62,.15);root.add(hatchInnerRing);interiorParts.push(hatchInnerRing);
  const hatchLid = new THREE.Group(); hatchLid.position.set(0.70,1.50,0.15);
  const hatchPlate = new THREE.Mesh(new THREE.CylinderGeometry(0.62,0.62,0.09,32),orangeMat); hatchPlate.position.x=-0.70; hatchLid.add(hatchPlate);
  const hatchHandle = new THREE.Mesh(new THREE.TorusGeometry(0.17,0.04,7,16),hatchFrameMat); hatchHandle.rotation.x=Math.PI/2; hatchHandle.position.set(-0.70,0.055,0); hatchLid.add(hatchHandle);
  hatchLid.rotation.z=0; root.add(hatchLid); exteriorParts.push(hatchLid);
  // Inner liner is only shown while the diver is inside the pod, preserving a solid exterior.
  const innerMat = new THREE.MeshStandardMaterial({color:0x294653,map:metalTexture,bumpMap:metalBumpTexture,bumpScale:0.045,metalness:0.46,roughness:0.72,side:THREE.BackSide});
  const innerTube = new THREE.Mesh(new THREE.CylinderGeometry(1.30,1.36,3.12,24,1,true),innerMat);
  innerTube.rotation.x=Math.PI/2; innerTube.position.z=0.15; root.add(innerTube); interiorParts.push(innerTube);
  const innerNose = new THREE.Mesh(new THREE.SphereGeometry(1.30,24,16,0,Math.PI*2,0,Math.PI/2),innerMat);
  innerNose.position.z=-1.53; innerNose.rotation.x=-Math.PI/2; root.add(innerNose); interiorParts.push(innerNose);
  const innerRibMat = new THREE.MeshStandardMaterial({color:0x6d8990,metalness:0.65,roughness:0.46});
  for (const z of [-0.95,-0.25,0.45,1.15]) {
    const rib=new THREE.Mesh(new THREE.TorusGeometry(1.30,0.035,6,28),innerRibMat); rib.position.z=z; rib.rotation.x=Math.PI/2; root.add(rib); interiorParts.push(rib);
  }
  const ladderMat = new THREE.MeshStandardMaterial({color:0xd58a48,metalness:0.72,roughness:0.35});
  for(let rung=0;rung<5;rung++){const step=new THREE.Mesh(new THREE.BoxGeometry(0.58,0.055,0.08),ladderMat);step.position.set(0,1.10-rung*0.32,0.15);root.add(step);interiorParts.push(step);}

  const consoleMaterial = new THREE.MeshStandardMaterial({color:0x4b3428,emissive:0xc05a22,emissiveIntensity:0.72});
  const console = new THREE.Mesh(new THREE.BoxGeometry(0.62,0.52,0.12),consoleMaterial);
  console.position.set(0,-0.45, 1.65); root.add(console);
  root.userData.consoleMaterial = consoleMaterial;
  interiorParts.push(console);
  root.userData.exteriorParts = exteriorParts;
  root.userData.interiorParts = interiorParts;
  root.userData.hatchLid = hatchLid;
  root.userData.hatchClosedRotation = 0;
  root.userData.hatchOpenUntil = 0;
  const lamp = new THREE.PointLight(0x54e9df,1.35,18); lamp.position.set(0,1.1,0.2); root.add(lamp);
  // The Lifepod includes its own powered fabricator and interior oxygen supply.
  const interiorMetal = new THREE.MeshStandardMaterial({color:0x294653,metalness:0.55,roughness:0.62});
  const interiorGlow = new THREE.MeshStandardMaterial({color:0x6df3e6,emissive:0x1a9e9b,emissiveIntensity:1.4});
  const fab = new THREE.Mesh(new THREE.BoxGeometry(0.72,0.76,0.50),interiorMetal); fab.position.set(0.70,-0.78,-0.28); root.add(fab); interiorParts.push(fab);
  const fabScreen = new THREE.Mesh(new THREE.BoxGeometry(0.48,0.34,0.045),new THREE.MeshStandardMaterial({color:0x0c2633,emissive:0x0e717b,emissiveIntensity:0.9})); fabScreen.position.set(0.70,-0.51,-0.55); root.add(fabScreen); interiorParts.push(fabScreen);
  const fabTrim = new THREE.Mesh(new THREE.BoxGeometry(0.60,0.05,0.06),interiorGlow); fabTrim.position.set(0.70,-0.98,-0.55); root.add(fabTrim); interiorParts.push(fabTrim);
  const oxygenOutlet = new THREE.Mesh(new THREE.CylinderGeometry(0.17,0.17,0.12,12),interiorGlow); oxygenOutlet.rotation.x=Math.PI/2; oxygenOutlet.position.set(0.38,-0.05,1.22); root.add(oxygenOutlet); interiorParts.push(oxygenOutlet);
  const interiorLamp = new THREE.PointLight(0x70e9e0,0.62,7); interiorLamp.position.set(0,0.92,0.15); root.add(interiorLamp); interiorParts.push(interiorLamp);
  // The enlarged cabin adds a visible overhead brace and practical floor grating.
  const braceMat = new THREE.MeshStandardMaterial({color:0x657d82,map:metalTexture,metalness:0.62,roughness:0.54});
  for(const side of [-1,1]){const brace=new THREE.Mesh(new THREE.CylinderGeometry(0.035,0.035,2.35,8),braceMat);brace.position.set(side*0.96,0.1,0.15);brace.rotation.z=side*0.12;root.add(brace);interiorParts.push(brace);}
  const consolePanel=new THREE.Mesh(new THREE.BoxGeometry(0.62,0.08,0.18),interiorGlow);consolePanel.position.set(0,-0.82,1.60);root.add(consolePanel);interiorParts.push(consolePanel);
  // Float at the waterline: the upper shell and hatch stay above the surface, lower hull submerged.
  root.position.set(LIFEPOD_POSITION.x,LIFEPOD_POSITION.y,LIFEPOD_POSITION.z);
  root.scale.setScalar(LIFEPOD_SCALE);
  root.rotation.y = 0.18;
  root.userData.isLifepod = true;
  root.updateMatrixWorld(true);
  const lifepodBounds=new THREE.Box3().setFromObject(root);
  const lifepodSize=new THREE.Vector3();lifepodBounds.getSize(lifepodSize);
  root.userData.dimensions={width:lifepodSize.x,height:lifepodSize.y,length:lifepodSize.z};
  scene.add(root);
  lifepodGroup = root;
  root.userData.collisionRadius = 1.56;
  root.userData.collisionLength = 3.4;
  updateLifepodInteriorVisibility();
  return root;
}

function createIntroCapsule() {
  const pod = new THREE.Group();
  const shell = new THREE.MeshStandardMaterial({color:0xe4e3d7,map:metalTexture,bumpMap:metalBumpTexture,bumpScale:0.08,roughness:0.7,metalness:0.22});
  const orange = new THREE.MeshStandardMaterial({color:0xe18a43,map:metalTexture,roughness:0.55,metalness:0.22,emissive:0x7b2d0a,emissiveIntensity:0.18});
  const glass = new THREE.MeshStandardMaterial({color:0x8fe8eb,roughness:0.16,metalness:0.16,transparent:true,opacity:0.7});
  const body = new THREE.Mesh(new THREE.CylinderGeometry(1.45,1.55,3.6,32,3),shell); body.rotation.x=Math.PI/2; pod.add(body);
  const front = new THREE.Mesh(new THREE.SphereGeometry(1.46,24,16,0,Math.PI*2,0,Math.PI/2),shell); front.position.z=-1.75; front.rotation.x=-Math.PI/2; pod.add(front);
  const rim = new THREE.Mesh(new THREE.TorusGeometry(1.48,0.12,10,36),orange); rim.rotation.x=Math.PI/2; rim.position.z=0.95; pod.add(rim);
  for(const z of [-0.95,-0.05,0.82]){const rib=new THREE.Mesh(new THREE.TorusGeometry(1.47,0.045,6,32),shell);rib.rotation.x=Math.PI/2;rib.position.z=z;pod.add(rib);}
  const port = new THREE.Mesh(new THREE.CircleGeometry(0.58,24),glass); port.position.z=-1.35; pod.add(port);
  const portRim=new THREE.Mesh(new THREE.TorusGeometry(0.60,0.075,8,28),orange);portRim.rotation.x=Math.PI/2;portRim.position.z=-1.34;pod.add(portRim);
  const hatchFrame=new THREE.Mesh(new THREE.TorusGeometry(0.39,0.07,8,28),orange);hatchFrame.rotation.x=Math.PI/2;hatchFrame.position.set(0,1.36,0.18);pod.add(hatchFrame);
  const hatchCap=new THREE.Mesh(new THREE.CylinderGeometry(0.33,0.33,0.08,24),shell);hatchCap.position.set(0,1.38,0.18);pod.add(hatchCap);
  const nozzle = new THREE.Mesh(new THREE.ConeGeometry(0.86,1.5,16),orange); nozzle.rotation.x=-Math.PI/2; nozzle.position.z=2.3; pod.add(nozzle);
  const engineRing=new THREE.Mesh(new THREE.TorusGeometry(0.68,0.085,8,28),shell);engineRing.rotation.x=Math.PI/2;engineRing.position.z=2.72;pod.add(engineRing);
  const thruster=new THREE.Mesh(new THREE.CylinderGeometry(0.42,0.52,0.11,20),new THREE.MeshStandardMaterial({color:0x172b35,emissive:0x6b411d,emissiveIntensity:0.28,metalness:0.68,roughness:0.4}));thruster.rotation.x=Math.PI/2;thruster.position.z=2.78;pod.add(thruster);
  const glow = new THREE.PointLight(0xffa45e,1.8,18); glow.position.z=2.2; pod.add(glow);
  return pod;
}

function createIntroPlanetTexture(baseColor, landColor, seed=1) {
  const canvas=document.createElement('canvas');canvas.width=768;canvas.height=384;
  const ctx=canvas.getContext('2d');
  const gradient=ctx.createLinearGradient(0,0,0,384);
  gradient.addColorStop(0,'#071b43');gradient.addColorStop(.48,baseColor);gradient.addColorStop(1,'#020b20');
  ctx.fillStyle=gradient;ctx.fillRect(0,0,768,384);
  // Procedural continents / mineral bands: original art, deterministic for each planet.
  for(let i=0;i<38;i++){
    const x=((Math.sin(seed*13+i*17)*.5+.5)*768),y=((Math.cos(seed*7+i*11)*.5+.5)*384);
    const w=18+((Math.sin(i*3.4+seed)*.5+.5)*88),h=8+((Math.cos(i*2.2+seed)*.5+.5)*36);
    ctx.save();ctx.translate(x,y);ctx.rotate(Math.sin(i+seed)*.8);
    ctx.fillStyle=i%3===0?'rgba(180,210,166,.58)':landColor;
    ctx.beginPath();ctx.ellipse(0,0,w,h,0,0,Math.PI*2);ctx.fill();
    ctx.strokeStyle='rgba(224,245,224,.16)';ctx.lineWidth=3;ctx.stroke();ctx.restore();
  }
  for(let i=0;i<18;i++){
    const x=((Math.sin(i*12.3+seed)*.5+.5)*768),y=((Math.cos(i*5.1+seed)*.5+.5)*384);
    ctx.fillStyle='rgba(220,246,255,.12)';ctx.beginPath();ctx.ellipse(x,y,20+i%7*6,3+i%5*2,0,0,Math.PI*2);ctx.fill();
  }
  const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;texture.anisotropy=Math.min(8,renderer?.capabilities?.getMaxAnisotropy?.()||1);texture.needsUpdate=true;
  return texture;
}

function createIntroPlanet(group,{name,position,radius,baseColor,landColor,seed}) {
  const texture=createIntroPlanetTexture(baseColor,landColor,seed);
  const material=new THREE.MeshStandardMaterial({map:texture,roughness:.94,metalness:.02});
  const planet=new THREE.Mesh(new THREE.SphereGeometry(radius,48,32),material);planet.position.set(...position);group.add(planet);
  const atmosphere=new THREE.Mesh(new THREE.SphereGeometry(radius*1.055,40,28),new THREE.MeshBasicMaterial({color:name==='8142C'?0x50cbd5:0x5b9fff,transparent:true,opacity:.14,side:THREE.BackSide,depthWrite:false}));
  atmosphere.position.copy(planet.position);group.add(atmosphere);
  return {planet,atmosphere,texture,name};
}

function createTransferCraft() {
  const craft=new THREE.Group();
  const hull=new THREE.MeshStandardMaterial({color:0x738d9a,map:metalTexture,metalness:.72,roughness:.48});
  const white=new THREE.MeshStandardMaterial({color:0xe0e8e5,map:metalTexture,metalness:.28,roughness:.58});
  const glow=new THREE.MeshStandardMaterial({color:0x9cf8f0,emissive:0x3ddacb,emissiveIntensity:2.1});
  const core=new THREE.Mesh(new THREE.CapsuleGeometry(1.35,7.5,5,12),white);core.rotation.x=Math.PI/2;craft.add(core);
  const bridge=new THREE.Mesh(new THREE.BoxGeometry(3.3,1.5,3.8),hull);bridge.position.set(0,1.25,-1.4);craft.add(bridge);
  for(const side of [-1,1]){
    const wing=new THREE.Mesh(new THREE.BoxGeometry(8,.26,2.2),hull);wing.position.set(side*4.2,-.25,1.3);wing.rotation.z=side*.08;craft.add(wing);
    const engine=new THREE.Mesh(new THREE.CylinderGeometry(.48,.62,1.25,16),glow);engine.rotation.x=Math.PI/2;engine.position.set(side*4.9,-.05,4.9);craft.add(engine);
    const light=new THREE.PointLight(0x52dfec,.65,12);light.position.copy(engine.position);craft.add(light);
  }
  const nose=new THREE.Mesh(new THREE.ConeGeometry(1.45,4.4,12),hull);nose.rotation.x=-Math.PI/2;nose.position.z=-6.2;craft.add(nose);
  craft.scale.setScalar(.72);return craft;
}

function createIntroSet() {
  const group = new THREE.Group();
  const metal = new THREE.MeshStandardMaterial({color:0x476b77,map:metalTexture,bumpMap:metalBumpTexture,bumpScale:0.1,metalness:0.58,roughness:0.62});
  const pale = new THREE.MeshStandardMaterial({color:0xd5e5df,map:metalTexture,bumpMap:metalBumpTexture,bumpScale:0.05,metalness:0.22,roughness:0.72});
  const glass = new THREE.MeshPhysicalMaterial({color:0x67c8d0,roughness:0.12,metalness:0.1,transparent:true,opacity:0.36,transmission:0.18});
  const amber = new THREE.MeshStandardMaterial({color:0xf18c4b,emissive:0x9a3c16,emissiveIntensity:0.7});
  const earth=createIntroPlanet(group,{name:'Bumi',position:[-34,19,-88],radius:12.5,baseColor:'#236caa',landColor:'rgba(68,145,91,.86)',seed:71});
  const targetPlanet=createIntroPlanet(group,{name:'8142C',position:[39,22,-120],radius:18,baseColor:'#147e91',landColor:'rgba(160,154,103,.88)',seed:8142});
  const starsGeometry=new THREE.BufferGeometry();const starPositions=[];
  for(let i=0;i<460;i++){const a=hash2(i,19)*Math.PI*2,b=hash2(i+23,91)*Math.PI,r=260+hash2(i+61,7)*80;starPositions.push(Math.cos(a)*Math.sin(b)*r,Math.cos(b)*r,Math.sin(a)*Math.sin(b)*r-75);}
  starsGeometry.setAttribute('position',new THREE.Float32BufferAttribute(starPositions,3));
  const stars=new THREE.Points(starsGeometry,new THREE.PointsMaterial({color:0xd7f5ff,size:.72,sizeAttenuation:true,transparent:true,opacity:.85}));group.add(stars);
  const transport=createTransferCraft();transport.position.set(-24,19,-77);transport.rotation.set(.02,-.38,-.04);group.add(transport);
  const base = new THREE.Group();
  base.position.set(LIFEPOD_POSITION.x,3,LIFEPOD_POSITION.z);
  const platform = new THREE.Mesh(new THREE.CylinderGeometry(17,18,2.1,32),metal); platform.position.y=-1; base.add(platform);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(16.5,0.35,10,48),amber); ring.rotation.x=Math.PI/2; ring.position.y=0.2; base.add(ring);
  const hub = new THREE.Mesh(new THREE.CylinderGeometry(5.8,7.2,6.4,20),pale); hub.position.y=3.3; base.add(hub);
  const dome = new THREE.Mesh(new THREE.SphereGeometry(6.0,20,12,0,Math.PI*2,0,Math.PI/2),glass); dome.position.y=6.4; base.add(dome);
  const antenna = new THREE.Mesh(new THREE.CylinderGeometry(0.16,0.24,12,8),metal); antenna.position.set(0,12,0); base.add(antenna);
  for(let i=0;i<6;i++){
    const a=i*Math.PI/3; const tower=new THREE.Group();
    const leg=new THREE.Mesh(new THREE.CylinderGeometry(0.65,1.0,8,8),pale); leg.position.y=1.2; tower.add(leg);
    const windowBand=new THREE.Mesh(new THREE.BoxGeometry(2.2,1.1,1.0),glass); windowBand.position.y=2.4; tower.add(windowBand);
    tower.position.set(Math.cos(a)*11,0,Math.sin(a)*11); base.add(tower);
    const lamp=new THREE.PointLight(0x72eee1,1.8,18); lamp.position.set(Math.cos(a)*11,3,Math.sin(a)*11); base.add(lamp);
  }
  group.add(base);
  // Original abyssal leviathan: brighter silhouette, readable jaw, dorsal crest,
  // segmented bioluminescent markings, and animated tail/fins make it visible in the intro.
  const attacker = new THREE.Group();
  const shadowMat = new THREE.MeshStandardMaterial({color:0x294957,roughness:0.34,metalness:0.2,emissive:0x0d3845,emissiveIntensity:0.72});
  const ridgeMat = new THREE.MeshStandardMaterial({color:0x426f78,roughness:0.42,metalness:0.26,emissive:0x0a3841,emissiveIntensity:0.42});
  const glowMat = new THREE.MeshStandardMaterial({color:0x9af5e6,emissive:0x39d7c6,emissiveIntensity:2.8,roughness:0.22,metalness:0.08});
  const mouthMat = new THREE.MeshStandardMaterial({color:0x071923,roughness:0.92,metalness:0.02});
  const toothMat = new THREE.MeshStandardMaterial({color:0xd2e3d9,roughness:0.28,metalness:0.18,emissive:0x34514b,emissiveIntensity:0.15});
  const body = new THREE.Mesh(new THREE.SphereGeometry(1,32,20),shadowMat);
  body.scale.set(6.8,3.1,10.5); attacker.add(body);
  const head = new THREE.Mesh(new THREE.SphereGeometry(1,28,18),ridgeMat);
  head.scale.set(3.7,2.15,4.0);head.position.set(0,-0.05,-7.0);attacker.add(head);
  const upperMouth = new THREE.Mesh(new THREE.SphereGeometry(1,20,12),mouthMat);
  upperMouth.scale.set(2.85,.76,2.0);upperMouth.position.set(0,-.92,-9.15);attacker.add(upperMouth);
  const lowerJaw = new THREE.Group();
  const jawBase = new THREE.Mesh(new THREE.SphereGeometry(1,20,12),ridgeMat);
  jawBase.scale.set(2.8,.66,2.0);jawBase.position.set(0,-1.56,-8.95);lowerJaw.add(jawBase);
  const jawGlow = new THREE.Mesh(new THREE.TorusGeometry(2.35,.075,7,28,Math.PI),glowMat);
  jawGlow.scale.set(1,.8,1);jawGlow.position.set(0,-1.16,-9.35);jawGlow.rotation.x=Math.PI;lowerJaw.add(jawGlow);
  attacker.add(lowerJaw);
  // Visible upper/lower teeth establish the creature's silhouette even at cinematic distance.
  for(let tooth=0;tooth<9;tooth++){
    const x=-2.15+tooth*.54;
    const upperTooth=new THREE.Mesh(new THREE.ConeGeometry(.17,.72,6),toothMat);
    upperTooth.position.set(x,-1.24,-10.2);upperTooth.rotation.x=Math.PI;attacker.add(upperTooth);
    const lowerTooth=new THREE.Mesh(new THREE.ConeGeometry(.15,.62,6),toothMat);
    lowerTooth.position.set(x,-1.15,-9.95);attacker.add(lowerTooth);
  }
  const eyeSockets=[];
  const pectoralFins=[];
  for(const side of [-1,1]){
    const socket=new THREE.Mesh(new THREE.SphereGeometry(.62,14,10),mouthMat);socket.position.set(side*2.55,.8,-8.35);attacker.add(socket);
    const eye=new THREE.Mesh(new THREE.SphereGeometry(.43,16,12),glowMat);eye.position.set(side*2.62,.88,-8.62);attacker.add(eye);eyeSockets.push(eye);
    const pectoral=new THREE.Mesh(new THREE.ConeGeometry(1.5,7.5,8),shadowMat);pectoral.position.set(side*5.4,-.65,-2.5);pectoral.rotation.z=side*1.0;pectoral.rotation.x=-.18;attacker.add(pectoral);pectoralFins.push(pectoral);
  }
  const dorsalFins=[];
  for(let i=0;i<5;i++){
    const fin=new THREE.Mesh(new THREE.ConeGeometry(.72,3.3+(i%2)*.7,7),ridgeMat);
    fin.position.set(0,2.6, -4.2+i*3.0);fin.rotation.x=Math.PI/2;attacker.add(fin);dorsalFins.push(fin);
    const beacon=new THREE.Mesh(new THREE.SphereGeometry(.13,8,6),glowMat);beacon.position.set(0,3.92,-4.2+i*3.0);attacker.add(beacon);
  }
  const tail = new THREE.Group();
  tail.position.set(0,0,8.2);
  const tailStem=new THREE.Mesh(new THREE.ConeGeometry(1.45,5.2,10),ridgeMat);tailStem.rotation.x=-Math.PI/2;tailStem.position.z=2.4;tail.add(tailStem);
  for(const side of [-1,1]){const lobe=new THREE.Mesh(new THREE.ConeGeometry(1.25,4.5,8),shadowMat);lobe.position.set(side*1.05,0,4.4);lobe.rotation.z=side*.52;tail.add(lobe);}
  attacker.add(tail);
  // Bioluminescent lateral bands and gill slits break up the dark body mass.
  for(const side of [-1,1]){
    for(let i=0;i<7;i++){
      const marker=new THREE.Mesh(new THREE.SphereGeometry(.105+(i%2)*.035,8,6),glowMat);
      marker.position.set(side*(5.55-i*.12),.55-Math.sin(i*.42)*.2,-5.7+i*2.0);attacker.add(marker);
    }
    for(let i=0;i<4;i++){
      const gill=new THREE.Mesh(new THREE.CapsuleGeometry(.07,.72,3,6),ridgeMat);
      gill.position.set(side*5.45,.05,-3.0+i*.62);gill.rotation.z=side*.16;attacker.add(gill);
    }
  }
  for(let i=0;i<6;i++){
    const tendril=new THREE.Mesh(new THREE.CylinderGeometry(.13,.035,7.2,8),shadowMat);
    tendril.position.set(Math.cos(i*Math.PI/3)*4.15,-2.65,Math.sin(i*Math.PI/3)*5.1);
    tendril.rotation.z=Math.cos(i*Math.PI/3)*.6;tendril.rotation.x=Math.sin(i*Math.PI/3)*.5;attacker.add(tendril);
  }
  const creatureGlow=new THREE.PointLight(0x43d9d0,4.4,48);creatureGlow.position.set(0,.3,-8);attacker.add(creatureGlow);
  attacker.userData.tail=tail;attacker.userData.lowerJaw=lowerJaw;attacker.userData.dorsalFins=dorsalFins;attacker.userData.pectoralFins=pectoralFins;attacker.userData.eyeSockets=eyeSockets;attacker.userData.creatureGlow=creatureGlow;attacker.userData.glowMaterial=glowMat;
  attacker.scale.setScalar(1.34);
  attacker.position.set(28,0,LIFEPOD_POSITION.z-2); attacker.visible=true; group.add(attacker);
  const pod = createIntroCapsule(); pod.position.set(-22,16,-69); pod.rotation.set(0.05,0.3,-0.04); group.add(pod);
  const reentryFlame=new THREE.Mesh(new THREE.ConeGeometry(.66,3.3,14),new THREE.MeshBasicMaterial({color:0xff8b32,transparent:true,opacity:.9,blending:THREE.AdditiveBlending,depthWrite:false}));
  reentryFlame.rotation.x=Math.PI/2;reentryFlame.position.set(0,0,3.1);reentryFlame.visible=false;pod.add(reentryFlame);
  const reentryCore=new THREE.Mesh(new THREE.ConeGeometry(.30,2.25,12),new THREE.MeshBasicMaterial({color:0xffe9a0,transparent:true,opacity:.95,blending:THREE.AdditiveBlending,depthWrite:false}));
  reentryCore.rotation.x=Math.PI/2;reentryCore.position.set(0,0,3.55);reentryCore.visible=false;pod.add(reentryCore);
  const reentryLight=new THREE.PointLight(0xff7a35,0,24);reentryLight.position.set(0,0,2.75);pod.add(reentryLight);
  const splashRingMat=new THREE.MeshBasicMaterial({color:0x8deaff,transparent:true,opacity:0,wireframe:true,depthWrite:false});
  const splashRing=new THREE.Mesh(new THREE.TorusGeometry(1.0,.10,8,48),splashRingMat);splashRing.rotation.x=Math.PI/2;splashRing.position.set(LIFEPOD_POSITION.x,.04,LIFEPOD_POSITION.z);splashRing.visible=false;group.add(splashRing);
  const splashPositions=[];for(let i=0;i<36;i++){const a=i/36*Math.PI*2,r=1.2+hash2(i,8142)*1.8;splashPositions.push(Math.cos(a)*r,.15+hash2(i+7,22)*1.1,Math.sin(a)*r);}
  const splashGeometry=new THREE.BufferGeometry();splashGeometry.setAttribute('position',new THREE.Float32BufferAttribute(splashPositions,3));
  const splashMaterial=new THREE.PointsMaterial({color:0xc6f7ff,size:.34,transparent:true,opacity:0,depthWrite:false,sizeAttenuation:true});
  const splashParticles=new THREE.Points(splashGeometry,splashMaterial);splashParticles.position.set(LIFEPOD_POSITION.x,.05,LIFEPOD_POSITION.z);splashParticles.visible=false;group.add(splashParticles);
  scene.add(group);
  return {group,base,attacker,pod,transport,earth,targetPlanet,stars,ownedTextures:[earth.texture,targetPlanet.texture],reentryFlame,reentryCore,reentryLight,splashRing,splashRingMat,splashParticles,splashMaterial,lights:base.children.filter(child=>child.isPointLight)};
}

function setCinematicLine(index) {
  const lines = [
    ['MISSION CONTROL','Bumi mengirim ekspedisi penelitian menuju planet samudra 8142C. Transfer antarbintang dimulai.'],
    ['NAVIGATION SYSTEM','Kapal transfer meninggalkan orbit Bumi. 8142C terkonfirmasi sebagai tujuan ekspedisi.'],
    ['DESCENT CONTROL','Memasuki atmosfer 8142C. Kapsul evakuasi dilepas menuju permukaan samudra.'],
    ['EMERGENCY SYSTEM','Perisai kapsul memanas saat re-entry. Pertahankan jalur turun dan siapkan pendaratan.'],
    ['BIOLOGICAL ALERT','Sinyal organisme raksasa terdeteksi di dekat stasiun penelitian. Jarak semakin dekat.'],
    ['ABYSSAL GUIDANCE','Kapsul mencapai laut 8142C. Pulihkan sistem Lifepod, cari oksigen, dan bertahan hidup.']
  ];
  const line=lines[index]; if(!line) return;
  $('cinematic-speaker').textContent=line[0]; $('cinematic-line').textContent=line[1];
  $('radio-subtitle')?.classList.add('hidden');
  clearTimeout(radioHideTimer);
}

function startIntroCinematic({ replayOnly = false } = {}) {
  if ((!replayOnly && storyState.introSeen) || introSequence.active) return;
  cancelPendingKnifeAttack();
  const set=createIntroSet();
  const originalCameraFov = Number.isFinite(camera?.fov) ? camera.fov : settings.fov;
  introSequence={active:true,elapsed:0,...set,baseFov:originalCameraFov,cameraLookAt:null,podReleased:false,podReleasePosition:null,splashSfxPlayed:false,debrisSpawned:false,lineIndex:-1,reentrySfxPlayed:false,roarPlayed:false,replayOnly};
  $('cinematic-overlay')?.classList.remove('hidden');
  $('radio-subtitle')?.classList.add('hidden');
  $('hud')?.classList.add('hidden');
  camera.position.set(-10,29,-46); camera.lookAt(-34,19,-88);
  camera.fov=54;camera.updateProjectionMatrix();
  updateMissionUI();
  setCinematicLine(0); introSequence.lineIndex=0;
}

function makeIntroDebris(position, count=22) {
  const geometry=new THREE.IcosahedronGeometry(0.26,0);
  introDebrisResources.push(geometry);
  for(let i=0;i<count;i++){
    const material=new THREE.MeshStandardMaterial({color:0x9b8170,roughness:0.82,metalness:0.28,emissive:0x6c321a,emissiveIntensity:0.18});
    introDebrisResources.push(material);
    const mesh=new THREE.Mesh(geometry,material);
    mesh.position.copy(position).add(new THREE.Vector3((Math.random()-0.5)*10,(Math.random()-0.5)*7,(Math.random()-0.5)*10));
    const velocity=new THREE.Vector3((Math.random()-0.5)*11,Math.random()*8+2,(Math.random()-0.5)*10);
    scene.add(mesh); introDebris.push({mesh,velocity,age:0});
  }
}

function disposeIntroSet() {
  if(introSequence.group){
    scene.remove(introSequence.group);
    introSequence.group.traverse(object=>{
      if(object.geometry){object.geometry.dispose(); if(Array.isArray(object.material)) object.material.forEach(material=>material?.dispose()); else object.material?.dispose();}
    });
  }
  for(const texture of introSequence.ownedTextures||[])texture?.dispose?.();
  for(const item of introDebris)scene.remove(item.mesh);
  introDebris=[];
  for(const resource of introDebrisResources)resource.dispose();
  introDebrisResources=[];
  introSequence={active:false,elapsed:0,group:null,base:null,attacker:null,pod:null,transport:null,earth:null,targetPlanet:null,stars:null,ownedTextures:[],lights:[],splashRing:null,splashParticles:null,podReleased:false,podReleasePosition:null,debrisSpawned:false,lineIndex:-1,baseFov:null,cameraLookAt:null};
  try{window.speechSynthesis?.cancel();}catch{}
}

function finishIntroCinematic() {
  if(!introSequence.active) return;
  const replayOnly=Boolean(introSequence.replayOnly);
  const restoreFov=Number.isFinite(introSequence.baseFov)?introSequence.baseFov:settings.fov;
  disposeIntroSet();
  if(camera){camera.fov=restoreFov;camera.updateProjectionMatrix();}
  $('cinematic-overlay')?.classList.add('hidden');
  $('radio-subtitle')?.classList.add('hidden');
  $('hud')?.classList.remove('hidden');
  if(replayOnly){
    updateCamera(0.016);updateHud();updateSurvivalHud();updateInteractionPrompt();
    showToast('Cutscene selesai. Ekspedisi dilanjutkan dari posisi tersimpan.');
    return;
  }
  storyState.introSeen=true;
  storyState.missionIndex=0;
  storyState.counters={materials:0};
  storyState.completed=[];
  player.position.set(0,-6.8,-1.5); player.velocity.set(0,0,0); player.yaw=0; player.pitch=0.34;
  makeLifePod();
  updateMissionUI(); updateCamera(0.016); updateHud();
  speakRadio('ABYSSAL GUIDANCE','Lifepod terdeteksi di depanmu. Dekati kapsul dan aktifkan konsol darurat.');
  markUnsaved();
}

// Cancelling a cinematic (for example, returning to the main menu mid-scene)
// releases temporary geometry and restores the user's first-person FOV without
// marking the intro as seen or changing any story/save data.
function cancelIntroCinematic() {
  if(!introSequence.active) return false;
  const restoreFov=Number.isFinite(introSequence.baseFov)?introSequence.baseFov:settings.fov;
  disposeIntroSet();
  if(camera){camera.fov=restoreFov;camera.updateProjectionMatrix();}
  $('cinematic-overlay')?.classList.add('hidden');
  $('radio-subtitle')?.classList.add('hidden');
  return true;
}

function updateCinematic(dt) {
  introSequence.elapsed+=dt;
  const t=introSequence.elapsed;
  const nextLine=getIntroSubtitleIndex(t);
  if(nextLine>introSequence.lineIndex){introSequence.lineIndex=nextLine;setCinematicLine(nextLine);}
  if(introSequence.earth?.planet)introSequence.earth.planet.rotation.y+=dt*.018;
  if(introSequence.targetPlanet?.planet)introSequence.targetPlanet.planet.rotation.y+=dt*.012;
  if(introSequence.stars)introSequence.stars.rotation.y+=dt*.0018;
  if(introSequence.transport){
    const transfer=smoothstep(3.8,14.5,t);
    introSequence.transport.position.set(lerp(-24,17,transfer),lerp(19,28,transfer)+Math.sin(t*1.4)*.18,lerp(-77,-111,transfer));
    introSequence.transport.rotation.set(Math.sin(t*.65)*.025,lerp(-.38,.12,transfer),Math.sin(t*.8)*.035);
  }
  const descent=smoothstep(9.3,19.0,t);
  const attachOffset=new THREE.Vector3(2,-3,8);
  const podEnd=new THREE.Vector3(LIFEPOD_POSITION.x,LIFEPOD_POSITION.y,LIFEPOD_POSITION.z);
  if(t<9.3){
    const craftPosition=introSequence.transport?.position||new THREE.Vector3(-24,19,-77);
    introSequence.pod.position.copy(craftPosition).add(attachOffset);
    introSequence.podReleased=false;
    introSequence.podReleasePosition=introSequence.pod.position.clone();
  }else{
    if(!introSequence.podReleased){
      introSequence.podReleasePosition=introSequence.pod.position.clone();
      introSequence.podReleased=true;
    }
    const start=introSequence.podReleasePosition||new THREE.Vector3(-2,22,-86);
    const arc=descent;
    introSequence.pod.position.set(
      lerp(start.x,podEnd.x,arc)+Math.sin(arc*Math.PI)*1.2,
      lerp(start.y,podEnd.y,arc)+Math.sin(arc*Math.PI)*5.5,
      lerp(start.z,podEnd.z,arc)
    );
  }
  const cinematicFx=getIntroCinematicEffects(t);
  introSequence.pod.rotation.set(Math.sin(t*1.9)*.08 + cinematicFx.impactRoll,.3+Math.sin(t*.85)*.10,Math.sin(t*1.25)*.10 + cinematicFx.impactRoll*.62);
  const splashProgress=smoothstep(18.1,21.0,t);
  if(introSequence.splashRing&&introSequence.splashParticles){
    const visible=t>=18.1&&t<24.0;introSequence.splashRing.visible=visible;introSequence.splashParticles.visible=visible;
    const expansion=.12+splashProgress*4.1;introSequence.splashRing.scale.setScalar(expansion);introSequence.splashRingMat.opacity=visible?(1-smoothstep(20.0,24.0,t))*.72:0;
    introSequence.splashParticles.scale.setScalar(.3+splashProgress*2.8);introSequence.splashMaterial.opacity=visible?(1-smoothstep(20.2,24.0,t))*.82:0;
    if(visible){const attr=introSequence.splashParticles.geometry.getAttribute('position');for(let i=0;i<attr.count;i++)attr.setY(i,attr.getY(i)+dt*(.55+(i%5)*.09));attr.needsUpdate=true;}
  }
  if(t>18.8&&!introSequence.splashSfxPlayed){introSequence.splashSfxPlayed=true;playSfx('splash');}
  
  const reentry=t>12.5&&t<20.0;
  if(introSequence.reentryFlame){introSequence.reentryFlame.visible=reentry;introSequence.reentryCore.visible=reentry;introSequence.reentryLight.intensity=reentry?2.2+Math.sin(t*18)*.45:0;}
  if(t>15.2&&!introSequence.reentrySfxPlayed){introSequence.reentrySfxPlayed=true;playSfx('reentry');}
  const attackProgress=smoothstep(15.5,25.0,t);
  introSequence.attacker.position.set(lerp(28,7.5,attackProgress),Math.sin(t*1.7)*.62,lerp(LIFEPOD_POSITION.z-2,LIFEPOD_POSITION.z-4.5,attackProgress));
  introSequence.attacker.rotation.y=Math.sin(t*.75)*.12;
  introSequence.attacker.rotation.x=Math.sin(t*.62)*.022;
  introSequence.attacker.rotation.z=Math.sin(t*1.1)*.045;
  if(introSequence.attacker.userData.tail)introSequence.attacker.userData.tail.rotation.y=Math.sin(t*2.4)*.34;
  if(introSequence.attacker.userData.lowerJaw)introSequence.attacker.userData.lowerJaw.rotation.x=.04+Math.max(0,Math.sin(t*2.1))*.12;
  (introSequence.attacker.userData.dorsalFins||[]).forEach((fin,index)=>{fin.rotation.z=Math.sin(t*1.6+index*.55)*.07;});
  (introSequence.attacker.userData.pectoralFins||[]).forEach((fin,index)=>{const side=index===0?-1:1;fin.rotation.z=side*(1.0+Math.sin(t*2.0+index*.4)*.13);fin.rotation.x=-.18+Math.sin(t*1.7+index*.5)*.07;});
  (introSequence.attacker.userData.eyeSockets||[]).forEach((eye,index)=>{const pulse=1+Math.sin(t*2.8+index*.7)*.07;eye.scale.setScalar(pulse);});
  if(introSequence.attacker.userData.creatureGlow)introSequence.attacker.userData.creatureGlow.intensity=3.7+Math.sin(t*2.2)*.65+cinematicFx.revealPulse*1.05;
  if(introSequence.attacker.userData.glowMaterial)introSequence.attacker.userData.glowMaterial.emissiveIntensity=2.45+Math.sin(t*2.5)*.45+cinematicFx.revealPulse*.52;
  if(t>20.7&&!introSequence.roarPlayed){introSequence.roarPlayed=true;playSfx('roar');}
  if(t>22.0&&!introSequence.debrisSpawned){
    introSequence.debrisSpawned=true;
    makeIntroDebris(new THREE.Vector3(LIFEPOD_POSITION.x-1,5,LIFEPOD_POSITION.z),34);
    playSfx('impact');
  }
  if(t>22.0){
    const flash=0.5+Math.sin(t*17)*0.5;
    introSequence.lights.forEach(light=>{light.intensity=0.35+flash*2.2;});
    introSequence.base.rotation.z=Math.sin((t-22)*1.1)*Math.min(0.18,(t-22)*0.025);
  }
  for(let i=introDebris.length-1;i>=0;i--){
    const item=introDebris[i];item.age+=dt;item.velocity.y=integrateGroundGravity(item.velocity.y,dt,18);item.velocity.multiplyScalar(Math.exp(-0.72*dt));item.mesh.position.addScaledVector(item.velocity,dt);item.mesh.rotation.x+=dt*1.7;item.mesh.rotation.z+=dt*1.3;
    if(item.mesh.position.y<heightAt(item.mesh.position.x,item.mesh.position.z)+0.16){item.mesh.position.y=heightAt(item.mesh.position.x,item.mesh.position.z)+0.16;item.velocity.set(0,0,0);item.mesh.rotation.x*=0.88;item.mesh.rotation.z*=0.88;}
    if(item.age>3.2){scene.remove(item.mesh);introDebris.splice(i,1);}
  }
  const shot=getIntroCameraShot(t);
  const focusPosition={
    earth:introSequence.earth?.planet?.position,
    transport:introSequence.transport?.position,
    pod:introSequence.pod?.position,
    attacker:introSequence.attacker?.position
  }[shot.focus] || introSequence.pod?.position || new THREE.Vector3();
  const cameraOffset=new THREE.Vector3(...shot.cameraOffset);
  const targetOffset=new THREE.Vector3(...shot.targetOffset);
  const desiredCamera=focusPosition.clone().add(cameraOffset);
  if (cinematicFx.cameraShake > 0.001) {
    desiredCamera.x += Math.sin(t * 31.0) * cinematicFx.cameraShake;
    desiredCamera.y += Math.cos(t * 24.0) * cinematicFx.cameraShake * 0.62;
    desiredCamera.z += Math.sin(t * 19.0 + 0.8) * cinematicFx.cameraShake * 0.48;
  }
  const desiredLookAt=focusPosition.clone().add(targetOffset);
  const cameraBlend=1-Math.exp(-dt*shot.follow);
  camera.position.lerp(desiredCamera,cameraBlend);
  if(!introSequence.cameraLookAt)introSequence.cameraLookAt=desiredLookAt.clone();
  else introSequence.cameraLookAt.lerp(desiredLookAt,1-Math.exp(-dt*(shot.follow+0.45)));
  camera.lookAt(introSequence.cameraLookAt);
  cinematicBaseQuaternion.copy(camera.quaternion);
  cameraRollQuaternion.setFromAxisAngle(cameraRollAxis, Number.isFinite(shot.roll) ? shot.roll : 0);
  camera.quaternion.copy(cinematicBaseQuaternion).multiply(cameraRollQuaternion);
  const nextFov=(Number.isFinite(shot.fov)?shot.fov:(introSequence.baseFov||settings.fov)) + cinematicFx.fovPunch;
  const blendedFov=THREE.MathUtils.damp(camera.fov,nextFov,1.9,dt);
  if(Math.abs(blendedFov-camera.fov)>.01){camera.fov=blendedFov;camera.updateProjectionMatrix();}
  if(t>=INTRO_CINEMATIC_DURATION) finishIntroCinematic();
}

function createDropMaterial(type) {
  if(dropMaterials.has(type)) return dropMaterials.get(type);
  const colors={titanium:0xb5c4c7,copper:0xc47b4b,quartz:0xc9ffff,kelp:0x57c99a,coral:0xe38bb8,lithium:0xb9a9ed,sulfur:0xf1d36b,magnetite:0x607f9b,salt:0xecf7ee,glowcap:0x8df1dc,fish_meat:0xe7a27f};
  const color=colors[type]||0x9fc5c4;
  const material=new THREE.MeshStandardMaterial({color,map:type==='kelp'?kelpTexture:type==='coral'||type==='glowcap'?coralTexture:rockTexture,roughness:0.48,metalness:['titanium','copper','magnetite'].includes(type)?0.42:0.08,emissive:color,emissiveIntensity:type==='quartz'||type==='glowcap'?0.22:0.035});
  dropMaterials.set(type,material);return material;
}

function disposeWorldDrop(drop) {
  if (!drop?.mesh) return;
  scene?.remove(drop.mesh);
  disposeObjectTree(drop.mesh, {
    geometries: dropGeometry ? [dropGeometry] : [],
    materials: dropMaterials.has(drop.type) ? [dropMaterials.get(drop.type)] : []
  });
}

function spawnWorldDrop(type, position, amount=1) {
  for(let i=0;i<clamp(amount,1,4);i++){
    const mesh=new THREE.Group();
    if(type==='glowcap'){
      const stem=new THREE.Mesh(new THREE.CylinderGeometry(0.09,0.12,0.38,7),new THREE.MeshStandardMaterial({color:0xd7c9a6,roughness:0.9}));stem.position.y=0.1;mesh.add(stem);
      const cap=new THREE.Mesh(new THREE.SphereGeometry(0.28,9,7,0,Math.PI*2,0,Math.PI*0.58),createDropMaterial(type));cap.scale.y=0.78;cap.position.y=0.28;mesh.add(cap);
    } else {
      const geo=dropGeometry || (dropGeometry=new THREE.IcosahedronGeometry(0.26,1));
      const item=new THREE.Mesh(geo,createDropMaterial(type));item.scale.set(type==='fish_meat'?1.25:1,type==='fish_meat'?0.62:0.82,type==='fish_meat'?0.72:1);mesh.add(item);
    }
    mesh.position.copy(position).add(new THREE.Vector3((Math.random()-0.5)*0.55,0.6+Math.random()*0.35,(Math.random()-0.5)*0.55));
    const velocity=new THREE.Vector3((Math.random()-0.5)*2.1,1.4+Math.random()*2.0,(Math.random()-0.5)*2.1);
    const id=`drop-${Date.now()}-${Math.floor(Math.random()*1e8)}`;
    scene.add(mesh);floatingDrops.push({id,type,amount:1,mesh,velocity,age:0,settled:false});
  }
  while (floatingDrops.length > 80) disposeWorldDrop(floatingDrops.shift());
}

function restoreWorldDrops(records=[]) {
  for(const drop of floatingDrops) disposeWorldDrop(drop);
  floatingDrops=[];
  for(const record of Array.isArray(records)?records.slice(0,80):[]){
    if(!RESOURCE_LABELS[record.type]||!record.position)continue;
    const mesh=new THREE.Group();
    if(record.type==='glowcap'){
      const stem=new THREE.Mesh(new THREE.CylinderGeometry(0.09,0.12,0.38,7),new THREE.MeshStandardMaterial({color:0xd7c9a6,roughness:0.9}));stem.position.y=0.1;mesh.add(stem);
      const cap=new THREE.Mesh(new THREE.SphereGeometry(0.28,9,7,0,Math.PI*2,0,Math.PI*0.58),createDropMaterial(record.type));cap.scale.y=0.78;cap.position.y=0.28;mesh.add(cap);
    }else{const item=new THREE.Mesh(dropGeometry||(dropGeometry=new THREE.IcosahedronGeometry(0.26,1)),createDropMaterial(record.type));mesh.add(item);}
    mesh.position.set(Number(record.position.x)||0,Number(record.position.y)||-8,Number(record.position.z)||0);scene.add(mesh);
    floatingDrops.push({id:record.id||`restored-${Math.random()}`,type:record.type,amount:1,mesh,velocity:new THREE.Vector3(),age:0,settled:true});
  }
}

function nearestDrop(maxDistance=4.8){
  let best=null;
  for(const drop of floatingDrops){const distance=player.position.distanceTo(drop.mesh.position);if(distance<maxDistance&&(!best||distance<best.distance))best={...drop,distance};}
  return best;
}

function spawnDebrisBurst(position,color=0x9cb7b6,count=8){
  const geometry=debrisGeometry||(debrisGeometry=new THREE.IcosahedronGeometry(0.19,0));
  for(let i=0;i<count;i++){
    const material=new THREE.MeshStandardMaterial({color,roughness:0.78,metalness:0.12});
    const mesh=new THREE.Mesh(geometry,material);mesh.position.copy(position);mesh.scale.setScalar(0.45+Math.random()*1.2);scene.add(mesh);
    physicsDebris.push({mesh,velocity:new THREE.Vector3((Math.random()-0.5)*4,Math.random()*3.8+0.6,(Math.random()-0.5)*4),age:0,material});
  }
}

function completeResourceBreak(action) {
  const { id, node, type, position, color } = action;
  if (resourceNodes.get(id) !== node || !node.mesh?.parent) return;
  node.mesh.parent.remove(node.mesh);
  disposeObjectTree(node.mesh);
  resourceNodes.delete(id);
  collectedResources.add(id);
  publishSharedWorldEvent('resource_collected', id, { type });
  spawnDebrisBurst(position, color, type === 'kelp' ? 7 : 12);
  spawnWorldDrop(type, position, type === 'glowcap' || type === 'kelp' ? 2 : 1);
  playSfx('oreBreak');
  markUnsaved();
  updateInteractionPrompt();
  showToast(`${RESOURCE_LABELS[type]} berhasil dihancurkan. Ambil material yang jatuh.`);
}

function updateResourceBreakActions(dt) {
  for (let i = resourceBreakActions.length - 1; i >= 0; i--) {
    const action = resourceBreakActions[i];
    if (resourceNodes.get(action.id) !== action.node || !action.node.mesh?.parent) {
      resourceBreakActions.splice(i, 1);
      continue;
    }
    action.elapsed += dt;
    const progress = clamp(action.elapsed / action.duration, 0, 1);
    const pulse = Math.sin(progress * Math.PI);
    action.node.mesh.rotation.x = action.baseRotation.x + Math.sin(progress * Math.PI * 7) * 0.07 * (1 - progress);
    action.node.mesh.rotation.z = action.baseRotation.z + Math.cos(progress * Math.PI * 6) * 0.055 * (1 - progress);
    action.node.mesh.scale.copy(action.baseScale).multiplyScalar(1 + pulse * 0.055 - progress * 0.93);
    if (!action.crackBurst && progress >= 0.48) {
      action.crackBurst = true;
      spawnDebrisBurst(action.position, action.color, 5);
      playSfx('impact');
    }
    if (progress >= 1) {
      completeResourceBreak(action);
      resourceBreakActions.splice(i, 1);
    }
  }
}

function updateWorldPhysics(dt){
  updateResourceBreakActions(dt);
  for(let i=floatingDrops.length-1;i>=0;i--){
    const drop=floatingDrops[i];drop.age+=dt;
    if(!drop.settled){
      const flow=sampleOceanCurrent(drop.mesh.position.x,drop.mesh.position.y,drop.mesh.position.z,clockState.elapsed,currentBiome?.id||'open');
      const densityRatio=getResourceDensityRatio(drop.type);
      const nextVelocity=integrateFluidBody({velocity:drop.velocity,dt,densityRatio,drag:1.35,flow,flowCoupling:0.30,maxSpeed:12});
      drop.velocity.set(nextVelocity.x,nextVelocity.y,nextVelocity.z);
      const oldDropX=drop.mesh.position.x,oldDropZ=drop.mesh.position.z;
      drop.mesh.position.addScaledVector(drop.velocity,dt);
      const caveMove=constrainCaveHorizontalMotion(oldDropX,oldDropZ,drop.mesh.position.x,drop.mesh.position.z,0.20,CAVE_SITES);
      if(caveMove.blocked){drop.mesh.position.x=caveMove.x;drop.mesh.position.z=caveMove.z;drop.velocity.x=0;drop.velocity.z=0;}
      const dropRoof=getCaveCeilingY(drop.mesh.position.x,drop.mesh.position.z,heightAt(drop.mesh.position.x,drop.mesh.position.z),CAVE_SITES,0.30);
      if(dropRoof!==null&&drop.mesh.position.y>dropRoof-0.18){drop.mesh.position.y=dropRoof-0.18;drop.velocity.y=Math.min(0,-Math.abs(drop.velocity.y)*0.12);}
      const floor=heightAt(drop.mesh.position.x,drop.mesh.position.z)+0.34;
      const hitStructure=structureBlocksPosition(drop.mesh.position.x,drop.mesh.position.y,drop.mesh.position.z);
      if(drop.mesh.position.y<floor||hitStructure){
        drop.mesh.position.y=Math.max(floor,drop.mesh.position.y);
        drop.velocity.y=Math.abs(drop.velocity.y)*0.14;drop.velocity.x*=0.48;drop.velocity.z*=0.48;
        if(Math.abs(drop.velocity.y)<0.20){drop.velocity.set(0,0,0);drop.settled=true;}
      }
      drop.mesh.rotation.x+=dt*1.1;drop.mesh.rotation.y+=dt*1.5;
    }else{drop.mesh.position.y+=Math.sin(clockState.elapsed*1.8+drop.mesh.position.x)*dt*0.025;drop.mesh.rotation.y+=dt*0.22;}
    if(drop.age>900){disposeWorldDrop(drop);floatingDrops.splice(i,1);}
  }
  for(let i=physicsDebris.length-1;i>=0;i--){
    const item=physicsDebris[i];item.age+=dt;
    const flow=sampleOceanCurrent(item.mesh.position.x,item.mesh.position.y,item.mesh.position.z,clockState.elapsed,currentBiome?.id||'open');
    const nextVelocity=integrateFluidBody({velocity:item.velocity,dt,densityRatio:1.62,drag:0.92,flow,flowCoupling:0.22,maxSpeed:20});
    item.velocity.set(nextVelocity.x,nextVelocity.y,nextVelocity.z);
    const oldDebrisX=item.mesh.position.x,oldDebrisZ=item.mesh.position.z;
    item.mesh.position.addScaledVector(item.velocity,dt);item.mesh.rotation.x+=dt*2.2;item.mesh.rotation.y+=dt*1.7;
    const caveMove=constrainCaveHorizontalMotion(oldDebrisX,oldDebrisZ,item.mesh.position.x,item.mesh.position.z,0.35,CAVE_SITES);
    if(caveMove.blocked){item.mesh.position.x=caveMove.x;item.mesh.position.z=caveMove.z;item.velocity.x=0;item.velocity.z=0;}
    const debrisRoof=getCaveCeilingY(item.mesh.position.x,item.mesh.position.z,heightAt(item.mesh.position.x,item.mesh.position.z),CAVE_SITES,0.30);
    if(debrisRoof!==null&&item.mesh.position.y>debrisRoof-0.12){item.mesh.position.y=debrisRoof-0.12;item.velocity.y=Math.min(0,-Math.abs(item.velocity.y)*0.12);}
    const floor=heightAt(item.mesh.position.x,item.mesh.position.z)+0.1;
    if(item.mesh.position.y<floor||structureBlocksPosition(item.mesh.position.x,item.mesh.position.y,item.mesh.position.z)){
      item.mesh.position.y=Math.max(floor,item.mesh.position.y);item.velocity.y=Math.abs(item.velocity.y)*0.12;item.velocity.x*=0.38;item.velocity.z*=0.38;
    }
    if(item.age>2.8){scene.remove(item.mesh);item.mesh.material.dispose();physicsDebris.splice(i,1);}
  }
}

function updateMissionInteractions() {
  // Mission interactions use the same contextual Interact control as objects in the world.
}

function activateLifepod(){
  const inside=getInsideHabitat();
  if(!lifepodGroup||!inside||inside.type!=='lifepod'||!isNearInteriorPoint(inside,0,1.65,1.05)){showToast('Masuk ke dalam Lifepod dan dekati konsol yang rusak.');return;}
  if(!ownedTools.includes('repair_tool')||getSelectedHotbarItem()!=='repair_tool'){showToast('Buat Repair Tool di Fabricator, lalu pilih alat itu pada Quick Slot.');return;}
  triggerToolAnimation('repair');
  const consoleMaterial=lifepodGroup.userData?.consoleMaterial;
  if(consoleMaterial){consoleMaterial.color.setHex(0x173f43);consoleMaterial.emissive.setHex(0x18c9b8);consoleMaterial.emissiveIntensity=1.25;}
  playSfx('craft');
  advanceMission('lifepod');
}

function beginIntroDebriefForOldSave(){
  storyState={...STORY_DEFAULTS,introSeen:true,missionIndex:1,counters:{materials:0},completed:['lifepod']};
  updateMissionUI();
}

function startAmbient() {
  if (ambientContext) return;
  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  if (!AudioCtx) return;
  try {
    ambientContext = new AudioCtx();
    const output = ambientContext.createGain();
    output.gain.value = 0.92;
    output.connect(ambientContext.destination);
    sfxBus = ambientContext.createGain();
    underwaterFilter = ambientContext.createBiquadFilter();
    underwaterFilter.type = 'lowpass'; underwaterFilter.frequency.value = 2200; underwaterFilter.Q.value = 0.55;
    sfxDryGain = ambientContext.createGain(); sfxDryGain.gain.value = 0.92;
    caveWetGain = ambientContext.createGain(); caveWetGain.gain.value = 0.04;
    caveConvolver = ambientContext.createConvolver();
    const impulseLength = Math.max(1, Math.floor(ambientContext.sampleRate * 1.85));
    const impulse = ambientContext.createBuffer(2, impulseLength, ambientContext.sampleRate);
    for (let channelIndex = 0; channelIndex < 2; channelIndex++) {
      const impulseData = impulse.getChannelData(channelIndex);
      for (let sample = 0; sample < impulseLength; sample++) {
        const decay = Math.pow(1 - sample / impulseLength, 2.8);
        impulseData[sample] = (Math.random() * 2 - 1) * decay * 0.22;
      }
    }
    caveConvolver.buffer = impulse;
    caveDelay = ambientContext.createDelay(1.85);
    caveEchoFilter = ambientContext.createBiquadFilter();
    caveEchoFilter.type = 'lowpass'; caveEchoFilter.frequency.value = 820; caveEchoFilter.Q.value = 0.45;
    caveEchoFeedback = ambientContext.createGain(); caveEchoFeedback.gain.value = 0.06;
    caveEchoOut = ambientContext.createGain(); caveEchoOut.gain.value = 0.012;
    caveDelay.delayTime.value = 0.34;
    sfxBus.connect(underwaterFilter);
    underwaterFilter.connect(sfxDryGain); sfxDryGain.connect(output);
    underwaterFilter.connect(caveConvolver); caveConvolver.connect(caveWetGain);
    caveWetGain.connect(output);
    // A damped feedback delay adds bounded cave reflections after the impulse tail.
    caveWetGain.connect(caveDelay); caveDelay.connect(caveEchoFilter);
    caveEchoFilter.connect(caveEchoOut); caveEchoOut.connect(output);
    caveEchoFilter.connect(caveEchoFeedback); caveEchoFeedback.connect(caveDelay);
    audioAssetBank = new AudioAssetBank(ambientContext, sfxBus, { masterVolume: settings.volume / 100 });
    audioAssetBank.load().then(() => { audioAssetBank?.setBiome(currentBiome?.id || 'open'); audioAssetBank?.setCaveBlend(caveAudioBlend); });
    const osc = ambientContext.createOscillator();
    const filter = ambientContext.createBiquadFilter();
    ambientGain = ambientContext.createGain();
    osc.type = 'sine'; osc.frequency.value = 58;
    filter.type = 'lowpass'; filter.frequency.value = 130;
    ambientGain.gain.value = 0;
    osc.connect(filter); filter.connect(ambientGain); ambientGain.connect(output);
    osc.start();
    ambientOscillators = [osc];
    const drone2 = ambientContext.createOscillator();
    const drone2Gain = ambientContext.createGain();
    drone2.type = 'triangle'; drone2.frequency.value = 87; drone2Gain.gain.value = 0.12;
    drone2.connect(drone2Gain); drone2Gain.connect(ambientGain); drone2.start(); ambientOscillators.push(drone2);
    const lfo = ambientContext.createOscillator();
    const lfoGain = ambientContext.createGain();
    lfo.type = 'sine'; lfo.frequency.value = 0.11; lfoGain.gain.value = 0.008;
    lfo.connect(lfoGain); lfoGain.connect(ambientGain.gain); lfo.start();
    const buffer = ambientContext.createBuffer(1, ambientContext.sampleRate * 2, ambientContext.sampleRate);
    sfxNoiseBuffer = buffer;
    const channel = buffer.getChannelData(0);
    for (let i = 0; i < channel.length; i++) channel[i] = (Math.random() * 2 - 1) * 0.16;
    const noise = ambientContext.createBufferSource();
    const noiseFilter = ambientContext.createBiquadFilter();
    soundNoiseGain = ambientContext.createGain();
    noise.buffer = buffer; noise.loop = true; noiseFilter.type = 'lowpass'; noiseFilter.frequency.value = 320;
    soundNoiseGain.gain.value = 0.012;
    noise.connect(noiseFilter); noiseFilter.connect(soundNoiseGain); soundNoiseGain.connect(output); noise.start();
    updateAmbientVolume();
  } catch { ambientContext = null; }
}
function updateAmbientVolume() {
  audioAssetBank?.setMasterVolume(settings.volume / 100);
  if (ambientGain && ambientContext) {
    const target = (settings.volume / 100) * 0.035;
    ambientGain.gain.setTargetAtTime(target, ambientContext.currentTime, 0.12);
    if (soundNoiseGain) soundNoiseGain.gain.setTargetAtTime(target * 0.38, ambientContext.currentTime, 0.16);
  }
}

function updateUnderwaterAudioEnvironment(dt = 0) {
  if (!ambientContext || ambientContext.state === 'closed') return;
  audioEnvironmentTimer += Math.max(0, dt);
  if (audioEnvironmentTimer < 0.18) return;
  audioEnvironmentTimer = 0;
  const depth = Math.max(0, -player.position.y);
  const caveBlend = getCaveAudioBlend(player.position.x, player.position.z, CAVE_SITES);
  const previousCaveBlend = caveAudioBlend;
  caveAudioBlend += (caveBlend - caveAudioBlend) * 0.22;
  audioAssetBank?.setCaveBlend(caveAudioBlend);
  if (previousCaveBlend < 0.58 && caveAudioBlend >= 0.58) playSfx('caveRumble');
  else if (previousCaveBlend >= 0.58 && caveAudioBlend < 0.28) playSfx('caveScrape');
  const profile = getUnderwaterAudioProfile(depth, caveAudioBlend, currentBiome?.id || 'open');
  const now = ambientContext.currentTime;
  underwaterFilter?.frequency.setTargetAtTime(profile.lowpassHz, now, 0.34);
  sfxDryGain?.gain.setTargetAtTime(profile.dryGain, now, 0.32);
  caveWetGain?.gain.setTargetAtTime(profile.reverbWet, now, 0.42);
  caveDelay?.delayTime.setTargetAtTime(Math.min(0.72,profile.reverbSeconds*0.28),now,0.58);
  caveEchoFilter?.frequency.setTargetAtTime(Math.max(320,profile.lowpassHz*0.72),now,0.42);
  caveEchoFeedback?.gain.setTargetAtTime(Math.min(0.22,0.025+profile.reverbSeconds*0.072),now,0.55);
  caveEchoOut?.gain.setTargetAtTime(profile.reverbWet*0.24,now,0.48);
  if (ambientGain) ambientGain.gain.setTargetAtTime((settings.volume / 100) * 0.035 * profile.ambienceGain, now, 0.42);
  if (soundNoiseGain) soundNoiseGain.gain.setTargetAtTime((settings.volume / 100) * 0.013 * profile.ambienceGain, now, 0.46);
  if (caveAudioBlend > 0.72) {
    caveAudioCueTimer -= 0.18;
    if (caveAudioCueTimer <= 0) { caveAudioCueTimer = 7.5 + Math.random() * 6; playSfx('caveDrip'); }
  } else caveAudioCueTimer = 0;
}

function updateBiomeAudio(biome) {
  if (!ambientContext || !biome || lastAudioBiome === biome.id) return;
  lastAudioBiome = biome.id;
  audioAssetBank?.setBiome(biome.id);
  const base = { reef:62, kelp:54, wreck:46, thermal:78, deep:39, abyss:31, abyssal_shelf:28, midnight_grotto:24, blue_void:20, hadal_rift:17, hadal_garden:14, open:58 }[biome.id] || 58;
  ambientOscillators.forEach((osc,index) => {
    const hz = base + (index ? 23 : 0);
    try { osc.frequency.setTargetAtTime(hz, ambientContext.currentTime, 1.8); } catch { /* audio is optional */ }
  });
}

function playSfx(kind = 'tap', position = null) {
  if (!ambientContext) return;
  const sourcePosition = position || player?.position || null;
  if (audioAssetBank?.playEvent(kind, { volume: kind === 'roar' || kind === 'creatureAttack' ? 0.44 : 0.34, position:sourcePosition })) return;
  try {
    if (ambientContext.state === 'suspended') ambientContext.resume().catch(() => {});
    const now = ambientContext.currentTime;
    const presets = {
      collect:[620,920], craft:[420,680], build:[310,520], scan:[820,1160], damage:[120,76], tap:[360,440],
      panelOpen:[460,760], panelClose:[620,390], fabricatorOpen:[210,540], enter:[260,680],
      oxygen:[190,520], locker:[270,390], discovery:[740,1320], radio:[920,480], impact:[78,42], knife:[210,86], creatureAttack:[96,48], faunaHit:[310,125],
      hatch:[280,640], light:[620,780], flashlightOn:[520,1080], flashlightOff:[430,150], oreHit:[185,72],
      oreBreak:[145,48], hologram:[690,1160], equip:[360,640], splash:[240,560], dive:[560,180],
      repair:[360,820], use:[510,760], launch:[140,620], warp:[95,980], reentry:[220,68], roar:[52,24], jump:[180,520], oxygenPlant:[380,760], caveDrip:[760,210], caveRumble:[48,31], caveScrape:[185,68]
    };
    const [startHz,endHz] = presets[kind] || presets.tap;
    const osc = ambientContext.createOscillator();
    const filter = ambientContext.createBiquadFilter();
    const gain = ambientContext.createGain();
    const duration = kind === 'oreBreak' ? 0.48 : kind === 'oreHit' ? 0.22 : ['panelOpen','panelClose','fabricatorOpen','enter'].includes(kind) ? 0.24 : 0.32;
    osc.type = ['damage','oreHit','oreBreak','impact','creatureAttack','faunaHit'].includes(kind) ? 'triangle' : 'sine';
    filter.type = ['oreHit','oreBreak','hatch','repair'].includes(kind) ? 'bandpass' : 'lowpass';
    filter.frequency.setValueAtTime(kind === 'oreBreak' ? 620 : kind === 'oreHit' ? 980 : 1900, now);
    filter.Q.value = kind === 'oreHit' ? 1.8 : 0.7;
    osc.frequency.setValueAtTime(startHz, now);
    osc.frequency.exponentialRampToValueAtTime(Math.max(40,endHz), now + Math.min(.24,duration*.72));
    gain.gain.setValueAtTime(0.0001,now);
    gain.gain.exponentialRampToValueAtTime(Math.max(0.0002,settings.volume/100*(kind==='oreBreak'?.055:.045)),now+.018);
    gain.gain.exponentialRampToValueAtTime(0.0001,now+duration);
    osc.connect(filter);filter.connect(gain);gain.connect(sfxBus||ambientContext.destination);
    osc.start(now);osc.stop(now+duration+.015);

    // Layered, offline-generated noise adds texture to tactile actions and the
    // intro's larger cinematic beats without depending on remote audio files.
    const noiseProfiles={
      oreHit:{type:'bandpass',frequency:1450,q:1.8,duration:.13,level:.016},
      oreBreak:{type:'bandpass',frequency:760,q:1.4,duration:.38,level:.028},
      hatch:{type:'lowpass',frequency:520,q:.65,duration:.22,level:.016},
      repair:{type:'bandpass',frequency:1180,q:.9,duration:.24,level:.014},
      build:{type:'lowpass',frequency:920,q:.7,duration:.25,level:.016},
      splash:{type:'highpass',frequency:1750,q:.55,duration:.42,level:.024},
      dive:{type:'lowpass',frequency:680,q:.75,duration:.34,level:.02},
      flashlightOn:{type:'highpass',frequency:2800,q:.7,duration:.12,level:.009},
      flashlightOff:{type:'lowpass',frequency:700,q:.7,duration:.12,level:.009},
      impact:{type:'lowpass',frequency:260,q:.55,duration:.46,level:.034},
      reentry:{type:'bandpass',frequency:820,q:.72,duration:.72,level:.026},
      roar:{type:'lowpass',frequency:145,q:.55,duration:.92,level:.042},
      launch:{type:'bandpass',frequency:430,q:.6,duration:.48,level:.022},
      warp:{type:'highpass',frequency:2400,q:.65,duration:.4,level:.018},
      caveDrip:{type:'bandpass',frequency:520,q:2.2,duration:.48,level:.014},
      caveRumble:{type:'lowpass',frequency:92,q:.8,duration:1.0,level:.024},
      caveScrape:{type:'bandpass',frequency:380,q:1.1,duration:.42,level:.018}
    };
    const noiseProfile=noiseProfiles[kind];
    if(sfxNoiseBuffer&&noiseProfile){
      const noise=ambientContext.createBufferSource();
      const noiseFilter=ambientContext.createBiquadFilter();
      const noiseGain=ambientContext.createGain();
      noise.buffer=sfxNoiseBuffer;
      noiseFilter.type=noiseProfile.type;
      noiseFilter.frequency.setValueAtTime(noiseProfile.frequency,now);
      noiseFilter.Q.value=noiseProfile.q;
      noiseGain.gain.setValueAtTime(.0001,now);
      noiseGain.gain.exponentialRampToValueAtTime(Math.max(.0001,settings.volume/100*noiseProfile.level),now+.025);
      noiseGain.gain.exponentialRampToValueAtTime(.0001,now+noiseProfile.duration);
      noise.connect(noiseFilter);noiseFilter.connect(noiseGain);noiseGain.connect(sfxBus||ambientContext.destination);
      const maxOffset=Math.max(.001,1.95-noiseProfile.duration);
      noise.start(now,Math.random()*maxOffset,noiseProfile.duration);
      noise.stop(now+noiseProfile.duration+.025);
    }
  } catch { /* Audio is optional; gameplay must remain functional without it. */ }
}

async function enterFullscreenLandscape() {
  try {
    if (!document.fullscreenElement && document.documentElement.requestFullscreen) await document.documentElement.requestFullscreen({ navigationUI: 'hide' });
  } catch { /* Browser or installed-app policy may refuse; the PWA manifest still requests fullscreen. */ }
  try {
    if (screen.orientation && screen.orientation.lock) await screen.orientation.lock('landscape');
  } catch { /* Native Android Activity is already locked to landscape. */ }
  try { window.scrollTo(0, 0); } catch { /* no-op */ }
}

function getInventoryEntries(inventorySource = inventory, toolsSource = ownedTools, survivalSource = survival) {
  const entries = [];
  const addEntry = (id, count, kindOverride = null, suffix = '') => {
    const def = ITEM_DEFS[id];
    if (!def || count <= 0) return;
    const defaultWidth = def.size >= 4 ? 2 : def.size === 2 && def.kind !== 'tool' ? 2 : 1;
    const defaultHeight = def.size >= 4 ? 2 : def.size === 2 && def.kind === 'tool' ? 2 : 1;
    entries.push({ id: suffix || id, hotbarKey:id, name:def.name, icon:def.icon, size:def.size, width:def.width || defaultWidth, height:def.height || defaultHeight, kind:kindOverride || def.kind, count });
  };
  for (const id of toolsSource) addEntry(id, 1, 'tool');
  for (const [key, countValue] of Object.entries(inventorySource || {})) {
    const def = ITEM_DEFS[key];
    let remaining = Math.max(0, Math.floor(Number(countValue) || 0));
    if (!def || remaining <= 0) continue;
    const stackSize = def.stack || 1;
    let stackIndex = 0;
    while (remaining > 0) {
      const count = Math.min(stackSize, remaining);
      addEntry(key, count, def.kind, `${key}-${stackIndex++}`);
      remaining -= count;
    }
  }
  for (const [key, countValue] of [['medkit',survivalSource.medkits],['ration',survivalSource.rations],['water',survivalSource.waterBottles]]) {
    const def = ITEM_DEFS[key];
    let remaining = Math.max(0, Math.floor(Number(countValue) || 0));
    let stackIndex = 0;
    while (remaining > 0) {
      const count = Math.min(def.stack, remaining);
      addEntry(key, count, 'supply', `${key}-${stackIndex++}`);
      remaining -= count;
    }
  }
  return entries;
}

function packInventory(entries = getInventoryEntries()) {
  const columns = 8, rows = 6;
  const occupied = Array(columns * rows).fill(null);
  const placements = [], overflow = [];
  for (const entry of entries) {
    const width = clamp(Math.floor(entry.width || (entry.size > 2 ? 2 : 1)), 1, columns);
    const height = clamp(Math.floor(entry.height || (entry.kind === 'tool' && entry.size > 1 ? 2 : 1)), 1, rows);
    let found = null;
    for (let row = 0; row <= rows - height && !found; row++) {
      for (let col = 0; col <= columns - width; col++) {
        let free = true;
        for (let y = 0; y < height && free; y++) for (let x = 0; x < width; x++) if (occupied[(row+y)*columns+col+x]) { free = false; break; }
        if (free) { found = { row, col, width, height }; break; }
      }
    }
    if (!found) { overflow.push(entry); continue; }
    for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) occupied[(found.row+y)*columns+found.col+x] = entry;
    placements.push({ entry, ...found });
  }
  return { occupied, placements, overflow, used:occupied.filter(Boolean).length, capacity:columns*rows, columns, rows };
}

function canFitResource(type, amount = 1) {
  if (!ITEM_DEFS[type]) return false;
  const next = { ...inventory, [type]:clamp((inventory[type] || 0) + amount, 0, 999) };
  return packInventory(getInventoryEntries(next)).overflow.length === 0;
}

function canFitSupply(type, amount = 1) {
  const next = { ...survival };
  const key = type === 'medkit' ? 'medkits' : type === 'ration' ? 'rations' : 'waterBottles';
  next[key] = clamp((next[key] || 0) + amount, 0, 20);
  return packInventory(getInventoryEntries(inventory, ownedTools, next)).overflow.length === 0;
}

function renderHotbarNode(root) {
  if (!root) return;
  root.replaceChildren();
  for (let index = 0; index < 5; index++) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `hotbar-slot ${index === selectedHotbarIndex ? 'active' : ''}`;
    button.dataset.hotbarIndex = String(index);
    const number = document.createElement('span'); number.className='hotbar-number'; number.textContent=String(index+1);
    const img = document.createElement('img'); img.alt='';
    const label = document.createElement('small');
    const id = hotbarSlots[index];
    const def = id ? ITEM_DEFS[id] : null;
    if (def) { img.src=`./icons/items/${def.icon}.png`; img.hidden=false; label.textContent=id==='seaglide'?`${def.name} · ${Math.ceil(equipment.seaglideCharge)}%`:def.name; }
    else if (id && ITEM_DEFS[id]) { img.src=`./icons/items/${ITEM_DEFS[id].icon}.png`; label.textContent=ITEM_DEFS[id].name; }
    else if (id) { const fallback=ITEM_DEFS[id]; img.hidden=!fallback; if(fallback)img.src=`./icons/items/${fallback.icon}.png`; label.textContent=fallback?.name || id; }
    else { img.hidden=true; label.textContent='KOSONG'; }
    button.append(number,img,label);
    button.addEventListener('click', () => selectHotbar(index));
    root.append(button);
  }
}

function renderHotbar() {
  renderHotbarNode($('hotbar'));
  renderHotbarNode($('inventory-quickbar'));
  const builderSelected = getSelectedHotbarItem() === 'habitat_builder' && ownedTools.includes('habitat_builder');
  updateInteractionPrompt();
}

function getSelectedHotbarItem() { return hotbarSlots[selectedHotbarIndex] || null; }

function hasQuickSlotItem(itemId) {
  if (!itemId || !ITEM_DEFS[itemId]) return false;
  if (ITEM_DEFS[itemId].kind === 'tool') return ownedTools.includes(itemId);
  if (itemId === 'medkit') return (Number(survival.medkits) || 0) > 0;
  if (itemId === 'ration') return (Number(survival.rations) || 0) > 0;
  if (itemId === 'water') return (Number(survival.waterBottles) || 0) > 0;
  return (Number(inventory[itemId]) || 0) > 0;
}

function selectHotbar(index) {
  selectedHotbarIndex = clamp(Number(index) || 0, 0, 4);
  if (viewModel) viewModel.userData.equipTimer = 0.34;
  renderHotbar();
  const active = getSelectedHotbarItem();
  if (active) playSfx('equip');
  markUnsaved();
}

function assignItemToHotbar(itemId) {
  if (!itemId) return;
  if (itemId === 'explorer_pda') { showToast('Explorer PDA dibuka melalui tombol PDA, bukan Quick Slot.'); return; }
  hotbarSlots[selectedHotbarIndex] = itemId;
  renderHotbar();
  showToast(`${ITEM_DEFS[itemId]?.name || RESOURCE_LABELS[itemId] || itemId} dipasang pada slot aktif.`);
  markUnsaved();
}

function renderInventory() {
  const root = $('inventory-list');
  if (!root) return;
  root.replaceChildren();
  const layout = packInventory();
  $('inventory-capacity').textContent = `${layout.used} / 48 CELLS USED${layout.overflow.length ? ` · ${layout.overflow.length} ITEM(S) CANNOT FIT` : ''}`;
  $('inventory-capacity').classList.toggle('is-full', layout.used >= 48 || layout.overflow.length > 0);
  const overflowRoot=$('inventory-overflow');
  if(overflowRoot){overflowRoot.replaceChildren();overflowRoot.classList.toggle('hidden',layout.overflow.length===0);for(const entry of layout.overflow){const row=document.createElement('div');row.className='inventory-overflow-item';const icon=document.createElement('img');icon.src=`./icons/items/${entry.icon}.png`;icon.alt='';const name=document.createElement('span');name.textContent=entry.name;const count=document.createElement('b');count.textContent=`x${entry.count} · ${entry.size} SLOT`;row.append(icon,name,count);overflowRoot.append(row);}}
  for (const placement of layout.placements) {
    const { entry, row, col, width, height } = placement;
    const card = document.createElement('button');
    card.type='button';
    card.className=`inventory-slot-item ${entry.kind || ''}`;
    card.style.gridColumn=`${col + 1} / span ${width}`;
    card.style.gridRow=`${row + 1} / span ${height}`;
    card.title=`${entry.name} · ${width}×${height} cells${entry.count > 1 ? ` · jumlah ${entry.count}` : ''}`;
    const img=document.createElement('img'); img.src=`./icons/items/${entry.icon}.png`; img.alt='';
    const name=document.createElement('span'); name.textContent=entry.name;
    const count=document.createElement('b'); count.textContent=entry.count > 1 ? `x${entry.count}` : `${width}×${height}`;
    card.append(img,name,count);
    card.addEventListener('click', () => {
      assignItemToHotbar(entry.hotbarKey);
    });
    root.append(card);
  }
  for (let index=0; index<48; index++) {
    if (layout.occupied[index]) continue;
    const empty=document.createElement('div'); empty.className='inventory-slot-empty';
    empty.style.gridColumn=String((index%8)+1); empty.style.gridRow=String(Math.floor(index/8)+1);
    empty.textContent=String(index+1).padStart(2,'0'); root.append(empty);
  }
  const eqRoot = $('equipment-list');
  if (eqRoot) {
    eqRoot.replaceChildren();
    const gear = [
      { id:'tank', name:'OXYGEN TANK', icon:'oxygen_tank', value:`TANK MK ${equipment.tankLevel + 1} · ${getMaxOxygen()} O₂ · ${oxygenTankDepthRating(equipment.tankLevel)} M`, action:() => showToast(`Tangki MK ${equipment.tankLevel + 1} · kapasitas ${getMaxOxygen()} O₂ · batas aman ${oxygenTankDepthRating(equipment.tankLevel)} meter.`) },
      { id:'fins', name:'SWIM FINS', icon:'fins', value:equipment.fins?'EQUIPPED':'NOT CRAFTED', action:() => showToast(equipment.fins?'Swim Fins terpasang.':'Buat Swim Fins melalui Fabricator.') },
      { id:'rebreather', name:'REBREATHER', icon:'rebreather', value:equipment.rebreather?'EQUIPPED':'NOT CRAFTED', action:() => showToast(equipment.rebreather?'Rebreather terpasang.':'Buat Rebreather melalui Fabricator.') }
    ];
    for (const item of gear) {
      const button=document.createElement('button'); button.type='button'; button.className='equipment-slot';
      const img=document.createElement('img'); img.src=`./icons/items/${item.icon}.png`; img.alt='';
      const label=document.createElement('span'); label.textContent=item.name;
      const value=document.createElement('b'); value.textContent=item.value;
      button.append(img,label,value); button.addEventListener('click',item.action); eqRoot.append(button);
    }
  }
  renderHotbar();
}

function openInventory() {
  if (!gameActive) return;
  gamePaused = true;
  renderInventory();
  setVisibleScreen('inventory');
  playSfx('panelOpen');
  requestAnimationFrame(()=>{const card=UI.inventory?.querySelector('.panel-card');if(card)card.scrollTop=0;});
}

function closeGamePanel() {
  if (!gameActive) { setVisibleScreen('main'); return; }
  if(UI.vehicle&&!UI.vehicle.classList.contains('hidden')){renderVehicleBay();}
  gamePaused = false;
  setVisibleScreen('hud');
  playSfx('panelClose');
  enterFullscreenLandscape();
}

function nearestResource(maxDistance = 9) {
  let best = null;
  for (const [id, node] of resourceNodes) {
    const position = node.mesh.getWorldPosition(tmpVector);
    const distance = player.position.distanceTo(position);
    if (distance < maxDistance && (!best || distance < best.distance)) best = { id, ...node, position: position.clone(), distance };
  }
  return best;
}

function getAimedWorldTarget() {
  const pitch = clamp(player.pitch, -1.1, 1.1);
  const forward = new THREE.Vector3(Math.sin(player.yaw)*Math.cos(pitch),-Math.sin(pitch),-Math.cos(player.yaw)*Math.cos(pitch)).normalize();
  const eye = new THREE.Vector3(player.position.x,player.position.y+0.55,player.position.z);
  let best = null;
  const consider = (kind,id,object,position,maxDistance) => {
    const distance=eye.distanceTo(position);
    if(distance>maxDistance || distance<0.2)return;
    const direction=position.clone().sub(eye).normalize();
    const alignment=forward.dot(direction);
    if(alignment<0.945)return;
    const score=alignment-distance*0.0015;
    if(!best||score>best.score)best={kind,id,object,position:position.clone(),distance,alignment,score};
  };
  for(const [id,node] of resourceNodes){
    if(node.breaking)continue;
    const position=node.mesh.getWorldPosition(new THREE.Vector3());
    position.y+=node.type==='kelp'?1.6:1.15;
    consider('resource',id,node,position,15);
  }
  for(const drop of floatingDrops)consider('drop',drop.id,drop,drop.mesh.position.clone(),8);
  for(const cache of supplyCacheLocations){if(!collectedCaches.has(cache.id))consider('cache',cache.id,cache,new THREE.Vector3(cache.x,cache.y+1,cache.z),10);}
  return best;
}

function getInsideHabitat() {
  if(lifepodGroup){
    const angle=lifepodGroup.rotation.y||0;
    const local=worldToLifepodLocal(player.position.x,player.position.y,player.position.z,lifepodGroup.position,angle,LIFEPOD_SCALE);
    if(lifepodInteriorContains(local.x,local.y,local.z))return {type:'lifepod',id:'lifepod',x:lifepodGroup.position.x,y:lifepodGroup.position.y,z:lifepodGroup.position.z,yaw:angle};
  }
  for(const item of placedStructures){
    if(item.type!=='compartment')continue;
    const angle=Number(item.yaw)||0;
    const local=worldToLifepodLocal(player.position.x,player.position.y,player.position.z,{x:item.x,y:item.y,z:item.z},angle);
    if(Math.hypot(local.x,local.z)<3.62&&local.y>1.45&&local.y<5.85)return item;
  }
  return null;
}

function interiorPoint(inside, localX, localZ) {
  const angle=Number(inside?.yaw)||0;
  return {
    x:inside.x+(inside.type==='lifepod'?localX*LIFEPOD_SCALE:localX)*Math.cos(angle)+(inside.type==='lifepod'?localZ*LIFEPOD_SCALE:localZ)*Math.sin(angle),
    z:inside.z-(inside.type==='lifepod'?localX*LIFEPOD_SCALE:localX)*Math.sin(angle)+(inside.type==='lifepod'?localZ*LIFEPOD_SCALE:localZ)*Math.cos(angle)
  };
}
function isNearInteriorPoint(inside, localX, localZ, radius=2.8) {
  if(!inside)return false;
  const point=interiorPoint(inside,localX,localZ);
  return Math.hypot(player.position.x-point.x,player.position.z-point.z)<=radius*(inside.type==='lifepod'?LIFEPOD_SCALE:1);
}
function isNearFabricator(inside=getInsideHabitat()) {
  return inside?.type==='lifepod' ? isNearInteriorPoint(inside,0.70,-0.28,2.6) : isNearInteriorPoint(inside,2.25,0.8,3.2);
}

function getAimedLifepodHatchTarget(maxDistance=16) {
  if(!lifepodGroup || getInsideHabitat()?.type==='lifepod') return null;
  const pitch=clamp(player.pitch,-1.1,1.1);
  const direction=new THREE.Vector3(Math.sin(player.yaw)*Math.cos(pitch),-Math.sin(pitch),-Math.cos(player.yaw)*Math.cos(pitch)).normalize();
  const origin=new THREE.Vector3(player.position.x,player.position.y+0.55,player.position.z);
  const hit=getLifepodHatchAim(origin,direction,lifepodGroup.position,lifepodGroup.rotation.y||0,maxDistance,LIFEPOD_SCALE);
  return hit ? { ...hit, type:'lifepod', id:'lifepod', x:lifepodGroup.position.x, y:lifepodGroup.position.y, z:lifepodGroup.position.z, yaw:lifepodGroup.rotation.y||0 } : null;
}

function findNearbyHabitat(maxDistance=16) {
  let best=null;
  // Lifepod entry is intentionally available only while the reticle intersects its roof hatch.
  const hatchTarget=getAimedLifepodHatchTarget(Math.min(12,maxDistance));
  if(hatchTarget) best={...hatchTarget,distance:hatchTarget.distance};
  for(const item of placedStructures){
    if(item.type!=='compartment')continue;
    const distance=Math.hypot(player.position.x-item.x,player.position.y-item.y,player.position.z-item.z);
    if(distance<=maxDistance&&(!best||distance<best.distance))best={...item,distance};
  }
  return best;
}

function openLifepodHatch(duration=1.35) {
  if(!lifepodGroup?.userData?.hatchLid)return;
  lifepodGroup.userData.hatchOpenUntil=clockState.elapsed+duration;
}

function updateLifepodHatchAnimation(dt) {
  const pod=lifepodGroup;
  if(!pod?.userData?.hatchLid)return;
  const target=clockState.elapsed<(pod.userData.hatchOpenUntil||0)?-1.38:(pod.userData.hatchClosedRotation??-0.72);
  const lid=pod.userData.hatchLid;
  lid.rotation.z+=(target-lid.rotation.z)*(1-Math.exp(-Math.max(0,dt)*9));
}

function enterHabitat(target) {
  if(!target)return;
  const previousPosition=player.position.clone();
  const previousVelocity=player.velocity.clone();
  const previousYaw=player.yaw,previousPitch=player.pitch;
  const previousRespawnPoint=respawnPoint.clone();
  const yaw=Number(target.yaw)||0;
  if(target.type==='lifepod'){
    const hatch=getAimedLifepodHatchTarget(12);
    if(!hatch){showToast('Bidik hatch di bagian atas Lifepod lalu tekan INTERACT.');return;}
    const s=Math.sin(yaw),c=Math.cos(yaw);
    // A valid reticle hit opens the hatch first, then places the diver at a
    // known interior coordinate. Validate the transform before changing state
    // so a malformed scale/yaw can never strand the player in the hull.
    const entry={x:target.x-0.15*s*LIFEPOD_SCALE,y:target.y+0.22*LIFEPOD_SCALE,z:target.z-0.15*c*LIFEPOD_SCALE};
    const local=worldToLifepodLocal(entry.x,entry.y,entry.z,lifepodGroup.position,yaw,LIFEPOD_SCALE);
    if(!lifepodInteriorContains(local.x,local.y,local.z)){
      showToast('Posisi hatch tidak valid. Coba bidik bagian tengah pintu masuk.');return;
    }
    openLifepodHatch(2.6);
    player.position.set(entry.x,entry.y,entry.z);
    playSfx('hatch');
  }else{
    player.position.set(target.x,target.y+2.15,target.z);
  }
  player.velocity.set(0,0,0);player.yaw=yaw;player.pitch=0.02;
  updateLifepodInteriorVisibility();
  updateCamera(0.016);updateSurvivalHud();updateInteractionPrompt();
  if(target.type==='lifepod'&&getInsideHabitat()?.type!=='lifepod'){
    // Defensive rollback: the player must never be shown an interior shell
    // unless the runtime's own interior-volume test confirms the position.
    player.position.copy(previousPosition);player.yaw=previousYaw;player.pitch=previousPitch;
    respawnPoint.copy(previousRespawnPoint);
    player.velocity.copy(previousVelocity);updateLifepodInteriorVisibility();updateCamera(0.016);updateInteractionPrompt();
    showToast('Gagal memasuki Lifepod. Bidik hatch sekali lagi.');
    return;
  }
  respawnPoint.copy(player.position);markUnsaved();
  playSfx('enter');
  showToast('Kamu berada di dalam habitat. Oksigen dipulihkan hanya di dalam habitat berdaya atau di permukaan.');
}

function updateLifepodInteriorVisibility() {
  if(!lifepodGroup) return;
  const inside=getInsideHabitat()?.type==='lifepod';
  for(const part of lifepodGroup.userData.exteriorParts||[]) part.visible=!inside;
  for(const part of lifepodGroup.userData.interiorParts||[]) part.visible=inside;
}

function exitHabitat() {
  const inside=getInsideHabitat();if(!inside)return;
  const previousPosition=player.position.clone();
  const previousVelocity=player.velocity.clone();
  const previousYaw=player.yaw,previousPitch=player.pitch;
  const angle=Number(inside.yaw)||0;
  if(inside.type==='lifepod'){
    // The old exit point was still inside the hull's roof/hatch channel. The
    // waterline clamp kept the player at that height, so the hatch could close
    // around the diver and every movement axis was then blocked. Choose a
    // collision-free side position at the actual waterline instead.
    const surfaceY=waterSurfaceHeightAt(inside.x,inside.z,clockState.elapsed);
    const candidates=[1,-1].map(side=>getLifepodExitWorldPosition(
      {x:inside.x,y:inside.y,z:inside.z},angle,LIFEPOD_SCALE,surfaceY,side,0.38
    ));
    const isSafeExit=point=>{
      const local=worldToLifepodLocal(point.x,point.y,point.z,lifepodGroup.position,angle,LIFEPOD_SCALE);
      return !lifepodInteriorContains(local.x,local.y,local.z)
        && !lifepodHatchChannelContains(local.x,local.y,local.z)
        && !lifepodHullBlocksWorld(point.x,point.y,point.z,lifepodGroup.position,angle,0.38,LIFEPOD_SCALE,false)
        && !structureBlocksPosition(point.x,point.y,point.z)
        && point.y>=samplePlayerFloor(point.x,point.z)+1.9;
    };
    let exitPoint=candidates.find(isSafeExit);
    if(!exitPoint){
      // Expand the side clearance and try both sides if a placed structure or
      // steep seabed happens to obstruct the normal egress point.
      const wider=[1,-1].map(side=>getLifepodExitWorldPosition(
        {x:inside.x,y:inside.y,z:inside.z},angle,LIFEPOD_SCALE,surfaceY,side,0.95
      ));
      exitPoint=wider.find(isSafeExit)||null;
    }
    if(!exitPoint){
      showToast('Area keluar Lifepod terhalang. Bersihkan ruang di kedua sisi kapsul terlebih dahulu.');return;
    }
    openLifepodHatch(1.8);
    player.position.set(exitPoint.x,exitPoint.y,exitPoint.z);
    player.pitch=-0.12;
    playSfx('hatch');
  }else{
    const distance=5.5;
    player.position.x=inside.x+Math.sin(angle)*distance;
    player.position.z=inside.z-Math.cos(angle)*distance;
    player.position.y=inside.y+2.0;
  }
  player.velocity.set(0,0,0);
  updateLifepodInteriorVisibility();
  updateCamera(0.016);updateSurvivalHud();updateInteractionPrompt();
  if(inside.type==='lifepod'&&getInsideHabitat()?.type==='lifepod'){
    // Never leave the diver in a half-exited state if the final runtime volume
    // check disagrees with the candidate clearance test. Restore the safe pose.
    player.position.copy(previousPosition);player.velocity.copy(previousVelocity);
    player.yaw=previousYaw;player.pitch=previousPitch;
    updateLifepodInteriorVisibility();updateCamera(0.016);updateInteractionPrompt();
    showToast('Keluar Lifepod belum aman. Posisi dipulihkan; coba sisi kapsul lainnya.');return;
  }
  playSfx('enter');
  showToast('Kamu keluar dari habitat.');
}

function updateReticleFeedback(kind = 'none', label = '') {
  const reticle = $('aim-reticle');
  const targetLabel = $('target-label');
  if (reticle) {
    reticle.dataset.targetKind = kind;
    reticle.classList.toggle('has-target', kind !== 'none');
    reticle.setAttribute('aria-label', kind === 'none' ? 'Tanda bidik' : `Target: ${label || kind}`);
  }
  if (targetLabel) targetLabel.dataset.targetKind = kind;
}

function triggerToolAnimation(type = 'scanner') {
  if (viewModel) {
    viewModel.userData.actionType = type;
    viewModel.userData.actionTimer = type === 'knife' ? 0.54 : type === 'mine' ? 0.46 : 0.52;
  }
  if (type === 'scanner') {
    const flash = $('scan-flash');
    if (flash) {
      flash.classList.remove('active');
      void flash.offsetWidth;
      flash.classList.add('active');
    }
  }
}

function updateInteractionPrompt() {
  const interact=$('interact-btn');
  const targetLabel=$('target-label');
  if(!interact||!targetLabel)return;
  // Declare contextual action elements before the vehicle branch. Accessing
  // these below their later declaration caused a temporal-dead-zone error
  // as soon as the prompt refreshed while a vehicle was being piloted.
  const attackButton=$('attack-btn');
  const useButton=$('use-item-btn');
  const selected=getSelectedHotbarItem();
  const inside=getInsideHabitat();
  if(activeVehicleId){
    attackButton?.classList.add('hidden');$('scan-btn')?.classList.add('hidden');useButton?.classList.add('hidden');$('exit-habitat-btn')?.classList.add('hidden');$('vehicle-special-btn')?.classList.remove('hidden');$('vehicle-cargo-btn')?.classList.toggle('hidden',activeVehicleId!=='carrier');
    interact.classList.remove('hidden');interact.dataset.action='vehicle-exit';interact.dataset.hudLabel='EXIT';interact.textContent='EXIT VEHICLE';interact.setAttribute('aria-label','Keluar dari kendaraan');interact.title='Exit vehicle';targetLabel.textContent=`PILOTING · ${VEHICLE_DEFS[activeVehicleId].name.toUpperCase()} · ${Math.round(-player.position.y)} M`;updateReticleFeedback('vehicle','EXIT VEHICLE');syncVehicleHudActions();return;
  }
  $('vehicle-special-btn')?.classList.add('hidden');$('vehicle-cargo-btn')?.classList.add('hidden');
  const vehicleAim=getAimedVehicleTarget(13);
  const nearbyVehicleBay=getVehicleBay(12);
  const nearbyHabitat=findNearbyHabitat(16);
  const hatchAim=!inside?getAimedLifepodHatchTarget(16):null;
  const nearbyLocker=nearestBuiltStructure('storage_locker',8);
  const aim=getAimedWorldTarget();
  const faunaAim=getAimedHarvestTarget();
  const pitch=clamp(player.pitch,-1.1,1.1);
  const direction=new THREE.Vector3(Math.sin(player.yaw)*Math.cos(pitch),-Math.sin(pitch),-Math.cos(player.yaw)*Math.cos(pitch)).normalize();
  const origin=new THREE.Vector3(player.position.x,player.position.y+0.55,player.position.z);
  const knifeReady=selected==='knife'&&hasQuickSlotItem('knife')&&ownedTools.includes('knife');
  const attackAim=knifeReady?faunaDirector?.getAttackTarget(player.position,origin,direction,KNIFE_ATTACK_PROFILE.range,{playerVelocity:player.velocity}):null;
  // Keep the attack control available whenever the knife is equipped. The diver may
  // swing while swimming or steering; a missing target produces a harmless air-swing.
  attackButton?.classList.toggle('hidden',!knifeReady);
  if(attackButton){const attackLabel=pendingKnifeAttack?'Serangan berlangsung':attackAim?`Serang ${attackAim.name} dengan Survival Knife`:'Ayunkan Survival Knife saat bergerak';attackButton.setAttribute('aria-label',attackLabel);attackButton.title=pendingKnifeAttack?'Animasi serangan sedang berlangsung':attackAim?`Serang ${attackAim.name}`:'Ayunkan pisau sambil berenang; target diperiksa pada frame benturan';attackButton.classList.toggle('attack-winding',!!pendingKnifeAttack);}
  const scanAim=selected==='scanner'?faunaDirector?.getScanTarget(player.position,24,{origin,direction,minAlignment:0.945}):null;
  $('scan-btn')?.classList.toggle('hidden',selected!=='scanner'||!scanAim);
  $('scan-btn')?.classList.toggle('ready-to-scan',!!scanAim);
  $('exit-habitat-btn')?.classList.toggle('hidden',!inside);
  $('pda-btn')?.classList.toggle('hidden',!ownedTools.includes('explorer_pda'));
  const useCounts={medkit:survival.medkits,ration:survival.rations,water:survival.waterBottles,fish_meat:inventory.fish_meat||0};
  const canUse=['medkit','ration','water','fish_meat'].includes(selected)&&(useCounts[selected]||0)>0;
  const canToggleFlashlight=selected==='flashlight'&&ownedTools.includes('flashlight');
  const canRecharge=selected==='seaglide'&&equipment.seaglideCharge<100&&(inventory.battery||0)>0;
  const needsBattery=selected==='seaglide'&&equipment.seaglideCharge<100;
  useButton?.classList.toggle('hidden',!canUse&&!needsBattery&&!canToggleFlashlight);
  useButton?.classList.toggle('battery-action',needsBattery);
  useButton?.classList.toggle('needs-battery',needsBattery&&!canRecharge);
  if(useButton){const actionLabel=needsBattery?'BATTERY':canToggleFlashlight?(flashlightEnabled?'LIGHT ON':'LIGHT OFF'):'USE';useButton.dataset.hudLabel=actionLabel;useButton.setAttribute('aria-label',needsBattery?'Ganti baterai Seaglide':canToggleFlashlight?'Nyalakan atau matikan senter':'Gunakan item');useButton.title=needsBattery?'Ganti baterai Seaglide':canToggleFlashlight?'Toggle flashlight':'Use item';}
  interact.classList.add('hidden');
  interact.dataset.action='';
  for(const key of ['resourceId','dropId','cacheId','habitatId','vehicleId'])delete interact.dataset[key];
  let message='';let targetKind='none';
  const show=(label,action,hud,kind)=>{
    interact.textContent=label;interact.dataset.action=action;interact.dataset.hudLabel=hud;
    interact.setAttribute('aria-label',label);interact.title=label;interact.classList.remove('hidden');targetKind=kind;
  };
  if(pendingBuildType){
    const recipe=BUILD_RECIPES[pendingBuildType];
    show(buildPreviewValid?`PLACE ${recipe?.label?.toUpperCase()||'STRUCTURE'}`:'INVALID BUILD LOCATION','confirm-build',buildPreviewValid?'PLACE':'MOVE','build');
    message=buildPreviewValid?'HOLOGRAM LOCKED · PRESS BUILD TO CONFIRM':'MOVE THE HOLOGRAM TO A FLAT, CLEAR SEABED';
    targetLabel.textContent=message;updateReticleFeedback('build',message);return;
  }
  if(inside){
    if(nearbyLocker){show('OPEN WALL LOCKER','storage','OPEN','storage');message='WALL LOCKER';}
    else if(getCurrentMission()?.id==='lifepod'&&inside.type==='lifepod'&&isNearInteriorPoint(inside,0,1.65,1.05)){
      if(ownedTools.includes('repair_tool')&&selected==='repair_tool'){show('REPAIR LIFEPOD','mission','REPAIR','mission');message='DAMAGED CONTROL CONSOLE · REPAIR TOOL READY';}
      else message=ownedTools.includes('repair_tool')?'CONTROL CONSOLE · EQUIP REPAIR TOOL':'CONTROL CONSOLE · FABRICATE REPAIR TOOL';
    }else if(isNearFabricator(inside)&&isHabitatPowered(inside)){
      show('FABRICATOR','fabricator','FAB','fabricator');message='FABRICATOR ACCESS';
    }else message='SAFE HABITAT INTERIOR';
  }else if(vehicleAim){
    show(`ENTER ${VEHICLE_DEFS[vehicleAim.id].name.toUpperCase()}`,'vehicle-enter','ENTER','vehicle');interact.dataset.vehicleId=vehicleAim.id;message=`${VEHICLE_DEFS[vehicleAim.id].name.toUpperCase()} · ${Math.round(vehicleAim.distance)} M · ${Math.round(vehicleAim.state.power)}% POWER`;
  }else if(nearbyVehicleBay){
    show('OPEN VEHICLE FABRICATION BAY','vehicle-bay','VEHICLES','vehicle');message='VEHICLE BAY · FABRICATE / UPGRADE / REPAIR';
  }else if(nearbyHabitat){
    show(nearbyHabitat.type==='lifepod'?'ENTER THROUGH TOP HATCH':'ENTER HABITAT','enter','ENTER','habitat');
    interact.dataset.habitatId=nearbyHabitat.id||'';message=nearbyHabitat.type==='lifepod'?'LIFEPOD · ROOF HATCH LOCKED ON RETICLE':'MULTIPURPOSE ROOM';
  }else if(!inside&&lifepodGroup&&Math.hypot(player.position.x-lifepodGroup.position.x,player.position.y-lifepodGroup.position.y,player.position.z-lifepodGroup.position.z)<16){
    message='LIFEPOD NEARBY · SWIM ABOVE IT AND AIM AT THE TOP HATCH';targetKind='habitat';
  }else if(nearbyLocker){show('OPEN WALL LOCKER','storage','OPEN','storage');message='WALL LOCKER';
  }else if(selected==='habitat_builder'&&ownedTools.includes('habitat_builder')){
    show('BUILD','build','BUILD','build');message='HABITAT BUILDER READY';
  }else if(aim?.kind==='drop'){
    show(`TAKE ${RESOURCE_LABELS[aim.object.type]?.toUpperCase()||'ITEM'}`,'take','TAKE','drop');
    interact.dataset.dropId=aim.id;message=`${RESOURCE_LABELS[aim.object.type]?.toUpperCase()||'ITEM'} · ${aim.distance.toFixed(1)} M`;
  }else if(aim?.kind==='cache'){
    show('OPEN SUPPLY CRATE','cache','OPEN','cache');interact.dataset.cacheId=aim.id;message=`SUPPLY CRATE · ${aim.distance.toFixed(1)} M`;
  }else if(aim?.kind==='resource'){
    const plant=aim.object.type==='kelp';
    show(plant?(selected==='knife'?'CUT CREEPVINE':'EQUIP KNIFE'):`BREAK ${RESOURCE_LABELS[aim.object.type].toUpperCase()}`,plant?'cut':'break',plant?'CUT':'BREAK','resource');
    interact.dataset.resourceId=aim.id;message=`${RESOURCE_LABELS[aim.object.type].toUpperCase()} · ${aim.distance.toFixed(1)} M`;
  }else if(scanAim){
    message=`${scanAim.name.toUpperCase()} · ${scanAim.distance.toFixed(1)} M · SCANNER LOCK`;targetKind='fauna';
  }else if(faunaAim){
    show(`CATCH ${faunaAim.name.toUpperCase()}`,'harvest','CATCH','fauna');message=`${faunaAim.name.toUpperCase()} · ${faunaAim.distance.toFixed(1)} M`;
  }
  targetLabel.textContent=message;
  updateReticleFeedback(targetKind,message);
}

function updateResourcePrompt() { updateInteractionPrompt(); }

function useSelectedHotbarItem() {
  const selected=getSelectedHotbarItem();
  if(selected==='flashlight'&&ownedTools.includes('flashlight')){
    triggerToolAnimation('use');
    flashlightEnabled=!flashlightEnabled;
    if(viewModel?.userData.flashlightBeam)viewModel.userData.flashlightBeam.visible=flashlightEnabled;
    if(viewModel?.userData.flashlightCone)viewModel.userData.flashlightCone.visible=flashlightEnabled;
    if(viewModel?.userData.flashlightNearLight)viewModel.userData.flashlightNearLight.intensity=flashlightEnabled?2.25:0;
    if(viewModel?.userData.flashlightLensMat)viewModel.userData.flashlightLensMat.emissiveIntensity=flashlightEnabled?1.8:0.04;
    playSfx(flashlightEnabled?'flashlightOn':'flashlightOff');updateInteractionPrompt();showToast(flashlightEnabled?'Senter dinyalakan.':'Senter dimatikan.');return;
  }
  if(selected==='seaglide'){
    if(equipment.seaglideCharge>=100){showToast('Baterai Seaglide masih penuh.');return;}
    if((inventory.battery||0)<1){showToast('Tidak ada baterai cadangan di Backpack.');return;}
    triggerToolAnimation('use');
    inventory.battery-=1;equipment.seaglideCharge=100;seaglideChargeUiBucket=100;
    renderInventory();renderHotbar();updateSurvivalHud();markUnsaved();playSfx('craft');showToast('Baterai Seaglide diganti · daya 100%.');return;
  }
  if(selected==='medkit'){triggerToolAnimation('use');useMedkit();return;}
  if(selected==='ration'){triggerToolAnimation('use');useRation();return;}
  if(selected==='water'){triggerToolAnimation('use');useWater();return;}
  if(selected==='fish_meat'){triggerToolAnimation('use');useFreshFish();return;}
  showToast('Item ini tidak memiliki aksi pakai langsung.');
}

function cancelPendingKnifeAttack() {
  pendingKnifeAttack = null;
  if (viewModel?.userData) { viewModel.userData.actionTimer = 0; viewModel.userData.actionType = ''; }
}

function attackWithKnife() {
  if(!gameActive||gamePaused||getSelectedHotbarItem()!=='knife'||!ownedTools.includes('knife')){showToast('Pilih Survival Knife pada Quick Slot untuk menyerang.');return;}
  const now=performance.now();
  if(now-lastKnifeAttackAt<KNIFE_ATTACK_PROFILE.cooldownMs||pendingKnifeAttack)return;
  lastKnifeAttackAt=now;
  pendingKnifeAttack={elapsed:0,hitApplied:false};
  triggerToolAnimation('knife');
  playSfx('knife');
  // Do not pause, slow, or lock the diver. The hit is resolved at the blade's
  // active animation frame using the diver's live movement and current aim.
}

function updatePendingKnifeAttack(dt) {
  if(!pendingKnifeAttack)return;
  pendingKnifeAttack.elapsed+=Math.max(0,Math.min(Number(dt)||0,0.05));
  if(!pendingKnifeAttack.hitApplied&&pendingKnifeAttack.elapsed>=KNIFE_ATTACK_PROFILE.hitFrame){
    pendingKnifeAttack.hitApplied=true;
    const pitch=clamp(player.pitch,-1.1,1.1);
    const direction=new THREE.Vector3(Math.sin(player.yaw)*Math.cos(pitch),-Math.sin(pitch),-Math.cos(player.yaw)*Math.cos(pitch)).normalize();
    const origin=new THREE.Vector3(player.position.x,player.position.y+0.55,player.position.z);
    const hit=faunaDirector?.attackTarget(player.position,origin,direction,KNIFE_ATTACK_PROFILE.range,KNIFE_ATTACK_PROFILE.damage,{playerVelocity:player.velocity,leadTime:KNIFE_ATTACK_PROFILE.leadTime,sweepRadius:KNIFE_ATTACK_PROFILE.baseSweepRadius});
    if(!hit){showToast('Pisau mengayun. Tidak ada target dalam jangkauan.');}
    else{
      playSfx('faunaHit');
      spawnDebrisBurst(hit.position,0x9cc9c4,6);
      if(hit.killed){
        if(hit.speciesKind==='fish'&&!hit.hostile)spawnWorldDrop('fish_meat',hit.position,1);
        playSfx('impact');showToast(`${hit.name} berhasil diusir. Sisa biologis dapat dikumpulkan bila tersedia.`);
      }else showToast(`${hit.name} terkena serangan. Jaga jarak dari predator.`);
    }
  }
  if(pendingKnifeAttack.elapsed>=KNIFE_ATTACK_PROFILE.duration)pendingKnifeAttack=null;
}

function interactNearby() {
  const action=$('interact-btn')?.dataset.action;
  if(action==='vehicle-bay') { openVehicleBay(); return; }
  if(action==='vehicle-enter') { enterVehicle($('interact-btn')?.dataset.vehicleId); return; }
  if(action==='vehicle-exit') { exitActiveVehicle(); return; }
  if(action==='fabricator') { openFabricator(); return; }
  if(action==='storage') { openStorage(); return; }
  if(action==='mission') { activateLifepod(); return; }
  if(action==='build') { openBuildMenu(); return; }
  if(action==='confirm-build') { commitBuildPreview(); return; }
  if(action==='break' || action==='cut') { gatherNearbyResource(); return; }
  if(action==='harvest') { harvestNearbyFish(); return; }
  if(action==='enter') { enterHabitat(findNearbyHabitat(16)); return; }
  if(action==='cache'){ openSupplyCache($('interact-btn').dataset.cacheId||'');return; }
  if(action==='take') {
    const id=$('interact-btn').dataset.dropId;
    const index=floatingDrops.findIndex(item=>item.id===id);
    if(index<0){updateInteractionPrompt();return;}
    const drop=floatingDrops[index];
    if(!canFitResource(drop.type,drop.amount)){showToast('Inventory penuh. Kosongkan beberapa slot terlebih dahulu.');return;}
    inventory[drop.type]=clamp((inventory[drop.type]||0)+drop.amount,0,999);
    disposeWorldDrop(drop);floatingDrops.splice(index,1);
    renderInventory();playSfx('collect');
    if(drop.type==='fish_meat')advanceMission('fish');else recordMissionMaterial();
    markUnsaved();showToast(`+${drop.amount} ${RESOURCE_LABELS[drop.type]}`);return;
  }
  showToast('Tidak ada objek interaksi dalam bidikan.');
}

function gatherNearbyResource() {
  const target=getAimedWorldTarget();
  if(!target||target.kind!=='resource'){showToast('Arahkan tanda bidik ke Ore atau tanaman terlebih dahulu.');updateInteractionPrompt();return;}
  if (target.object.type === 'kelp' && getSelectedHotbarItem() !== 'knife') { showToast('Pilih Survival Knife untuk memotong Creepvine.'); return; }
  const node=resourceNodes.get(target.id);
  if(!node||node.breaking)return;
  const position=node.mesh.getWorldPosition(new THREE.Vector3());
  const color=node.type==='copper'?0xc47b4b:node.type==='glowcap'?0x83d9d0:node.type==='kelp'?0x53be94:node.type==='quartz'?0xb8eff0:node.type==='silver'?0xc3ced8:0x9fb2b7;
  node.breaking=true;
  triggerToolAnimation(node.type==='kelp'?'knife':'mine');
  playSfx(node.type==='kelp'?'knife':'oreHit',node.mesh?.getWorldPosition(tmpVector)||player.position);
  spawnDebrisBurst(position,color,3);
  resourceBreakActions.push({id:target.id,node,type:node.type,position,color,elapsed:0,duration:node.type==='kelp'?.28:.46,baseScale:node.mesh.scale.clone(),baseRotation:node.mesh.rotation.clone(),crackBurst:false});
  updateInteractionPrompt();
  showToast(node.type==='kelp'?'Memotong Creepvine...':'Memecahkan deposit mineral...');
}

function getAimedHarvestTarget(){
  const pitch=clamp(player.pitch,-1.1,1.1);
  const direction=new THREE.Vector3(Math.sin(player.yaw)*Math.cos(pitch),-Math.sin(pitch),-Math.cos(player.yaw)*Math.cos(pitch)).normalize();
  const origin=new THREE.Vector3(player.position.x,player.position.y+0.55,player.position.z);
  return faunaDirector?.getHarvestTarget(player.position,6.5,{origin,direction,minAlignment:0.945})||null;
}
function harvestNearbyFish(){
  const fish=getAimedHarvestTarget();
  if(!fish){showToast('Arahkan tanda bidik ke fauna kecil sebelum mengumpulkan sampel.');return;}
  const harvested=faunaDirector.harvestNearest(player.position,6.5,fish.id);
  if(!harvested){showToast('Fauna tersebut sudah menjauh.');return;}
  spawnDebrisBurst(harvested.position,0x9cc9c4,7);
  spawnWorldDrop('fish_meat',harvested.position,1);
  playSfx('impact');
  showToast(`${harvested.name} berhasil ditangkap.`);
}

function useFreshFish(){
  if((inventory.fish_meat||0)<1){showToast('Tidak ada ikan segar di inventory.');return;}
  inventory.fish_meat-=1;survival.food=clamp(survival.food+22,0,100);survival.water=clamp(survival.water-1,0,100);
  updateSurvivalHud();renderInventory();renderHotbar();playSfx('eat');markUnsaved();showToast('Fresh Fish dikonsumsi · Food +22.');
}

function canAfford(cost) { return Object.entries(cost).every(([key, amount]) => (inventory[key] || 0) >= amount); }
function spendResources(cost) { for (const [key, amount] of Object.entries(cost)) inventory[key] -= amount; }
function getTankUpgradeCost(level=equipment.tankLevel||0) {
  const tier=Math.max(0,Math.floor(Number(level)||0));
  if(tier<4)return EQUIPMENT_RECIPES.tank.cost;
  const costs=[
    {titanium:5,lithium:4,magnetite:2,computer_chip:1},
    {titanium:7,lithium:5,magnetite:3,computer_chip:2},
    {titanium:9,lithium:7,magnetite:4,computer_chip:2,power_cell:1}
  ];
  return costs[Math.min(2,tier-4)];
}

function craftSupply(kind) {
  const recipes = {
    medkit: { cost:{fiber_mesh:1}, label:'First Aid Kit' },
    ration: { cost:{fish_meat:1}, label:'Cooked Fish' },
    water: { cost:{bleach:1}, label:'Filtered Water' }
  };
  const recipe=recipes[kind];
  if(!recipe || !canAfford(recipe.cost)){showToast('Material belum mencukupi.');return;}
  if(!canFitSupply(kind)){showToast('Inventory penuh. Kosongkan slot sebelum fabrikasi.');return;}
  spendResources(recipe.cost);
  if(kind==='medkit') survival.medkits=clamp(survival.medkits+1,0,20);
  else if(kind==='ration') survival.rations=clamp(survival.rations+1,0,20);
  else if(kind==='water') survival.waterBottles=clamp(survival.waterBottles+1,0,20);
  updateSurvivalHud();renderInventory();playSfx('craft');markUnsaved();
  if(kind==='medkit') advanceMission('craft');
  showToast(`${recipe.label} berhasil dibuat.`);
}

function craftEquipment(kind) {
  const recipe=EQUIPMENT_RECIPES[kind];
  if(!recipe)return;
  if(kind==='tank'&&equipment.tankLevel>=MAX_OXYGEN_TANK_LEVEL){showToast('Kapasitas O₂ sudah maksimum.');return;}
  if(kind!=='tank'&&equipment[kind]){showToast('Peralatan ini sudah dipasang.');return;}
  const cost=kind==='tank'?getTankUpgradeCost(equipment.tankLevel):recipe.cost;
  if(!canAfford(cost)){showToast('Material belum mencukupi.');return;}
  spendResources(cost);
  if(kind==='tank'){equipment.tankLevel+=1;survival.oxygen=clamp(survival.oxygen+75,0,getMaxOxygen());}
  else equipment[kind]=true;
  renderInventory();updateSurvivalHud();playSfx('craft');markUnsaved();
  showToast(kind==='tank'?`${recipe.label} terpasang · batas kedalaman aman ${oxygenTankDepthRating(equipment.tankLevel)} m.`:`${recipe.label} berhasil dipasang.`);
}

function openPda() {
  if (!gameActive) return;
  if (!ownedTools.includes('explorer_pda')) { showToast('Explorer PDA tidak tersedia di inventory.'); return; }
  gamePaused = true;
  renderPda();
  setVisibleScreen('pda');
}
function renderPda() {
  const biomeRoot=$('biome-log'), speciesRoot=$('species-log');
  if (!biomeRoot || !speciesRoot) return;
  biomeRoot.replaceChildren(); speciesRoot.replaceChildren();
  for (const biome of Object.values(BIOME_DATA)) {
    const known=knownBiomes.has(biome.id);
    const card=document.createElement('article'); card.className=`pda-entry ${known?'is-known':'is-unknown'}`;
    const title=document.createElement('strong'); title.textContent=known?biome.label:'Unknown region';
    const note=document.createElement('p'); note.textContent=known?biome.note:'Jelajahi area baru untuk mengumpulkan data lingkungan.';
    const status=document.createElement('small'); status.textContent=known?'ENVIRONMENT LOGGED':'NOT DISCOVERED';
    card.append(title,note,status); biomeRoot.append(card);
  }
  const records=faunaDirector?.getDiscoveryRecords?.() || [];
  if (!records.length) { const p=document.createElement('p'); p.className='panel-hint'; p.textContent='Belum ada spesies yang dipindai. Gunakan SCAN LIFE saat makhluk terlihat.'; speciesRoot.append(p); }
  for (const species of records) {
    const card=document.createElement('article'); card.className='pda-entry is-known';
    const title=document.createElement('strong'); title.textContent=species.name;
    const note=document.createElement('p'); note.textContent=`Kategori: ${species.kind} · Kedalaman umum: ${Math.abs(species.depth[0])}–${Math.abs(species.depth[1])} m`;
    const status=document.createElement('small'); status.textContent='FAUNA SCAN COMPLETE';
    card.append(title,note,status); speciesRoot.append(card);
  }
  $('pda-progress').textContent=`${knownBiomes.size}/${Object.keys(BIOME_DATA).length} BIOME LOGGED · ${records.length}/${FAUNA_SPECIES_COUNT} SPECIES SCANNED`;
  updateMissionUI();
}

function isHabitatPowered(inside = getInsideHabitat()) {
  if (!inside) return false;
  if (inside.type === 'lifepod') return true;
  return placedStructures.some(item => item.type === 'solar_array' && Math.hypot(item.x-inside.x, item.z-inside.z) < 85);
}

function openFabricator() {
  if (!gameActive) return;
  const inside = getInsideHabitat();
  if (!inside) { showToast('Fabricator hanya dapat digunakan dari dalam Lifepod atau Multipurpose Room.'); return; }
  if (!isHabitatPowered(inside)) { showToast('Habitat belum memiliki daya. Pasang Solar Panel terlebih dahulu.'); return; }
  gamePaused=true;fabricatorCategory='sustenance';renderFabricator();setVisibleScreen('fabricator');
  playSfx('fabricatorOpen');
  requestAnimationFrame(()=>{const card=UI.fabricator?.querySelector('.panel-card');if(card)card.scrollTop=0;});
}

function renderFabricator() {
  const tabs=$('fabricator-tabs'),root=$('fabricator-recipes');
  if(!tabs||!root)return;
  tabs.querySelectorAll('[data-fabricator-category]').forEach(tab=>tab.classList.toggle('active',tab.dataset.fabricatorCategory===fabricatorCategory));
  root.replaceChildren();
  const category=FABRICATOR_CATEGORIES[fabricatorCategory]||FABRICATOR_CATEGORIES.sustenance;
  for(const recipe of category.recipes){
    const card=document.createElement('article');card.className='fabricator-recipe';
    const icon=document.createElement('img');icon.src=`./icons/items/${recipe.icon}.png`;icon.alt='';
    const info=document.createElement('div');info.className='fabricator-recipe-info';
    const title=document.createElement('strong');
    title.textContent=recipe.id==='tank'?`O₂ TANK MK ${equipment.tankLevel+2} · ${oxygenTankDepthRating(equipment.tankLevel+1)} M`:recipe.name;
    const cost=document.createElement('small');
    const recipeCost=recipe.id==='tank'?getTankUpgradeCost(equipment.tankLevel):recipe.cost;
    cost.textContent=Object.entries(recipeCost).map(([key,value])=>`${value} ${RESOURCE_LABELS[key]||key}`).join(' · ')+(recipe.id==='tank'?` · SAFE DEPTH ${oxygenTankDepthRating(equipment.tankLevel+1)} M`:'');
    info.append(title,cost);
    const button=document.createElement('button');button.type='button';button.className='small-action';button.textContent='FABRICATE';
    const owned=recipe.id==='tank'?equipment.tankLevel>=MAX_OXYGEN_TANK_LEVEL:['fins','rebreather'].includes(recipe.id)?Boolean(equipment[recipe.id]):['habitat_builder','repair_tool','seaglide'].includes(recipe.id)?ownedTools.includes(recipe.id):false;
    const supply= ['medkit','ration','water'].includes(recipe.id);
    const resourceOutput=ITEM_DEFS[recipe.id]&&['glass','silicone','fiber_mesh','battery','wiring_kit','computer_chip','power_cell','lubricant','bleach'].includes(recipe.id);
    const full=supply?!canFitSupply(recipe.id):resourceOutput&&!canFitResource(recipe.id,1);
    button.disabled=owned||!canAfford(recipeCost)||full;
    button.textContent=owned?'OWNED / INSTALLED':full?'INVENTORY FULL':'FABRICATE';
    button.addEventListener('click',()=>craftFabricatorRecipe(recipe.id));
    card.append(icon,info,button);root.append(card);
  }
}

function craftFabricatorRecipe(id) {
  const inside=getInsideHabitat();
  if(!inside||!isHabitatPowered(inside)){showToast('Fabricator harus digunakan dari dalam habitat yang memiliki daya.');return;}
  if(['medkit','ration','water'].includes(id)){craftSupply(id);renderFabricator();return;}
  if(['tank','fins','rebreather'].includes(id)){craftEquipment(id);renderFabricator();return;}
  const resourceRecipes={
    glass:{cost:{quartz:2},label:'Glass'},silicone:{cost:{kelp:2},label:'Silicone Rubber'},
    fiber_mesh:{cost:{kelp:2},label:'Fiber Mesh'},battery:{cost:{copper:1,quartz:1},label:'Battery'},
    wiring_kit:{cost:{silver:2},label:'Wiring Kit'},computer_chip:{cost:{quartz:1,copper:1,coral:1},label:'Computer Chip'},
    power_cell:{cost:{battery:2,silicone:1},label:'Power Cell'},lubricant:{cost:{kelp:2},label:'Lubricant'},bleach:{cost:{salt:1,coral:1},label:'Bleach'}
  };
  if(resourceRecipes[id]){
    const recipe=resourceRecipes[id];
    if(!canAfford(recipe.cost)){showToast('Material belum mencukupi.');return;}
    if(!canFitResource(id,1)){showToast('Tidak ada ruang di inventory untuk hasil fabrikasi.');return;}
    spendResources(recipe.cost);inventory[id]=clamp((inventory[id]||0)+1,0,999);
    renderInventory();markUnsaved();playSfx('craft');showToast(`${recipe.label} berhasil dibuat.`);renderFabricator();return;
  }
  const tools={
    habitat_builder:{cost:{titanium:2,copper:1,battery:1}},
    repair_tool:{cost:{titanium:1,silicone:1,battery:1}},
    seaglide:{cost:{battery:1,copper:1,titanium:1}}
  };
  if(tools[id]){
    if(ownedTools.includes(id)){showToast(`${ITEM_DEFS[id].name} sudah dimiliki.`);return;}
    if(!canAfford(tools[id].cost)){showToast('Material belum mencukupi.');return;}
    const trial=[...ownedTools,id];
    if(packInventory(getInventoryEntries(inventory,trial)).overflow.length){showToast('Inventory tidak memiliki cukup ruang untuk alat baru.');return;}
    spendResources(tools[id].cost);ownedTools.push(id);
    if(id==='seaglide'){equipment.seaglideCharge=100;seaglideChargeUiBucket=100;}
    const empty=hotbarSlots.findIndex(value=>!value);
    const slot=empty>=0?empty:3;hotbarSlots[slot]=id;selectedHotbarIndex=slot;
    renderInventory();markUnsaved();playSfx('craft');showToast(`${ITEM_DEFS[id].name} berhasil dibuat dan dipasang di Quick Slot ${slot+1}.`);renderFabricator();
  }
}

function openBuildMenu() {
  if (!gameActive) return;
  if (!ownedTools.includes('habitat_builder') || getSelectedHotbarItem() !== 'habitat_builder') {
    showToast('Pilih Habitat Builder pada Slot Cepat untuk membuka mode pembangunan.'); return;
  }
  gamePaused = true;
  updateBuildButtons();
  setVisibleScreen('build');
}

function updateBuildButtons() {
  document.querySelectorAll('[data-build]').forEach(button => {
    const recipe = BUILD_RECIPES[button.dataset.build];
    button.disabled = !recipe || !canAfford(recipe.cost) || !ownedTools.includes('habitat_builder');
  });
}

function clearBuildPreview() {
  if (buildPreviewGroup) {
    scene?.remove(buildPreviewGroup);
    const geometries=new Set(),materials=new Set();
    buildPreviewGroup.traverse(object=>{
      if(object.geometry)geometries.add(object.geometry);
      const list=Array.isArray(object.material)?object.material:[object.material];
      for(const material of list)if(material)materials.add(material);
    });
    geometries.forEach(geometry=>geometry.dispose());
    materials.forEach(material=>material.dispose());
  }
  buildPreviewGroup=null;pendingBuildType='';buildPreviewValid=false;buildPreviewElapsed=0;
}

function addBuildGhostPart(group, geometry, material, position=[0,0,0], rotation=[0,0,0], scale=null) {
  const mesh=new THREE.Mesh(geometry,material);
  mesh.position.set(...position);mesh.rotation.set(...rotation);
  if(scale)mesh.scale.set(...scale);
  mesh.frustumCulled=false;mesh.renderOrder=12;group.add(mesh);
  const edges=new THREE.LineSegments(new THREE.EdgesGeometry(geometry,22),new THREE.LineBasicMaterial({color:0x7effe5,transparent:true,opacity:.86,depthTest:false}));
  edges.position.copy(mesh.position);edges.rotation.copy(mesh.rotation);edges.scale.copy(mesh.scale);edges.renderOrder=13;group.add(edges);
  return mesh;
}

function createBuildPreview(type) {
  clearBuildPreview();
  const ghost=new THREE.Group();
  const material=new THREE.MeshBasicMaterial({color:0x55f4dd,transparent:true,opacity:.28,wireframe:false,depthWrite:false,side:THREE.DoubleSide});
  const glow=new THREE.MeshBasicMaterial({color:0x8affec,transparent:true,opacity:.62,depthWrite:false,side:THREE.DoubleSide});
  if(type==='compartment'){
    addBuildGhostPart(ghost,new THREE.CylinderGeometry(4.35,4.45,.28,32),material,[0,.18,0]);
    addBuildGhostPart(ghost,new THREE.SphereGeometry(4.35,24,14,0,Math.PI*2,0,Math.PI/2),material,[0,.34,0]);
    for(let i=0;i<6;i++){const a=i*Math.PI/3;addBuildGhostPart(ghost,new THREE.CylinderGeometry(.1,.14,4.2,8),glow,[Math.cos(a)*4,2.35,Math.sin(a)*4]);}
  }else if(type==='foundation'){
    addBuildGhostPart(ghost,new THREE.CylinderGeometry(3.4,3.65,.42,24),material,[0,.22,0]);
    addBuildGhostPart(ghost,new THREE.TorusGeometry(3.1,.09,8,28),glow,[0,.48,0],[Math.PI/2,0,0]);
  }else if(type==='storage_locker'){
    addBuildGhostPart(ghost,new THREE.BoxGeometry(2.1,2.5,1.7),material,[0,1.35,0]);
    addBuildGhostPart(ghost,new THREE.BoxGeometry(1.75,2.12,.08),glow,[0,1.38,-.88]);
  }else if(type==='solar_array'){
    addBuildGhostPart(ghost,new THREE.CylinderGeometry(.12,.2,3.5,10),glow,[0,1.75,0]);
    for(const side of [-1,1])addBuildGhostPart(ghost,new THREE.BoxGeometry(2.2,.12,1.6),material,[side*1.25,3.35,0],[0,0,side*.16]);
  }else if(type==='beacon'){
    addBuildGhostPart(ghost,new THREE.CylinderGeometry(.13,.2,2.5,10),material,[0,1.2,0]);
    addBuildGhostPart(ghost,new THREE.SphereGeometry(.28,12,8),glow,[0,2.55,0]);
  }else if(type==='vehicle_bay'){
    addBuildGhostPart(ghost,new THREE.BoxGeometry(8.8,.42,7.2),material,[0,.28,0]);
    for(const side of [-1,1]){
      addBuildGhostPart(ghost,new THREE.BoxGeometry(.22,2.1,6.5),material,[side*4.15,1.45,0]);
      addBuildGhostPart(ghost,new THREE.CylinderGeometry(.13,.18,4.2,10),glow,[side*3.7,3,-2.8]);
    }
    addBuildGhostPart(ghost,new THREE.TorusGeometry(2.25,.16,8,30,Math.PI),glow,[0,3.5,-2.8]);
    addBuildGhostPart(ghost,new THREE.BoxGeometry(1.45,1.9,.82),material,[0,1.45,3]);
  }
  const groundRing=new THREE.Mesh(new THREE.TorusGeometry(type==='compartment'?4.5:type==='foundation'?3.7:type==='storage_locker'?1.5:type==='solar_array'?2.4:type==='vehicle_bay'?5.5:.7,.055,6,48),glow);
  groundRing.rotation.x=Math.PI/2;groundRing.position.y=.12;ghost.add(groundRing);
  ghost.userData.materials=[material,glow];ghost.userData.groundRing=groundRing;
  ghost.frustumCulled=false;scene.add(ghost);
  buildPreviewGroup=ghost;pendingBuildType=type;buildPreviewValid=false;
}

function getBuildClearanceRadius(type) {
  return ({compartment:4.8,foundation:3.9,storage_locker:1.8,solar_array:2.6,beacon:.9,vehicle_bay:6.2})[type]||2;
}

function updateBuildPreview(dt=0) {
  if(!pendingBuildType||!buildPreviewGroup||!gameActive||gamePaused)return;
  buildPreviewElapsed+=dt;
  const recipe=BUILD_RECIPES[pendingBuildType];
  const fx=Math.sin(player.yaw),fz=-Math.cos(player.yaw);
  const distance=pendingBuildType==='compartment'?10:pendingBuildType==='vehicle_bay'?13:8;
  const x=player.position.x+fx*distance,z=player.position.z+fz*distance;
  const ground=heightAt(x,z);
  const radius=getBuildClearanceRadius(pendingBuildType);
  const samples=[[0,0],[radius*.72,0],[-radius*.72,0],[0,radius*.72],[0,-radius*.72]];
  const heights=samples.map(([sx,sz])=>heightAt(x+sx,z+sz));
  const slope=Math.max(...heights)-Math.min(...heights);
  const overlaps=placedStructures.some(item=>Math.hypot(item.x-x,item.z-z)<radius+getBuildClearanceRadius(item.type)*.82);
  const overlapsLifepod=lifepodGroup&&Math.hypot(lifepodGroup.position.x-x,lifepodGroup.position.z-z)<radius+3.2;
  const valid=Boolean(recipe&&canAfford(recipe.cost)&&ground<-7&&Math.abs(player.position.y-ground)<15&&slope<1.85&&!overlaps&&!overlapsLifepod&&player.position.distanceTo(new THREE.Vector3(x,ground,z))>=4.5);
  buildPreviewValid=valid;
  buildPreviewGroup.position.set(x,ground+.08,z);buildPreviewGroup.rotation.y=player.yaw;
  const tint=valid?0x55f4dd:0xff6475;
  for(const mat of buildPreviewGroup.userData.materials||[])mat.color.setHex(tint);
  const pulse=.52+.22*Math.sin(buildPreviewElapsed*4.2);
  if(buildPreviewGroup.userData.groundRing){buildPreviewGroup.userData.groundRing.material.opacity=pulse;buildPreviewGroup.userData.groundRing.scale.setScalar(1+Math.sin(buildPreviewElapsed*3.2)*.025);}
  buildPreviewGroup.userData.materials?.forEach((mat,index)=>{mat.opacity=index===0?.24+.06*Math.sin(buildPreviewElapsed*3.6):.45+.18*Math.sin(buildPreviewElapsed*4.2);});
  buildPreviewGroup.traverse(object=>{if(object.isLineSegments&&object.material)object.material.color.setHex(valid?0x7effe5:0xff8a96);});
}

function cancelBuildPreview(notify=true) {
  if(!pendingBuildType)return;
  clearBuildPreview();
  updateInteractionPrompt();
  if(notify)showToast('Mode hologram pembangunan dibatalkan.');
}

function commitBuildPreview() {
  const type=pendingBuildType;
  if(!type)return;
  updateBuildPreview(0);
  if(!buildPreviewValid){playSfx('tap');showToast('Lokasi tidak valid. Cari dasar yang lebih rata, bebas tabrakan, dan cukup material.');return;}
  const recipe=BUILD_RECIPES[type];
  const {x,y,z}=buildPreviewGroup.position;
  if(!recipe||!canAfford(recipe.cost)){showToast('Material pembangunan tidak lagi mencukupi.');return;}
  spendResources(recipe.cost);
  triggerToolAnimation('builder');
  const record={id:`build-${Date.now()}-${Math.floor(Math.random()*9999)}`,type,x,y,z,yaw:player.yaw,builtAt:Date.now()};
  placedStructures.push(record);
  publishSharedWorldEvent('structure_placed',record.id,{type:record.type,x:record.x,y:record.y,z:record.z,yaw:record.yaw});
  const cx=Math.floor(x/CHUNK_SIZE),cz=Math.floor(z/CHUNK_SIZE),chunk=chunks.get(`${cx},${cz}`);
  if(chunk)addBuiltStructure(chunk.group,record,cx*CHUNK_SIZE,cz*CHUNK_SIZE);
  clearBuildPreview();
  updateBuildButtons();renderInventory();playSfx('build');markUnsaved();advanceMission('build');
  showToast(`${recipe.label} berhasil dibangun dari hologram pada lokasi yang valid.`);
  updateInteractionPrompt();
}

function placeStructure(type) {
  if (!ownedTools.includes('habitat_builder') || getSelectedHotbarItem() !== 'habitat_builder') { showToast('Pilih Habitat Builder pada Slot Cepat terlebih dahulu.'); return; }
  const recipe=BUILD_RECIPES[type];
  if(!recipe)return;
  if(!canAfford(recipe.cost)){showToast('Material pembangunan belum cukup.');return;}
  createBuildPreview(type);
  gamePaused=false;
  setVisibleScreen('hud');$('hud')?.classList.remove('hidden');
  playSfx('hologram');
  showToast('Hologram aktif. Arahkan lokasi konstruksi, lalu tekan BUILD untuk mengonfirmasi. Tekan Esc untuk membatalkan.');
  updateBuildPreview(0);updateInteractionPrompt();
  enterFullscreenLandscape();
}

function openStorage() {
  if (!nearestBuiltStructure('storage_locker',13)) { showToast('Dekati Wall Locker terlebih dahulu.'); return; }
  gamePaused=true;renderStorage();setVisibleScreen('storage');
}

function renderStorage() {
  const root=$('locker-storage-list');
  const summary=$('locker-storage-summary');
  if(!root||!summary)return;
  root.replaceChildren();
  const stored=Object.entries(lockerStorage).filter(([,amount])=>amount>0);
  const total=stored.reduce((sum,[,amount])=>sum+amount,0);
  summary.textContent=`${total} MATERIAL STORED · MAX 99 PER TYPE`;
  if(!stored.length){const empty=document.createElement('p');empty.className='panel-hint';empty.textContent='Locker masih kosong.';root.append(empty);return;}
  for(const [key,amount] of stored){
    const row=document.createElement('div');row.className='storage-material-row';
    const icon=document.createElement('img');icon.src=`./icons/items/${ITEM_DEFS[key]?.icon||key}.png`;icon.alt='';
    const name=document.createElement('span');name.textContent=RESOURCE_LABELS[key]||key;
    const count=document.createElement('b');count.textContent=String(amount);
    row.append(icon,name,count);root.append(row);
  }
}

function lockerTransfer(direction) {
  if (!nearestBuiltStructure('storage_locker',13)) { showToast('Dekati Wall Locker terlebih dahulu.'); return; }
  let moved=0;
  for (const key of Object.keys(INVENTORY_DEFAULTS)) {
    if (direction==='store') {
      const amount=Math.max(0,inventory[key]||0);
      const room=Math.max(0,99-(lockerStorage[key]||0));
      const transfer=Math.min(amount,room);
      inventory[key]-=transfer;lockerStorage[key]=(lockerStorage[key]||0)+transfer;moved+=transfer;
    } else {
      let transfer=Math.max(0,lockerStorage[key]||0);
      while(transfer>0&&!canFitResource(key,transfer))transfer--;
      if(transfer){inventory[key]=(inventory[key]||0)+transfer;lockerStorage[key]-=transfer;moved+=transfer;}
    }
  }
  renderInventory();renderStorage();updateSurvivalHud();markUnsaved();
  showToast(moved?`${direction==='store'?'Material disimpan':'Material diambil'} · ${moved} unit`:'Tidak ada material yang dapat dipindahkan atau ruang backpack penuh.');
}

function renderSlotCards(containerId, mode) {
  const root = $(containerId);
  root.replaceChildren();
  for (let index = 0; index < 5; index++) {
    const record = slots[index];
    const card = document.createElement('div');
    card.className = 'slot-card';
    const info = document.createElement('div');
    info.className = 'slot-info';
    const title = document.createElement('div');
    title.className = 'slot-title';
    title.textContent = `SLOT ${String(index + 1).padStart(2, '0')}`;
    const meta = document.createElement('div');
    meta.className = 'slot-meta';
    meta.textContent = record ? `Last saved: ${formatTime(record.savedAt)} · ${Math.round(record.position?.x || 0)}, ${Math.round(record.position?.z || 0)}` : 'EMPTY · No expedition data';
    info.append(title, meta);
    const actions = document.createElement('div');
    actions.className = 'slot-actions';
    const action = document.createElement('button');
    action.type = 'button';
    action.className = 'slot-action';
    action.textContent = mode === 'new' ? (record ? 'REPLACE' : 'START') : 'LOAD';
    action.disabled = mode === 'load' && !record;
    action.addEventListener('click', () => {
      if (mode === 'new') {
        if (record && !window.confirm(`Timpa data Slot ${index + 1}?`)) return;
        startGame(index, true);
      } else if (record) startGame(index, false);
    });
    actions.append(action);
    if (mode === 'load' && record) {
      const del = document.createElement('button');
      del.type = 'button'; del.className = 'slot-action'; del.textContent = 'DEL';
      del.setAttribute('aria-label', `Hapus Slot ${index + 1}`);
      del.addEventListener('click', () => {
        if (!window.confirm(`Hapus data Slot ${index + 1}?`)) return;
        slots[index] = null; saveJson(STORAGE.slots, slots);
        renderSlotCards(containerId, mode);
      });
      actions.append(del);
    }
    card.append(info, actions);
    root.append(card);
  }
}

async function startGame(slotIndex, isNew) {
  runtimeFrameError = null;
  clearRemoteDivers();
  startAmbient();
  if (ambientContext?.state === 'suspended') ambientContext.resume().catch(() => {});
  await enterFullscreenLandscape();
  activeSlot = slotIndex;
  const record = isNew ? null : normalizeSaveRecord(slots[slotIndex]);
  if (!isNew && !record) { showToast('Slot rusak atau tidak valid. Pulihkan backup atau pilih slot lain.'); return; }
  if (isNew) {
    if(lifepodGroup){scene.remove(lifepodGroup);disposeObjectTree(lifepodGroup);lifepodGroup=null;}
    for(const drop of floatingDrops)disposeWorldDrop(drop);floatingDrops=[];
    storyState={...STORY_DEFAULTS,counters:{materials:0},completed:[]};
    player.position.set(0, -7, 0);
    respawnPoint.set(0, -7, 0);
    player.velocity.set(0,0,0);
    player.yaw = 0;
    player.pitch = 0.08;
    survival = { ...SURVIVAL_DEFAULTS };
    oxygenTickTimer=0;
    collectedCaches = new Set();
    inventory = { ...INVENTORY_DEFAULTS };
    equipment = { ...EQUIPMENT_DEFAULTS };
    vehicleFleet = normalizeVehicleFleet(null);activeVehicleId=null;activeVehicleVelocity.set(0,0,0);
    ownedTools = [...STARTER_TOOLS];
    hotbarSlots = ['scanner','knife','flashlight',null,null];
    selectedHotbarIndex = 0;
    hasUnsavedChanges = false;
    lastSavedRecord = null;
    survival.oxygen = getMaxOxygen();
    lockerStorage = { ...INVENTORY_DEFAULTS };
    knownBiomes = new Set();
    collectedResources = new Set();
    placedStructures = [];
    faunaDirector?.setDiscoveries([]);
  } else {
    if(lifepodGroup){scene.remove(lifepodGroup);lifepodGroup=null;}
    storyState = record.story && typeof record.story === 'object'
      ? { ...STORY_DEFAULTS, ...record.story, counters:{...STORY_DEFAULTS.counters,...(record.story.counters||{})}, completed:Array.isArray(record.story.completed)?record.story.completed:[] }
      : { ...STORY_DEFAULTS, introSeen:true, missionIndex:1, counters:{materials:0}, completed:['lifepod'] };
    player.position.set(record.position?.x || 0, clamp(record.position?.y ?? -7, -MAX_DIVE_DEPTH, 12), record.position?.z || 0);
    player.velocity.set(0,0,0);
    player.yaw = record.yaw || 0;
    player.pitch = record.pitch ?? 0.08;
    survival = { ...SURVIVAL_DEFAULTS, ...(record.survival && typeof record.survival === 'object' ? record.survival : {}) };
    collectedCaches = new Set(Array.isArray(record.collectedCaches) ? record.collectedCaches : []);
    inventory = { ...INVENTORY_DEFAULTS, ...(record.inventory && typeof record.inventory === 'object' ? record.inventory : {}) };
    equipment = { ...EQUIPMENT_DEFAULTS, ...(record.equipment && typeof record.equipment === 'object' ? record.equipment : {}) };
    vehicleFleet=normalizeVehicleFleet(record.vehicles);activeVehicleId=record.activeVehicleId&&vehicleFleet[record.activeVehicleId]?.deployed?record.activeVehicleId:null;activeVehicleVelocity.set(0,0,0);
    ownedTools = Array.isArray(record.ownedTools) ? [...new Set(record.ownedTools.filter(id => ITEM_DEFS[id]?.kind === 'tool'))] : [...STARTER_TOOLS];
    hotbarSlots = Array.isArray(record.hotbar) ? Array.from({length:5},(_,index)=>record.hotbar[index] || null) : ['scanner','knife','flashlight',null,null];
    hotbarSlots = hotbarSlots.map(item => item === 'explorer_pda' ? null : item);
    selectedHotbarIndex = clamp(Number(record.selectedHotbar)||0,0,4);
    hasUnsavedChanges = false;
    lockerStorage = { ...INVENTORY_DEFAULTS, ...(record.lockerStorage && typeof record.lockerStorage === 'object' ? record.lockerStorage : {}) };
    knownBiomes = new Set(Array.isArray(record.knownBiomes) ? record.knownBiomes.filter(id => BIOME_DATA[id]) : []);
    collectedResources = new Set(Array.isArray(record.collectedResources) ? record.collectedResources : []);
    placedStructures = Array.isArray(record.placedStructures) ? record.placedStructures : [];
    faunaDirector?.setDiscoveries(record.discoveries || []);
  }
  survival = Object.fromEntries(Object.entries(SURVIVAL_DEFAULTS).map(([key, fallback]) => {
    const value = Number(survival[key] ?? fallback);
    return [key, clamp(Number.isFinite(value) ? value : fallback, 0, key === 'medkits' || key === 'rations' || key === 'waterBottles' ? 20 : key === 'oxygen' ? getMaxOxygen() : 100)];
  }));
  survival.oxygen = clamp(survival.oxygen,0,getMaxOxygen());
  respawnPoint.copy(record?.respawnPoint ? new THREE.Vector3(record.respawnPoint.x,record.respawnPoint.y,record.respawnPoint.z) : new THREE.Vector3(0,-7,0));
  lastSavedRecord = !isNew && record ? JSON.parse(JSON.stringify(record)) : null;
  oxygenTickTimer = oxygenDamageTimer = hungerDamageTimer = thirstDamageTimer = depthStressTickTimer = 0;
  isRespawning = false;
  faunaDirector?.setQuality(getActiveGraphicsQuality(), activeGraphicsProfile?.faunaTextureSize || getGraphicsProfile().faunaTextureSize);
  currentBiome=getBiomeAt(player.position.x,player.position.y,player.position.z);
  faunaDirector?.setBiome(currentBiome.id);
  faunaDirector?.resetPopulation(player.position);
  cameraOrientationInitialized=false;
  gameActive = true;
  gamePaused = false;
  for (const chunk of chunks.values()) disposeChunk(chunk);
  chunks.clear();
  resourceNodes.clear();
  resourceBreakActions.length=0;
  clearBuildPreview();
  chunkCenterX = NaN; chunkCenterZ = NaN;
  updateChunks(true);
  syncVehicleMeshes();
  if(!isNew) { restoreWorldDrops(record?.droppedItems||[]); if(storyState.introSeen) makeLifePod(); }
  online.refreshWorldEvents?.();
  setVisibleScreen('hud');
  $('hud').classList.remove('hidden');
  updateMissionUI();
  updateNetworkLabels();
  updateSurvivalHud();
  renderHotbar();
  showToast(isNew ? `Ekspedisi dimulai · Slot ${slotIndex + 1}` : `Progres Slot ${slotIndex + 1} dimuat`);
  if (isNew) markUnsaved();
  if(isNew || !storyState.introSeen) startIntroCinematic();
}

function buildSaveRecord() {
  const previous = slots[activeSlot] || {};
  return normalizeSaveRecord({
    version: 11,
    savedAt: Date.now(),
    position: { x: player.position.x, y: player.position.y, z: player.position.z },
    yaw: player.yaw,
    pitch: player.pitch,
    survival: { ...survival, schemaVersion: SURVIVAL_STORAGE_VERSION },
    discoveries: faunaDirector?.getDiscoveries() || previous.discoveries || [],
    collectedCaches: [...collectedCaches],
    inventory: { ...inventory },
    equipment: { ...equipment },
    ownedTools: [...ownedTools],
    hotbar: [...hotbarSlots],
    selectedHotbar: selectedHotbarIndex,
    respawnPoint: { x:respawnPoint.x, y:respawnPoint.y, z:respawnPoint.z },
    lockerStorage: { ...lockerStorage },
    knownBiomes: [...knownBiomes],
    collectedResources: [...collectedResources],
    placedStructures: placedStructures.map(item => ({ ...item })),
    story: { ...storyState, counters:{ ...(storyState.counters||{}) }, completed:[...(storyState.completed||[])] },
    droppedItems: floatingDrops.slice(0,80).map(drop => ({ id:drop.id, type:drop.type, position:{x:drop.mesh.position.x,y:drop.mesh.position.y,z:drop.mesh.position.z} })),
    vehicles: normalizeVehicleFleet(vehicleFleet),
    activeVehicleId
  });
}

function markUnsaved() { hasUnsavedChanges = true; }

// No background saving: progress is committed only when the player selects Save.
function saveCurrentSlot() {
  if (activeSlot < 0 || activeSlot > 4) return false;
  const record = buildSaveRecord();
  slots[activeSlot] = record;
  const okay = saveJson(STORAGE.slots, slots);
  if (!okay) { showToast('Save gagal. Periksa ruang penyimpanan perangkat.'); return false; }
  lastSavedRecord = JSON.parse(JSON.stringify(record));
  hasUnsavedChanges = false;
  showToast(`Game tersimpan · SLOT ${activeSlot + 1}`);
  return true;
}

async function persistCurrentSlotNow() { return saveCurrentSlot(); }

function returnToMain() {
  if (gameActive && hasUnsavedChanges && !window.confirm('Perubahan belum disimpan. Keluar tanpa menyimpan?')) return;
  cancelPendingKnifeAttack();
  if (introSequence.active) cancelIntroCinematic();
  if(activeVehicleId && !exitActiveVehicle()){
    // The vehicle is already persisted as deployed. Detach the pilot state
    // safely rather than leaving the next menu frame in vehicle camera mode.
    activeVehicleId=null;activeVehicleVelocity.set(0,0,0);document.body.classList.remove('vehicle-active-hud');if(viewModel)viewModel.visible=true;
  }
  gameActive = false; gamePaused = false;
  $('hud').classList.add('hidden');
  setVisibleScreen('main');
}
function pauseGame() {
  if (!gameActive || gamePaused) return;
  cancelPendingKnifeAttack();
  gamePaused = true;
  if (introSequence.active) $('cinematic-overlay')?.classList.add('hidden');
  setVisibleScreen('pause');
}
function resumeGame() {
  if (!gameActive) return;
  runtimeFrameError = null;
  if (ambientContext?.state === 'suspended') ambientContext.resume().catch(() => {});
  gamePaused = false;
  setVisibleScreen('hud');
  $('hud').classList.remove('hidden');
  if (introSequence.active) {
    $('hud').classList.add('hidden');
    $('cinematic-overlay')?.classList.remove('hidden');
  }
}
function startAnimationLoop() {
  if (animationLoopRunning || applicationSuspended || webglContextLost || !rendererReady) return;
  animationLoopRunning = true;
  lastFrame = performance.now();
  animationFrameId = requestAnimationFrame(animate);
}

function stopAnimationLoop() {
  animationLoopRunning = false;
  if (animationFrameId) cancelAnimationFrame(animationFrameId);
  animationFrameId = 0;
}

function suspendApplication() {
  releaseTouchControls();
  if (gameActive && !gamePaused) pauseGame();
  applicationSuspended = true;
  stopAnimationLoop();
  $('menu-background-video')?.pause();
  if (ambientContext?.state === 'running') ambientContext.suspend().catch(() => {});
}

function resumeApplication() {
  applicationSuspended = Boolean(document.hidden || nativeAppInactive || webglContextLost);
  if (applicationSuspended) return;
  lastFrame = performance.now();
  if (ambientContext?.state === 'suspended' && gameActive && !gamePaused) ambientContext.resume().catch(() => {});
  if (UI.main && !UI.main.classList.contains('hidden')) {
    const video = $('menu-background-video');
    const playPromise = video?.play();
    if (playPromise?.catch) playPromise.catch(() => {});
  }
  startAnimationLoop();
  onResize();
}

function bindWebGLContextRecovery() {
  if (webglRecoveryBound || !canvas) return;
  webglRecoveryBound = true;
  canvas.addEventListener('webglcontextlost', event => {
    event.preventDefault();
    webglContextLost = true;
    suspendApplication();
    showToast('Koneksi grafis terputus. Ekspedisi dijeda sambil menunggu pemulihan GPU.');
  });
  canvas.addEventListener('webglcontextrestored', () => {
    webglContextLost = false;
    runtimeFrameError = null;
    try {
      renderer?.resetState?.();
      if (rendererReady) applySettings();
      showToast('Grafis berhasil dipulihkan. Tekan Resume untuk melanjutkan ekspedisi.');
      resumeApplication();
    } catch (error) {
      console.error('[The Abyssal] WebGL recovery failed:', error);
      showToast('Grafis belum dapat dipulihkan. Muat ulang game untuk mencoba kembali.');
    }
  });
}

function handleNativeBack() {
  if (UI.inventory && !UI.inventory.classList.contains('hidden')) { closeGamePanel(); return true; }
  if (UI.build && !UI.build.classList.contains('hidden')) { closeGamePanel(); return true; }
  if (UI.pda && !UI.pda.classList.contains('hidden')) { closeGamePanel(); return true; }
  if (UI.fabricator && !UI.fabricator.classList.contains('hidden')) { closeGamePanel(); return true; }
  if (UI.storage && !UI.storage.classList.contains('hidden')) { closeGamePanel(); return true; }
  if (UI.vehicle && !UI.vehicle.classList.contains('hidden')) { closeGamePanel(); return true; }
  if (UI.settings && !UI.settings.classList.contains('hidden')) { closeSettings(); return true; }
  if (UI.multiplayer && !UI.multiplayer.classList.contains('hidden')) { closeMultiplayer(); return true; }
  if (UI.pause && !UI.pause.classList.contains('hidden')) { resumeGame(); return true; }
  if (gameActive) { pauseGame(); return true; }
  const secondary = ['newGame','load','exit'].find(key => UI[key] && !UI[key].classList.contains('hidden'));
  if (secondary) { setVisibleScreen('main'); return true; }
  return false;
}

let nativeLifecycleBound = false;
async function bindNativeLifecycle() {
  if (nativeLifecycleBound || !window.Capacitor?.isNativePlatform?.()) return;
  try {
    const { App } = await import('@capacitor/app');
    await App.addListener('backButton', async () => {
      const active = document.activeElement;
      if (active && /^(INPUT|TEXTAREA|SELECT)$/.test(active.tagName)) {
        active.blur();
        return;
      }
      const handled = handleNativeBack();
      if (!handled) {
        if (window.confirm('Keluar dari The Abyssal?')) await App.exitApp();
      }
    });
    await App.addListener('appStateChange', ({ isActive }) => {
      nativeAppInactive = !isActive;
      if (!isActive) suspendApplication();
      else if (!document.hidden) resumeApplication();
    });
    nativeLifecycleBound = true;
  } catch (error) {
    console.warn('[The Abyssal] Native lifecycle listeners unavailable:', error?.message || error);
  }
}
async function exitGame() {
  if (gameActive && hasUnsavedChanges && !window.confirm('Ada perubahan yang belum disimpan. Keluar tanpa menyimpan?')) return;
  gameActive = false;
  gamePaused = false;
  $('hud')?.classList.add('hidden');
  setVisibleScreen('exit');
}

function setupControls() {
  $('replay-intro-btn').addEventListener('click', () => {
    if(!gameActive){showToast('Mulai atau muat ekspedisi terlebih dahulu untuk memutar cutscene.');return;}
    gamePaused=false;setVisibleScreen('hud');$('hud').classList.remove('hidden');startIntroCinematic({replayOnly:true});
  });
  $('play-btn').addEventListener('click', () => { renderSlotCards('new-slots', 'new'); setVisibleScreen('newGame'); });
  $('continue-btn').addEventListener('click', () => { renderSlotCards('load-slots', 'load'); setVisibleScreen('load'); });
  $('settings-btn').addEventListener('click', () => openSettings('main'));
  $('multiplayer-btn').addEventListener('click', () => openMultiplayer('main'));
  $('pause-multiplayer-btn').addEventListener('click', () => openMultiplayer('pause'));
  $('multiplayer-close-btn').addEventListener('click', closeMultiplayer);
  $('exit-btn').addEventListener('click', exitGame);
  $('backend-config-form').addEventListener('submit', async event => {
    event.preventDefault();
    const button = $('backend-config-save-btn'); button.disabled = true;
    try {
      const result = await online.configureBackend({
        url:$('backend-project-url').value,
        publishableKey:$('backend-publishable-key').value
      });
      updateOnlineConfigNote();
      updateOnlineRoomUi();
      if (result?.reachable === false) {
        updateOnlineStatus(`Konfigurasi tersimpan, tetapi server belum terjangkau. ${result.error?.message || 'Periksa internet dan Project URL, lalu tekan Simpan & Hubungkan lagi.'}`, 'warning');
      } else if (online.authSettings?.disable_signup === true) {
        $('backend-config-details').open = false;
        updateOnlineStatus('Server terhubung, tetapi Register dinonaktifkan di Supabase. Login tetap tersedia untuk akun yang sudah ada.', 'warning');
      } else if (online.authSettings?.external?.email === false) {
        $('backend-config-details').open = false;
        updateOnlineStatus('Server terhubung, tetapi provider Email belum aktif di Supabase Authentication.', 'warning');
      } else {
        $('backend-config-details').open = false;
        updateOnlineStatus('Server Supabase berhasil dihubungkan. Register dan Login siap digunakan.', 'success');
      }
    } catch (error) {
      updateOnlineConfigNote();
      updateOnlineRoomUi();
      updateOnlineStatus(explainOnlineError(error, 'Backend tidak dapat dihubungkan. Periksa URL dan Publishable Key.'), 'error');
    } finally { button.disabled = false; }
  });

  document.querySelectorAll('[data-auth-mode]').forEach(button => button.addEventListener('click', () => {
    const registerMode = button.dataset.authMode === 'register';
    $('online-login-section').classList.toggle('hidden', registerMode);
    $('online-register-section').classList.toggle('hidden', !registerMode);
    updateOnlineStatus(registerMode ? 'Buat akun baru dengan email aktif.' : 'Masuk menggunakan email dan kata sandi.', 'info');
  }));
  $('online-login-form').addEventListener('submit', async event => {
    event.preventDefault();
    const button = $('login-submit-btn'); button.disabled = true;
    try {
      await online.login({ email:$('login-email').value, password:$('login-password').value });
      updateOnlineStatus(`Berhasil masuk sebagai ${online.displayName}.`, 'success');
      $('login-password').value = '';
    } catch (error) {
      updateOnlineStatus(explainOnlineError(error, 'Login gagal. Periksa email dan kata sandi.'), 'error');
    } finally { button.disabled = !online.configured; }
  });
  $('online-register-form').addEventListener('submit', async event => {
    event.preventDefault();
    const button = $('register-submit-btn'); button.disabled = true;
    try {
      const result = await online.register({
        displayName:$('register-name').value,
        email:$('register-email').value,
        password:$('register-password').value
      });
      $('register-password').value = '';
      if (result.needsEmailConfirmation) {
        updateOnlineStatus('Akun berhasil dibuat. Buka email verifikasi dari Supabase, konfirmasi alamat email, lalu kembali ke sini untuk Login.', 'success');
        $('online-login-section').classList.remove('hidden');
        $('online-register-section').classList.add('hidden');
      } else {
        updateOnlineStatus(`Akun berhasil dibuat. Selamat datang, ${online.displayName}.`, 'success');
      }
    } catch (error) {
      updateOnlineStatus(explainOnlineError(error, 'Registrasi gagal. Coba email lain atau periksa konfigurasi Auth.'), 'error');
    } finally { button.disabled = !online.configured; }
  });
  $('logout-btn').addEventListener('click', async () => {
    const button = $('logout-btn'); button.disabled = true;
    try { await online.logout(); updateOnlineStatus('Kamu sudah logout.', 'success'); }
    catch (error) { updateOnlineStatus(error.message || 'Logout gagal.', 'error'); }
    finally { button.disabled = false; }
  });
  $('create-room-btn').addEventListener('click', async () => {
    const button = $('create-room-btn'); button.disabled = true;
    try {
      const room = await online.createRoom($('room-name-input').value);
      updateOnlineStatus(`Ruang ${room.code} berhasil dibuat. Bagikan kode undangan kepada teman.`, 'success');
      updateOnlineRoomUi();
    } catch (error) { updateOnlineStatus(error.message || 'Gagal membuat ruang.', 'error'); }
    finally { updateOnlineRoomUi(); }
  });
  $('join-room-btn').addEventListener('click', async () => {
    const button = $('join-room-btn'); button.disabled = true;
    try {
      const room = await online.joinRoom($('room-code-input').value);
      $('room-code-input').value = '';
      updateOnlineStatus(`Berhasil bergabung ke ${room.name} (${room.code}).`, 'success');
      updateOnlineRoomUi();
    } catch (error) { updateOnlineStatus(error.message || 'Tidak dapat bergabung ke ruang.', 'error'); }
    finally { updateOnlineRoomUi(); }
  });
  $('room-code-input').addEventListener('input', event => { event.target.value = event.target.value.toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,6); });
  $('leave-room-btn').addEventListener('click', async () => {
    const button = $('leave-room-btn'); button.disabled = true;
    try { await online.leaveRoom(); clearRemoteDivers(); updateOnlineStatus('Kamu sudah keluar dari ruang ekspedisi.', 'success'); }
    catch (error) { updateOnlineStatus(error.message || 'Gagal keluar dari ruang.', 'error'); }
    finally { updateOnlineRoomUi(); }
  });
  $('online-chat-form').addEventListener('submit', async event => {
    event.preventDefault();
    const inputNode = $('online-chat-input');
    const value = inputNode.value;
    try { await online.sendChat(value); inputNode.value = ''; }
    catch (error) { updateOnlineStatus(error.message || 'Pesan tidak dapat dikirim.', 'error'); }
  });
  document.querySelectorAll('[data-back]').forEach(button => button.addEventListener('click', () => {
    if (button.closest('#settings-screen')) closeSettings();
    else setVisibleScreen('main');
  }));
  $('pause-btn').addEventListener('click', pauseGame);
  $('resume-btn').addEventListener('click', resumeGame);
  $('pause-save-btn').addEventListener('click', saveCurrentSlot);
  $('pause-settings-btn').addEventListener('click', () => openSettings('pause'));
  $('main-menu-btn').addEventListener('click', returnToMain);
  $('scan-btn').addEventListener('click', scanNearestFauna);
  $('vehicle-special-btn')?.addEventListener('click',activateVehicleSpecial);
  $('vehicle-cargo-btn')?.addEventListener('click',openVehicleBay);
  $('vehicle-bay-close-btn')?.addEventListener('click',closeGamePanel);
  $('attack-btn').addEventListener('click', attackWithKnife);
  $('interact-btn').addEventListener('click', interactNearby);
  $('use-item-btn').addEventListener('click', useSelectedHotbarItem);
  $('exit-habitat-btn').addEventListener('click', exitHabitat);
  $('cinematic-skip').addEventListener('click', finishIntroCinematic);
  $('inventory-btn').addEventListener('click', openInventory);
  $('pda-btn').addEventListener('click', openPda);
  $('pda-close-btn').addEventListener('click', closeGamePanel);
  $('fabricator-close-btn').addEventListener('click', closeGamePanel);
  $('fabricator-tabs').addEventListener('click', event => { const tab=event.target.closest('[data-fabricator-category]'); if(!tab)return; fabricatorCategory=tab.dataset.fabricatorCategory; renderFabricator(); playSfx('tap'); });
  $('storage-close-btn').addEventListener('click', closeGamePanel);
  $('storage-store-btn').addEventListener('click', () => lockerTransfer('store'));
  $('storage-take-btn').addEventListener('click', () => lockerTransfer('take'));
  $('inventory-close-btn').addEventListener('click', closeGamePanel);
  $('build-close-btn').addEventListener('click', closeGamePanel);
  document.querySelectorAll('[data-build]').forEach(button => button.addEventListener('click', () => placeStructure(button.dataset.build)));
  $('return-menu-btn').addEventListener('click', () => { setVisibleScreen('main'); });
  $('fullscreen-btn').addEventListener('click', enterFullscreenLandscape);
  $('export-save-btn').addEventListener('click', exportSaveBackup);
  $('import-save-btn').addEventListener('click', () => $('import-save-file').click());
  $('import-save-file').addEventListener('change', async event => {
    try { await importSaveBackup(event.target.files?.[0]); }
    catch (error) { showToast(error.message || 'Gagal membaca file backup.'); }
    finally { event.target.value = ''; }
  });

  // Local single-player campaign; the only save actions are manual and backup/restore.

  $('graphics-select').addEventListener('change', event => { settings.graphics = event.target.value; applySettings(); });
  $('render-select').addEventListener('change', event => { settings.renderDistance = Number(event.target.value); applySettings(); });
  $('volume-range').addEventListener('input', event => { settings.volume = Number(event.target.value); $('volume-value').textContent = `${settings.volume}%`; updateAmbientVolume(); saveJson(STORAGE.settings, settings); });
  $('fov-range').addEventListener('input', event => { settings.fov = Number(event.target.value); $('fov-value').textContent = `${settings.fov}°`; applySettings(); });
  $('camera-sensitivity-range').addEventListener('input', event => { settings.cameraSensitivity = Number(event.target.value)/100; $('camera-sensitivity-value').textContent = `${event.target.value}%`; saveJson(STORAGE.settings, settings); });
  $('hud-scale-range').addEventListener('input', event => { settings.hudScale = Number(event.target.value); $('hud-scale-value').textContent = `${settings.hudScale}%`; document.documentElement.style.setProperty('--abyssal-hud-scale', String(settings.hudScale/100)); saveJson(STORAGE.settings, settings); });
  $('language-select').addEventListener('change', event => { settings.language = event.target.value; applyLanguage(); saveJson(STORAGE.settings, settings); });

  window.addEventListener('keydown', event => {
    const target = event.target;
    const typing = target && (target.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName));
    if (typing) return;
    if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(event.code)) event.preventDefault();
    if(event.code==='Space'&&!input.keys.has('Space')&&gameActive&&!gamePaused){
      const ground=samplePlayerFloor(player.position.x,player.position.z),waterY=waterSurfaceHeightAt(player.position.x,player.position.z,clockState.elapsed);
      spaceUsedForJump=canPlayerJump(player.position.y-1.9,ground,waterY,player.velocity.y,.28);
      if(spaceUsedForJump)jumpRequested=true;
    }
    input.keys.add(event.code);
    if (event.code === 'KeyI' && gameActive && !gamePaused) openInventory();
    if (event.code === 'KeyB' && gameActive && !gamePaused) openBuildMenu();
    if (event.code === 'KeyJ' && gameActive && !gamePaused) openPda();
    if (event.code === 'KeyV' && gameActive && !gamePaused) openVehicleBay();
    if (event.code === 'KeyE' && gameActive && !gamePaused) interactNearby();
    if (event.code === 'KeyQ' && gameActive && !gamePaused) attackWithKnife();
    if (event.code === 'KeyF' && gameActive && !gamePaused && getSelectedHotbarItem()==='flashlight') useSelectedHotbarItem();
    if (/^Digit[1-5]$/.test(event.code) && gameActive && !gamePaused) selectHotbar(Number(event.code.slice(5))-1);
    if (event.code === 'Escape' && gameActive) { if (pendingBuildType) cancelBuildPreview(); else if (gamePaused) closeGamePanel(); else pauseGame(); }
  });
  window.addEventListener('keyup', event => {input.keys.delete(event.code);if(event.code==='Space')spaceUsedForJump=false;});
  const joystick = $('joystick'), knob = $('joystick-knob');
  let joyPointer = null;
  const verticalPointers = { ascend:new Set(), descend:new Set() };
  const updateVerticalInput = () => { input.vertical=resolveVerticalInput(verticalPointers.ascend.size,verticalPointers.descend.size); };
  releaseTouchControls = () => {
    input.keys.clear();
    jumpRequested=false;spaceUsedForJump=false;
    input.joyX = 0; input.joyY = 0; input.vertical = 0;
    joyPointer = null; verticalPointers.ascend.clear(); verticalPointers.descend.clear();
    knob.style.transform = 'translate(0,0)';
    look.active = false; look.pointerId = null;
  };
  window.addEventListener('blur', releaseTouchControls);
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) suspendApplication();
    else if (!nativeAppInactive) resumeApplication();
  });
  window.addEventListener('pagehide', suspendApplication);
  window.addEventListener('pageshow', () => { if (!document.hidden && !nativeAppInactive) resumeApplication(); });
  const moveJoy = (event) => {
    if (event.pointerId !== joyPointer) return;
    const rect = joystick.getBoundingClientRect();
    const cx = rect.left + rect.width / 2, cy = rect.top + rect.height / 2;
    const dx = event.clientX - cx, dy = event.clientY - cy;
    const max = rect.width * 0.34;
    const length = Math.hypot(dx, dy) || 1;
    const factor = Math.min(1, max / length);
    const px = dx * factor, py = dy * factor;
    knob.style.transform = `translate(${px}px,${py}px)`;
    input.joyX = clamp(px / max, -1, 1);
    input.joyY = clamp(py / max, -1, 1);
  };
  joystick.addEventListener('pointerdown', event => {
    event.preventDefault();
    if (joyPointer !== null) return; // One tracked pointer per control; keep the other finger free for camera look.
    joyPointer = event.pointerId;
    joystick.setPointerCapture(joyPointer);
    moveJoy(event);
  });
  joystick.addEventListener('pointermove', moveJoy);
  const resetJoy = event => { if (event.pointerId !== joyPointer) return; joyPointer = null; input.joyX = 0; input.joyY = 0; knob.style.transform = 'translate(0,0)'; };
  joystick.addEventListener('pointerup', resetJoy);
  joystick.addEventListener('pointercancel', resetJoy);
  joystick.addEventListener('lostpointercapture', resetJoy);

  const lookpad = $('lookpad');
  lookpad.addEventListener('pointerdown', event => {
    event.preventDefault();
    if (look.active) return; // Ignore a second pointer in this zone without disturbing joystick tracking.
    look.active = true;
    look.pointerId = event.pointerId;
    look.x = event.clientX;
    look.y = event.clientY;
    lookpad.setPointerCapture(event.pointerId);
  });
  lookpad.addEventListener('pointermove', event => {
    if (!look.active || event.pointerId !== look.pointerId) return;
    const dx = event.clientX - look.x, dy = event.clientY - look.y;
    look.x = event.clientX; look.y = event.clientY;
    const nextLook=applyTouchLook(player.yaw,player.pitch,dx,dy,0.0039*settings.cameraSensitivity,0.0027*settings.cameraSensitivity);
    player.yaw=nextLook.yaw;
    player.pitch=nextLook.pitch;
  });
  const stopLook = event => { if (event.pointerId === look.pointerId) { look.active = false; look.pointerId = null; } };
  lookpad.addEventListener('pointerup', stopLook); lookpad.addEventListener('pointercancel', stopLook); lookpad.addEventListener('lostpointercapture', stopLook);

  const bindHold = (id, direction) => {
    const node = $(id);
    const pointerSet=direction>0?verticalPointers.ascend:verticalPointers.descend;
    const down = event => {
      event.preventDefault();
      pointerSet.add(event.pointerId);
      try { node.setPointerCapture(event.pointerId); } catch { /* Pointer may already have been released by the browser. */ }
      updateVerticalInput();
    };
    const up = event => { event.preventDefault(); pointerSet.delete(event.pointerId); updateVerticalInput(); };
    node.addEventListener('pointerdown', down); node.addEventListener('pointerup', up); node.addEventListener('pointercancel', up); node.addEventListener('lostpointercapture', up);
  };
  bindHold('ascend-btn', 1); bindHold('descend-btn', -1);
  $('jump-btn')?.addEventListener('pointerdown',event=>{
    event.preventDefault();
    const ground=samplePlayerFloor(player.position.x,player.position.z),waterY=waterSurfaceHeightAt(player.position.x,player.position.z,clockState.elapsed);
    if(canPlayerJump(player.position.y-1.9,ground,waterY,player.velocity.y,.28)){jumpRequested=true;}
  });
  window.addEventListener('resize', onResize);
  window.addEventListener('orientationchange', () => setTimeout(onResize, 160));
  document.addEventListener('focusin', event => {
    const target = event.target;
    if (target && /^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName)) {
      document.body.classList.add('keyboard-open');
      setTimeout(() => target.scrollIntoView({ block: 'center', behavior: 'smooth' }), 120);
    }
  });
  document.addEventListener('focusout', () => {
    clearTimeout(visualViewportResizeTimer);
    visualViewportResizeTimer = setTimeout(() => {
      document.body.classList.remove('keyboard-open');
      onResize();
    }, 180);
  });
}

function onResize() {
  if (!renderer || !camera) return;
  // Keep the render target stable while Android's IME is visible; adjustPan
  // pans the content without shrinking the native full-screen game surface.
  if (document.body.classList.contains('keyboard-open')) return;
  const viewport = getGameViewportSize();
  renderer.setSize(viewport.width, viewport.height, false);
  camera.aspect = viewport.width / viewport.height;
  camera.updateProjectionMatrix();
}

function samplePlayerFloor(x, z) {
  // Approximate the diver's capsule footprint with a centre plus eight radial
  // contacts; narrow ridges no longer slip between four cardinal samples.
  const radius = 0.46;
  let highest = heightAt(x, z);
  for (let index = 0; index < 8; index++) {
    const angle = index * Math.PI / 4;
    highest = Math.max(highest, heightAt(x + Math.cos(angle) * radius, z + Math.sin(angle) * radius));
  }
  return highest;
}

function structureBlocksPosition(x, y, z) {
  for (const item of placedStructures) {
    // Walkable habitat pieces are intentionally not solid at the centre so the diver can enter them.
    if (item.type === 'compartment' || item.type === 'foundation') continue;
    const radius = item.type === 'solar_array' ? 1.7 : item.type === 'storage_locker' ? 0.9 : item.type === 'vehicle_bay' ? 4.0 : 0.72;
    if (Math.abs(y - item.y) < 2.0 && Math.hypot(x-item.x,z-item.z) < radius + 0.58) return true;
  }
  // The Lifepod has a true 3D capsule boundary. Interior is passable only after hatch interaction.
  if(lifepodGroup && lifepodHullBlocksWorld(x,y,z,lifepodGroup.position,lifepodGroup.rotation.y||0,0.38,LIFEPOD_SCALE,clockState.elapsed<(lifepodGroup.userData.hatchOpenUntil||0)))return true;
  // The large wreck hull is an oriented solid, not a pass-through decoration.
  const dx=x-shipOfInterest.x, dz=z-shipOfInterest.z, angle=0.72;
  const localX=dx*Math.cos(angle)-dz*Math.sin(angle);
  const localZ=dx*Math.sin(angle)+dz*Math.cos(angle);
  if (Math.abs(y+37)<4.2 && Math.abs(localX)<16.5 && Math.abs(localZ)<4.7) return true;
  // Supply crates also have a small interaction-safe collision volume.
  for (const cache of supplyCacheLocations) {
    if (Math.abs(y-cache.y)<1.5 && Math.abs(x-cache.x)<1.85 && Math.abs(z-cache.z)<1.45) return true;
  }
  return false;
}

function updateMovement(dt) {
  // Tool/attack viewmodel timers are presentation-only; locomotion always updates in parallel.
  if(activeVehicleId){updateVehicleMovement(dt);player.bob+=dt*1.4;player.swimPhase+=dt*1.2;return;}
  const oldX=player.position.x, oldY=player.position.y, oldZ=player.position.z;
  const groundNow=samplePlayerFloor(oldX,oldZ);
  const waterNow=waterSurfaceHeightAt(oldX,oldZ,clockState.elapsed);
  const floorNow=groundNow+1.9;
  const dryGround=groundNow>waterNow+0.18;
  const grounded=dryGround&&Math.abs(oldY-floorNow)<=0.28;
  const spaceHeld=input.keys.has('Space');
  const vertical = input.vertical + (spaceHeld && !dryGround && !spaceUsedForJump ? 1 : 0) - (input.keys.has('ControlLeft') || input.keys.has('ControlRight') ? 1 : 0);
  const keyForward = (input.keys.has('KeyW') || input.keys.has('ArrowUp') ? 1 : 0) - (input.keys.has('KeyS') || input.keys.has('ArrowDown') ? 1 : 0);
  const keyStrafe = (input.keys.has('KeyD') || input.keys.has('ArrowRight') ? 1 : 0) - (input.keys.has('KeyA') || input.keys.has('ArrowLeft') ? 1 : 0);
  const forward = clamp(keyForward - input.joyY, -1, 1);
  const strafe = clamp(keyStrafe + input.joyX, -1, 1);
  const pitch = clamp(player.pitch, -0.48, 0.58);
  const fwd = tmpVector.set(Math.sin(player.yaw)*Math.cos(pitch),-Math.sin(pitch),-Math.cos(player.yaw)*Math.cos(pitch));
  const right = tmpRight.set(Math.cos(player.yaw),0,Math.sin(player.yaw));
  const wish = tmpDirection.set(0,0,0).addScaledVector(fwd,forward).addScaledVector(right,strafe);
  if (wish.lengthSq()>1) wish.normalize();
  const seaglideSelected=getSelectedHotbarItem()==='seaglide'&&ownedTools.includes('seaglide');
  const seaglideEquipped=seaglideSelected&&equipment.seaglideCharge>0;
  const isMoving=wish.lengthSq()>0.02||Math.abs(vertical)>0.03;
  if(seaglideEquipped&&isMoving){
    const previousCharge=Math.ceil(equipment.seaglideCharge);
    equipment.seaglideCharge=clamp(equipment.seaglideCharge-0.30*dt,0,100);
    const nextCharge=Math.ceil(equipment.seaglideCharge);
    if(nextCharge!==previousCharge){markUnsaved();if(nextCharge!==seaglideChargeUiBucket){seaglideChargeUiBucket=nextCharge;renderHotbar();}}
    if(equipment.seaglideCharge===0){showToast('Daya Seaglide habis. Ganti baterai melalui tombol BATTERY.');renderHotbar();}
  }
  const speed=10.2*(equipment.fins?1.2:1)*(seaglideEquipped?1.75:1);
  const sheltered= dryGround || Boolean(getInsideHabitat());
  const flow=sampleOceanCurrent(oldX,oldY,oldZ,clockState.elapsed,currentBiome?.id||'open');
  const flowResponse=getDiverCurrentResponse({fins:Boolean(equipment.fins),seaglide:seaglideEquipped,sheltered});
  const flowX=flow.x*flowResponse,flowY=flow.y*flowResponse*.55,flowZ=flow.z*flowResponse;
  const desiredX=wish.x*speed+flowX, desiredY=clamp(vertical,-1,1)*7.0+flowY, desiredZ=wish.z*speed+flowZ;
  const accel=1-Math.exp(-dt*4.8), verticalAccel=1-Math.exp(-dt*5.2);
  player.velocity.x=lerp(player.velocity.x,desiredX,accel);
  player.velocity.z=lerp(player.velocity.z,desiredZ,accel);
  if(jumpRequested){
    if(canPlayerJump(oldY-1.9,groundNow,waterNow,player.velocity.y,.28)&&!getInsideHabitat()){
      player.velocity.y=8.1;playSfx('jump');
    }
    jumpRequested=false;
  }
  if(dryGround&&!getInsideHabitat()){
    if(grounded&&player.velocity.y<0)player.velocity.y=0;
    else if(!grounded)player.velocity.y=integrateGroundGravity(player.velocity.y,dt);
  }else {
    const buoyancyTrim=getDiverBuoyancyTrim({tankLevel:equipment.tankLevel,rebreather:equipment.rebreather,seaglide:seaglideEquipped,insideHabitat:Boolean(getInsideHabitat())});
    player.velocity.y=lerp(player.velocity.y,desiredY+buoyancyTrim,verticalAccel);
  }
  if (wish.lengthSq()<0.002 && Math.abs(vertical)<0.01) {
    // Neutral input settles the diver into the local water mass instead of
    // freezing in place; fins and Seaglide reduce this passive drift.
    const horizontalDrag=Math.exp(-dt*2.4),verticalDrag=Math.exp(-dt*2.0);
    player.velocity.x=flowX+(player.velocity.x-flowX)*horizontalDrag;
    player.velocity.z=flowZ+(player.velocity.z-flowZ)*horizontalDrag;
    if(!dryGround)player.velocity.y=flowY+(player.velocity.y-flowY)*verticalDrag;
  }

  
  const nextX=oldX+player.velocity.x*dt, nextZ=oldZ+player.velocity.z*dt;
  let nextY=clamp(oldY+player.velocity.y*dt,-MAX_DIVE_DEPTH,28);
  const requestedCaveFloor=heightAt(nextX,nextZ);
  const requestedCaveRoof=getCaveCeilingY(nextX,nextZ,requestedCaveFloor,CAVE_SITES,0.30);
  if (requestedCaveRoof !== null) nextY=clampCapsuleBelowCeiling(nextY,requestedCaveRoof,1.42,0.08);
  const floorOld=samplePlayerFloor(oldX,oldZ)+1.9;
  const floorNext=samplePlayerFloor(nextX,nextZ)+1.9;
  let targetX=nextX, targetZ=nextZ;
  // Block steep terrain faces rather than allowing the diver to tunnel through islands or cliffs.
  if (floorNext > oldY + 1.05 && floorNext > floorOld + 0.65) {
    const xOnlyFloor=samplePlayerFloor(nextX,oldZ)+1.9;
    const zOnlyFloor=samplePlayerFloor(oldX,nextZ)+1.9;
    if (xOnlyFloor <= oldY+1.05) { targetZ=oldZ; player.velocity.z=0; }
    else if (zOnlyFloor <= oldY+1.05) { targetX=oldX; player.velocity.x=0; }
    else { targetX=oldX;targetZ=oldZ;player.velocity.x=0;player.velocity.z=0; }
  }

  // Resolve X, Z and Y independently. The previous combined-segment collision
  // restored horizontal coordinates after a hit but still accepted nextY,
  // which let the diver pass through the Lifepod roof or underside.
  const caveMove=constrainCaveHorizontalMotion(oldX,oldZ,targetX,targetZ,0.72,CAVE_SITES);
  if(caveMove.blocked){targetX=caveMove.x;targetZ=caveMove.z;player.velocity.x=0;player.velocity.z=0;}
  const from={x:oldX,y:oldY,z:oldZ};
  const requested={x:targetX,y:nextY,z:targetZ};
  const podResult=lifepodGroup
    ? resolveLifepodMovement(from,requested,lifepodGroup.position,lifepodGroup.rotation.y||0,0.38,LIFEPOD_SCALE,clockState.elapsed<(lifepodGroup.userData.hatchOpenUntil||0))
    : {position:requested,blocked:{x:false,y:false,z:false}};
  for(const axis of ['x','y','z']) if(podResult.blocked[axis]) player.velocity[axis]=0;
  let resolved={...from};
  for(const axis of ['x','z','y']){
    const candidate={...resolved,[axis]:podResult.position[axis]};
    if(structureBlocksPosition(candidate.x,candidate.y,candidate.z)) player.velocity[axis]=0;
    else resolved=candidate;
  }
  player.position.set(resolved.x,resolved.y,resolved.z);
  tmpPlayerBeforeFauna.copy(player.position);
  faunaDirector?.resolvePlayerCollision(player.position);
  if(structureBlocksPosition(player.position.x,player.position.y,player.position.z) || player.position.y < samplePlayerFloor(player.position.x,player.position.z)+1.9) {
    player.position.copy(tmpPlayerBeforeFauna);
    player.velocity.x=0; player.velocity.z=0;
  }
  const floorClearance=Math.max(-MAX_DIVE_DEPTH,samplePlayerFloor(player.position.x,player.position.z)+1.9);
  // In open water the diver can reach the surface but cannot fly above it. On dry island terrain,
  // the terrain floor becomes the upper bound so the capsule can stand on the island.
  const surfaceBodyLimit = waterSurfaceHeightAt(player.position.x, player.position.z, clockState.elapsed) - 0.42;
  let upperBound=dryGround&&!getInsideHabitat()
    ? Math.max(surfaceBodyLimit,floorClearance+2.25)
    : Math.max(surfaceBodyLimit,floorClearance);
  const finalCaveRoof=getCaveCeilingY(player.position.x,player.position.z,heightAt(player.position.x,player.position.z),CAVE_SITES,0.30);
  if (finalCaveRoof !== null) upperBound=Math.min(upperBound,finalCaveRoof-1.50);
  // Clamp the collision-resolved Y coordinate. Reusing nextY here would undo
  // the Lifepod roof/underside collision result and reintroduce vertical tunnelling.
  player.position.y=clamp(player.position.y,floorClearance,upperBound);
  if (player.position.y>=-0.5 && player.velocity.y>0) player.velocity.y*=0.3;
  player.bob+=dt*(wish.lengthSq()>0.015||Math.abs(vertical)>0.05?6.3:1.2);
  player.swimPhase+=dt*(2.3+Math.min(3,player.velocity.length()*0.22));
}

const cameraTargetQuaternion = new THREE.Quaternion();
const cameraBaseQuaternion = new THREE.Quaternion();
const cameraRollQuaternion = new THREE.Quaternion();
const cameraRollAxis = new THREE.Vector3(0,0,1);
const cinematicBaseQuaternion = new THREE.Quaternion();
let cameraOrientationInitialized = false;
function updateCamera(dt) {
  const eyeBob = Math.sin(player.bob) * 0.022;
  const vehicleDef=activeVehicleId?VEHICLE_DEFS[activeVehicleId]:null;
  const pilotForward=tmpDirection.set(Math.sin(player.yaw),0,-Math.cos(player.yaw));
  const vehicleCameraOffset=vehicleDef?vehicleDef.dimensions.camera:0;
  const targetPosition = vehicleDef
    ? new THREE.Vector3(player.position.x-pilotForward.x*vehicleCameraOffset,player.position.y+(activeVehicleId==='carrier'?3.0:activeVehicleId==='exosuit'?2.2:1.2),player.position.z-pilotForward.z*vehicleCameraOffset)
    : new THREE.Vector3(player.position.x, player.position.y + 0.55 + eyeBob, player.position.z);
  const cameraBlend = 1 - Math.exp(-Math.max(0.001,Math.min(dt,0.08))*18);
  camera.position.lerp(targetPosition,cameraBlend);
  if (viewModel) viewModel.visible = gameActive&&!activeVehicleId;
  const pitch = clamp(player.pitch, -1.15, 1.15);
  const forward = tmpDirection.set(Math.sin(player.yaw) * Math.cos(pitch), -Math.sin(pitch), -Math.cos(player.yaw) * Math.cos(pitch));
  if(vehicleDef){const vehicleLook=new THREE.Vector3(player.position.x,player.position.y+(activeVehicleId==='carrier'?1.2:.5),player.position.z).addScaledVector(forward,activeVehicleId==='carrier'?18:11);camera.lookAt(vehicleLook);}else camera.lookAt(tmpCamera.copy(camera.position).addScaledVector(forward, 22));
  cameraTargetQuaternion.copy(camera.quaternion);
  if(!cameraOrientationInitialized) {
    cameraBaseQuaternion.copy(cameraTargetQuaternion);
    cameraOrientationInitialized=true;
  } else {
    cameraBaseQuaternion.slerp(cameraTargetQuaternion,cameraBlend);
  }
  const lateralSpeed = player.velocity.dot(tmpRight.set(Math.cos(player.yaw), 0, Math.sin(player.yaw)));
  const cameraRoll = activeVehicleId ? -clamp(lateralSpeed * 0.0005,-0.008,0.008) : Math.sin(player.bob) * 0.0028 - clamp(lateralSpeed * 0.0022, -0.025, 0.025);
  cameraRollQuaternion.setFromAxisAngle(cameraRollAxis,cameraRoll);
  camera.quaternion.copy(cameraBaseQuaternion).multiply(cameraRollQuaternion);
  updateLifepodInteriorVisibility();
  if (viewModel) {
    const moving = clamp(player.velocity.length() / 10, 0, 1);
    const stroke = Math.sin(player.swimPhase);
    const selectedTool=getSelectedHotbarItem();
    const hasSelectedItem=hasQuickSlotItem(selectedTool);
    viewModel.userData.scanner.visible=selectedTool==='scanner'&&hasSelectedItem;
    viewModel.userData.knife.visible=selectedTool==='knife'&&hasSelectedItem;
    viewModel.userData.flashlight.visible=selectedTool==='flashlight'&&hasSelectedItem;
    const flashlightActive=selectedTool==='flashlight'&&hasSelectedItem&&flashlightEnabled;
    if(viewModel.userData.flashlightBeam)viewModel.userData.flashlightBeam.visible=flashlightActive;
    if(viewModel.userData.flashlightCone)viewModel.userData.flashlightCone.visible=flashlightActive;
    if(viewModel.userData.flashlightNearLight)viewModel.userData.flashlightNearLight.intensity=flashlightActive?2.25:0;
    if(viewModel.userData.flashlightLensMat)viewModel.userData.flashlightLensMat.emissiveIntensity=flashlightActive?1.8:0.04;
    viewModel.userData.builder.visible=selectedTool==='habitat_builder'&&hasSelectedItem;
    viewModel.userData.repairTool.visible=selectedTool==='repair_tool'&&hasSelectedItem;
    viewModel.userData.seaglide.visible=selectedTool==='seaglide'&&hasSelectedItem;
    const heldItems=viewModel.userData.heldItems||{};
    const toolModels=viewModel.userData.toolModels||{};
    for(const [toolId,toolModel] of Object.entries(toolModels)) toolModel.visible=toolId===selectedTool&&hasSelectedItem;
    for(const [itemId,heldModel] of Object.entries(heldItems)) heldModel.visible=itemId===selectedTool&&hasSelectedItem;
    const selectedModel=toolModels[selectedTool]||heldItems[selectedTool]||null;
    const rightGrip=viewModel.userData.rightGrip;
    const gripActive=Boolean(selectedModel&&hasSelectedItem);
    if(rightGrip){
      rightGrip.visible=gripActive;
      if(gripActive){
        const offset=(selectedModel.userData.gripOffset||new THREE.Vector3()).clone().multiply(selectedModel.scale).applyEuler(selectedModel.rotation);
        rightGrip.position.copy(selectedModel.position).add(offset);
        rightGrip.rotation.copy(selectedModel.rotation);
        rightGrip.scale.copy(selectedModel.scale);
      }
    }
    if(viewModel.userData.right?.userData?.fingers){
      for(const finger of viewModel.userData.right.userData.fingers) finger.visible=!gripActive;
    }
    const usingSeaglideView=selectedTool==='seaglide'&&hasSelectedItem&&equipment.seaglideCharge>0;
    if(viewModel.userData.leftGrip)viewModel.userData.leftGrip.visible=usingSeaglideView;
    if(viewModel.userData.left?.userData?.fingers){
      for(const finger of viewModel.userData.left.userData.fingers) finger.visible=!usingSeaglideView;
    }
    playerHitReactTimer = Math.max(0, playerHitReactTimer - dt);
    const hitPulse = playerHitReactTimer > 0 ? Math.sin((1 - playerHitReactTimer / 0.38) * Math.PI) : 0;
    const equipTimer = Math.max(0, (viewModel.userData.equipTimer || 0) - dt);
    viewModel.userData.equipTimer = equipTimer;
    const equipProgress = 1 - equipTimer / 0.34;
    const equipDip = equipTimer > 0 ? Math.sin(equipProgress * Math.PI) * 0.095 : 0;
    const actionTimer = Math.max(0, (viewModel.userData.actionTimer || 0) - dt);
    viewModel.userData.actionTimer = actionTimer;
    const actionDuration = viewModel.userData.actionType === 'knife' ? 0.54 : viewModel.userData.actionType === 'mine' ? 0.46 : 0.52;
    const actionProgress = actionTimer > 0 ? 1 - actionTimer / actionDuration : 0;
    const actionPulse = actionTimer > 0 ? Math.sin(actionProgress * Math.PI) : 0;
    const knifeActive=viewModel.userData.actionType==='knife'&&actionTimer>0;
    viewModel.userData.knife.rotation.x = knifeActive ? -actionPulse * 1.18 : 0;
    viewModel.userData.knife.rotation.y = knifeActive ? Math.sin(actionProgress*Math.PI*1.35)*0.22 : 0;
    viewModel.userData.knife.position.z = knifeActive ? -0.39 + actionPulse*0.18 : -0.39;
    viewModel.userData.knife.position.y = knifeActive ? -0.39 - actionPulse*0.045 : -0.39;
    viewModel.userData.scanner.rotation.x = viewModel.userData.actionType === 'scanner' ? -actionPulse * 0.15 : 0;
    viewModel.userData.builder.rotation.x = viewModel.userData.actionType === 'builder' ? -actionPulse * 0.12 : 0;
    viewModel.userData.repairTool.rotation.x = viewModel.userData.actionType === 'repair' ? -actionPulse * 0.16 : 0;
    for(const [itemId,heldModel] of Object.entries(viewModel.userData.heldItems||{})) {
      if(itemId!==selectedTool) continue;
      const profile=heldModel.userData.heldPresentation||resolveHeldItemPresentation(itemId);
      const motion=computeHeldItemMotion({
        itemId,
        elapsed:clockState.elapsed,
        equipProgress:1-equipTimer/0.34,
        actionProgress:actionProgress,
        actionType:viewModel.userData.actionType
      });
      const basePosition=heldModel.userData.basePosition||new THREE.Vector3(0,-.39,-.39);
      const baseRotation=heldModel.userData.baseRotation||new THREE.Euler();
      const baseScale=heldModel.userData.baseScale||new THREE.Vector3(profile.scale,profile.scale,profile.scale);
      heldModel.position.set(basePosition.x+motion.offsetX,basePosition.y+motion.offsetY,basePosition.z);
      heldModel.rotation.set(baseRotation.x+motion.rotationX,baseRotation.y+motion.rotationY,baseRotation.z+motion.rotationZ);
      heldModel.scale.copy(baseScale).multiplyScalar(motion.scaleFactor);
    }
    // Recompute the glove overlay after the animated viewmodel transform so
    // the fingers remain attached to the selected object's authored grip.
    if(rightGrip&&selectedModel&&gripActive){
      const offset=(selectedModel.userData.gripOffset||new THREE.Vector3()).clone().multiply(selectedModel.scale).applyEuler(selectedModel.rotation);
      rightGrip.position.copy(selectedModel.position).add(offset);
      rightGrip.rotation.copy(selectedModel.rotation);
      rightGrip.scale.copy(selectedModel.scale);
    }
    if(viewModel.userData.scanner.userData.scanRings) viewModel.userData.scanner.userData.scanRings.rotation.z+=dt*(viewModel.userData.actionType==='scanner'?5.5:0.45);
    if(viewModel.userData.builder.userData.emitters) viewModel.userData.builder.userData.emitters.rotation.z+=dt*1.25;
    if(viewModel.userData.repairTool.userData.coil) viewModel.userData.repairTool.userData.coil.rotation.z+=dt*(viewModel.userData.actionType==='repair'?8:0.65);
    viewModel.userData.seaglideProp.rotation.z += dt * (selectedTool === 'seaglide' ? 14 : 0.35);
    if (actionTimer <= 0) viewModel.userData.actionType = '';
    const swimPose = computeSwimPose(player.swimPhase, moving, selectedTool === 'seaglide' && equipment.seaglideCharge > 0, Boolean(selectedTool));
    const actionArmLift=actionTimer>0?actionPulse*0.16:0;
    const actionArmTurn=actionTimer>0?actionPulse*0.055:0;
    const knifeSwing=knifeActive?actionPulse:0;
    const knifeArc=knifeActive?Math.sin(actionProgress*Math.PI*1.12):0;
    viewModel.userData.left.rotation.x = usingSeaglideView ? -0.10 : swimPose.leftArmX + (viewModel.userData.actionType==='use'?actionArmLift*.28:0) + hitPulse*0.20;
    viewModel.userData.right.rotation.x = usingSeaglideView ? -0.10 : swimPose.rightArmX - actionArmLift - knifeSwing*.30 + hitPulse*0.28;
    viewModel.userData.left.rotation.z = usingSeaglideView ? 0.015 : swimPose.leftArmZ + Math.sin(player.bob) * 0.012;
    viewModel.userData.right.rotation.z = usingSeaglideView ? -0.015 : swimPose.rightArmZ - Math.sin(player.bob) * 0.012 + actionArmTurn + knifeArc*.22;
    viewModel.userData.right.rotation.y = (usingSeaglideView?0: -Math.sin(player.swimPhase * 0.5) * 0.032 * swimPose.blend) + knifeArc*.18;
    viewModel.userData.left.rotation.y = Math.sin(player.swimPhase * 0.5) * 0.045 * swimPose.blend;
    viewModel.userData.right.rotation.y = -Math.sin(player.swimPhase * 0.5) * 0.032 * swimPose.blend;
    viewModel.userData.left.position.y = -0.19 + swimPose.bob;
    viewModel.userData.right.position.y = -0.19 - swimPose.bob * 0.78;
    viewModel.position.y = -0.015 + eyeBob * 0.65 - equipDip + swimPose.bob * 0.42;
    viewModel.position.x = Math.sin(player.swimPhase * 0.5) * 0.026 * swimPose.blend;
    viewModel.rotation.z = -clamp(player.velocity.x * 0.004, -0.035, 0.035) * (1 - surfaceBlend * 0.45) + hitPulse*0.045;
  }
  if (particleGroup) { particleGroup.position.set(player.position.x, player.position.y, player.position.z); particleGroup.rotation.y += dt * 0.012; }
  if (lightRayGroup) { lightRayGroup.position.set(player.position.x, Math.min(-3, player.position.y + 18), player.position.z); lightRayGroup.rotation.y += dt * 0.004; }
  const waterCellX = Math.floor(player.position.x / 500) * 500;
  const waterCellZ = Math.floor(player.position.z / 500) * 500;
  if (water) { water.position.x = waterCellX; water.position.z = waterCellZ; }
  const depth = Math.max(0, -player.position.y);
  const biome = getBiomeAt(player.position.x, player.position.y, player.position.z);
  currentBiome = biome;
  updateBiomeAudio(biome);
  updateUnderwaterAudioEnvironment(dt);
  const eyeY = camera.position.y;
  const localWaterHeight = waterSurfaceHeightAt(player.position.x,player.position.z,clockState.elapsed);
  updateSurfacePresentation(eyeY,localWaterHeight,biome);
  const sunlight = 1 - smoothstep(12, 175, depth);
  if (fillLight) {
    fillLight.intensity = 0.28 + sunlight * 1.18 * (1-surfaceBlend*0.5);
    fillLight.position.set(player.position.x + 14, player.position.y + 7, player.position.z + 12);
  }
  if (lightRayGroup?.userData?.rayMaterial) {
    const rayFade = (1 - smoothstep(18, 92, depth)) * (1-surfaceBlend);
    lightRayGroup.visible = rayFade > 0.015;
    lightRayGroup.userData.rayMaterial.opacity = 0.62 * rayFade;
  }
  if (causticTexture) { causticTexture.offset.x = (clockState.elapsed * 0.0032) % 1; causticTexture.offset.y = (clockState.elapsed * -0.0021) % 1; }
  if (water?.material?.map) { water.material.map.offset.x = (clockState.elapsed * 0.0018) % 1; water.material.map.offset.y = (clockState.elapsed * 0.0011) % 1; }
  if (water?.material?.normalMap) { water.material.normalMap.offset.x = (clockState.elapsed * -0.0027) % 1; water.material.normalMap.offset.y = (clockState.elapsed * 0.0021) % 1; }
  updateWaterSurface(dt);
}

function setSurvivalBar(name, value) {
  const percent = clamp(Number(value) || 0, 0, 100);
  const fill = $(`${name}-fill`);
  const label = $(`${name}-value`);
  const gauge = $(`${name}-gauge`);
  if (gauge) {
    gauge.style.setProperty('--gauge-pct', `${percent}%`);
    gauge.classList.toggle('is-low', percent <= 25);
    gauge.classList.toggle('is-critical', percent <= 12);
    if (name === 'oxygen') gauge.style.setProperty('--gauge-color', percent <= 12 ? '#ff625f' : percent <= 25 ? '#efbb62' : '#83e4a0');
  }
  if (fill) {
    fill.style.width = `${percent}%`;
    fill.classList.toggle('is-low', percent <= 25);
    fill.classList.toggle('is-critical', percent <= 12);
  }
  if (label) label.textContent = String(Math.round(percent));
}

function updateSurvivalHud() {
  setSurvivalBar('hp', survival.hp);
  setSurvivalBar('oxygen', survival.oxygen / getMaxOxygen() * 100);
  $('oxygen-value').textContent = `${Math.ceil(survival.oxygen)}/${getMaxOxygen()}`;
  setSurvivalBar('food', survival.food);
  setSurvivalBar('water', survival.water);
  const depthNow=Math.max(0,-player.position.y);
  const depthRating=activeVehicleId?getVehicleDepthRating(activeVehicleId,vehicleFleet[activeVehicleId]):oxygenTankDepthRating(equipment.tankLevel);
  const overDepthRating=depthNow>depthRating;
  const nearDepthRating=depthNow>=depthRating*0.82;
  const hud = $('hud');
  if (hud) {
    hud.classList.toggle('is-deep', depthNow >= 60);
    hud.classList.toggle('is-oxygen-critical', survival.oxygen <= getMaxOxygen() * 0.22);
    hud.classList.toggle('is-depth-warning', nearDepthRating);
    hud.classList.toggle('is-depth-danger', overDepthRating);
    hud.dataset.depthBand = overDepthRating ? 'danger' : depthNow < 20 ? 'shallow' : depthNow < 60 ? 'shelf' : depthNow < 180 ? 'deep' : 'extreme';
  }
  const depthIndicator = document.querySelector('.depth-indicator');
  if (depthIndicator) {
    depthIndicator.style.setProperty('--depth-progress', `${clamp(depthNow / MAX_DIVE_DEPTH * 100, 0, 100)}%`);
    depthIndicator.dataset.depthBand = overDepthRating ? 'danger' : depthNow < 20 ? 'shallow' : depthNow < 60 ? 'shelf' : depthNow < 180 ? 'deep' : 'extreme';
    depthIndicator.classList.toggle('over-limit', overDepthRating);
    depthIndicator.classList.toggle('near-limit', nearDepthRating && !overDepthRating);
  }
  const depthLimitLabel=$('depth-limit-label');
  if(depthLimitLabel) depthLimitLabel.textContent=activeVehicleId?`VEHICLE ${depthRating} M${overDepthRating?' · EXCEEDED':''}`:overDepthRating?`LIMIT ${depthRating} M · EXCEEDED`:`LIMIT ${depthRating} M`;
  const depthCaption = document.querySelector('.depth-caption');
  if (depthCaption) depthCaption.textContent = 'DEPTH';
  const critical = survival.hp <= 25 || survival.oxygen <= getMaxOxygen() * 0.18 || survival.water <= 15 || survival.food <= 10 || overDepthRating;
  $('survival-status')?.classList.toggle('is-warning', critical || survival.oxygen <= getMaxOxygen() * 0.32);
  if ($('biome-label')) $('biome-label').textContent = currentBiome.label.toUpperCase();
  const nearOxygen=isHabitatPowered(getInsideHabitat());
  const status=$('survival-status');
  if(status)status.textContent = overDepthRating ? 'PRESSURE' : critical ? 'WARNING' : nearOxygen ? 'O₂ REFILL' : survival.oxygen <= getMaxOxygen() * 0.32 ? 'LOW O₂' : nearDepthRating ? 'DEPTH LIMIT' : 'STABLE';
  updateResourcePrompt();
}

function applyDamage(amount, source = 'Bahaya bawah laut') {
  if (!gameActive || isRespawning || amount <= 0) return;
  playSfx('damage');
  if (source && !['Bahaya bawah laut','Kehabisan oksigen','Kelaparan','Dehidrasi'].includes(source) && !String(source).startsWith('Tekanan kedalaman')) playSfx('creatureAttack');
  playerHitReactTimer = Math.max(playerHitReactTimer, 0.38);
  survival.hp = clamp(survival.hp - amount, 0, 100);
  const flash = $('damage-flash');
  flash.classList.remove('active');
  void flash.offsetWidth;
  flash.classList.add('active');
  showToast(`${source} · -${Math.round(amount)} HP`);
  updateSurvivalHud();
  if (survival.hp <= 0) {
    if(activeVehicleId && !exitActiveVehicle()){
      activeVehicleId=null;activeVehicleVelocity.set(0,0,0);document.body.classList.remove('vehicle-active-hud');if(viewModel)viewModel.visible=true;
    }
    isRespawning = true;
    setTimeout(() => {
      player.position.copy(respawnPoint);
      player.velocity.set(0,0,0); player.pitch=0.02;
      survival.hp=75; survival.oxygen=Math.min(getMaxOxygen(),45);
      survival.food=Math.max(survival.food,35); survival.water=Math.max(survival.water,35);
      isRespawning=false; chunkCenterX=NaN; updateChunks(true); updateCamera(0.016); updateSurvivalHud();
      markUnsaved(); showToast('Kamu pingsan dan kembali ke habitat aman terakhir.');
    },850);
  }
}

function updateSurvival(dt) {
  const depth = Math.max(0, -player.position.y);
  const diverEyeY = player.position.y + 0.55 + Math.sin(player.bob) * 0.022;
  const atSurface = canBreatheAtSurface(diverEyeY,waterSurfaceHeightAt(player.position.x,player.position.z,clockState.elapsed),0.045);
  const indoorHabitat = getInsideHabitat();
  const sealedVehicle = Boolean(activeVehicleId && vehicleFleet[activeVehicleId]?.deployed);
  const biome = getBiomeAt(player.position.x, player.position.y, player.position.z);
  currentBiome = biome;
  // Habitat oxygen is intentionally an interior-only service. Being next to a module or an outside station does not refill O2.
  if(sealedVehicle){
    oxygenTickTimer=0;oxygenDamageTimer=0;
  } else if (indoorHabitat && isHabitatPowered(indoorHabitat)) {
    oxygenTickTimer=0;
    survival.oxygen = clamp(survival.oxygen + 15 * dt, 0, getMaxOxygen());
    if (Math.floor(clockState.elapsed) !== Math.floor(clockState.elapsed - dt)) playSfx('oxygen');
  } else if (atSurface) {
    oxygenTickTimer=0;
    survival.oxygen = clamp(survival.oxygen + 9 * dt, 0, getMaxOxygen());
  } else {
    oxygenTickTimer += dt;
    // One authoritative two-second timer prevents frame-rate-dependent or duplicate oxygen drains.
    while (oxygenTickTimer >= 2) {
      oxygenTickTimer -= 2;
      const needsOxygen=survival.oxygen<getMaxOxygen()-1;
      const nearbyPlant=needsOxygen?oxygenPlantNodes.find(plant=>plant.charge>0&&plant.root?.parent&&(()=>{const p=plant.root.getWorldPosition(tmpVector);return p.distanceTo(player.position)<=4.6;})()):null;
      if(nearbyPlant){
        survival.oxygen=clamp(survival.oxygen+8,0,getMaxOxygen());
        nearbyPlant.charge=Math.max(0,nearbyPlant.charge-14);
        if(nearbyPlant.charge===0)nearbyPlant.rechargeTimer=26;
        playSfx('oxygenPlant');
      }else{
        const oxygenCost=oxygenUsePerTick(depth,Boolean(equipment.rebreather));
        survival.oxygen=clamp(survival.oxygen-oxygenCost,0,getMaxOxygen());
      }
      if(survival.oxygen<=0){oxygenTickTimer=0;break;}
    }
  }
  // Tank depth rating protects the diver from pressure. Above the rating, damage is applied
  // on a single two-second timer; entering a powered habitat or returning to a safe depth resets it.
  const depthRating=oxygenTankDepthRating(equipment.tankLevel);
  if (!indoorHabitat && !sealedVehicle && depth > depthRating) {
    depthStressTickTimer += dt;
    while (depthStressTickTimer >= 2) {
      depthStressTickTimer -= 2;
      const stress=depthStressDamage(depth,equipment.tankLevel);
      if (stress > 0) applyDamage(stress, `Tekanan kedalaman melewati rating tangki ${depthRating} m`);
      if (survival.hp <= 0 || isRespawning) { depthStressTickTimer=0; break; }
    }
  } else depthStressTickTimer=0;
  survival.food = clamp(survival.food - 0.014 * dt, 0, 100);
  survival.water = clamp(survival.water - 0.02 * dt, 0, 100);
  // Oxygen consumption is quantized to a two-second tick and accelerates with depth.

  if (survival.oxygen <= 0 && !sealedVehicle) {
    oxygenDamageTimer += dt;
    if (oxygenDamageTimer >= 2.2) { oxygenDamageTimer = 0; applyDamage(6, 'Kehabisan oksigen'); }
  } else oxygenDamageTimer = 0;
  if (survival.food <= 0) {
    hungerDamageTimer += dt;
    if (hungerDamageTimer >= 10) { hungerDamageTimer = 0; applyDamage(2, 'Kelaparan'); }
  } else hungerDamageTimer = 0;
  if (survival.water <= 0) {
    thirstDamageTimer += dt;
    if (thirstDamageTimer >= 8) { thirstDamageTimer = 0; applyDamage(2.5, 'Dehidrasi'); }
  } else thirstDamageTimer = 0;
}

function useMedkit() {
  if (survival.medkits <= 0 || survival.hp >= 96) return;
  survival.medkits -= 1;
  survival.hp = clamp(survival.hp + 38, 0, 100);
  updateSurvivalHud();
  renderHotbar();
  markUnsaved();
  showToast('Medkit digunakan · HP dipulihkan.');
}

function useRation() {
  if (survival.rations <= 0 || (survival.food >= 96 && survival.water >= 96)) return;
  survival.rations -= 1;
  survival.food = clamp(survival.food + 42, 0, 100);
  survival.water = clamp(survival.water + 38, 0, 100);
  updateSurvivalHud();
  renderHotbar();
  markUnsaved();
  showToast('Ransum digunakan · Food dan Water dipulihkan.');
}

function useWater() {
  if (survival.waterBottles <= 0 || survival.water >= 96) return;
  survival.waterBottles -= 1;
  survival.water = clamp(survival.water + 46, 0, 100);
  updateSurvivalHud();
  renderHotbar();
  markUnsaved();
  showToast('Air murni diminum · hidrasi dipulihkan.');
}

function openSupplyCache(cacheId) {
  const cache = supplyCacheLocations.find(item => item.id === cacheId);
  if (!cache || collectedCaches.has(cache.id)) { showToast('Tidak ada supply cache yang dapat dijangkau.'); return; }
  const distance = Math.hypot(player.position.x-cache.x, player.position.y-cache.y, player.position.z-cache.z);
  if (distance >= 14) { showToast('Dekati peti suplai terlebih dahulu.'); return; }
  collectedCaches.add(cache.id);
  publishSharedWorldEvent('cache_collected',cache.id,{cacheId:cache.id});
  rebuildChunkAtWorld(cache.x,cache.z);
  survival.medkits = clamp(survival.medkits + 1, 0, 20);
  survival.rations = clamp(survival.rations + 2, 0, 20);
  survival.waterBottles = clamp(survival.waterBottles + 1, 0, 20);
  inventory.titanium = clamp(inventory.titanium + 2, 0, 999);
  inventory.copper = clamp(inventory.copper + 1, 0, 999);
  updateSurvivalHud();
  markUnsaved();
  showToast(`${cache.name} dibuka · +1 Medkit · +2 Rations`);
}

function scanNearestFauna() {
  triggerToolAnimation('scanner');
  playSfx('scan');
  const scanPitch=clamp(player.pitch,-1.1,1.1);
  const scanDirection=new THREE.Vector3(Math.sin(player.yaw)*Math.cos(scanPitch),-Math.sin(scanPitch),-Math.cos(player.yaw)*Math.cos(scanPitch)).normalize();
  const scanOrigin=new THREE.Vector3(player.position.x,player.position.y+0.55,player.position.z);
  const scanAim={origin:scanOrigin,direction:scanDirection,minAlignment:0.945};
  const faunaTarget=faunaDirector?.getScanTarget(player.position,62,scanAim);
  const worldTarget=getAimedWorldTarget();
  if(worldTarget && faunaTarget && worldTarget.distance <= faunaTarget.distance){showToast('Bidik makhluk hidup dengan reticle; ada objek lain lebih dekat di garis pandang.');return;}
  const result = faunaDirector?.scan(player.position, 24, scanAim);
  if (!result) { showToast('Arahkan reticle tepat ke makhluk hidup dalam jangkauan pemindai.'); return; }
  if (result.isNew) publishSharedWorldEvent('fauna_scanned',result.id,{speciesId:result.id});
  if (getCurrentMission()?.id === 'scan') advanceMission('scan');
  const prefix = result.isNew ? 'SPESIES BARU' : 'TERDETEKSI';
  showToast(`${prefix}: ${result.name} · ${result.distance} m · ${result.total}/${result.maximum}`);
  updateSurvivalHud();
  renderPda();
  if (activeSlot >= 0) markUnsaved();
}

function updateHud() {
  const liveBiome=getBiomeAt(player.position.x,player.position.y,player.position.z);
  currentBiome=liveBiome;
  $('biome-label').textContent = liveBiome.label.toUpperCase();
  if (!knownBiomes.has(liveBiome.id)) { knownBiomes.add(liveBiome.id); publishSharedWorldEvent('biome_discovered',liveBiome.id,{biomeId:liveBiome.id}); if(activeSlot>=0) markUnsaved(); showToast(`BIOME DISCOVERED · ${liveBiome.label}`); }
  faunaDirector?.setBiome(liveBiome.id);
  $('depth-label').textContent = `${Math.max(0, Math.round(-player.position.y))} m`;
  const jumpButton=$('jump-btn');
  if(jumpButton){const floor=samplePlayerFloor(player.position.x,player.position.z);const waterY=waterSurfaceHeightAt(player.position.x,player.position.z,clockState.elapsed);const canJump=canPlayerJump(player.position.y-1.9,floor,waterY,player.velocity.y,.28);jumpButton.classList.toggle('hidden',!canJump);jumpButton.disabled=!canJump;}
  const dIsland = Math.hypot(player.position.x - islandOfInterest.x, player.position.z - islandOfInterest.z);
  const dShip = Math.hypot(player.position.x - shipOfInterest.x, player.position.z - shipOfInterest.z);
  const dTrench = Math.hypot(player.position.x - ABYSSAL_TRENCH.x, player.position.z - ABYSSAL_TRENCH.z);
  if(dShip < 82 && getCurrentMission()?.id === 'wreck') advanceMission('wreck');
  updateResourcePrompt(); 
  $('poi-banner').innerHTML = `${liveBiome.label.toUpperCase()} <span>— ${liveBiome.note}</span>`;
  if (dIsland < 115) $('poi-banner').innerHTML = `VERDANT ISLE · ${liveBiome.label.toUpperCase()} <span>— Island habitat</span>`;
  else if (dShip < 95) $('poi-banner').innerHTML = `WRECKFALL SHELF <span>— Abandoned vessel signal</span>`;
  else if (dTrench < 720) $('poi-banner').innerHTML = `TRENCH ANOMALY <span>— ${Math.round(dTrench)} m to the outer rift</span>`;
  if (faunaStatus.threat && faunaStatus.threat.distance < 40) {
    $('poi-banner').innerHTML = `PREDATOR ALERT · ${faunaStatus.threat.name.toUpperCase()} <span>— Threat detected · ${Math.round(faunaStatus.threat.distance)} m</span>`;
    $('poi-banner').classList.add('danger-signal');
  } else if (faunaStatus.nearest) {
    $('poi-banner').classList.remove('danger-signal');
    if (dIsland >= 115 && dShip >= 95 && dTrench >= 720) $('poi-banner').innerHTML = `LIFEFORM SIGNAL <span>— ${faunaStatus.nearest.species.name} · ${Math.round(faunaStatus.nearest.distance)} m</span>`;
  } else {
    $('poi-banner').classList.remove('danger-signal');
    if(dIsland>=115&&dShip>=95&&dTrench>=720){
      const current=sampleOceanCurrent(player.position.x,player.position.y,player.position.z,clockState.elapsed,liveBiome.id);
      if(current.speed>=.52){
        const sectors=['N','NE','E','SE','S','SW','W','NW'];
        const bearing=sectors[Math.round((Math.atan2(current.directionX,-current.directionZ)+Math.PI*2)%(Math.PI*2)/(Math.PI/4))%8];
        $('poi-banner').innerHTML=`OCEAN CURRENT <span>— ${bearing} · ${current.speed.toFixed(1)} m/s</span>`;
      }
    }
  }
  updateSurvivalHud();
}

function syncSpatialAudioListener() {
  if (!ambientContext || ambientContext.state === 'closed' || !camera) return;
  const listener = ambientContext.listener;
  const p = camera.position;
  const forward = camera.getWorldDirection(audioListenerForward);
  audioListenerUp.set(0,1,0).applyQuaternion(camera.quaternion).normalize();
  const now = ambientContext.currentTime;
  if (listener.positionX) {
    listener.positionX.setTargetAtTime(p.x,now,0.045);
    listener.positionY.setTargetAtTime(p.y,now,0.045);
    listener.positionZ.setTargetAtTime(p.z,now,0.045);
    listener.forwardX.setTargetAtTime(forward.x,now,0.045);
    listener.forwardY.setTargetAtTime(forward.y,now,0.045);
    listener.forwardZ.setTargetAtTime(forward.z,now,0.045);
    listener.upX.setTargetAtTime(audioListenerUp.x,now,0.045);
    listener.upY.setTargetAtTime(audioListenerUp.y,now,0.045);
    listener.upZ.setTargetAtTime(audioListenerUp.z,now,0.045);
  } else {
    listener.setPosition(p.x,p.y,p.z);
    listener.setOrientation(forward.x,forward.y,forward.z,audioListenerUp.x,audioListenerUp.y,audioListenerUp.z);
  }
}

function animate(now) {
  if (!animationLoopRunning || applicationSuspended || webglContextLost) return;
  animationFrameId = requestAnimationFrame(animate);
  const rawDelta = Number.isFinite(now - lastFrame) ? (now - lastFrame) / 1000 : 0;
  const dt = Math.max(0, Math.min(rawDelta, 0.05));
  lastFrame = now;

  // Background tabs/native app suspension stop the loop entirely. This guard
  // catches isolated runtime faults and pauses the expedition instead of
  // silently abandoning the render loop or consuming survival resources.
  if (!runtimeFrameError) {
    try {
      clockState.elapsed += dt;
      updateLifepodHatchAnimation(dt);
      updateVehicleVisuals(dt);
      updateWorldVisualEffects(dt);
      if (kelpShader?.uniforms?.uAbyssTime) kelpShader.uniforms.uAbyssTime.value=clockState.elapsed;
      if(introSequence.active && !gamePaused) {
        updateCinematic(dt);
      } else if (gameActive && !gamePaused) {
        updateMovement(dt);
        updatePendingKnifeAttack(dt);
        updateBuildPreview(dt);
        updateWorldPhysics(dt);
        updateSurvival(dt);
        currentBiome = getBiomeAt(player.position.x, player.position.y, player.position.z);
        faunaStatus = faunaDirector?.update(dt, player.position, currentBiome.id) || faunaStatus;
        const cx = Math.floor(player.position.x / CHUNK_SIZE), cz = Math.floor(player.position.z / CHUNK_SIZE);
        if (cx !== chunkCenterX || cz !== chunkCenterZ) updateChunks();
        updateCamera(dt);
        updateSwimBubbles(dt);

        // Co-op broadcasts player transforms at a conservative 5 Hz.
        if (online.inRoom && now - lastMultiplayerSync >= 190) {
          lastMultiplayerSync = now;
          online.broadcastPlayerState({
            x:player.position.x, y:player.position.y, z:player.position.z,
            yaw:player.yaw, pitch:player.pitch,
            depth:Math.max(0,-player.position.y), biome:currentBiome.id,
            tool:getSelectedHotbarItem() || ''
          }).catch(error => console.warn('[The Abyssal] Multiplayer broadcast:', error.message));
        }
        if (now - lastHudUpdate > 300) { lastHudUpdate = now; updateHud(); }
      } else if (!gameActive && rendererReady) {
        camera.position.x += Math.sin(now * 0.00007) * 0.012;
        camera.lookAt(0, -5, 0);
      }
      syncSpatialAudioListener();
      updateRemoteDiverVisuals(dt);
    } catch (error) {
      runtimeFrameError = error instanceof Error ? error : new Error(String(error));
      releaseTouchControls();
      if (gameActive && !gamePaused) pauseGame();
      console.error('[The Abyssal] Runtime frame paused safely:', runtimeFrameError);
      showToast('Ekspedisi dijeda karena terjadi kesalahan runtime. Periksa log, lalu coba Resume atau muat ulang.');
    }
  }
  if (renderer && scene && camera && !webglContextLost && !runtimeFrameError) {
    try { renderer.render(scene, camera); }
    catch (error) {
      runtimeFrameError = error instanceof Error ? error : new Error(String(error));
      if (gameActive && !gamePaused) pauseGame();
      console.error('[The Abyssal] Renderer paused safely:', runtimeFrameError);
      showToast('Rendering mengalami gangguan. Ekspedisi dijeda; pemulihan grafis akan dicoba bila tersedia.');
    }
  }
}

async function checkForAppUpdate() {
  const manifestUrl = window.ABYSSAL_UPDATE_MANIFEST_URL || '';
  if (!manifestUrl || !/^https:\/\//i.test(manifestUrl)) return;
  try {
    const response = await fetch(manifestUrl, { cache: 'no-store', headers: { Accept: 'application/json' } });
    if (!response.ok) throw new Error(`Update server returned ${response.status}`);
    const manifest = await response.json();
    const current = '3.1.0';
    if (!manifest || typeof manifest.version !== 'string' || typeof manifest.downloadUrl !== 'string') return;
    const download = new URL(manifest.downloadUrl);
    if (download.protocol !== 'https:') return;
    if (manifest.version !== current && compareVersions(manifest.version, current) > 0) {
      const install = window.confirm(`The Abyssal ${manifest.version} tersedia. Buka unduhan pembaruan APK?\n\n${manifest.notes || ''}\n\nAndroid akan meminta persetujuan sebelum memasang APK.`);
      if (install) {
        if (Boolean(window.Capacitor?.isNativePlatform?.())) {
          const { Browser } = await import('@capacitor/browser');
          await Browser.open({ url: download.toString() });
        } else window.open(download.toString(), '_blank', 'noopener');
      }
    }
  } catch (error) {
    console.info('Abyssal update check skipped:', error.message);
  }
}
function compareVersions(a, b) {
  const aa = a.split('.').map(Number), bb = b.split('.').map(Number);
  for (let i = 0; i < Math.max(aa.length, bb.length); i++) {
    const diff = (aa[i] || 0) - (bb[i] || 0);
    if (diff) return diff;
  }
  return 0;
}

async function boot() {
  try {
    $('boot-message').textContent = 'Membangun geometri dasar laut...';
    $('loading-bar').style.width = '18%';
    createWorld();
    $('boot-message').textContent = 'Menyiapkan kontrol dan antarmuka...';
    $('loading-bar').style.width = '72%';
    setupControls();
    bindNativeLifecycle().catch(error => console.warn('[The Abyssal] Native lifecycle setup skipped:', error));
    syncSettingsInputs();
    applyLanguage();
    // Online accounts/co-op are optional. Local single-player remains available
    // when no Supabase credentials or network connection are present.
    initializeOnlineServices().catch(error => console.warn('[The Abyssal] Online init skipped:', error));
    checkForAppUpdate().catch(() => {});
    $('boot-message').textContent = 'Dunia siap. Memulai ekspedisi...';
    $('loading-bar').style.width = '100%';
    // The APK contains its own offline-ready bundle. Service workers are only
    // used by an optional browser preview, never by the native Android shell.
    if (!Boolean(window.Capacitor?.isNativePlatform?.()) && 'serviceWorker' in navigator && location.protocol.startsWith('http')) {
      navigator.serviceWorker.register('./sw.js').catch(() => {});
    }
    setTimeout(() => {
      setVisibleScreen('main');
      $('boot-screen').classList.add('hidden');
    }, 350);
    startAnimationLoop();
  } catch (error) {
    console.error('[The Abyssal] Boot failed:', error);
    const message = error instanceof Error ? error.message : String(error);
    $('boot-title')?.classList.add('boot-error');
    $('boot-subtitle')?.classList.add('hidden');
    $('boot-message').textContent = `Dunia 3D gagal dimuat: ${message}. Periksa perangkat, lalu coba lagi.`;
    $('loading-bar').style.width = '100%';
    const retryButton = $('boot-retry-btn');
    if (retryButton) {
      retryButton.hidden = false;
      retryButton.onclick = () => window.location.reload();
    }
  }
}

boot();
