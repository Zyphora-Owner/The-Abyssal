/**
 * Shared presentation helpers for The Abyssal's first-person and underwater
 * rendering. These functions are deterministic and safe to test without WebGL.
 */

const freezeProfile = profile => Object.freeze({
  ...profile,
  position: Object.freeze(profile.position),
  rotation: Object.freeze(profile.rotation),
  gripOffset: Object.freeze(profile.gripOffset)
});

const DEFAULT_HELD_PRESENTATION = freezeProfile({
  scale: 0.78,
  position: [0.02, -0.39, -0.39],
  rotation: [0, 0, 0],
  gripOffset: [0, -0.01, -0.04],
  idleBob: 0.006,
  idleRoll: 0.012,
  idleYaw: 0.008,
  actionPitch: 0.24,
  actionLift: 0.055,
  phase: 0
});

export const HELD_ITEM_PRESENTATIONS = Object.freeze({
  titanium: freezeProfile({ scale:.78, position:[.02,-.395,-.39], rotation:[-.04,0,.08], gripOffset:[0,-.015,-.045], idleBob:.006, idleRoll:.009, idleYaw:.006, actionPitch:.16, actionLift:.045, phase:.2 }),
  copper: freezeProfile({ scale:.78, position:[.02,-.395,-.39], rotation:[-.03,0,.12], gripOffset:[0,-.012,-.045], idleBob:.006, idleRoll:.009, idleYaw:.006, actionPitch:.16, actionLift:.045, phase:.8 }),
  quartz: freezeProfile({ scale:.74, position:[.02,-.39,-.39], rotation:[-.12,0,.02], gripOffset:[0,-.01,-.05], idleBob:.008, idleRoll:.014, idleYaw:.008, actionPitch:.2, actionLift:.055, phase:1.4 }),
  lithium: freezeProfile({ scale:.74, position:[.02,-.39,-.39], rotation:[-.08,0,-.06], gripOffset:[0,-.01,-.05], idleBob:.007, idleRoll:.013, idleYaw:.008, actionPitch:.19, actionLift:.05, phase:2.0 }),
  sulfur: freezeProfile({ scale:.76, position:[.02,-.39,-.39], rotation:[-.1,0,.04], gripOffset:[0,-.01,-.05], idleBob:.007, idleRoll:.012, idleYaw:.007, actionPitch:.18, actionLift:.05, phase:2.6 }),
  magnetite: freezeProfile({ scale:.79, position:[.02,-.39,-.39], rotation:[.02,0,.1], gripOffset:[0,-.015,-.045], idleBob:.005, idleRoll:.008, idleYaw:.005, actionPitch:.14, actionLift:.04, phase:3.2 }),
  salt: freezeProfile({ scale:.75, position:[.02,-.39,-.39], rotation:[-.06,0,0], gripOffset:[0,-.01,-.05], idleBob:.006, idleRoll:.01, idleYaw:.007, actionPitch:.17, actionLift:.045, phase:3.8 }),
  silver: freezeProfile({ scale:.77, position:[.02,-.39,-.39], rotation:[-.02,0,.09], gripOffset:[0,-.012,-.045], idleBob:.005, idleRoll:.008, idleYaw:.006, actionPitch:.15, actionLift:.04, phase:4.4 }),
  coral: freezeProfile({ scale:.78, position:[.02,-.39,-.39], rotation:[-.08,0,-.08], gripOffset:[0,-.01,-.045], idleBob:.009, idleRoll:.016, idleYaw:.01, actionPitch:.2, actionLift:.06, phase:5.0 }),
  glowcap: freezeProfile({ scale:.78, position:[.02,-.39,-.39], rotation:[-.08,0,.04], gripOffset:[0,-.01,-.045], idleBob:.01, idleRoll:.018, idleYaw:.012, actionPitch:.2, actionLift:.06, phase:5.6 }),
  kelp: freezeProfile({ scale:.78, position:[.02,-.39,-.39], rotation:[-.04,0,.12], gripOffset:[0,-.01,-.045], idleBob:.012, idleRoll:.024, idleYaw:.016, actionPitch:.22, actionLift:.07, phase:6.2 }),
  fish_meat: freezeProfile({ scale:.72, position:[.02,-.405,-.385], rotation:[-.14,0,.1], gripOffset:[0,-.005,-.045], idleBob:.008, idleRoll:.014, idleYaw:.009, actionPitch:.34, actionLift:.11, phase:1.1 }),
  medkit: freezeProfile({ scale:.68, position:[.02,-.405,-.39], rotation:[-.02,0,0], gripOffset:[0,-.01,-.045], idleBob:.005, idleRoll:.008, idleYaw:.006, actionPitch:.3, actionLift:.095, phase:1.9 }),
  ration: freezeProfile({ scale:.72, position:[.02,-.40,-.39], rotation:[-.04,0,.08], gripOffset:[0,-.01,-.045], idleBob:.005, idleRoll:.01, idleYaw:.006, actionPitch:.32, actionLift:.09, phase:2.7 }),
  water: freezeProfile({ scale:.72, position:[.02,-.40,-.39], rotation:[-.03,0,-.05], gripOffset:[0,-.01,-.045], idleBob:.006, idleRoll:.012, idleYaw:.008, actionPitch:.38, actionLift:.12, phase:3.5 }),
  battery: freezeProfile({ scale:.75, position:[.02,-.40,-.39], rotation:[-.03,0,.06], gripOffset:[0,-.012,-.045], idleBob:.005, idleRoll:.008, idleYaw:.006, actionPitch:.18, actionLift:.05, phase:4.3 }),
  power_cell: freezeProfile({ scale:.69, position:[.02,-.40,-.39], rotation:[-.08,0,.04], gripOffset:[0,-.012,-.045], idleBob:.005, idleRoll:.008, idleYaw:.006, actionPitch:.15, actionLift:.04, phase:5.1 }),
  wiring_kit: freezeProfile({ scale:.74, position:[.02,-.40,-.39], rotation:[-.03,0,.1], gripOffset:[0,-.01,-.045], idleBob:.006, idleRoll:.012, idleYaw:.008, actionPitch:.19, actionLift:.05, phase:5.9 }),
  computer_chip: freezeProfile({ scale:.76, position:[.02,-.40,-.39], rotation:[-.04,0,-.06], gripOffset:[0,-.01,-.045], idleBob:.005, idleRoll:.009, idleYaw:.006, actionPitch:.16, actionLift:.045, phase:6.7 }),
  glass: freezeProfile({ scale:.72, position:[.02,-.40,-.39], rotation:[-.08,0,0], gripOffset:[0,-.01,-.045], idleBob:.007, idleRoll:.012, idleYaw:.008, actionPitch:.19, actionLift:.05, phase:7.5 }),
  fiber_mesh: freezeProfile({ scale:.75, position:[.02,-.40,-.39], rotation:[-.02,0,.04], gripOffset:[0,-.01,-.045], idleBob:.006, idleRoll:.01, idleYaw:.007, actionPitch:.18, actionLift:.05, phase:8.3 }),
  silicone: freezeProfile({ scale:.73, position:[.02,-.40,-.39], rotation:[-.03,0,.07], gripOffset:[0,-.01,-.045], idleBob:.005, idleRoll:.01, idleYaw:.006, actionPitch:.18, actionLift:.05, phase:9.1 }),
  lubricant: freezeProfile({ scale:.73, position:[.02,-.40,-.39], rotation:[-.03,0,-.06], gripOffset:[0,-.01,-.045], idleBob:.005, idleRoll:.01, idleYaw:.006, actionPitch:.18, actionLift:.05, phase:9.9 }),
  bleach: freezeProfile({ scale:.73, position:[.02,-.40,-.39], rotation:[-.03,0,0], gripOffset:[0,-.01,-.045], idleBob:.005, idleRoll:.01, idleYaw:.006, actionPitch:.18, actionLift:.05, phase:10.7 })
});

export function resolveHeldItemPresentation(itemId) {
  return HELD_ITEM_PRESENTATIONS[itemId] || DEFAULT_HELD_PRESENTATION;
}

const clamp01 = value => Math.min(1, Math.max(0, Number(value) || 0));
const smooth01 = value => { const t = clamp01(value); return t * t * (3 - 2 * t); };

/** Returns additive local transforms for one selected held resource/supply model. */
export function computeHeldItemMotion({
  itemId = '', elapsed = 0, equipProgress = 1, actionProgress = 0, actionType = ''
} = {}) {
  const profile = resolveHeldItemPresentation(itemId);
  const time = Number.isFinite(Number(elapsed)) ? Number(elapsed) : 0;
  const equipped = smooth01(equipProgress);
  const action = smooth01(actionProgress);
  const actionAmount = actionType === 'use' || actionType === 'consume' ? action : 0;
  return {
    offsetY: -(1 - equipped) * 0.15 + Math.sin(time * 1.65 + profile.phase) * profile.idleBob - actionAmount * profile.actionLift,
    offsetX: Math.sin(time * 0.82 + profile.phase) * profile.idleBob * 0.32,
    rotationX: -(1 - equipped) * 0.28 - actionAmount * profile.actionPitch,
    rotationY: Math.sin(time * 0.72 + profile.phase) * profile.idleYaw,
    rotationZ: Math.sin(time * 1.1 + profile.phase) * profile.idleRoll,
    scaleFactor: 0.94 + equipped * 0.06
  };
}

/** Depth-dependent visual cues; all outputs are bounded and platform independent. */
export function getDepthAtmosphereProfile(depth = 0, surfaceBlend = 0, quality = 'balanced') {
  const safeDepth = Math.max(0, Number.isFinite(Number(depth)) ? Number(depth) : 0);
  const surface = clamp01(surfaceBlend);
  const deepBlend = smooth01((safeDepth - 80) / 470);
  const hadalBlend = smooth01((safeDepth - 520) / 980);
  const qualityScale = quality === 'low' ? 0.84 : quality === 'high' || quality === 'ultra' ? 1 : 0.92;
  return Object.freeze({
    deepBlend: deepBlend * (1 - surface),
    hadalBlend: hadalBlend * (1 - surface),
    lightRetention: Math.max(0.055, (1 - deepBlend * 0.72 - hadalBlend * 0.22) * (1 - surface * 0.18)),
    fogScale: (1 + deepBlend * 0.34 + hadalBlend * 0.58) * qualityScale,
    particleVisibility: (1 - surface) * Math.max(0.42, 1 - deepBlend * 0.12 - hadalBlend * 0.28)
  });
}
