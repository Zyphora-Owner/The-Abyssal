/**
 * Deterministic three-dimensional ocean-current field.
 * Currents are sampled from world coordinates and simulation time, so nearby
 * entities share a coherent flow and the field remains stable across saves.
 * Values are metres per second and are intentionally bounded for mobile play.
 */

const BIOME_FLOW = Object.freeze({
  reef: Object.freeze({ strength: 0.66, phase: 0.2, vertical: 0.035, maxSpeed: 0.88 }),
  kelp: Object.freeze({ strength: 0.82, phase: 1.1, vertical: 0.045, maxSpeed: 1.02 }),
  wreck: Object.freeze({ strength: 0.72, phase: 2.2, vertical: 0.025, maxSpeed: 0.94 }),
  thermal: Object.freeze({ strength: 1.12, phase: 0.7, vertical: 0.34, maxSpeed: 1.2 }),
  deep: Object.freeze({ strength: 0.58, phase: 1.8, vertical: 0.06, maxSpeed: 0.82 }),
  abyss: Object.freeze({ strength: 0.72, phase: 2.7, vertical: 0.075, maxSpeed: 0.96 }),
  abyssal_shelf: Object.freeze({ strength: 0.68, phase: 3.4, vertical: 0.08, maxSpeed: 0.92 }),
  midnight_grotto: Object.freeze({ strength: 0.84, phase: 4.1, vertical: 0.09, maxSpeed: 1.08 }),
  blue_void: Object.freeze({ strength: 0.72, phase: 4.8, vertical: 0.12, maxSpeed: 0.98 }),
  hadal_rift: Object.freeze({ strength: 1.2, phase: 5.4, vertical: 0.28, maxSpeed: 1.3 }),
  hadal_garden: Object.freeze({ strength: 0.9, phase: 6.1, vertical: 0.16, maxSpeed: 1.12 }),
  open: Object.freeze({ strength: 0.74, phase: 0.9, vertical: 0.05, maxSpeed: 0.98 })
});

const finite = (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback;
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const smooth01 = value => { const t = clamp(value, 0, 1); return t * t * (3 - 2 * t); };

/**
 * Samples a smooth, spatially coherent flow in m/s.
 * @param {number} x World X in metres.
 * @param {number} y World Y in metres (negative below sea level).
 * @param {number} z World Z in metres.
 * @param {number} elapsedSeconds Simulation time in seconds.
 * @param {string} biomeId Active biome identifier.
 * @returns {{x:number,y:number,z:number,speed:number,directionX:number,directionZ:number,biome:string}}
 */
export function sampleOceanCurrent(x = 0, y = 0, z = 0, elapsedSeconds = 0, biomeId = 'open') {
  const px = finite(x), py = finite(y), pz = finite(z), time = finite(elapsedSeconds);
  const biome = Object.prototype.hasOwnProperty.call(BIOME_FLOW, biomeId) ? biomeId : 'open';
  const profile = BIOME_FLOW[biome];
  const depth = Math.max(0, -py);
  const depthScale = 0.82 + smooth01(depth / 720) * 0.18;
  const phase = time * 0.16;

  // Two broad directional bands plus a slower cross-current create a gyre-like
  // field without discontinuities, random impulses, or per-frame allocations.
  const eastWest = Math.sin(pz * 0.0087 + phase + profile.phase) * 0.56
    + Math.sin((px + pz) * 0.0041 - phase * 0.58 + profile.phase * 0.37) * 0.29;
  const northSouth = Math.cos(px * 0.0076 - phase * 0.83 + profile.phase * 0.61) * 0.52
    + Math.sin((pz - px) * 0.0048 + phase * 0.46 - profile.phase * 0.22) * 0.31;
  const eddy = Math.sin((px * 0.012 + pz * 0.009) + time * 0.31 + profile.phase) * 0.11;
  const scale = profile.strength * depthScale;

  let vx = (eastWest + eddy) * 0.46 * scale;
  let vz = (northSouth - eddy * 0.72) * 0.46 * scale;
  let vy = Math.sin(px * 0.013 - pz * 0.011 + time * 0.22 + profile.phase) * profile.vertical * depthScale;

  // Submarine vent plumes and rift upwellings add a weak, readable vertical
  // component; they never become a lift force capable of launching the diver.
  if (biome === 'thermal') vy += 0.12 * depthScale;
  if (biome === 'hadal_rift') vy += Math.sin((px + pz) * 0.006 + time * 0.12) * 0.08;

  const magnitude = Math.hypot(vx, vy, vz);
  if (magnitude > profile.maxSpeed) {
    const factor = profile.maxSpeed / magnitude;
    vx *= factor; vy *= factor; vz *= factor;
  }
  const horizontal = Math.hypot(vx, vz);
  return {
    x: vx,
    y: vy,
    z: vz,
    speed: Math.hypot(vx, vy, vz),
    directionX: horizontal > 1e-6 ? vx / horizontal : 0,
    directionZ: horizontal > 1e-6 ? vz / horizontal : 0,
    biome
  };
}

/** The diver resists currents with fins and strongly resists them with Seaglide. */
export function getDiverCurrentResponse({ fins = false, seaglide = false, sheltered = false } = {}) {
  if (sheltered) return 0;
  if (seaglide) return 0.12;
  return fins ? 0.27 : 0.48;
}

/** Heavy vehicles are affected less than a free-swimming diver. */
export function getVehicleCurrentResponse(vehicleId = 'skimmer') {
  return vehicleId === 'carrier' ? 0.075 : vehicleId === 'exosuit' ? 0.11 : 0.19;
}

export const OCEAN_CURRENT_BIOMES = Object.freeze(Object.keys(BIOME_FLOW));
