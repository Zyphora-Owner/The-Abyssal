/**
 * Lightweight, deterministic seafloor ecology budgets. These are original
 * The Abyssal habitat rules; counts scale with graphics quality without
 * changing world coordinates, save data, or collision.
 */
const QUALITY_SCALE = Object.freeze({ low: 0.58, balanced: 0.82, high: 1, ultra: 1.16 });

const PROFILES = Object.freeze({
  reef: Object.freeze({ seagrass: 10, coral: 18, fanCoral: 4, spongeClusters: 0, oxygenPlants: 0, hadalBlooms: 0, basaltFormations: 0 }),
  kelp: Object.freeze({ seagrass: 28, coral: 10, fanCoral: 3, spongeClusters: 0, oxygenPlants: 1, hadalBlooms: 0, basaltFormations: 0 }),
  wreck: Object.freeze({ seagrass: 3, coral: 4, fanCoral: 1, spongeClusters: 1, oxygenPlants: 0, hadalBlooms: 0, basaltFormations: 1 }),
  thermal: Object.freeze({ seagrass: 0, coral: 7, fanCoral: 2, spongeClusters: 2, oxygenPlants: 0, hadalBlooms: 1, basaltFormations: 2 }),
  deep: Object.freeze({ seagrass: 0, coral: 0, fanCoral: 0, spongeClusters: 2, oxygenPlants: 0, hadalBlooms: 1, basaltFormations: 1 }),
  abyss: Object.freeze({ seagrass: 0, coral: 0, fanCoral: 0, spongeClusters: 2, oxygenPlants: 0, hadalBlooms: 1, basaltFormations: 2 }),
  abyssal_shelf: Object.freeze({ seagrass: 0, coral: 2, fanCoral: 1, spongeClusters: 3, oxygenPlants: 0, hadalBlooms: 1, basaltFormations: 2 }),
  midnight_grotto: Object.freeze({ seagrass: 0, coral: 0, fanCoral: 0, spongeClusters: 4, oxygenPlants: 0, hadalBlooms: 2, basaltFormations: 3 }),
  blue_void: Object.freeze({ seagrass: 0, coral: 0, fanCoral: 0, spongeClusters: 2, oxygenPlants: 0, hadalBlooms: 2, basaltFormations: 3 }),
  hadal_rift: Object.freeze({ seagrass: 0, coral: 0, fanCoral: 0, spongeClusters: 4, oxygenPlants: 0, hadalBlooms: 2, basaltFormations: 3 }),
  hadal_garden: Object.freeze({ seagrass: 0, coral: 0, fanCoral: 0, spongeClusters: 5, oxygenPlants: 0, hadalBlooms: 4, basaltFormations: 2 }),
  open: Object.freeze({ seagrass: 3, coral: 2, fanCoral: 1, spongeClusters: 0, oxygenPlants: 0, hadalBlooms: 0, basaltFormations: 0 })
});

const clampQuality = value => Object.prototype.hasOwnProperty.call(QUALITY_SCALE, value) ? value : 'balanced';

export function getBiomeEcologyProfile(biomeId = 'open', quality = 'balanced') {
  const base = PROFILES[String(biomeId)] || PROFILES.open;
  const scale = QUALITY_SCALE[clampQuality(quality)];
  const counts = {};
  for (const [key, value] of Object.entries(base)) {
    counts[key] = value === 0 ? 0 : Math.max(1, Math.round(value * scale));
  }
  return Object.freeze({ biomeId: PROFILES[biomeId] ? biomeId : 'open', quality: clampQuality(quality), ...counts });
}

export function isValidEcologyProfile(profile) {
  if (!profile || typeof profile !== 'object') return false;
  return ['seagrass','coral','fanCoral','spongeClusters','oxygenPlants','hadalBlooms','basaltFormations'].every(key => Number.isInteger(profile[key]) && profile[key] >= 0 && profile[key] <= 64);
}

export const OCEAN_ECOLOGY_BIOMES = Object.freeze(Object.keys(PROFILES));
