/** Lightweight, deterministic buoyancy, gravity and fluid-drag helpers. */
export const STANDARD_GRAVITY = 9.81;
export const SEAWATER_DENSITY_KG_M3 = 1025;
const finite = (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback;
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

/** Positive acceleration rises; negative acceleration sinks. */
export function computeBuoyancyAcceleration(densityRatio = 1, gravity = STANDARD_GRAVITY) {
  const ratio = clamp(finite(densityRatio, 1), 0.15, 4);
  const g = clamp(finite(gravity, STANDARD_GRAVITY), 0, 40);
  return g * (1 - ratio);
}

/**
 * Integrate a small free body in water using semi-implicit Euler and exponential
 * drag. Flow is a medium velocity, not a direct teleport, so frame rate does
 * not change the damping response.
 */
export function integrateFluidBody({
  velocity = { x:0, y:0, z:0 }, dt = 0,
  densityRatio = 1.28, gravity = STANDARD_GRAVITY,
  drag = 1.15, flow = { x:0, y:0, z:0 }, flowCoupling = 0.25,
  maxSpeed = 18
} = {}) {
  const step = clamp(finite(dt), 0, 0.05);
  const vx = finite(velocity?.x), vy = finite(velocity?.y), vz = finite(velocity?.z);
  const fx = finite(flow?.x), fy = finite(flow?.y), fz = finite(flow?.z);
  const coupling = clamp(finite(flowCoupling, 0.25), 0, 2);
  const medium = { x:fx * coupling, y:fy * coupling, z:fz * coupling };
  let x = vx + medium.x * step;
  let y = vy + (computeBuoyancyAcceleration(densityRatio, gravity) + medium.y) * step;
  let z = vz + medium.z * step;
  const damping = Math.exp(-clamp(finite(drag, 1.15), 0, 12) * step);
  x = medium.x + (x - medium.x) * damping;
  y = medium.y + (y - medium.y) * damping;
  z = medium.z + (z - medium.z) * damping;
  const speed = Math.hypot(x, y, z);
  const speedLimit = clamp(finite(maxSpeed, 18), 0.1, 80);
  if (speed > speedLimit && speed > 0) { const scale = speedLimit / speed; x *= scale; y *= scale; z *= scale; }
  return { x, y, z };
}

/** Neutral-buoyancy trim for the diver. Heavy equipment creates a gentle sink bias. */
export function getDiverBuoyancyTrim({ tankLevel = 0, rebreather = false, seaglide = false, insideHabitat = false } = {}) {
  if (insideHabitat) return 0;
  const tankLoad = clamp(Math.floor(finite(tankLevel)), 0, 7) * 0.018;
  const breathingLoad = rebreather ? 0.008 : 0;
  const poweredTrim = seaglide ? 0.006 : 0;
  return clamp(0.035 - tankLoad - breathingLoad - poweredTrim, -0.10, 0.04);
}

/** Grounded locomotion uses normal gravity, not the exaggerated arcade fall rate. */
export function integrateGroundGravity(verticalVelocity = 0, dt = 0, terminalSpeed = 24) {
  const step = clamp(finite(dt), 0, 0.05);
  return clamp(finite(verticalVelocity) - STANDARD_GRAVITY * step, -Math.abs(terminalSpeed), Math.abs(terminalSpeed));
}

/** Clamp a capsule centre below a cave roof while preserving body clearance. */
export function clampCapsuleBelowCeiling(centerY, ceilingY, halfHeight = 0.9, margin = 0.08) {
  const y = finite(centerY);
  const roof = Number(ceilingY);
  if (!Number.isFinite(roof)) return y;
  return Math.min(y, roof - Math.max(0.1, finite(halfHeight, 0.9)) - Math.max(0, finite(margin, 0.08)));
}

/** Density ratios relative to seawater; light flora barely sinks while ore drops settle. */
export function getResourceDensityRatio(type = '') {
  const ratios = {
    titanium:1.68, copper:1.82, quartz:1.42, lithium:1.36, sulfur:1.30,
    magnetite:1.92, salt:1.22, silver:1.86, coral:1.24, glowcap:0.91,
    kelp:0.88, fish_meat:0.96, glass:1.56, silicone:1.08, fiber_mesh:0.92,
    battery:1.48, wiring_kit:1.34, computer_chip:1.22, power_cell:1.56,
    lubricant:0.94, bleach:1.04
  };
  return ratios[String(type)] ?? 1.30;
}
