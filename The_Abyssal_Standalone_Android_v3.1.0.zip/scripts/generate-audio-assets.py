#!/usr/bin/env python3
"""Generate original, loop-safe underwater ambience and gameplay SFX for The Abyssal."""
from pathlib import Path
import numpy as np, subprocess
from scipy.signal import butter, sosfilt

ROOT=Path(__file__).resolve().parents[1]/'assets'/'audio'; ROOT.mkdir(parents=True,exist_ok=True)
SR=44100
rng=np.random.default_rng(8142)

def filtered_noise(n, low=None, high=None, seed=None):
    r=np.random.default_rng(seed) if seed is not None else rng
    x=r.normal(0,1,n)
    if low and high: sos=butter(3,[low,high],btype='bandpass',fs=SR,output='sos')
    elif low: sos=butter(3,low,btype='highpass',fs=SR,output='sos')
    elif high: sos=butter(3,high,btype='lowpass',fs=SR,output='sos')
    else: return x
    return sosfilt(sos,x)

def smooth_loop(x, fade=0.18):
    k=max(1,int(SR*fade)); ramp=np.linspace(0,1,k,endpoint=False)
    a=x[:k].copy(); b=x[-k:].copy(); blend=b*(1-ramp)+a*ramp
    x[:k]=blend; x[-k:]=blend
    return x

def write_ogg(name, audio, q='5'):
    audio=np.asarray(audio,dtype=np.float32)
    peak=max(float(np.max(np.abs(audio))),1e-5)
    audio=np.clip(audio*(0.82/peak),-0.98,0.98)
    wav=ROOT/(name+'.wav'); ogg=ROOT/(name+'.ogg')
    import soundfile as sf
    sf.write(wav,audio,SR,subtype='PCM_16')
    subprocess.run(['ffmpeg','-y','-loglevel','error','-i',str(wav),'-c:a','libvorbis','-q:a',q,str(ogg)],check=True)
    wav.unlink(missing_ok=True)
    print(name, ogg.stat().st_size)

def ambience(name, seconds, tone_set, noise_band, clicks=0, creaks=0, seed=0):
    n=int(SR*seconds); t=np.arange(n)/SR
    x=filtered_noise(n,*noise_band,seed=seed)
    x/=max(np.std(x),1e-6); x*=0.16
    left=x.copy(); right=np.roll(x,int(SR*.23))*.82
    for freq,amp,mod,phase in tone_set:
        base=np.sin(2*np.pi*freq*t+phase + .11*np.sin(2*np.pi*mod*t))
        overtone=np.sin(2*np.pi*(freq*1.51)*t+phase*.7)*.21
        wave=(base+overtone)*amp
        left+=wave; right+=np.roll(wave,int(SR*(.025+(freq%7)*.004)))
    # Low, distant swells are smooth periodic envelopes.
    swell=(.5+.5*np.sin(2*np.pi*t/seconds*3+1.1))**2
    low=filtered_noise(n,high=145,seed=seed+10); low/=max(np.std(low),1e-6)
    left+=low*.10*swell; right+=np.roll(low,int(SR*.07))*.09*swell
    if clicks:
        for i in range(clicks):
            at=int((i+.5)*n/clicks + rng.integers(-SR//8,SR//8)); at%=n
            dur=int(SR*rng.uniform(.008,.032)); idx=(np.arange(dur)+at)%n
            env=np.exp(-np.arange(dur)/(dur*.17))
            pulse=filtered_noise(dur,1200,9500,seed+100+i)*env*.08
            left[idx]+=pulse; right[(idx+int(SR*.018))%n]+=pulse*.7
    if creaks:
        for i in range(creaks):
            at=int((i+.5)*n/creaks); dur=int(SR*rng.uniform(.25,.8)); idx=(np.arange(dur)+at)%n
            tt=np.arange(dur)/SR; f=rng.uniform(55,180)
            tone=np.sin(2*np.pi*(f*tt+22*tt*tt))*np.exp(-tt*3)*.045
            left[idx]+=tone; right[(idx+int(SR*.09))%n]+=tone*.72
    left=smooth_loop(left); right=smooth_loop(right)
    write_ogg(name,np.stack([left,right],axis=1))

ambience('ambience_reef',12,[(53,.08,.09,.2),(91,.045,.13,1.2),(173,.022,.18,2.2)],(170,1150),clicks=48,creaks=3,seed=110)
ambience('ambience_kelp',12,[(42,.075,.055,.5),(68,.055,.08,1.4),(128,.026,.11,2.1)],(95,720),clicks=18,creaks=7,seed=210)
ambience('ambience_wreck',12,[(29,.085,.04,.4),(61,.055,.075,1.5),(112,.022,.09,2.4)],(60,520),clicks=8,creaks=13,seed=310)
ambience('ambience_hadal',14,[(18,.085,.023,.8),(31,.06,.037,1.8),(49,.035,.055,2.7)],(24,260),clicks=7,creaks=6,seed=410)
ambience('ambience_cave',12,[(24,.075,.032,.1),(39,.05,.047,1.4),(83,.027,.08,2.1)],(35,420),clicks=14,creaks=16,seed=510)

def sfx(name, seconds, builder, q='5'):
    n=int(SR*seconds); t=np.arange(n)/SR
    mono=builder(t,n)
    mono=smooth_loop(mono,fade=min(.04,seconds*.08))
    write_ogg(name,np.stack([mono,mono*.91],axis=1),q)

def tone_sweep(t, f0, f1, dur, phase=0):
    end=max(dur,1e-4); k=(f1-f0)/end
    return np.sin(2*np.pi*(f0*t+.5*k*t*t)+phase)

def bubble(t,n):
    out=np.zeros(n)
    local=np.random.default_rng(91)
    for _ in range(23):
        at=local.uniform(.02,1.28); f=local.uniform(240,1050); dur=local.uniform(.025,.12)
        env=np.exp(-np.maximum(0,t-at)/(dur*.42))*(t>=at)*(t<at+dur)
        phase=2*np.pi*(f*(t-at)+local.uniform(0,1)*28*np.maximum(0,t-at)**2)
        out+=np.sin(phase)*env*local.uniform(.14,.38)
    fizz=filtered_noise(n,1200,9000,seed=92)*np.exp(-t*3.8)*.08
    return out+fizz

def sonar(t,n):
    env=np.exp(-t*2.4)
    carrier=np.sin(2*np.pi*(420*t+175*t*t))
    shimmer=np.sin(2*np.pi*(840*t+350*t*t)+.2)
    return (carrier+.35*shimmer)*env*.35

def roar(t,n):
    env=np.minimum(1,t/.22)*np.exp(-np.maximum(0,t-.65)*1.25)
    low=tone_sweep(t,38,74,2.8)*.48
    growl=filtered_noise(n,45,360,seed=121)*.25
    rasp=filtered_noise(n,380,1700,seed=122)*.08
    modulation=.7+.3*np.sin(2*np.pi*3.4*t)
    return (low+growl+rasp)*env*modulation

def small_call(t,n):
    env=np.exp(-t*3.5)
    chirp=tone_sweep(t,740,1280,1.6)*.25+np.sin(2*np.pi*1770*t)*.08
    clicks=filtered_noise(n,1800,8000,seed=134)*.05
    return (chirp+clicks)*env

def hatch(t,n):
    env=np.minimum(1,t/.04)*np.exp(-np.maximum(0,t-.35)*2.7)
    motor=tone_sweep(t,96,42,1.4)*.22 + np.sin(2*np.pi*28*t)*.16
    scrape=filtered_noise(n,450,2600,seed=145)*.08
    return (motor+scrape)*env

def pickup(t,n):
    env=np.exp(-t*9)
    return (np.sin(2*np.pi*660*t)+.48*np.sin(2*np.pi*990*t))*env*.22

def scanner(t,n):
    env=np.exp(-t*1.5)
    return (np.sin(2*np.pi*(520*t+380*t*t))*.22+np.sin(2*np.pi*(1040*t+760*t*t))*.08)*env

def impact(t,n):
    env=np.exp(-t*5.2)
    low=tone_sweep(t,92,28,.9)*.55
    burst=filtered_noise(n,80,2400,seed=155)*.25
    return (low+burst)*env

def mineral(t,n):
    env=np.exp(-t*13)
    return (np.sin(2*np.pi*1450*t)+.62*np.sin(2*np.pi*2210*t))*env*.22+filtered_noise(n,1200,8500,seed=165)*env*.08

def whale_song(t,n):
    env=np.minimum(1,t/.5)*np.exp(-np.maximum(0,t-1.5)*.7)
    f=95+28*np.sin(2*np.pi*.24*t)
    phase=2*np.pi*np.cumsum(f)/SR
    return (np.sin(phase)+.3*np.sin(phase*2.03))*env*.28

sfx('sfx_bubbles',1.65,bubble)
sfx('sfx_sonar',2.25,sonar)
sfx('sfx_leviathan_call',3.4,roar)
sfx('sfx_fauna_chirp',1.7,small_call)
sfx('sfx_hatch_servo',1.45,hatch)
sfx('sfx_item_pickup',.58,pickup)
sfx('sfx_scanner_sweep',1.55,scanner)
sfx('sfx_hull_impact',1.2,impact)
sfx('sfx_mineral_strike',.72,mineral)
sfx('sfx_whale_song',4.5,whale_song)

def predator_growl(t,n):
    env=np.minimum(1,t/.10)*np.exp(-np.maximum(0,t-.72)*2.1)
    low=tone_sweep(t,58,104,1.5)*.34
    rasp=filtered_noise(n,180,1450,seed=171)*(.22+.08*np.sin(2*np.pi*5.2*t))
    pulse=.72+.28*np.sin(2*np.pi*7.0*t)
    return (low+rasp)*env*pulse

def crustacean_click(t,n):
    out=np.zeros(n)
    local=np.random.default_rng(182)
    for _ in range(18):
        at=local.uniform(.025,.68); dur=local.uniform(.008,.034); freq=local.uniform(900,3600)
        env=np.exp(-np.maximum(0,t-at)/(dur*.35))*(t>=at)*(t<at+dur)
        out+=np.sin(2*np.pi*freq*(t-at))*env*local.uniform(.18,.48)
        out+=filtered_noise(n,1800,9000,seed=183+_)*env*.08
    return out

def jelly_pulse(t,n):
    phase=2*np.pi*(155*t+22*t*t)
    carrier=np.sin(phase)+.35*np.sin(phase*1.8+.4)
    envelope=(.5+.5*np.sin(2*np.pi*1.6*t))**2*np.exp(-t*.42)
    airy=filtered_noise(n,500,3200,seed=194)*.10*np.exp(-t*1.5)
    return carrier*envelope*.20+airy

def ray_sweep(t,n):
    env=np.sin(np.minimum(1,t/2.5)*np.pi)**1.4
    phase=2*np.pi*(280*t+94*t*t)
    whistle=np.sin(phase)*.22+np.sin(phase*1.51+.8)*.07
    air=filtered_noise(n,700,6200,seed=205)*.12
    return (whistle+air)*env

sfx('sfx_predator_growl',1.8,predator_growl)
sfx('sfx_crustacean_click',.82,crustacean_click)
sfx('sfx_jelly_pulse',2.4,jelly_pulse)
sfx('sfx_ray_sweep',2.6,ray_sweep)

def knife_swipe(t,n):
    env=np.exp(-t*7.8)*(1-np.exp(-t*45))
    sweep=filtered_noise(n,650,7200,seed=216)*.24
    edge=tone_sweep(t,1250,260,.42)*.14
    return (sweep+edge)*env

def fabricator_cycle(t,n):
    env=np.minimum(1,t/.08)*np.exp(-t*.95)
    motor=(np.sin(2*np.pi*(76*t+18*t*t))*.25+np.sin(2*np.pi*(152*t+36*t*t))*.12)
    grind=filtered_noise(n,350,3800,seed=227)*(.12+.05*np.sin(2*np.pi*9*t))
    ticks=np.zeros(n)
    for at in [.16,.38,.61,.86,1.08]:
        ticks+=np.exp(-((t-at)/.012)**2)*np.sin(2*np.pi*2100*(t-at))*.18
    return (motor+grind+ticks)*env

def build_seal(t,n):
    env=np.exp(-t*6.5)
    thump=tone_sweep(t,100,38,.6)*.42
    hiss=filtered_noise(n,700,5200,seed=238)*.16
    latch=np.exp(-((t-.31)/.026)**2)*np.sin(2*np.pi*1450*t)*.28
    return (thump+hiss+latch)*env

def repair_tool(t,n):
    env=(.65+.35*np.sin(2*np.pi*13*t))*np.exp(-t*1.65)
    beam=np.sin(2*np.pi*(360*t+780*t*t))*.19
    fizz=filtered_noise(n,1200,9000,seed=249)*.11
    return (beam+fizz)*env

def oxygen_alarm(t,n):
    pulse=((np.sin(2*np.pi*2.4*t)>0).astype(float))
    env=np.minimum(1,t/.04)*np.exp(-t*.28)
    signal=np.sin(2*np.pi*880*t)*.22+np.sin(2*np.pi*660*t)*.10
    return signal*pulse*env

def fin_sweep(t,n):
    env=np.sin(np.minimum(1,t/.58)*np.pi)**1.2
    whoosh=filtered_noise(n,180,2400,seed=260)*.24
    bubbles=filtered_noise(n,1200,6800,seed=261)*.08
    return (whoosh+bubbles)*env

def switch_click(t,n):
    click=filtered_noise(n,1200,9000,seed=272)*np.exp(-t*55)*.32
    tone=np.sin(2*np.pi*(540*t+220*t*t))*np.exp(-t*17)*.16
    return click+tone

def creature_bite(t,n):
    env=np.exp(-t*8.5)
    crunch=filtered_noise(n,160,3200,seed=283)*.3
    low=tone_sweep(t,72,32,.46)*.34
    return (crunch+low)*env

def eating_gulp(t,n):
    env=np.exp(-t*3.8)
    bubbles=filtered_noise(n,250,1800,seed=294)*.2
    gulp=tone_sweep(t,280,135,.75)*.2
    pops=np.exp(-((t-.18)/.045)**2)*np.sin(2*np.pi*920*t)*.18
    return (bubbles+gulp+pops)*env

def engine_start(t,n):
    env=np.minimum(1,t/.18)*np.exp(-np.maximum(0,t-1.0)*1.1)
    motor=tone_sweep(t,32,118,1.45)*.27+np.sin(2*np.pi*235*t)*.09
    airy=filtered_noise(n,250,1900,seed=305)*.12
    return (motor+airy)*env

sfx('sfx_knife_swipe',.62,knife_swipe)
sfx('sfx_fabricator_cycle',1.35,fabricator_cycle)
sfx('sfx_build_seal',.92,build_seal)
sfx('sfx_repair_tool',1.35,repair_tool)
sfx('sfx_oxygen_alarm',1.4,oxygen_alarm)
sfx('sfx_fin_sweep',.62,fin_sweep)
sfx('sfx_switch_click',.32,switch_click)
sfx('sfx_creature_bite',.66,creature_bite)
sfx('sfx_eating_gulp',.95,eating_gulp)
sfx('sfx_engine_start',1.65,engine_start)
# Manifest maps semantic game events to authored sound effects and biome ambience.
manifest={
 'ambience': {'reef':'ambience_reef.ogg','kelp':'ambience_kelp.ogg','wreck':'ambience_wreck.ogg','thermal':'ambience_wreck.ogg','deep':'ambience_hadal.ogg','abyss':'ambience_hadal.ogg','abyssal_shelf':'ambience_hadal.ogg','midnight_grotto':'ambience_cave.ogg','blue_void':'ambience_hadal.ogg','hadal_rift':'ambience_hadal.ogg','hadal_garden':'ambience_hadal.ogg','open':'ambience_reef.ogg','cave':'ambience_cave.ogg'},
 'events': {
  'collect':'sfx_item_pickup.ogg','discovery':'sfx_sonar.ogg','scan':'sfx_scanner_sweep.ogg',
  'hatch':'sfx_hatch_servo.ogg','enter':'sfx_hatch_servo.ogg','splash':'sfx_bubbles.ogg','dive':'sfx_fin_sweep.ogg',
  'impact':'sfx_hull_impact.ogg','creatureAttack':'sfx_creature_bite.ogg','faunaHit':'sfx_fauna_chirp.ogg','roar':'sfx_leviathan_call.ogg',
  'oreHit':'sfx_mineral_strike.ogg','oreBreak':'sfx_mineral_strike.ogg','caveDrip':'sfx_bubbles.ogg','caveRumble':'ambience_cave.ogg','caveScrape':'sfx_hull_impact.ogg',
  'oxygen':'sfx_oxygen_alarm.ogg','craft':'sfx_fabricator_cycle.ogg','fabricatorOpen':'sfx_fabricator_cycle.ogg','repair':'sfx_repair_tool.ogg',
  'build':'sfx_build_seal.ogg','knife':'sfx_knife_swipe.ogg','jump':'sfx_fin_sweep.ogg','flashlightOn':'sfx_switch_click.ogg','flashlightOff':'sfx_switch_click.ogg',
  'light':'sfx_switch_click.ogg','tap':'sfx_switch_click.ogg','panelOpen':'sfx_hatch_servo.ogg','panelClose':'sfx_hatch_servo.ogg',
  'locker':'sfx_hatch_servo.ogg','hologram':'sfx_sonar.ogg','launch':'sfx_engine_start.ogg','reentry':'sfx_hull_impact.ogg',
  'oxygenPlant':'sfx_bubbles.ogg','equip':'sfx_item_pickup.ogg','use':'sfx_switch_click.ogg','radio':'sfx_whale_song.ogg','eat':'sfx_eating_gulp.ogg'
 },
 'fauna': {'small':'sfx_fauna_chirp.ogg','large':'sfx_whale_song.ogg','leviathan':'sfx_leviathan_call.ogg','predator':'sfx_predator_growl.ogg','crustacean':'sfx_crustacean_click.ogg','jelly':'sfx_jelly_pulse.ogg','ray':'sfx_ray_sweep.ogg'}
}
import json
(ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print('Audio files generated.')
