#!/usr/bin/env python3
"""Generate seamless, original PBR texture sets for The Abyssal.
Requires Pillow and NumPy. All patterns are procedurally authored and tileable.
"""
from pathlib import Path
import math, json
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1] / 'assets' / 'pbr'
ROOT.mkdir(parents=True, exist_ok=True)
SIZE = 1024
NORMAL_SIZE = 1024

PALETTES = {
    'sand': (164, 143, 105),
    'basalt': (66, 83, 93),
    'coral': (164, 104, 130),
    'kelp': (34, 104, 75),
    'wreck_wood': (105, 73, 48),
    'oxidized_metal': (74, 113, 119),
    'fish_scales': (92, 137, 151),
    'biolum_tissue': (63, 105, 128),
}


def periodic_field(size, seed, octaves=5):
    rng = np.random.default_rng(seed)
    y, x = np.mgrid[0:size, 0:size].astype(np.float32)
    result = np.zeros((size, size), dtype=np.float32)
    total = 0.0
    # Integer-frequency harmonics are exactly periodic at the texture edges.
    for octave in range(octaves):
        amp = 1.0 / (2.0 ** octave)
        count = 2 + octave
        for _ in range(count):
            fx = int(rng.integers(1, 2 ** (octave + 1) + 2))
            fy = int(rng.integers(1, 2 ** (octave + 1) + 2))
            phase = float(rng.random() * math.tau)
            angle = float(rng.random() * math.tau)
            freq = 0.5 * (fx + fy)
            arg = (np.cos(angle) * x + np.sin(angle) * y) / size * math.tau * freq
            result += amp * np.sin(arg + phase)
            total += amp
    result /= max(total / 2.0, 1e-6)
    return result


def make_height(kind, seed, size):
    rng = np.random.default_rng(seed)
    y, x = np.mgrid[0:size, 0:size].astype(np.float32)
    broad = periodic_field(size, seed + 17, 3)
    medium = periodic_field(size, seed + 31, 3)
    fine = periodic_field(size, seed + 53, 3)
    h = 0.48 + 0.20 * broad + 0.10 * medium + 0.045 * fine
    if kind == 'sand':
        phase = 2 * np.pi * (y / size * 36 + 0.035 * np.sin(x / size * 12 * np.pi))
        h += 0.13 * np.sin(phase) + 0.035 * np.sin(phase * 2.0 + fine)
        # Ripples carry sparse shallow troughs and granular flecks.
        h -= 0.035 * np.maximum(0, np.sin(phase + 0.65)) ** 4
    elif kind == 'basalt':
        cracks = np.abs(np.sin((x * 0.011 + y * 0.007) + 1.8 * np.sin(y * 0.003)))
        h -= 0.16 * np.exp(-cracks * 65)
        h += 0.08 * np.maximum(0, medium - 0.15)
    elif kind == 'coral':
        # Repeated pores and raised ridges, characteristic of a porous reef skeleton.
        px = (x / size * 17 + 0.18 * np.sin(y / size * 2 * np.pi)) % 1.0
        py = (y / size * 15 + 0.14 * np.sin(x / size * 2 * np.pi)) % 1.0
        d = np.sqrt(((px - .5) * 1.0) ** 2 + ((py - .5) * 1.1) ** 2)
        pores = np.exp(-((d / .16) ** 2))
        h += 0.15 * np.sin(d * 38) - 0.18 * pores
    elif kind == 'kelp':
        fibers = np.sin(x / size * 2 * np.pi * 165 + 0.8 * np.sin(y / size * 2 * np.pi * 4))
        h += 0.10 * fibers + 0.025 * np.sin(x / size * 2 * np.pi * 410 + fine)
        h += 0.06 * np.sin(y / size * 2 * np.pi * 8 + medium)
    elif kind == 'wreck_wood':
        grain = np.sin(y / size * 2 * np.pi * 64 + 1.2 * np.sin(x / size * 2 * np.pi * 7))
        knots = np.sin(np.sqrt(((x % (size / 4) - size / 8) / size * 11) ** 2 + ((y % (size / 3) - size / 6) / size * 22) ** 2) * 21)
        h += 0.12 * grain + 0.035 * knots
    elif kind == 'oxidized_metal':
        scratches = np.exp(-((np.sin((x * .0015 + y * .00018) * 2 * np.pi) * 42) ** 2))
        pits = np.maximum(0, periodic_field(size, seed + 101, 3) - .28)
        h += .06 * scratches - .13 * pits
    elif kind == 'fish_scales':
        rows = 30
        cols = 34
        sx = (x / size * cols + 0.5 * np.floor(y / size * rows)) % 1.0
        sy = (y / size * rows) % 1.0
        # Curved overlapping scale lip, seamless in both directions.
        d = np.sqrt(((sx - .5) * .95) ** 2 + ((sy - .40) * .72) ** 2)
        h += 0.11 * np.exp(-((d - .34) / .055) ** 2) - .035 * np.exp(-(d / .21) ** 2)
    elif kind == 'biolum_tissue':
        ridges = np.sin(x / size * 2 * np.pi * 28 + 1.7 * np.sin(y / size * 2 * np.pi * 5))
        spots = np.maximum(0, periodic_field(size, seed + 201, 4) - .32)
        h += .10 * ridges + .09 * spots
    return np.clip(h, 0, 1)


def make_albedo(kind, seed, size, height):
    rng = np.random.default_rng(seed + 1009)
    base = np.array(PALETTES[kind], dtype=np.float32)
    broad = periodic_field(size, seed + 200, 3)
    medium = periodic_field(size, seed + 400, 3)
    fine = periodic_field(size, seed + 600, 3)
    luminance = (height - .5) * 74 + broad * 11 + medium * 7 + fine * 4
    rgb = np.stack([base[i] + luminance * (1.0 if i == 0 else 0.92 if i == 1 else .86) for i in range(3)], axis=-1)
    # Material-specific pigment makes the patterns legible at close range.
    if kind == 'sand':
        ripple = np.sin(np.mgrid[0:size,0:size][0] / size * 2*np.pi*36)
        rgb += ripple[...,None] * np.array([8,7,4], dtype=np.float32)
        grain = rng.normal(0, 3.2, (size,size,1))
        rgb += grain
    elif kind == 'basalt':
        vein = np.exp(-np.abs(np.sin(np.mgrid[0:size,0:size][0]/size*2*np.pi*9 + broad*1.6))*42)
        rgb += vein[...,None] * np.array([20,25,27], dtype=np.float32)
        rgb += np.maximum(0, medium[...,None]-.55)*22
    elif kind == 'coral':
        y,x=np.mgrid[0:size,0:size]
        pore=((x/size*17)%1-.5)**2+((y/size*15)%1-.5)**2
        hole=np.exp(-pore/.005)
        rgb -= hole[...,None] * np.array([40,35,33], dtype=np.float32)
        rgb += np.maximum(0, fine[...,None]) * np.array([8,13,17], dtype=np.float32)
    elif kind == 'kelp':
        x=np.mgrid[0:size,0:size][1]
        fiber=np.sin(x/size*2*np.pi*165)
        rgb += fiber[...,None]*np.array([5,17,8], dtype=np.float32)
        rgb += np.maximum(0,broad[...,None]) * np.array([5,14,4], dtype=np.float32)
    elif kind == 'wreck_wood':
        y=np.mgrid[0:size,0:size][0]
        grain=np.sin(y/size*2*np.pi*64 + medium*2)
        rgb += grain[...,None]*np.array([16,10,5], dtype=np.float32)
        knots=np.maximum(0, np.cos(np.sqrt((fine*3)**2 + (broad*2)**2)*14))
        rgb -= knots[...,None]*np.array([9,6,3],dtype=np.float32)
    elif kind == 'oxidized_metal':
        rust=np.maximum(0, medium-.18)
        rgb += rust[...,None]*np.array([34,8,-6],dtype=np.float32)
        scratch=np.exp(-np.abs(np.sin(np.mgrid[0:size,0:size][0]/size*2*np.pi*96 + fine))*50)
        rgb += scratch[...,None]*np.array([18,22,21],dtype=np.float32)
    elif kind == 'fish_scales':
        y,x=np.mgrid[0:size,0:size]
        rows,cols=30,34
        sx=(x/size*cols+.5*np.floor(y/size*rows))%1
        sy=(y/size*rows)%1
        d=np.sqrt(((sx-.5)*.95)**2+((sy-.4)*.72)**2)
        rim=np.exp(-((d-.34)/.045)**2)
        rgb += rim[...,None]*np.array([18,27,31],dtype=np.float32)
        rgb -= np.exp(-(d/.20)**2)[...,None]*np.array([13,14,12],dtype=np.float32)
    elif kind == 'biolum_tissue':
        glow=np.maximum(0, np.sin(np.mgrid[0:size,0:size][1]/size*2*np.pi*28+broad*3))
        rgb += glow[...,None]*np.array([5,31,43],dtype=np.float32)
        speck=(fine>.68).astype(np.float32)
        rgb += speck[...,None]*np.array([28,62,76],dtype=np.float32)
    return np.uint8(np.clip(rgb,0,255))


def normal_from_height(height, out_size, strength=5.0):
    im = Image.fromarray(np.uint8(np.clip(height*255,0,255)), 'L').resize((out_size,out_size), Image.Resampling.LANCZOS)
    h = np.asarray(im, dtype=np.float32)/255.0
    dx = (np.roll(h,-1,axis=1)-np.roll(h,1,axis=1))*strength
    dy = (np.roll(h,-1,axis=0)-np.roll(h,1,axis=0))*strength
    nx, ny, nz = -dx, -dy, np.ones_like(h)
    norm = np.sqrt(nx*nx+ny*ny+nz*nz)
    rgb = np.stack([(nx/norm+1)*127.5,(ny/norm+1)*127.5,(nz/norm+1)*127.5],axis=-1)
    return np.uint8(np.clip(rgb,0,255))


def make_roughness(kind, height, size):
    field = periodic_field(size, 987 + len(kind)*37, 3)
    if height.shape[0] != size:
        height = np.asarray(Image.fromarray(np.uint8(np.clip(height*255,0,255)), 'L').resize((size,size), Image.Resampling.LANCZOS), dtype=np.float32)/255.0
    base = {
        'sand': .89, 'basalt': .93, 'coral': .86, 'kelp': .72,
        'wreck_wood': .91, 'oxidized_metal': .68, 'fish_scales': .38, 'biolum_tissue': .47
    }[kind]
    v = base + .13*field - .16*(height-.5)
    if kind in ('fish_scales','biolum_tissue'):
        v += .07*np.maximum(0, .55-height)
    return np.uint8(np.clip(v*255,25,250))


manifest = {
    'version': 1,
    'description': 'Original seamless high-detail material set for The Abyssal; WebP basecolor/roughness/normal textures.',
    'materials': {}
}
for index, kind in enumerate(PALETTES):
    print('Generating', kind, flush=True)
    height = make_height(kind, 700 + index*101, SIZE)
    albedo = make_albedo(kind, 1700 + index*137, SIZE, height)
    normal = normal_from_height(height, NORMAL_SIZE, strength=8.0 if kind in ('coral','fish_scales') else 5.2)
    rough = make_roughness(kind, height, NORMAL_SIZE)
    base_img = Image.fromarray(albedo, 'RGB').resize((2048,2048), Image.Resampling.LANCZOS)
    # Add deterministic micro-grain after enlargement so the 2K output is not a simple resized placeholder.
    base_arr = np.asarray(base_img, dtype=np.int16).copy()
    yy, xx = np.mgrid[0:2048, 0:2048]
    micro = (np.sin(xx * .173 + np.sin(yy * .039) * 2.1) * 1.8 + np.cos(yy * .197 + xx * .017) * 1.2).astype(np.int16)
    base_arr = np.clip(base_arr + micro[...,None], 0, 255).astype(np.uint8)
    Image.fromarray(base_arr, 'RGB').save(ROOT/f'{kind}_base.webp', 'WEBP', quality=92, method=6)
    Image.fromarray(normal, 'RGB').save(ROOT/f'{kind}_normal.webp', 'WEBP', lossless=True, method=6)
    Image.fromarray(rough, 'L').save(ROOT/f'{kind}_rough.webp', 'WEBP', quality=95, method=6)
    manifest['materials'][kind] = {
        'baseColor': f'{kind}_base.webp', 'normal': f'{kind}_normal.webp', 'roughness': f'{kind}_rough.webp',
        'baseResolution': 2048, 'detailResolution': NORMAL_SIZE, 'seamless': True,
        'colorSpace': {'baseColor': 'sRGB', 'normal': 'linear', 'roughness': 'linear'}
    }
(ROOT/'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
print('Wrote', len(manifest['materials']), 'materials to', ROOT)
