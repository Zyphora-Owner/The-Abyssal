/**
 * Stable procedural world primitives.
 * Existing spawn-region terrain remains byte-for-byte deterministic; the
 * trench is an authored remote region so old bases and save coordinates stay put.
 */
export const WORLD_SEED = 0x0ab155a1;
export const MAX_DIVE_DEPTH = 1500;
export const ABYSSAL_TRENCH = Object.freeze({ x: 760, z: -620, innerRadius: 145, outerRadius: 820, depth: 1460 });

/** Authored depth layers within the remote trench; legacy biome IDs stay stable. */
export const TRENCH_BIOME_BANDS = Object.freeze([
  Object.freeze({ id: 'deep', min: 62, max: 180 }),
  Object.freeze({ id: 'abyss', min: 180, max: 500 }),
  Object.freeze({ id: 'abyssal_shelf', min: 500, max: 720 }),
  Object.freeze({ id: 'midnight_grotto', min: 720, max: 940 }),
  Object.freeze({ id: 'blue_void', min: 940, max: 1160 }),
  Object.freeze({ id: 'hadal_rift', min: 1160, max: 1360 }),
  Object.freeze({ id: 'hadal_garden', min: 1360, max: 1500 })
]);

export function getTrenchBiomeId(depth = 0) {
  const safeDepth = Math.max(0, Number.isFinite(Number(depth)) ? Number(depth) : 0);
  for (const band of TRENCH_BIOME_BANDS) {
    if (safeDepth >= band.min && safeDepth < band.max) return band.id;
  }
  return safeDepth >= 1500 ? 'hadal_garden' : 'open';
}

/** Deterministic pseudo-random value in [0, 1). */
export function hash2(x, z, seed = WORLD_SEED) {
  const value = Math.sin(x * 127.1 + z * 311.7 + seed) * 43758.5453123;
  return value - Math.floor(value);
}

/** Smooth, deterministic value noise in approximately [-1, 1]. */
export function valueNoise(x, z, seed = WORLD_SEED) {
  const ix = Math.floor(x);
  const iz = Math.floor(z);
  const fx = x - ix;
  const fz = z - iz;
  const sx = fx * fx * (3 - 2 * fx);
  const sz = fz * fz * (3 - 2 * fz);
  const mix = (a, b, t) => a + (b - a) * t;
  const a = hash2(ix, iz, seed);
  const b = hash2(ix + 1, iz, seed);
  const c = hash2(ix, iz + 1, seed);
  const d = hash2(ix + 1, iz + 1, seed);
  return mix(mix(a, b, sx), mix(c, d, sx), sz) * 2 - 1;
}

const smooth01 = value => {
  const t = Math.max(0, Math.min(1, value));
  return t * t * (3 - 2 * t);
};

/** 1 in the trench basin, smoothly fading to 0 outside its remote rim. */
export function trenchInfluenceAt(x, z) {
  const distance = Math.hypot(Number(x) - ABYSSAL_TRENCH.x, Number(z) - ABYSSAL_TRENCH.z);
  const t = (distance - ABYSSAL_TRENCH.innerRadius) / (ABYSSAL_TRENCH.outerRadius - ABYSSAL_TRENCH.innerRadius);
  return 1 - smooth01(t);
}

/**
 * Seafloor function shared by terrain streaming and fauna grounding.
 * The existing world keeps its former floor profile; only the remote trench
 * gets a deeper basin and deterministic ridges.
 */
export function seaFloorDepth(x, z) {
  const oldFloor = -43 + valueNoise(x * 0.017, z * 0.017) * 6.5 + valueNoise(x * 0.061, z * 0.061) * 1.8;
  const influence = trenchInfluenceAt(x, z);
  const basinRidge = valueNoise(x * 0.009, z * 0.009, WORLD_SEED + 913) * 13
    + valueNoise(x * 0.027, z * 0.027, WORLD_SEED + 173) * 4
    + valueNoise(x * 0.0045, z * 0.0045, WORLD_SEED + 2111) * 17;
  // Broad, deterministic terraces form shelves and ledges on the descent;
  // higher-frequency ridges keep the floor from becoming a flat circular pit.
  const trenchTerrace = influence > 0.12
    ? Math.sin(Math.hypot(x - ABYSSAL_TRENCH.x, z - ABYSSAL_TRENCH.z) * 0.018) * 10 * influence
    : 0;
  // Secondary ridge and sediment scales add readable terrain variation without
  // moving the authored spawn island or changing the deterministic world seed.
  const fineRidges = valueNoise(x * 0.038, z * 0.038, WORLD_SEED + 421) * 1.35
    + valueNoise(x * 0.115, z * 0.115, WORLD_SEED + 719) * 0.42;
  const shelfCuts = (1 - Math.abs(valueNoise(x * 0.021, z * 0.021, WORLD_SEED + 887))) * 0.72;
  const generatedFloor = oldFloor + fineRidges + shelfCuts + trenchTerrace - influence * (ABYSSAL_TRENCH.depth + basinRidge);
  // Keep a narrow clearance above the 1,500 m world limit for the diver and vehicles.
  return Math.max(-MAX_DIVE_DEPTH + 4, generatedFloor);
}
